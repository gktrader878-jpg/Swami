# SWAMI for Google AI Studio Build

This upload uses the same root layout as the working example: `package.json`, `index.html`, `vite.config.ts`, and `src/` are at the ZIP root. There is intentionally no npm lockfile so AI Studio can resolve the package versions in its environment.

The React/Vite frontend can start in AI Studio. `backend-reference/` contains SWAMI's Python backend for reference; it is not run by the AI Studio preview. API-backed features (chat persistence, local models, provider settings, documents, etc.) require adapting the backend/API and are not functional in the browser-only preview. The Vite `/api` proxy is retained for local development only.

To import: Google AI Studio → Build → **+** → **Upload ZIP file**. Use a fresh Build app, then ask it to verify dependency installation and start the frontend. Do not upload API keys or private documents.
