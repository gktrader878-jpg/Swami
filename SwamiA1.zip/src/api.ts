import type {
  ApiProtocol, CompareModelResult, CompareStreamEvent, Conversation, DocumentInfo, DownloadState, EngineStatus,
  LocalAiWindowsGuide, Memory, MemoryCategory, Message, Mode, ModelGenerationParams, ModelInfo, Project,
  ProviderConfig, ProviderPreset, ProviderUsageStat, RoutableModelOption, RoutingState, Settings, Status, StreamEvent,
  VoiceCapabilities, VoiceSttProvider, VoiceTtsProvider,
} from "./types";

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  let resp: Response;
  try {
    resp = await fetch(path, init);
  } catch {
    throw new ApiError("Cannot reach the SWAMI service. Is the app still running?", 0);
  }

  const contentType = resp.headers.get("content-type") || "";
  if (!contentType.includes("application/json")) {
    const text = await resp.text();
    if (text.trim().startsWith("<") || resp.status === 404 || resp.status >= 500) {
      throw new ApiError(`Service returned an unexpected response (${resp.status}). Please check API configuration or network.`, resp.status);
    }
  }

  if (!resp.ok) {
    let detail = `Request failed (${resp.status})`;
    try {
      const body = await resp.json();
      if (typeof body.detail === "string") detail = body.detail;
    } catch {
      /* keep the generic message */
    }
    throw new ApiError(detail, resp.status);
  }

  try {
    return (await resp.json()) as Promise<T>;
  } catch {
    throw new ApiError("Invalid JSON response received from server.", resp.status || 500);
  }
}

const json = (method: string, body?: unknown): RequestInit => ({
  method,
  headers: { "Content-Type": "application/json" },
  body: body === undefined ? undefined : JSON.stringify(body),
});

export const api = {
  status: () => request<Status>("/api/status"),
  connectivity: () => request<{ online: boolean; reason: string }>("/api/connectivity"),

  settings: () => request<Settings>("/api/settings"),
  saveSettings: (patch: Partial<Settings>) => request<Settings>("/api/settings", json("PATCH", patch)),
  resetSettings: () => request<Settings>("/api/settings/reset", json("POST")),

  models: () => request<{ models: ModelInfo[] }>("/api/models"),
  downloadModel: (id: string) => request<DownloadState>(`/api/models/${id}/download`, json("POST")),
  cancelDownload: (id: string) => request<{ ok: boolean }>(`/api/models/${id}/cancel`, json("POST")),
  deleteModel: (id: string) => request<{ ok: boolean }>(`/api/models/${id}`, json("DELETE")),
  loadEngine: (model_id = "") => request<EngineStatus>("/api/engine/load", json("POST", { model_id })),
  unloadEngine: () => request<EngineStatus>("/api/engine/unload", json("POST")),
  providerPresets: () => request<{ presets: ProviderPreset[] }>("/api/providers/presets"),
  configureProvider: (body: {
    base_url: string;
    model: string;
    api_key: string;
    provider_id?: string;
    protocol?: ApiProtocol;
    auto_select?: boolean;
  }) => request<Settings>("/api/providers/configure", json("POST", body)),
  fetchProviderModels: (body: { base_url?: string; api_key?: string; protocol?: ApiProtocol }) =>
    request<{ models: string[] }>("/api/providers/models", json("POST", body)),
  testProvider: (body?: { base_url?: string; model?: string; api_key?: string; protocol?: ApiProtocol }) =>
    request<{ ok: boolean; message: string; models?: string[] }>("/api/providers/test", json("POST", body ?? {})),
  deleteProviderKey: () => request<Settings>("/api/providers/key", json("DELETE")),

  conversations: (search = "") =>
    request<{ conversations: Conversation[]; projects: Project[] }>(
      `/api/conversations${search ? `?search=${encodeURIComponent(search)}` : ""}`,
    ),
  conversation: (id: string) =>
    request<{ conversation: Conversation; messages: Message[]; documents: DocumentInfo[] }>(`/api/conversations/${id}`),
  patchConversation: (id: string, body: { title?: string; project_id?: string; clear_project?: boolean }) =>
    request<{ conversation: Conversation }>(`/api/conversations/${id}`, json("PATCH", body)),
  deleteConversation: (id: string) => request<{ ok: boolean }>(`/api/conversations/${id}`, json("DELETE")),
  deleteAllConversations: () => request<{ ok: boolean }>("/api/data/conversations", json("DELETE")),

  createProject: (name: string) => request<Project>("/api/projects", json("POST", { name })),
  renameProject: (id: string, name: string) => request<{ ok: boolean }>(`/api/projects/${id}`, json("PATCH", { name })),
  deleteProject: (id: string) => request<{ ok: boolean }>(`/api/projects/${id}`, json("DELETE")),

  memories: (params?: { q?: string; category?: string; project_id?: string }) => {
    const qs = new URLSearchParams();
    if (params?.q) qs.set("q", params.q);
    if (params?.category && params.category !== "all") qs.set("category", params.category);
    if (params?.project_id && params.project_id !== "all") qs.set("project_id", params.project_id);
    const suffix = qs.toString() ? `?${qs.toString()}` : "";
    return request<{ memories: Memory[]; enabled: boolean; auto_suggest: boolean }>(`/api/memory${suffix}`);
  },
  addMemory: (
    content: string,
    options?: { category?: MemoryCategory; project_id?: string | null; replace_conflict_id?: string | null },
  ) =>
    request<Memory & { conflict?: { id: string; content: string } | null }>(
      "/api/memory",
      json("POST", { content, ...options }),
    ),
  updateMemory: (
    id: string,
    body: {
      content?: string;
      enabled?: boolean;
      category?: MemoryCategory;
      project_id?: string | null;
      clear_conflict?: boolean;
    },
  ) => request<{ ok: boolean; memory?: Memory }>(`/api/memory/${id}`, json("PATCH", body)),
  deleteMemory: (id: string) => request<{ ok: boolean }>(`/api/memory/${id}`, json("DELETE")),
  clearMemories: () => request<{ ok: boolean }>("/api/memory", json("DELETE")),
  importMemories: (memories: unknown[]) =>
    request<{ imported: number; skipped: number; memories: Memory[] }>("/api/memory/import", json("POST", { memories })),

  uploadDocument: (file: File, conversationId: string | null) => {
    const form = new FormData();
    form.append("file", file);
    form.append("conversation_id", conversationId ?? "");
    return request<DocumentInfo>("/api/documents", { method: "POST", body: form });
  },
  deleteDocument: (id: string) => request<{ ok: boolean }>(`/api/documents/${id}`, json("DELETE")),

  stopRun: (runId: string) => request<{ stopped: boolean }>(`/api/chat/${runId}/stop`, json("POST")),

  // ---- Multi-Provider & Model Management v1 ----
  v1Providers: () =>
    request<{
      providers: ProviderConfig[];
      presets: ProviderPreset[];
      usage_stats: ProviderUsageStat[];
      routing: RoutingState;
      windows_local_guide: LocalAiWindowsGuide;
    }>("/api/v1/providers"),
  v1SaveProvider: (body: {
    id?: string;
    preset_id?: string;
    name?: string;
    protocol?: ApiProtocol;
    base_url?: string;
    enabled?: boolean;
    default_model?: string;
    api_key?: string;
    clear_key?: boolean;
  }) => request<{ provider: ProviderConfig }>("/api/v1/providers", json("POST", body)),
  v1UpdateProvider: (
    id: string,
    body: {
      name?: string;
      protocol?: ApiProtocol;
      base_url?: string;
      enabled?: boolean;
      default_model?: string;
      api_key?: string;
      clear_key?: boolean;
    },
  ) => request<{ provider: ProviderConfig }>(`/api/v1/providers/${encodeURIComponent(id)}`, json("PATCH", body)),
  v1DeleteProvider: (id: string) =>
    request<{ ok: boolean; providers: ProviderConfig[] }>(`/api/v1/providers/${encodeURIComponent(id)}`, json("DELETE")),
  v1TestProvider: (id: string, body?: { base_url?: string; api_key?: string; model?: string; protocol?: ApiProtocol }) =>
    request<{ ok: boolean; status: string; latencyMs: number; message: string; provider: ProviderConfig }>(
      `/api/v1/providers/${encodeURIComponent(id)}/test`,
      json("POST", body ?? {}),
    ),
  v1DiscoverProviderModels: (id: string, body?: { base_url?: string; api_key?: string; protocol?: ApiProtocol }) =>
    request<{ ok: boolean; reachable: boolean; latencyMs: number; message: string; provider: ProviderConfig }>(
      `/api/v1/providers/${encodeURIComponent(id)}/discover`,
      json("POST", body ?? {}),
    ),
  v1AddProviderModel: (id: string, body: { model_id: string; name?: string; params?: ModelGenerationParams }) =>
    request<{ provider: ProviderConfig }>(`/api/v1/providers/${encodeURIComponent(id)}/models`, json("POST", body)),
  v1UpdateProviderModel: (
    id: string,
    body: { model_id: string; enabled?: boolean; name?: string; params?: ModelGenerationParams },
  ) => request<{ provider: ProviderConfig }>(`/api/v1/providers/${encodeURIComponent(id)}/models/update`, json("POST", body)),
  v1DeleteProviderModel: (id: string, model_id: string) =>
    request<{ provider: ProviderConfig }>(
      `/api/v1/providers/${encodeURIComponent(id)}/models/delete`,
      json("POST", { model_id }),
    ),
  v1RouterOptions: () =>
    request<{ models: RoutableModelOption[]; offline_mode: boolean; routing: RoutingState }>("/api/v1/models/router-options"),
  v1UpdateRouting: (patch: Partial<RoutingState>) =>
    request<{ settings: Settings; status: Status }>("/api/v1/models/routing", json("POST", patch)),
  v1AdoptComparison: (body: {
    conversation_id?: string | null;
    project_id?: string | null;
    prompt: string;
    result: CompareModelResult;
  }) => request<{ conversation: Conversation; user_message: Message; assistant_message: Message }>(
    "/api/v1/models/compare/adopt",
    json("POST", body),
  ),
  v1LocalStatus: () =>
    request<{
      ollama: { provider: ProviderConfig; reachable: boolean; latencyMs: number | null; message: string } | null;
      lmstudio: { provider: ProviderConfig; reachable: boolean; latencyMs: number | null; message: string } | null;
      windows_local_guide: LocalAiWindowsGuide;
    }>("/api/v1/local/status"),

  // ---- Real-Time Voice AI ----
  v1VoiceCapabilities: () => request<VoiceCapabilities>("/api/v1/voice/capabilities"),
  v1CreateVoiceSession: (body?: {
    mode?: "gemini_live" | "gemini_transcribe_live" | "router_pipeline";
    conversation_id?: string | null;
    project_id?: string | null;
    language?: string;
    voice_name?: string;
  }) =>
    request<{
      session_id: string;
      mode: "gemini_live" | "gemini_transcribe_live" | "router_pipeline";
      language: string;
      voice_name: string;
      expires_at: number;
      ws_url: string;
      capabilities: VoiceCapabilities;
    }>("/api/v1/voice/session", json("POST", body ?? {})),
  v1EndVoiceSession: (id: string) =>
    request<{ ok: boolean; removed: boolean }>(`/api/v1/voice/session/${encodeURIComponent(id)}`, json("DELETE")),
  v1TranscribeAudio: (params: {
    blob: Blob;
    language?: string;
    provider?: VoiceSttProvider;
    signal?: AbortSignal;
  }) => {
    const form = new FormData();
    form.append("audio", params.blob, "speech.webm");
    if (params.language) form.append("language", params.language);
    if (params.provider) form.append("provider", params.provider);
    return request<{
      transcript: string;
      provider_used: "gemini" | "openai" | "groq";
      language: string;
      latency_ms: number;
      fallback_used: boolean;
      warning?: string;
    }>("/api/v1/voice/transcribe", { method: "POST", body: form, signal: params.signal });
  },
  v1VoiceTts: (body: {
    text: string;
    voice_name?: string;
    speed?: number;
    language?: string;
    provider?: VoiceTtsProvider;
    high_quality?: boolean;
  }, signal?: AbortSignal) =>
    request<{
      audio_base64: string;
      mime_type: string;
      provider_used: "gemini" | "openai";
      voice_name: string;
      latency_ms: number;
      fallback_used: boolean;
      warning?: string;
    }>("/api/v1/voice/tts", { ...json("POST", body), signal }),
  v1VoiceTurn: (body: {
    transcript: string;
    conversation_id?: string | null;
    project_id?: string | null;
    language?: string;
    mode?: Mode;
    model_id?: string;
    stt_provider?: string;
    tts_provider?: string;
    voice_backend?: string;
  }, signal?: AbortSignal) =>
    request<{
      conversation: Conversation;
      user_message: Message;
      assistant_message: Message;
      spoken_text: string;
      intent: string;
      notice?: string;
    }>("/api/v1/voice/turn", { ...json("POST", body), signal }),
};

export interface ChatBody {
  conversation_id: string | null;
  content: string;
  mode: Mode;
  model_id: string;
  document_ids: string[];
  regenerate: boolean;
  project_id: string | null;
}

/** POST /api/chat and deliver each server-sent event as it arrives. */
export async function streamChat(body: ChatBody, onEvent: (e: StreamEvent) => void, signal: AbortSignal): Promise<void> {
  const resp = await fetch("/api/chat", { ...json("POST", body), signal });
  if (!resp.ok || !resp.body) {
    let detail = `Request failed (${resp.status})`;
    try {
      const data = await resp.json();
      if (typeof data.detail === "string") detail = data.detail;
    } catch {
      /* ignore */
    }
    throw new ApiError(detail, resp.status);
  }
  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    let cut: number;
    while ((cut = buffer.indexOf("\n\n")) >= 0) {
      const block = buffer.slice(0, cut);
      buffer = buffer.slice(cut + 2);
      for (const line of block.split("\n")) {
        if (line.startsWith("data: ")) {
          try {
            onEvent(JSON.parse(line.slice(6)) as StreamEvent);
          } catch {
            /* ignore a malformed frame */
          }
        }
      }
    }
  }
}

/** POST /api/v1/models/compare and stream side-by-side comparison updates. */
export async function streamCompare(
  body: { targets: string[]; prompt: string; system_prompt?: string; mode?: Mode },
  onEvent: (e: CompareStreamEvent) => void,
  signal: AbortSignal,
): Promise<void> {
  const resp = await fetch("/api/v1/models/compare", { ...json("POST", body), signal });
  if (!resp.ok || !resp.body) {
    let detail = `Comparison failed (${resp.status})`;
    try {
      const data = await resp.json();
      if (typeof data.detail === "string") detail = data.detail;
    } catch {
      /* ignore */
    }
    throw new ApiError(detail, resp.status);
  }
  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    let cut: number;
    while ((cut = buffer.indexOf("\n\n")) >= 0) {
      const block = buffer.slice(0, cut);
      buffer = buffer.slice(cut + 2);
      for (const line of block.split("\n")) {
        if (line.startsWith("data: ")) {
          try {
            onEvent(JSON.parse(line.slice(6)) as CompareStreamEvent);
          } catch {
            /* ignore malformed frame */
          }
        }
      }
    }
  }
}

