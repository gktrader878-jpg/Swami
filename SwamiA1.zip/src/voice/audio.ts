/**
 * Browser Web Audio helpers:
 * - Manual Float32 -> Int16 PCM encoding + downsampling to 16kHz for Gemini Live API
 * - Manual Int16 PCM 24kHz decoding + gapless AudioContext queue playback
 * - WAV base64 audio playback with speed/volume controls
 * - Real-time RMS microphone level extraction via AnalyserNode
 */

export function base64ToUint8Array(base64: string): Uint8Array {
  const bin = atob(base64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) {
    bytes[i] = bin.charCodeAt(i);
  }
  return bytes;
}

export function arrayBufferToBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

/** Downsample Float32 mono audio to 16kHz 16-bit signed LE PCM. */
export function float32ToPcm16kBase64(input: Float32Array, inputSampleRate: number): string {
  const targetRate = 16000;
  let samples: Float32Array;
  if (Math.abs(inputSampleRate - targetRate) < 50) {
    samples = input;
  } else {
    const ratio = inputSampleRate / targetRate;
    const outLen = Math.max(1, Math.floor(input.length / ratio));
    samples = new Float32Array(outLen);
    for (let i = 0; i < outLen; i++) {
      const start = Math.floor(i * ratio);
      const end = Math.min(input.length, Math.floor((i + 1) * ratio));
      let sum = 0;
      let count = 0;
      for (let j = start; j < end; j++) {
        sum += input[j];
        count += 1;
      }
      samples[i] = count > 0 ? sum / count : input[start] ?? 0;
    }
  }
  const pcm = new Int16Array(samples.length);
  for (let i = 0; i < samples.length; i++) {
    const clamped = Math.max(-1, Math.min(1, samples[i]));
    pcm[i] = clamped < 0 ? Math.round(clamped * 32768) : Math.round(clamped * 32767);
  }
  return arrayBufferToBase64(pcm.buffer);
}

export function decodePcm16ToAudioBuffer(
  ctx: AudioContext,
  pcmBytes: Uint8Array,
  sampleRate = 24000,
): AudioBuffer {
  const frameCount = Math.floor(pcmBytes.byteLength / 2);
  const view = new DataView(pcmBytes.buffer, pcmBytes.byteOffset, frameCount * 2);
  const buffer = ctx.createBuffer(1, frameCount, sampleRate);
  const channel = buffer.getChannelData(0);
  for (let i = 0; i < frameCount; i++) {
    channel[i] = view.getInt16(i * 2, true) / 32768;
  }
  return buffer;
}

export function computeTimeDomainRms(analyser: AnalyserNode, scratch: Float32Array<ArrayBuffer>): number {
  analyser.getFloatTimeDomainData(scratch);
  let sum = 0;
  for (let i = 0; i < scratch.length; i++) {
    sum += scratch[i] * scratch[i];
  }
  return Math.sqrt(sum / Math.max(1, scratch.length));
}

export function vadThresholdFromSensitivity(sensitivity = 0.55): number {
  const clamped = Math.min(1, Math.max(0.1, Number(sensitivity) || 0.55));
  return 0.048 - clamped * 0.036;
}

/**
 * Gapless AudioContext playback queue for 24kHz PCM chunks (Gemini Live) and WAV replies (Gemini/OpenAI TTS).
 */
export class VoiceAudioPlayer {
  private ctx: AudioContext | null = null;
  private gainNode: GainNode | null = null;
  private nextStartTime = 0;
  private activeSources = new Set<AudioBufferSourceNode>();
  private htmlAudio: HTMLAudioElement | null = null;
  private htmlAudioUrl: string | null = null;
  private onDrainCallbacks: Array<() => void> = [];
  private volume = 0.95;

  setVolume(vol: number) {
    this.volume = Math.min(1, Math.max(0, vol));
    if (this.gainNode) {
      this.gainNode.gain.value = this.volume;
    }
    if (this.htmlAudio) {
      this.htmlAudio.volume = this.volume;
    }
  }

  private ensureContext(sampleRate = 24000): AudioContext {
    if (!this.ctx || this.ctx.state === "closed") {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx({ sampleRate });
      this.gainNode = this.ctx.createGain();
      this.gainNode.gain.value = this.volume;
      this.gainNode.connect(this.ctx.destination);
      this.nextStartTime = 0;
    }
    if (this.ctx.state === "suspended") {
      void this.ctx.resume();
    }
    return this.ctx;
  }

  isPlaying(): boolean {
    return this.activeSources.size > 0 || Boolean(this.htmlAudio && !this.htmlAudio.paused);
  }

  enqueuePcm24kBase64(base64Pcm: string, onAllFinished?: () => void) {
    const ctx = this.ensureContext(24000);
    if (!this.gainNode) return;
    const bytes = base64ToUint8Array(base64Pcm);
    if (bytes.byteLength < 2) return;
    const buffer = decodePcm16ToAudioBuffer(ctx, bytes, 24000);
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(this.gainNode);

    const startAt = Math.max(ctx.currentTime + 0.015, this.nextStartTime);
    this.nextStartTime = startAt + buffer.duration;
    this.activeSources.add(source);
    if (onAllFinished) this.onDrainCallbacks.push(onAllFinished);

    source.onended = () => {
      this.activeSources.delete(source);
      if (this.activeSources.size === 0) {
        this.nextStartTime = 0;
        const cbs = this.onDrainCallbacks.splice(0);
        for (const cb of cbs) cb();
      }
    };
    source.start(startAt);
  }

  async playEncodedAudioBase64(
    base64: string,
    mimeType: string,
    speed = 1.0,
    signal?: AbortSignal,
  ): Promise<void> {
    this.stop();
    const bytes = base64ToUint8Array(base64);
    const blob = new Blob([new Uint8Array(bytes)], { type: mimeType || "audio/wav" });
    const url = URL.createObjectURL(blob);
    this.htmlAudioUrl = url;

    return new Promise<void>((resolve, reject) => {
      const audio = new Audio(url);
      this.htmlAudio = audio;
      audio.volume = this.volume;
      audio.playbackRate = Math.min(2.0, Math.max(0.6, speed));

      const cleanup = () => {
        if (this.htmlAudio === audio) {
          this.htmlAudio = null;
        }
        if (this.htmlAudioUrl === url) {
          URL.revokeObjectURL(url);
          this.htmlAudioUrl = null;
        }
        signal?.removeEventListener("abort", onAbort);
      };

      const onAbort = () => {
        try {
          audio.pause();
        } catch {
          /* ignore */
        }
        cleanup();
        resolve();
      };

      signal?.addEventListener("abort", onAbort, { once: true });
      audio.onended = () => {
        cleanup();
        resolve();
      };
      audio.onerror = () => {
        cleanup();
        reject(new Error("Audio playback failed."));
      };
      void audio.play().catch((err) => {
        cleanup();
        reject(err instanceof Error ? err : new Error("Browser blocked audio playback."));
      });
    });
  }

  stop() {
    for (const src of this.activeSources) {
      try {
        src.onended = null;
        src.stop();
        src.disconnect();
      } catch {
        /* already stopped */
      }
    }
    this.activeSources.clear();
    this.nextStartTime = 0;
    this.onDrainCallbacks = [];

    if (this.htmlAudio) {
      try {
        this.htmlAudio.pause();
        this.htmlAudio.src = "";
      } catch {
        /* ignore */
      }
      this.htmlAudio = null;
    }
    if (this.htmlAudioUrl) {
      URL.revokeObjectURL(this.htmlAudioUrl);
      this.htmlAudioUrl = null;
    }
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      try {
        window.speechSynthesis.cancel();
      } catch {
        /* ignore */
      }
    }
  }

  dispose() {
    this.stop();
    if (this.ctx && this.ctx.state !== "closed") {
      void this.ctx.close().catch(() => {});
    }
    this.ctx = null;
    this.gainNode = null;
  }
}

/** Browser-native SpeechSynthesis fallback when cloud TTS is unavailable or disabled. */
export function speakWithBrowserSpeechSynthesis(
  text: string,
  options: { language?: string; speed?: number; volume?: number },
  signal?: AbortSignal,
): Promise<void> {
  return new Promise<void>((resolve, reject) => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      return reject(new Error("Speech synthesis is not supported in this browser."));
    }
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    const lang = options.language === "auto" || !options.language ? "en-IN" : options.language;
    utter.lang = lang;
    utter.rate = Math.min(2.0, Math.max(0.6, options.speed ?? 1.0));
    utter.volume = Math.min(1, Math.max(0, options.volume ?? 0.95));

    const voices = window.speechSynthesis.getVoices();
    const match = voices.find((v) => v.lang.toLowerCase().startsWith(lang.split("-")[0].toLowerCase()));
    if (match) utter.voice = match;

    const onAbort = () => {
      window.speechSynthesis.cancel();
      resolve();
    };
    signal?.addEventListener("abort", onAbort, { once: true });

    utter.onend = () => {
      signal?.removeEventListener("abort", onAbort);
      resolve();
    };
    utter.onerror = (ev) => {
      signal?.removeEventListener("abort", onAbort);
      if (ev.error === "interrupted" || ev.error === "canceled") {
        resolve();
      } else {
        reject(new Error(`Browser speech error: ${ev.error}`));
      }
    };
    window.speechSynthesis.speak(utter);
  });
}

export async function listAudioInputDevices(): Promise<MediaDeviceInfo[]> {
  if (typeof navigator === "undefined" || !navigator.mediaDevices?.enumerateDevices) return [];
  try {
    const list = await navigator.mediaDevices.enumerateDevices();
    return list.filter((d) => d.kind === "audioinput");
  } catch {
    return [];
  }
}
