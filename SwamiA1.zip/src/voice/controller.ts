import { api } from "../api";
import type {
  Conversation,
  Message,
  Mode,
  Settings,
  VoiceCapabilities,
  VoiceLifecycleState,
} from "../types";
import {
  computeTimeDomainRms,
  float32ToPcm16kBase64,
  speakWithBrowserSpeechSynthesis,
  vadThresholdFromSensitivity,
  VoiceAudioPlayer,
} from "./audio";

export interface VoiceControllerCallbacks {
  getSettings: () => Settings | null;
  getCapabilities: () => VoiceCapabilities | null;
  getContextIds: () => { conversationId: string | null; projectId: string | null; mode: Mode; modelId: string };
  onStateChange: (state: VoiceLifecycleState) => void;
  onNotice: (notice: string) => void;
  onError: (message: string) => void;
  onTranscriptUpdate: (live: string, interim: string) => void;
  onMicLevel: (level: number) => void;
  onProvidersUpdate: (stt: string, tts: string) => void;
  onTurnPersisted: (payload: {
    conversation: Conversation;
    user_message: Message | null;
    assistant_message: Message | null;
  }) => void;
}

interface SpeechRecognitionInstance {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((ev: SpeechRecognitionResultEventLike) => void) | null;
  onerror: ((ev: { error?: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
}

interface SpeechRecognitionResultEventLike {
  resultIndex: number;
  results: ArrayLike<{
    isFinal: boolean;
    [index: number]: { transcript: string };
  }>;
}

function getBrowserSpeechRecognitionCtor(): (new () => SpeechRecognitionInstance) | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as {
    SpeechRecognition?: new () => SpeechRecognitionInstance;
    webkitSpeechRecognition?: new () => SpeechRecognitionInstance;
  };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

export function mapMicPermissionError(err: unknown): string {
  const name = err instanceof DOMException || err instanceof Error ? err.name : "";
  const msg = err instanceof Error ? err.message : String(err);
  if (name === "NotAllowedError" || name === "PermissionDeniedError" || /permission/i.test(msg)) {
    return "Microphone permission denied. Allow microphone access in your browser site settings and try again.";
  }
  if (name === "NotFoundError" || name === "DevicesNotFoundError") {
    return "No microphone was detected on this device. Connect a mic and select it in Settings → Voice.";
  }
  if (name === "NotReadableError" || name === "TrackStartError") {
    return "Your microphone is busy or used by another application.";
  }
  if (name === "SecurityError") {
    return "Microphone capture requires a secure HTTPS or localhost origin.";
  }
  return msg || "Could not access microphone.";
}

export class VoiceConversationController {
  private cb: VoiceControllerCallbacks;
  private state: VoiceLifecycleState = "idle";
  private player = new VoiceAudioPlayer();
  private micStream: MediaStream | null = null;
  private captureCtx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private processor: ScriptProcessorNode | null = null;
  private rafId = 0;
  private ws: WebSocket | null = null;
  private sessionId: string | null = null;
  private activeEngine: "gemini_live" | "router_pipeline" = "router_pipeline";
  private manualStop = false;
  private reconnectAttempts = 0;
  private readonly maxReconnects = 3;

  // Router pipeline recording / turn state
  private mediaRecorder: MediaRecorder | null = null;
  private recordedChunks: Blob[] = [];
  private speechDetectedInClip = false;
  private speechStartMs = 0;
  private lastSpeechMs = 0;
  private turnAbort: AbortController | null = null;
  private speakAbort: AbortController | null = null;
  private browserRec: SpeechRecognitionInstance | null = null;
  private browserRecFinalText = "";
  private bargeInFrames = 0;
  private pttHeld = false;
  private speakingReplayId: string | null = null;

  constructor(callbacks: VoiceControllerCallbacks) {
    this.cb = callbacks;
  }

  getState(): VoiceLifecycleState {
    return this.state;
  }

  getSpeakingMessageId(): string | null {
    return this.speakingReplayId;
  }

  private setState(next: VoiceLifecycleState) {
    this.state = next;
    this.cb.onStateChange(next);
  }

  private async openMicStream(): Promise<MediaStream> {
    if (typeof navigator === "undefined" || !navigator.mediaDevices?.getUserMedia) {
      throw new Error("Microphone capture is not supported in this browser environment.");
    }
    const settings = this.cb.getSettings();
    const audioConstraints: MediaTrackConstraints = {
      echoCancellation: true,
      noiseSuppression: true,
      autoGainControl: true,
      channelCount: 1,
      ...(settings?.voice_mic_device_id ? { deviceId: { exact: settings.voice_mic_device_id } } : {}),
    };
    return navigator.mediaDevices.getUserMedia({ audio: audioConstraints });
  }

  private startAnalyserLoop(onAudioRms: (rms: number) => void) {
    if (!this.captureCtx || !this.micStream) return;
    const source = this.captureCtx.createMediaStreamSource(this.micStream);
    this.analyser = this.captureCtx.createAnalyser();
    this.analyser.fftSize = 1024;
    source.connect(this.analyser);

    const scratch = new Float32Array(this.analyser.fftSize);
    const tick = () => {
      if (!this.analyser || this.manualStop) return;
      const rms = computeTimeDomainRms(this.analyser, scratch);
      const level = Math.min(1, Math.round(rms * 650) / 100);
      this.cb.onMicLevel(level);
      onAudioRms(rms);
      this.rafId = requestAnimationFrame(tick);
    };
    this.rafId = requestAnimationFrame(tick);
  }

  async startConversation(): Promise<void> {
    if (this.state !== "idle" && this.state !== "disconnected" && this.state !== "error") {
      return;
    }
    const settings = this.cb.getSettings();
    const caps = this.cb.getCapabilities() ?? (await api.v1VoiceCapabilities().catch(() => null));
    if (settings && !settings.voice_enabled) {
      this.cb.onError("Voice AI is disabled in Settings → Voice.");
      return;
    }

    this.manualStop = false;
    this.reconnectAttempts = 0;
    this.player.setVolume(settings?.voice_volume ?? 0.95);
    this.setState("connecting");
    this.cb.onTranscriptUpdate("", "");

    try {
      this.micStream = await this.openMicStream();
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.captureCtx = new AudioCtx();
      if (this.captureCtx.state === "suspended") await this.captureCtx.resume();
    } catch (err) {
      const msg = mapMicPermissionError(err);
      this.setState("error");
      this.cb.onError(msg);
      this.cleanupCapture();
      return;
    }

    const preferLive =
      settings?.voice_provider === "gemini_live" ||
      (settings?.voice_provider !== "router_pipeline" && Boolean(caps?.gemini_live_available));

    if (preferLive && caps?.gemini_live_available) {
      this.activeEngine = "gemini_live";
      await this.connectGeminiLiveSession();
    } else {
      this.activeEngine = "router_pipeline";
      this.startRouterConversationPipeline();
    }
  }

  private async connectGeminiLiveSession(): Promise<void> {
    const settings = this.cb.getSettings();
    const ctxIds = this.cb.getContextIds();
    try {
      const session = await api.v1CreateVoiceSession({
        mode: "gemini_live",
        conversation_id: ctxIds.conversationId,
        project_id: ctxIds.projectId,
        language: settings?.voice_language ?? "en-IN",
        voice_name: settings?.voice_name ?? "Zephyr",
      });
      this.sessionId = session.session_id;
      this.cb.onProvidersUpdate("gemini_live", "gemini_live");

      const ws = new WebSocket(session.ws_url);
      this.ws = ws;

      ws.onopen = () => {
        this.reconnectAttempts = 0;
        this.cb.onNotice("Connected to Gemini Live real-time voice.");
        this.startLivePcmStreaming();
      };

      ws.onmessage = (ev) => {
        if (this.manualStop) return;
        try {
          const msg = JSON.parse(ev.data as string) as {
            type?: string;
            data?: string;
            text?: string;
            cumulative?: string;
            message?: string;
            name?: string;
            conversation?: Conversation;
            user_message?: Message | null;
            assistant_message?: Message | null;
          };
          if (msg.type === "ready") {
            this.setState("listening");
            this.cb.onNotice("Gemini Live ready — speak naturally.");
          } else if (msg.type === "input_transcript") {
            this.cb.onTranscriptUpdate(msg.cumulative || msg.text || "", "");
          } else if (msg.type === "output_transcript") {
            if (this.state !== "speaking") this.setState("speaking");
            this.cb.onTranscriptUpdate("", msg.cumulative || msg.text || "");
          } else if (msg.type === "audio" && msg.data) {
            this.setState("speaking");
            this.player.enqueuePcm24kBase64(msg.data, () => {
              if (!this.manualStop && this.state === "speaking") {
                this.setState("listening");
              }
            });
          } else if (msg.type === "tool_call" && msg.name) {
            this.setState("processing");
            this.cb.onNotice(`Running SWAMI tool: ${msg.name}…`);
          } else if (msg.type === "interrupted") {
            this.player.stop();
            this.setState("interrupted");
            window.setTimeout(() => {
              if (!this.manualStop && this.state === "interrupted") {
                this.setState("listening");
              }
            }, 350);
          } else if (msg.type === "turn_persisted" && msg.conversation) {
            this.cb.onTurnPersisted({
              conversation: msg.conversation,
              user_message: msg.user_message ?? null,
              assistant_message: msg.assistant_message ?? null,
            });
            this.cb.onTranscriptUpdate("", "");
          } else if (msg.type === "error") {
            this.cb.onError(msg.message || "Gemini Live session error.");
          }
        } catch {
          /* ignore malformed JSON */
        }
      };

      ws.onerror = () => {
        /* handled by onclose */
      };

      ws.onclose = () => {
        this.ws = null;
        if (this.manualStop) {
          this.setState("disconnected");
          return;
        }
        if (this.reconnectAttempts < this.maxReconnects) {
          this.reconnectAttempts += 1;
          this.setState("reconnecting");
          const delay = 800 * Math.pow(2, this.reconnectAttempts - 1);
          this.cb.onNotice(`Voice connection interrupted. Reconnecting (${this.reconnectAttempts}/${this.maxReconnects})…`);
          window.setTimeout(() => {
            if (!this.manualStop) void this.connectGeminiLiveSession();
          }, delay);
        } else {
          this.cb.onNotice("Gemini Live unreachable; switching to SWAMI Router Voice Pipeline.");
          this.activeEngine = "router_pipeline";
          this.startRouterConversationPipeline();
        }
      };
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Could not start Gemini Live session.";
      this.cb.onNotice(`${msg} Falling back to SWAMI Router Voice Pipeline.`);
      this.activeEngine = "router_pipeline";
      this.startRouterConversationPipeline();
    }
  }

  private startLivePcmStreaming() {
    if (!this.captureCtx || !this.micStream) return;
    if (this.processor) {
      try {
        this.processor.disconnect();
      } catch {
        /* ignore */
      }
    }
    const source = this.captureCtx.createMediaStreamSource(this.micStream);
    const processor = this.captureCtx.createScriptProcessor(2048, 1, 1);
    this.processor = processor;
    const sampleRate = this.captureCtx.sampleRate;

    processor.onaudioprocess = (ev) => {
      if (this.manualStop || !this.ws || this.ws.readyState !== WebSocket.OPEN) return;
      const settings = this.cb.getSettings();
      if (settings?.voice_mode === "push_to_talk" && !this.pttHeld) return;

      const input = ev.inputBuffer.getChannelData(0);
      // Local RMS calculation for echo gate / barge-in detection
      let sum = 0;
      for (let i = 0; i < input.length; i++) sum += input[i] * input[i];
      const rms = Math.sqrt(sum / Math.max(1, input.length));
      this.cb.onMicLevel(Math.min(1, Math.round(rms * 650) / 100));

      const speakingNow = this.state === "speaking" || this.player.isPlaying();
      const baseThresh = vadThresholdFromSensitivity(settings?.voice_vad_sensitivity ?? 0.55);
      if (speakingNow) {
        if (settings?.voice_interrupt_enabled && rms > Math.max(0.065, baseThresh * 3.0)) {
          this.bargeInFrames += 1;
          if (this.bargeInFrames >= 3) {
            this.bargeInFrames = 0;
            this.interrupt();
          }
        } else {
          this.bargeInFrames = 0;
        }
        // Output echo gate: avoid looping SWAMI's own audio back into upstream mic while speaking
        return;
      }

      const b64 = float32ToPcm16kBase64(input, sampleRate);
      try {
        this.ws.send(JSON.stringify({ type: "audio", data: b64, mimeType: "audio/pcm;rate=16000" }));
      } catch {
        /* socket closing */
      }
    };

    source.connect(processor);
    // Keep node active silently without audible mic loopback
    const zeroGain = this.captureCtx.createGain();
    zeroGain.gain.value = 0;
    processor.connect(zeroGain);
    zeroGain.connect(this.captureCtx.destination);
  }

  private startRouterConversationPipeline() {
    const settings = this.cb.getSettings();
    const caps = this.cb.getCapabilities();
    const useBrowserSttOnly =
      settings?.voice_stt_provider === "browser" ||
      settings?.offline_mode ||
      (!caps?.gemini_stt_available && !caps?.openai_stt_available && !caps?.groq_stt_available);

    const SpeechRecCtor = getBrowserSpeechRecognitionCtor();
    if (useBrowserSttOnly && SpeechRecCtor) {
      this.cb.onProvidersUpdate("browser", caps?.recommended_tts ?? "browser");
      this.startBrowserSpeechLoop(SpeechRecCtor);
      this.startAnalyserLoop((rms) => {
        if ((this.state === "speaking" || this.player.isPlaying()) && settings?.voice_interrupt_enabled) {
          const thresh = vadThresholdFromSensitivity(settings.voice_vad_sensitivity ?? 0.55);
          if (rms > Math.max(0.065, thresh * 3.0)) {
            this.bargeInFrames += 1;
            if (this.bargeInFrames >= 4) {
              this.bargeInFrames = 0;
              this.interrupt();
            }
          } else {
            this.bargeInFrames = 0;
          }
        }
      });
      return;
    }

    // MediaRecorder + AnalyserNode VAD -> Server STT (/api/v1/voice/transcribe) -> Router (/api/v1/voice/turn) -> TTS
    this.cb.onProvidersUpdate(
      settings?.voice_stt_provider && settings.voice_stt_provider !== "auto"
        ? settings.voice_stt_provider
        : (caps?.recommended_stt ?? "gemini"),
      settings?.voice_tts_provider && settings.voice_tts_provider !== "auto"
        ? settings.voice_tts_provider
        : (caps?.recommended_tts ?? "gemini"),
    );
    this.setState("listening");
    this.cb.onNotice(
      settings?.voice_mode === "push_to_talk"
        ? "Push-to-talk ready. Hold Speak button while talking."
        : "Voice conversation listening — speak naturally.",
    );
    this.startVadRecorderCycle();
  }

  private startBrowserSpeechLoop(SpeechRecCtor: new () => SpeechRecognitionInstance) {
    const settings = this.cb.getSettings();
    const rec = new SpeechRecCtor();
    this.browserRec = rec;
    rec.continuous = true;
    rec.interimResults = true;
    rec.lang = settings?.voice_language && settings.voice_language !== "auto" ? settings.voice_language : "en-IN";
    this.browserRecFinalText = "";
    this.setState("listening");
    this.cb.onNotice("Browser speech recognition listening…");

    let silenceCommitTimer = 0;
    const commitRecognizedText = () => {
      const tx = this.browserRecFinalText.trim();
      this.browserRecFinalText = "";
      if (!tx || this.manualStop) return;
      if (this.state === "speaking" || this.state === "processing") return;
      void this.processRouterTranscriptTurn(tx, "browser");
    };

    rec.onresult = (ev) => {
      if (this.manualStop) return;
      // Echo gate while speaking unless user clicked Interrupt
      if (this.state === "speaking" || this.player.isPlaying()) return;
      let interim = "";
      for (let i = ev.resultIndex; i < ev.results.length; i++) {
        const res = ev.results[i];
        const part = res[0]?.transcript ?? "";
        if (res.isFinal) {
          this.browserRecFinalText += ` ${part}`;
        } else {
          interim += part;
        }
      }
      this.cb.onTranscriptUpdate(this.browserRecFinalText.trim(), interim.trim());
      window.clearTimeout(silenceCommitTimer);
      if (this.browserRecFinalText.trim() && (this.cb.getSettings()?.voice_mode ?? "conversation") !== "push_to_talk") {
        const waitMs = Math.max(450, Math.min(2500, this.cb.getSettings()?.voice_silence_ms ?? 1100));
        silenceCommitTimer = window.setTimeout(commitRecognizedText, waitMs);
      }
    };

    rec.onerror = (ev) => {
      if (this.manualStop) return;
      if (ev.error === "not-allowed") {
        this.setState("error");
        this.cb.onError("Speech recognition permission denied by browser.");
      }
    };

    rec.onend = () => {
      if (!this.manualStop && this.activeEngine === "router_pipeline" && this.state === "listening") {
        try {
          rec.start();
        } catch {
          /* ignore */
        }
      }
    };

    try {
      rec.start();
    } catch {
      /* ignore if already started */
    }
  }

  private startVadRecorderCycle() {
    if (!this.micStream || this.manualStop) return;
    const startClip = () => {
      if (!this.micStream || this.manualStop) return;
      const mimeType = MediaRecorder.isTypeSupported("audio/webm;codecs=opus")
        ? "audio/webm;codecs=opus"
        : MediaRecorder.isTypeSupported("audio/webm")
          ? "audio/webm"
          : "";
      const recorder = mimeType ? new MediaRecorder(this.micStream, { mimeType }) : new MediaRecorder(this.micStream);
      this.mediaRecorder = recorder;
      this.recordedChunks = [];
      this.speechDetectedInClip = false;
      this.speechStartMs = 0;
      this.lastSpeechMs = 0;

      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) this.recordedChunks.push(ev.data);
      };

      recorder.onstop = async () => {
        const chunks = this.recordedChunks;
        this.recordedChunks = [];
        const hadSpeech = this.speechDetectedInClip;
        this.speechDetectedInClip = false;
        if (this.manualStop || !hadSpeech || chunks.length === 0) {
          if (!this.manualStop && this.state === "listening") startClip();
          return;
        }
        const blob = new Blob(chunks, { type: recorder.mimeType || "audio/webm" });
        await this.transcribeAndRespondClip(blob);
        if (!this.manualStop && this.cb.getSettings()?.voice_auto_listen !== false && this.activeEngine === "router_pipeline") {
          this.setState("listening");
          startClip();
        }
      };

      recorder.start(200);
    };

    startClip();

    this.startAnalyserLoop((rms) => {
      const settings = this.cb.getSettings();
      const threshold = vadThresholdFromSensitivity(settings?.voice_vad_sensitivity ?? 0.55);
      const silenceMs = settings?.voice_silence_ms ?? 1150;
      const speakingNow = this.state === "speaking" || this.player.isPlaying();

      if (speakingNow) {
        if (settings?.voice_interrupt_enabled && rms > Math.max(0.065, threshold * 3.0)) {
          this.bargeInFrames += 1;
          if (this.bargeInFrames >= 4) {
            this.bargeInFrames = 0;
            this.interrupt();
          }
        } else {
          this.bargeInFrames = 0;
        }
        return;
      }

      if (this.state !== "listening" || !this.mediaRecorder || this.mediaRecorder.state !== "recording") return;
      if (settings?.voice_mode === "push_to_talk") return;

      const now = performance.now();
      if (rms >= threshold) {
        if (!this.speechDetectedInClip) this.speechStartMs = now;
        this.speechDetectedInClip = true;
        this.lastSpeechMs = now;
      } else if (
        this.speechDetectedInClip &&
        now - this.speechStartMs > 280 &&
        now - this.lastSpeechMs >= silenceMs
      ) {
        this.mediaRecorder.stop();
      }
    });
  }

  private async transcribeAndRespondClip(blob: Blob): Promise<void> {
    if (blob.size < 600 || this.manualStop) return;
    const settings = this.cb.getSettings();
    this.setState("processing");
    this.cb.onNotice("Transcribing speech…");
    this.turnAbort = new AbortController();

    try {
      const sttRes = await api.v1TranscribeAudio({
        blob,
        language: settings?.voice_language ?? "en-IN",
        provider: settings?.voice_stt_provider ?? "auto",
        signal: this.turnAbort.signal,
      });
      const tx = (sttRes.transcript || "").trim();
      if (!tx) {
        this.cb.onNotice("No speech recognized — listening again.");
        this.setState("listening");
        return;
      }
      if (sttRes.warning) this.cb.onNotice(sttRes.warning);
      this.cb.onTranscriptUpdate(tx, "");
      await this.processRouterTranscriptTurn(tx, sttRes.provider_used);
    } catch (err) {
      if (err instanceof DOMException && err.name === "AbortError") return;
      const msg = err instanceof Error ? err.message : "Speech recognition failed.";
      this.cb.onError(msg);
      this.setState("listening");
    }
  }

  private async processRouterTranscriptTurn(transcript: string, sttProvider: string): Promise<void> {
    if (this.manualStop) return;
    const settings = this.cb.getSettings();
    const ctxIds = this.cb.getContextIds();
    this.setState("processing");
    this.cb.onNotice("Thinking…");
    this.turnAbort = new AbortController();

    try {
      const turn = await api.v1VoiceTurn(
        {
          transcript,
          conversation_id: ctxIds.conversationId,
          project_id: ctxIds.projectId,
          language: settings?.voice_language ?? "en-IN",
          mode: ctxIds.mode,
          model_id: ctxIds.modelId,
          stt_provider: sttProvider,
          tts_provider: settings?.voice_tts_provider ?? "auto",
          voice_backend: "router_pipeline",
        },
        this.turnAbort.signal,
      );
      if (this.manualStop) return;
      this.cb.onTurnPersisted({
        conversation: turn.conversation,
        user_message: turn.user_message,
        assistant_message: turn.assistant_message,
      });
      if (turn.notice) this.cb.onNotice(turn.notice);
      await this.speakReplyText(turn.spoken_text || turn.assistant_message.content);
    } catch (err) {
      if (err instanceof DOMException && err.name === "AbortError") return;
      this.cb.onError(err instanceof Error ? err.message : "Voice turn failed.");
    } finally {
      this.turnAbort = null;
      this.cb.onTranscriptUpdate("", "");
      if (!this.manualStop && settings?.voice_auto_listen !== false) {
        this.setState("listening");
      } else if (!this.manualStop) {
        this.setState("idle");
      }
    }
  }

  async speakReplyText(text: string, messageId?: string): Promise<void> {
    const clean = text.trim();
    if (!clean) return;
    const settings = this.cb.getSettings();
    this.player.setVolume(settings?.voice_volume ?? 0.95);
    this.speakAbort?.abort();
    const ac = new AbortController();
    this.speakAbort = ac;
    this.speakingReplayId = messageId ?? null;
    this.setState("speaking");

    const preferredTts = settings?.voice_tts_provider ?? "auto";
    let usedBrowserFallback = preferredTts === "browser" || Boolean(settings?.offline_mode);

    if (!usedBrowserFallback) {
      try {
        const tts = await api.v1VoiceTts(
          {
            text: clean,
            voice_name: settings?.voice_name ?? "Zephyr",
            speed: settings?.voice_speed ?? 1.0,
            language: settings?.voice_language ?? "en-IN",
            provider: preferredTts,
          },
          ac.signal,
        );
        if (ac.signal.aborted) return;
        this.cb.onProvidersUpdate(settings?.voice_stt_provider ?? "auto", tts.provider_used);
        if (tts.warning) this.cb.onNotice(tts.warning);
        await this.player.playEncodedAudioBase64(
          tts.audio_base64,
          tts.mime_type,
          settings?.voice_speed ?? 1.0,
          ac.signal,
        );
        this.speakingReplayId = null;
        return;
      } catch (err) {
        if (err instanceof DOMException && err.name === "AbortError") {
          this.speakingReplayId = null;
          return;
        }
        usedBrowserFallback = true;
        this.cb.onNotice("Cloud TTS unavailable — using browser voice fallback.");
      }
    }

    if (usedBrowserFallback && !ac.signal.aborted) {
      try {
        this.cb.onProvidersUpdate(settings?.voice_stt_provider ?? "auto", "browser");
        await speakWithBrowserSpeechSynthesis(
          clean,
          {
            language: settings?.voice_language ?? "en-IN",
            speed: settings?.voice_speed ?? 1.0,
            volume: settings?.voice_volume ?? 0.95,
          },
          ac.signal,
        );
      } catch (err) {
        if (!(err instanceof DOMException && err.name === "AbortError")) {
          this.cb.onError(err instanceof Error ? err.message : "Voice playback failed.");
        }
      }
    }
    this.speakingReplayId = null;
    if (!this.manualStop && this.state === "speaking" && !this.micStream) {
      this.setState("idle");
    }
  }

  /** One-shot microphone dictation into text composer. */
  async dictateOnce(durationOrUntilStopped = false): Promise<string> {
    const SpeechRecCtor = getBrowserSpeechRecognitionCtor();
    const settings = this.cb.getSettings();
    const caps = this.cb.getCapabilities();

    // If cloud STT is unavailable/offline and Web Speech API exists, use it cleanly
    if (
      (settings?.voice_stt_provider === "browser" ||
        settings?.offline_mode ||
        (!caps?.gemini_stt_available && !caps?.openai_stt_available && !caps?.groq_stt_available)) &&
      SpeechRecCtor
    ) {
      this.setState("listening");
      return new Promise<string>((resolve, reject) => {
        const rec = new SpeechRecCtor();
        this.browserRec = rec;
        rec.continuous = false;
        rec.interimResults = true;
        rec.lang = settings?.voice_language && settings.voice_language !== "auto" ? settings.voice_language : "en-IN";
        let finalStr = "";
        rec.onresult = (ev) => {
          let interim = "";
          for (let i = ev.resultIndex; i < ev.results.length; i++) {
            const txt = ev.results[i][0]?.transcript ?? "";
            if (ev.results[i].isFinal) finalStr += ` ${txt}`;
            else interim += txt;
          }
          this.cb.onTranscriptUpdate(finalStr.trim(), interim.trim());
        };
        rec.onerror = (ev) => {
          this.setState("idle");
          reject(new Error(ev.error === "not-allowed" ? "Microphone permission denied." : `Speech error: ${ev.error}`));
        };
        rec.onend = () => {
          this.browserRec = null;
          this.setState("idle");
          resolve(finalStr.trim());
        };
        try {
          rec.start();
        } catch (err) {
          this.setState("idle");
          reject(err);
        }
      });
    }

    // Record audio clip via MediaRecorder and transcribe via server STT
    void durationOrUntilStopped;
    this.manualStop = false;
    this.setState("listening");
    try {
      this.micStream = await this.openMicStream();
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.captureCtx = new AudioCtx();
      if (this.captureCtx.state === "suspended") await this.captureCtx.resume();
    } catch (err) {
      this.setState("error");
      const msg = mapMicPermissionError(err);
      this.cb.onError(msg);
      this.cleanupCapture();
      throw new Error(msg);
    }

    return new Promise<string>((resolve, reject) => {
      if (!this.micStream) return reject(new Error("Microphone unavailable."));
      const rec = new MediaRecorder(this.micStream);
      this.mediaRecorder = rec;
      const chunks: Blob[] = [];
      let speechSeen = false;
      let startSpeechMs = 0;
      let lastSpeechMs = 0;

      rec.ondataavailable = (ev) => {
        if (ev.data.size > 0) chunks.push(ev.data);
      };

      rec.onstop = async () => {
        this.cleanupCapture();
        if (chunks.length === 0) {
          this.setState("idle");
          return resolve("");
        }
        this.setState("processing");
        try {
          const blob = new Blob(chunks, { type: rec.mimeType || "audio/webm" });
          const stt = await api.v1TranscribeAudio({
            blob,
            language: settings?.voice_language ?? "en-IN",
            provider: settings?.voice_stt_provider ?? "auto",
          });
          this.setState("idle");
          resolve(stt.transcript.trim());
        } catch (err) {
          this.setState("error");
          const msg = err instanceof Error ? err.message : "Dictation transcription failed.";
          this.cb.onError(msg);
          reject(new Error(msg));
        }
      };

      rec.start(200);
      this.startAnalyserLoop((rms) => {
        const thresh = vadThresholdFromSensitivity(settings?.voice_vad_sensitivity ?? 0.55);
        const now = performance.now();
        if (rms >= thresh) {
          if (!speechSeen) startSpeechMs = now;
          speechSeen = true;
          lastSpeechMs = now;
        } else if (speechSeen && now - startSpeechMs > 300 && now - lastSpeechMs >= (settings?.voice_silence_ms ?? 1150)) {
          if (rec.state === "recording") rec.stop();
        }
      });

      window.setTimeout(() => {
        if (rec.state === "recording") rec.stop();
      }, 20_000);
    });
  }

  setPushToTalkHeld(held: boolean) {
    this.pttHeld = held;
    if (this.activeEngine === "gemini_live") {
      if (!held && this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify({ type: "audio_end" }));
      }
      return;
    }
    if (!held && this.mediaRecorder && this.mediaRecorder.state === "recording") {
      this.speechDetectedInClip = true;
      this.mediaRecorder.stop();
    } else if (held && this.browserRec && this.browserRecFinalText.trim()) {
      /* hold continues listening */
    } else if (!held && this.browserRec && this.browserRecFinalText.trim()) {
      const tx = this.browserRecFinalText.trim();
      this.browserRecFinalText = "";
      void this.processRouterTranscriptTurn(tx, "browser");
    }
  }

  interrupt() {
    this.player.stop();
    this.speakAbort?.abort();
    this.turnAbort?.abort();
    this.speakingReplayId = null;

    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      try {
        this.ws.send(JSON.stringify({ type: "interrupt" }));
      } catch {
        /* ignore */
      }
    }

    if (!this.manualStop && this.micStream) {
      this.setState("interrupted");
      this.cb.onNotice("Response interrupted — listening.");
      window.setTimeout(() => {
        if (!this.manualStop && this.state === "interrupted") {
          this.setState("listening");
        }
      }, 300);
    } else {
      this.setState("idle");
    }
  }

  stopSpeakingOnly() {
    this.player.stop();
    this.speakAbort?.abort();
    this.speakingReplayId = null;
    if (this.micStream && !this.manualStop) {
      this.setState("listening");
    } else {
      this.setState("idle");
    }
  }

  private cleanupCapture() {
    cancelAnimationFrame(this.rafId);
    this.rafId = 0;
    this.cb.onMicLevel(0);

    if (this.browserRec) {
      try {
        this.browserRec.abort();
      } catch {
        /* ignore */
      }
      this.browserRec = null;
    }
    if (this.mediaRecorder) {
      try {
        if (this.mediaRecorder.state !== "inactive") this.mediaRecorder.stop();
      } catch {
        /* ignore */
      }
      this.mediaRecorder = null;
    }
    if (this.processor) {
      try {
        this.processor.disconnect();
      } catch {
        /* ignore */
      }
      this.processor = null;
    }
    if (this.analyser) {
      try {
        this.analyser.disconnect();
      } catch {
        /* ignore */
      }
      this.analyser = null;
    }
    if (this.captureCtx && this.captureCtx.state !== "closed") {
      void this.captureCtx.close().catch(() => {});
      this.captureCtx = null;
    }
    if (this.micStream) {
      for (const track of this.micStream.getTracks()) {
        track.stop();
      }
      this.micStream = null;
    }
  }

  stopConversation() {
    this.manualStop = true;
    this.pttHeld = false;
    this.turnAbort?.abort();
    this.speakAbort?.abort();
    this.player.stop();
    this.speakingReplayId = null;
    this.cleanupCapture();

    if (this.ws) {
      try {
        if (this.ws.readyState === WebSocket.OPEN) {
          this.ws.send(JSON.stringify({ type: "close" }));
        }
        this.ws.close(1000, "User stopped voice conversation");
      } catch {
        /* ignore */
      }
      this.ws = null;
    }
    if (this.sessionId) {
      const sid = this.sessionId;
      this.sessionId = null;
      void api.v1EndVoiceSession(sid).catch(() => {});
    }
    this.cb.onTranscriptUpdate("", "");
    this.setState("idle");
  }
}
