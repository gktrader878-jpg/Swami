import type { VoiceShortcut, VoiceShortcutAction } from "../types";

export const VOICE_SHORTCUT_ACTION_META: Array<{
  action: VoiceShortcutAction;
  label: string;
  description: string;
  needsParam?: boolean;
  paramLabel?: string;
  paramPlaceholder?: string;
}> = [
  {
    action: "summarize_conversation",
    label: "Summarize active chat",
    description: "Generates a concise summary of the current conversation.",
  },
  {
    action: "new_research",
    label: "Start new research project",
    description: "Opens a fresh Deep Research thread (speaks optional topic after phrase).",
  },
  {
    action: "new_chat",
    label: "Start new chat",
    description: "Clears current thread view and starts a clean conversation.",
  },
  {
    action: "switch_mode",
    label: "Switch chat mode",
    description: "Changes mode to Fast, Think, or Deep Research.",
    needsParam: true,
    paramLabel: "Target mode",
    paramPlaceholder: "fast | think | research",
  },
  {
    action: "open_settings",
    label: "Open Settings section",
    description: "Jumps directly to a specific Settings tab.",
    needsParam: true,
    paramLabel: "Section",
    paramPlaceholder: "voice | api | memory | research | skills | browser | models",
  },
  {
    action: "read_last_reply",
    label: "Read last reply aloud",
    description: "Speaks the most recent assistant message using configured TTS.",
  },
  {
    action: "clear_attachments",
    label: "Clear pending attachments",
    description: "Removes queued documents and images from the composer.",
  },
  {
    action: "run_prompt",
    label: "Run custom prompt",
    description: "Sends a reusable prompt template (use {query} for trailing speech).",
    needsParam: true,
    paramLabel: "Prompt template",
    paramPlaceholder: "Explain {query} in simple terms with 3 bullet points.",
  },
];

export function normalizeShortcutPhrase(input: string): string {
  return input
    .toLowerCase()
    .replace(/[\u2018\u2019\u201C\u201D'".,!?;:()\[\]{}।]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export interface MatchedVoiceShortcut {
  shortcut: VoiceShortcut;
  captured_arg: string;
}

export function matchVoiceShortcut(
  transcript: string,
  shortcuts: VoiceShortcut[] | undefined,
): MatchedVoiceShortcut | null {
  const list = Array.isArray(shortcuts) ? shortcuts : [];
  const normInput = normalizeShortcutPhrase(transcript);
  if (!normInput) return null;

  const candidates = list
    .filter((s) => s && s.enabled && s.phrase)
    .map((s) => ({ shortcut: s, normPhrase: normalizeShortcutPhrase(s.phrase) }))
    .filter((item) => item.normPhrase.length > 0)
    .sort((a, b) => b.normPhrase.length - a.normPhrase.length);

  for (const { shortcut, normPhrase } of candidates) {
    if (normInput === normPhrase) {
      return { shortcut, captured_arg: "" };
    }
    const mode = shortcut.match_mode ?? "prefix";
    if (mode === "prefix" && normInput.startsWith(`${normPhrase} `)) {
      const rawTail = normInput.slice(normPhrase.length).trim();
      const cleanTail = rawTail.replace(/^(about|on|for|called|named|regarding)\s+/i, "").trim();
      return { shortcut, captured_arg: cleanTail };
    }
  }
  return null;
}
