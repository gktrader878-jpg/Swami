export type Mode = "fast" | "think" | "research";

export interface Step {
  id: string;
  kind: string;
  title: string;
  detail: string;
  state: "running" | "done" | "error" | "skipped" | "stopped";
  t?: number;
  t_end?: number;
}

export interface Source {
  n?: number;
  kind: "web" | "document";
  title: string;
  url: string;
  site?: string;
  date?: string;
  snippet?: string;
  cited?: boolean;
}

export interface Metrics {
  model_id?: string;
  model_name?: string;
  provider_id?: string;
  provider_name?: string;
  is_local?: boolean;
  routed_reason?: string;
  fallback_from?: string;
  quantization?: string;
  context_length?: number;
  first_token_s?: number | null;
  total_s?: number;
  prompt_tokens?: number;
  completion_tokens?: number;
  total_tokens?: number;
  tokens_estimated?: boolean;
  tokens_per_second?: number | null;
  model_calls?: number;
  tool_calls?: number;
  peak_vram_mb?: number | null;
  peak_ram_mb?: number | null;
  load_seconds?: number | null;
  voice_turn?: boolean;
  voice_backend?: string;
  voice_stt_provider?: string;
  voice_tts_provider?: string;
  voice_language?: string;
  voice_latency_ms?: number | null;
}

export interface Attachment {
  id: string;
  name: string;
  size: number;
  kind?: "document" | "image" | "generated_image";
  mime?: string;
  width?: number | null;
  height?: number | null;
  url?: string;
  source_type?: "upload" | "generated" | "edited";
}

export interface VisionModelOption {
  target: string;
  provider_id: string;
  provider_name: string;
  model_id: string;
  model_name: string;
  is_local: boolean;
}

export interface VisionCapabilities {
  offline_mode: boolean;
  supported_formats: string[];
  max_image_bytes: number;
  max_images_per_message: number;
  max_total_bytes: number;
  analysis_available: boolean;
  analysis_models: VisionModelOption[];
  generation_available: boolean;
  gemini_generation_available: boolean;
  openai_generation_available: boolean;
  generation_models: Array<{
    id: string;
    name: string;
    provider: "gemini" | "openai";
    supports_edit: boolean;
    supports_4k: boolean;
    supports_wide_ratios: boolean;
    default_ratios: string[];
  }>;
}

export type MemoryCategory = "preference" | "project" | "instruction" | "fact" | "learning" | "general";

export interface MemorySuggestion {
  id: string;
  content: string;
  category: MemoryCategory;
  project_id: string | null;
  confidence: number;
  conflict_with?: string | null;
  conflict_content?: string | null;
}

export interface MemoryUsed {
  id: string;
  content: string;
  category: MemoryCategory;
  project_id: string | null;
}

export interface Message {
  id: string;
  conversation_id: string;
  role: "user" | "assistant";
  content: string;
  reasoning: string;
  mode: Mode;
  steps: Step[];
  sources: Source[];
  metrics: Metrics;
  attachments: Attachment[];
  memories_used?: MemoryUsed[];
  memory_suggestions?: MemorySuggestion[];
  status: "complete" | "streaming" | "stopped" | "error";
  created_at: number;
  error?: string;
}

export interface Conversation {
  id: string;
  title: string;
  kind: "chat" | "research";
  project_id: string | null;
  created_at: number;
  updated_at: number;
}

export interface Project {
  id: string;
  name: string;
  created_at: number;
}

export interface DocumentInfo {
  id: string;
  name: string;
  mime?: string;
  size: number;
  n_chunks: number;
  n_chars: number;
  conversation_id: string | null;
  created_at?: number;
  is_scanned?: boolean;
  page_count?: number;
  attachment_id?: string | null;
}

export interface Memory {
  id: string;
  content: string;
  category: MemoryCategory;
  project_id: string | null;
  conflict_with?: string | null;
  enabled: number;
  source: string;
  created_at: number;
  updated_at: number;
}

export interface Gpu {
  name: string;
  vram_total_mb: number;
  vram_used_mb: number;
  vram_free_mb: number;
  driver: string;
}

export interface Hardware {
  os: string;
  cpu: string;
  cpu_cores: number;
  cpu_threads: number;
  ram_total_gb: number;
  ram_available_gb: number;
  gpus: Gpu[];
  has_gpu: boolean;
}

export interface EngineStatus {
  loaded: boolean;
  loading: string;
  provider: string;
  model_id?: string;
  model_name?: string;
  runtime?: string;
  quantization?: string;
  context_length?: number;
  gpu_layers?: number;
  load_seconds?: number;
  model_vram_mb?: number | null;
  warnings?: string[];
  fallback?: boolean;
  last_load_failure?: string;
  busy?: boolean;
}

export interface ProfileInfo {
  label: string;
  description: string;
  model_id: string;
  context_length: number;
}

export interface Status {
  app: string;
  version: string;
  engine: EngineStatus;
  hardware: Hardware;
  recommended_profile: string;
  resolved: {
    model_id?: string;
    model_name?: string;
    provider_id?: string;
    provider_name?: string;
    is_local?: boolean;
    context_length?: number;
    gpu_layers?: number;
    profile?: string;
    error?: string;
  } | null;
  runtime_installed: boolean;
  paths: { data: string; models: string; database: string; uploads: string };
  profiles: Record<string, ProfileInfo>;
}

export interface DownloadState {
  state: "downloading" | "done" | "paused" | "error";
  received: number;
  total: number;
  speed_bps: number;
  error: string;
}

export interface ModelInfo {
  id: string;
  runtime?: string;
  name: string;
  family: string;
  publisher: string;
  base_repo: string;
  gguf_repo: string;
  file: string;
  size_bytes: number;
  license: string;
  parameters: string;
  quantization: string;
  tier: string;
  native_context: number;
  notes: string;
  lora_file?: string;
  adapter?: string;
  base_name?: string;
  experimental?: boolean;
  installed: boolean;
  loaded: boolean;
  compatibility: { level: "ok" | "warn" | "bad"; message: string };
  download: DownloadState | null;
}

export type ApiProtocol = "auto" | "openai" | "anthropic" | "gemini";
export type ProviderHealthStatus = "healthy" | "unhealthy" | "unreachable" | "unconfigured" | "unknown";
export type RoutingMode = "manual" | "auto";
export type RoutingPreference = "fastest" | "balanced" | "capability" | "lowest_cost";

export interface ModelCapabilities {
  vision: boolean;
  reasoning: boolean;
  tools: boolean;
  structured_output: boolean;
  context_length?: number;
  verified: boolean;
  source?: string;
}

export interface ModelGenerationParams {
  temperature?: number | null;
  top_p?: number | null;
  max_tokens?: number | null;
  timeout_ms?: number | null;
}

export interface ProviderModelConfig {
  id: string;
  name: string;
  enabled: boolean;
  custom?: boolean;
  capabilities: ModelCapabilities;
  params?: ModelGenerationParams;
  tier?: "fast" | "balanced" | "high";
  cost_tier?: "free" | "low" | "medium" | "high";
}

export interface ProviderConfig {
  id: string;
  preset_id: string;
  name: string;
  protocol: "openai" | "anthropic" | "gemini";
  base_url: string;
  enabled: boolean;
  configured: boolean;
  key_configured: boolean;
  is_local: boolean;
  default_model: string;
  models: ProviderModelConfig[];
  health_status: ProviderHealthStatus;
  health_message: string;
  last_checked_at: number | null;
  last_latency_ms: number | null;
  created_at: number;
  updated_at: number;
}

export interface ProviderUsageStat {
  provider_id: string;
  model_id: string;
  requests: number;
  successes: number;
  errors: number;
  avg_first_token_ms: number;
  avg_total_ms: number;
  total_prompt_tokens: number;
  total_completion_tokens: number;
}

export interface RoutableModelOption {
  target: string;
  provider_id: string;
  provider_name: string;
  preset_id: string;
  protocol: "openai" | "anthropic" | "gemini";
  model_id: string;
  model_name: string;
  is_local: boolean;
  health_status: ProviderHealthStatus;
  health_message: string;
  capabilities: ModelCapabilities;
  params?: ModelGenerationParams;
  tier: "fast" | "balanced" | "high";
  cost_tier: "free" | "low" | "medium" | "high";
  is_default: boolean;
  is_fallback: boolean;
}

export interface CompareModelResult {
  target: string;
  provider_id: string;
  provider_name: string;
  model_id: string;
  model_name: string;
  is_local: boolean;
  status: "running" | "complete" | "error" | "stopped";
  content: string;
  reasoning: string;
  error?: string;
  first_token_ms: number | null;
  total_ms: number;
  prompt_tokens: number;
  completion_tokens: number;
  tokens_estimated: boolean;
}

export type CompareStreamEvent =
  | { type: "delta" | "reasoning" | "done" | "error"; target: string; result: CompareModelResult; delta?: string }
  | { type: "complete"; results: CompareModelResult[] }
  | { type: "error"; message: string };

export interface LocalAiWindowsGuide {
  title: string;
  ollama: { default_url: string; steps: string[]; env_example: string };
  lmstudio: { default_url: string; steps: string[] };
  security_note: string;
}

export interface RoutingState {
  routing_mode: RoutingMode;
  routing_preference: RoutingPreference;
  default_provider_id: string;
  default_model_id: string;
  fallback_provider_id: string;
  fallback_model_id: string;
  request_timeout_ms: number;
  model_id: string;
}

export interface ProviderPreset {
  id: string;
  name: string;
  protocol: "openai" | "anthropic" | "gemini";
  base_url: string;
  default_model: string;
  models: string[];
  key_placeholder: string;
  notes: string;
  is_local?: boolean;
  core?: boolean;
}

export interface Settings {
  theme: "system" | "light" | "dark";
  density: "comfortable" | "compact";
  font_scale: number;
  profile: string;
  model_id: string;
  routing_mode: RoutingMode;
  routing_preference: RoutingPreference;
  default_provider_id: string;
  default_model_id: string;
  fallback_provider_id: string;
  fallback_model_id: string;
  request_timeout_ms: number;
  api_base_url: string;
  api_model: string;
  api_provider?: string;
  api_protocol?: ApiProtocol;
  api_key_configured: boolean;
  context_length: number;
  gpu_layers: number;
  idle_unload_minutes: number;
  temperature: number | null;
  top_p: number | null;
  top_k: number | null;
  max_tokens: number;
  style: "balanced" | "direct" | "creative" | "technical";
  custom_instructions: string;
  show_reasoning: boolean;
  think_max_tool_calls: number;
  think_time_budget_s: number;
  think_token_budget: number;
  think_verify: boolean;
  think_reasoning_budget: number;
  offline_mode: boolean;
  web_research_enabled: boolean;
  search_provider: "duckduckgo" | "searxng" | "brave";
  searxng_url: string;
  brave_api_key: string;
  brave_key_configured?: boolean;
  research_max_sources: number;
  research_max_rounds: number;
  research_time_budget_s: number;
  python_tool_enabled: boolean;
  memory_enabled: boolean;
  memory_auto_suggest: boolean;
  voice_enabled: boolean;
  voice_mode: VoiceMode;
  voice_provider: VoiceProviderPreference;
  voice_stt_provider: VoiceSttProvider;
  voice_tts_provider: VoiceTtsProvider;
  voice_name: string;
  voice_language: string;
  voice_speed: number;
  voice_volume: number;
  voice_auto_listen: boolean;
  voice_interrupt_enabled: boolean;
  voice_vad_sensitivity: number;
  voice_silence_ms: number;
  voice_mic_device_id: string;
  voice_shortcuts: VoiceShortcut[];
}

export type VoiceShortcutAction =
  | "summarize_conversation"
  | "new_research"
  | "new_chat"
  | "switch_mode"
  | "open_settings"
  | "read_last_reply"
  | "clear_attachments"
  | "run_prompt";

export interface VoiceShortcut {
  id: string;
  phrase: string;
  action: VoiceShortcutAction;
  param?: string;
  enabled: boolean;
  match_mode?: "exact" | "prefix";
  created_at: number;
}

export type VoiceLifecycleState =
  | "idle"
  | "connecting"
  | "listening"
  | "processing"
  | "speaking"
  | "interrupted"
  | "reconnecting"
  | "error"
  | "disconnected";

export type VoiceMode = "conversation" | "push_to_talk";
export type VoiceProviderPreference = "auto" | "gemini_live" | "router_pipeline";
export type VoiceSttProvider = "auto" | "gemini" | "openai" | "groq" | "browser";
export type VoiceTtsProvider = "auto" | "gemini" | "openai" | "browser";

export interface VoiceLanguageOption {
  code: string;
  label: string;
  native_label: string;
  bcp47: string;
}

export interface VoiceOption {
  id: string;
  name: string;
  provider: "gemini" | "openai" | "browser";
  description: string;
}

export interface VoiceCapabilities {
  voice_enabled: boolean;
  offline_mode: boolean;
  gemini_live_available: boolean;
  gemini_stt_available: boolean;
  gemini_tts_available: boolean;
  openai_stt_available: boolean;
  openai_tts_available: boolean;
  groq_stt_available: boolean;
  browser_fallback_available: boolean;
  recommended_engine: "gemini_live" | "router_pipeline";
  recommended_stt: string;
  recommended_tts: string;
  languages: VoiceLanguageOption[];
  voices: VoiceOption[];
}

export type StreamEvent =
  | { type: "run"; run_id: string }
  | { type: "start"; conversation_id: string; user_message: Message; assistant_message_id: string; mode: Mode }
  | {
      type: "model_selected";
      provider_id: string;
      provider_name: string;
      model_id: string;
      model_name: string;
      is_local: boolean;
      auto_routed: boolean;
      reason?: string;
      fallback_from?: string;
    }
  | { type: "step"; step: Step }
  | { type: "token"; text: string }
  | { type: "reasoning"; text: string }
  | { type: "content_reset" }
  | { type: "content_replace"; text: string }
  | { type: "sources"; sources: Source[] }
  | { type: "memories_used"; memories: MemoryUsed[] }
  | { type: "memory_suggestions"; suggestions: MemorySuggestion[] }
  | { type: "engine"; status: EngineStatus }
  | { type: "title"; conversation_id: string; title: string }
  | { type: "notice"; message: string }
  | { type: "error"; message: string }
  | { type: "done"; status: Message["status"]; message: Message };
