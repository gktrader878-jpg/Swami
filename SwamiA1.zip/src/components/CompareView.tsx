import { Columns2, Loader2, Play, Square, Check, AlertCircle, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { api, streamCompare } from "../api";
import { seconds } from "../lib/format";
import { useStore } from "../store";
import type { CompareModelResult } from "../types";
import { Markdown } from "./Markdown";

export function CompareView() {
  const open = useStore((s) => s.compareOpen);
  const setOpen = useStore((s) => s.setCompareOpen);
  const routableModels = useStore((s) => s.routableModels);
  const activeId = useStore((s) => s.activeId);
  const draftProjectId = useStore((s) => s.draftProjectId);
  const openConversation = useStore((s) => s.openConversation);
  const refreshConversations = useStore((s) => s.refreshConversations);
  const toast = useStore((s) => s.toast);

  const [selectedTargets, setSelectedTargets] = useState<string[]>([]);
  const [prompt, setPrompt] = useState("");
  const [running, setRunning] = useState(false);
  const [results, setResults] = useState<Record<string, CompareModelResult>>({});
  const [order, setOrder] = useState<string[]>([]);
  const [adopting, setAdopting] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  useEffect(() => {
    if (!open) return;
    if (selectedTargets.length === 0 && routableModels.length > 0) {
      setSelectedTargets(routableModels.slice(0, Math.min(2, routableModels.length)).map((m) => m.target));
    }
  }, [open, routableModels, selectedTargets.length]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && !running) setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, running, setOpen]);

  if (!open) return null;

  const toggleTarget = (target: string) => {
    setSelectedTargets((prev) => {
      if (prev.includes(target)) return prev.filter((t) => t !== target);
      if (prev.length >= 4) {
        toast("Select up to 4 models for side-by-side comparison.", "info");
        return prev;
      }
      return [...prev, target];
    });
  };

  const startCompare = async () => {
    const cleanPrompt = prompt.trim();
    if (!cleanPrompt || selectedTargets.length === 0 || running) return;
    const targets = selectedTargets.slice(0, 4);
    const initial: Record<string, CompareModelResult> = {};
    for (const t of targets) {
      const opt = routableModels.find((m) => m.target === t);
      initial[t] = {
        target: t,
        provider_id: opt?.provider_id ?? "unknown",
        provider_name: opt?.provider_name ?? "Provider",
        model_id: opt?.model_id ?? t,
        model_name: opt?.model_name ?? t,
        is_local: opt?.is_local ?? false,
        status: "running",
        content: "",
        reasoning: "",
        first_token_ms: null,
        total_ms: 0,
        prompt_tokens: 0,
        completion_tokens: 0,
        tokens_estimated: true,
      };
    }
    setOrder(targets);
    setResults(initial);
    setRunning(true);
    const ac = new AbortController();
    abortRef.current = ac;

    try {
      await streamCompare(
        { targets, prompt: cleanPrompt, mode: "fast" },
        (ev) => {
          if (ev.type === "complete") {
            const nextMap: Record<string, CompareModelResult> = {};
            for (const r of ev.results) nextMap[r.target] = r;
            setResults((prev) => ({ ...prev, ...nextMap }));
          } else if (ev.type === "error" && !("target" in ev)) {
            toast(ev.message, "error");
          } else if ("target" in ev && ev.result) {
            setResults((prev) => ({ ...prev, [ev.target]: ev.result }));
          }
        },
        ac.signal,
      );
    } catch (err) {
      if (!(err instanceof DOMException && err.name === "AbortError")) {
        toast(err instanceof Error ? err.message : "Comparison failed.", "error");
      }
    } finally {
      abortRef.current = null;
      setRunning(false);
    }
  };

  const stopCompare = () => {
    abortRef.current?.abort();
  };

  const adopt = async (res: CompareModelResult) => {
    if (!res.content.trim() || adopting) return;
    setAdopting(res.target);
    try {
      const adopted = await api.v1AdoptComparison({
        conversation_id: activeId,
        project_id: activeId ? null : draftProjectId,
        prompt: prompt.trim(),
        result: res,
      });
      await refreshConversations();
      if (activeId === adopted.conversation.id) {
        const convData = await api.conversation(adopted.conversation.id);
        useStore.setState({ messages: convData.messages, documents: convData.documents });
      } else {
        await openConversation(adopted.conversation.id);
      }
      toast(`Adopted response from ${res.model_name} (${res.provider_name}).`, "success");
      setOpen(false);
    } catch (err) {
      toast(err instanceof Error ? err.message : "Could not adopt response.", "error");
    } finally {
      setAdopting(null);
    }
  };

  return (
    <div className="backdrop" onClick={(e) => { if (e.target === e.currentTarget && !running) setOpen(false); }}>
      <div className="dialog compare-dialog" role="dialog" aria-modal="true" aria-label="Compare models side-by-side">
        <div className="compare-head">
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <Columns2 size={18} />
            <div>
              <h3>Side-by-side Model Comparison</h3>
              <div className="sub">Send one prompt concurrently to up to 4 configured models (tools disabled for clean parity).</div>
            </div>
          </div>
          <button className="icon-btn" aria-label="Close comparison" disabled={running} onClick={() => setOpen(false)}>
            <X size={18} />
          </button>
        </div>

        <div className="compare-controls">
          <div className="compare-model-picker">
            <div className="menu-label" style={{ padding: "0 0 6px" }}>
              Select 1–4 models ({selectedTargets.length}/4 selected)
            </div>
            {routableModels.length === 0 ? (
              <div className="note warn" style={{ marginTop: 0 }}>
                No configured provider/model is active yet. Add an API key or local Ollama/LM Studio under Settings → API providers.
              </div>
            ) : (
              <div className="compare-target-grid">
                {routableModels.map((opt) => {
                  const checked = selectedTargets.includes(opt.target);
                  return (
                    <button
                      key={opt.target}
                      type="button"
                      disabled={running}
                      aria-pressed={checked}
                      className={`compare-target-opt${checked ? " on" : ""}`}
                      onClick={() => toggleTarget(opt.target)}
                    >
                      <span className="t-name">{opt.model_name}</span>
                      <span className="t-meta">
                        {opt.provider_name} · {opt.is_local ? "Local" : "Cloud"} · {opt.health_status}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          <div className="compare-prompt-row">
            <textarea
              className="textarea"
              rows={2}
              value={prompt}
              placeholder="Enter a prompt to compare responses across selected models…"
              aria-label="Comparison prompt"
              disabled={running}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyDown={(e) => {
                if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
                  e.preventDefault();
                  void startCompare();
                }
              }}
            />
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              {running ? (
                <button className="btn danger" onClick={stopCompare}>
                  <Square size={14} fill="currentColor" /> Stop all
                </button>
              ) : (
                <button
                  className="btn primary"
                  disabled={!prompt.trim() || selectedTargets.length === 0}
                  onClick={() => void startCompare()}
                >
                  <Play size={14} /> Run comparison
                </button>
              )}
            </div>
          </div>
        </div>

        <div className="compare-grid scroll">
          {order.length === 0 ? (
            <div className="compare-empty">
              Pick 2–4 models above, enter your prompt, and run a live side-by-side comparison.
            </div>
          ) : (
            order.map((target) => {
              const r = results[target];
              if (!r) return null;
              return (
                <section key={target} className="compare-col" aria-label={`${r.model_name} result`}>
                  <header className="compare-col-head">
                    <div style={{ minWidth: 0 }}>
                      <div className="c-title">{r.model_name}</div>
                      <div className="c-sub">
                        {r.provider_name} · {r.is_local ? "Local" : "Cloud"}
                      </div>
                    </div>
                    <span className={`health-label ${r.status}`}>
                      {r.status === "running" && <Loader2 size={12} className="spin" />}
                      {r.status}
                    </span>
                  </header>

                  <div className="compare-col-metrics tabular">
                    <span>TTFT: {r.first_token_ms != null ? `${r.first_token_ms} ms` : "—"}</span>
                    <span>Total: {r.total_ms > 0 ? seconds(r.total_ms / 1000) : "—"}</span>
                    <span>
                      Tokens: {r.prompt_tokens + r.completion_tokens > 0 ? `${r.prompt_tokens}+${r.completion_tokens}` : "—"}
                      {r.tokens_estimated && r.completion_tokens > 0 ? " (est.)" : ""}
                    </span>
                  </div>

                  <div className="compare-col-body scroll">
                    {r.error ? (
                      <div className="msg-error" role="alert">
                        <AlertCircle size={15} />
                        <span>{r.error}</span>
                      </div>
                    ) : r.content ? (
                      <Markdown text={r.content} sources={[]} />
                    ) : r.status === "running" ? (
                      <div className="waiting">Streaming response…</div>
                    ) : (
                      <div className="sub">No content produced.</div>
                    )}
                  </div>

                  <footer className="compare-col-foot">
                    <button
                      className="btn sm primary"
                      disabled={running || !r.content.trim() || adopting === r.target}
                      onClick={() => void adopt(r)}
                    >
                      <Check size={14} /> {adopting === r.target ? "Adding to chat…" : "Use this response"}
                    </button>
                  </footer>
                </section>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
