import { useEffect, useState } from "react";
import { useStore } from "../store";
import { Lock, Play, CheckCircle, AlertCircle, History, Sparkles } from "lucide-react";

interface SkillFieldSchema {
  name: string;
  type: string;
  required: boolean;
  description: string;
}

interface SkillItem {
  id: string;
  name: string;
  description: string;
  version: string;
  category: string;
  enabled: boolean;
  requiredPermissions: string[];
  inputSchema: SkillFieldSchema[];
  outputSchema: SkillFieldSchema[];
}

interface ExecutionRecord {
  id: number;
  skill_id: string;
  status: string;
  input_summary: string;
  output_summary: string;
  error?: string;
  duration_ms: number;
  created_at: string;
}

export function SkillsPanel() {
  const [skills, setSkills] = useState<SkillItem[]>([]);
  const [history, setHistory] = useState<ExecutionRecord[]>([]);
  const [expandedSkillId, setExpandedSkillId] = useState<string | null>(null);
  const [testInputs, setTestInputs] = useState<Record<string, string>>({});
  const [executionResults, setExecutionResults] = useState<Record<string, { summary: string; output: any; durationMs: number; error?: string }>>({});
  const [loading, setLoading] = useState(true);
  const [runningId, setRunningId] = useState<string | null>(null);
  const toast = useStore((s) => s.toast);

  const loadSkillsAndHistory = async () => {
    try {
      const [skillsResp, historyResp] = await Promise.all([
        fetch("/api/v1/skills"),
        fetch("/api/v1/skills/history"),
      ]);
      if (skillsResp.ok) {
        const data = (await skillsResp.json()) as { skills: SkillItem[] };
        setSkills(data.skills);
      }
      if (historyResp.ok) {
        const data = (await historyResp.json()) as { history: ExecutionRecord[] };
        setHistory(data.history);
      }
    } catch {
      toast("Could not load skills registry.", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadSkillsAndHistory();
  }, []);

  const toggleSkill = async (id: string, enabled: boolean) => {
    try {
      const resp = await fetch(`/api/v1/skills/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ enabled }),
      });
      if (resp.ok) {
        const data = (await resp.json()) as { skills: SkillItem[] };
        setSkills(data.skills);
        toast(`Skill ${enabled ? "enabled" : "disabled"}`, "success");
      }
    } catch {
      toast("Could not update skill status.", "error");
    }
  };

  const handleRunSkill = async (skill: SkillItem) => {
    const inputPayload: Record<string, any> = {};
    for (const field of skill.inputSchema) {
      const val = testInputs[`${skill.id}_${field.name}`] ?? "";
      if (field.required && !val.trim()) {
        toast(`Missing required field '${field.name}'`, "error");
        return;
      }
      if (val.trim()) {
        inputPayload[field.name] = field.type === "number" ? Number(val) : field.type === "boolean" ? val === "true" : val;
      }
    }

    setRunningId(skill.id);
    try {
      const resp = await fetch(`/api/v1/skills/${skill.id}/execute`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(inputPayload),
      });
      const data = await resp.json();
      if (resp.ok) {
        setExecutionResults((prev) => ({
          ...prev,
          [skill.id]: { summary: data.summary, output: data.output, durationMs: data.durationMs },
        }));
        toast(`Skill executed successfully in ${data.durationMs}ms`, "success");
        void loadSkillsAndHistory();
      } else {
        setExecutionResults((prev) => ({
          ...prev,
          [skill.id]: { summary: "", output: null, durationMs: 0, error: data.detail || "Execution failed" },
        }));
        toast(data.detail || "Skill execution failed", "error");
      }
    } catch {
      toast("Network error executing skill", "error");
    } finally {
      setRunningId(null);
    }
  };

  if (loading) return <div className="sb-empty">Loading skills…</div>;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      <div className="set-group">
        <h4><Sparkles size={16} style={{ display: "inline", marginRight: 6 }} />Extensible AI Skills Registry ({skills.length})</h4>
        <div className="note">
          SWAMI automatically selects and invokes these registered skills when relevant to your prompt. You can also inspect schemas, test skills live, and view execution logs.
        </div>
        <div style={{ display: "grid", gap: 12, marginTop: 14 }}>
          {skills.map((s) => {
            const isExpanded = expandedSkillId === s.id;
            const res = executionResults[s.id];
            const isRunning = runningId === s.id;

            return (
              <div key={s.id} className="model-card" style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                <div className="row1" style={{ alignItems: "center" }}>
                  <span className="nm">{s.name}</span>
                  <span className="tag">v{s.version}</span>
                  <span className="tag">{s.category}</span>
                  <span style={{ flex: 1 }} />
                  <button
                    className="btn sm ghost"
                    onClick={() => setExpandedSkillId(isExpanded ? null : s.id)}
                  >
                    {isExpanded ? "Hide Test & Schema" : "Test & Inspect"}
                  </button>
                  <button
                    className={`btn sm ${s.enabled ? "primary" : "ghost"}`}
                    onClick={() => void toggleSkill(s.id, !s.enabled)}
                  >
                    {s.enabled ? "Enabled" : "Disabled"}
                  </button>
                </div>
                <div className="meta">{s.description}</div>
                {s.requiredPermissions.length > 0 && (
                  <div style={{ display: "flex", gap: 4, alignItems: "center", fontSize: "12px", color: "var(--text-3)" }}>
                    <Lock size={12} /> Required permissions: {s.requiredPermissions.join(", ")}
                  </div>
                )}

                {/* Expanded Test & Schema Inspector */}
                {isExpanded && (
                  <div style={{ marginTop: 8, padding: 12, background: "var(--bg-2)", borderRadius: 8, display: "flex", flexDirection: "column", gap: 10 }}>
                    <div style={{ fontSize: "12px", fontWeight: 600, color: "var(--text-2)" }}>INPUT PARAMETERS SCHEMA</div>
                    {s.inputSchema.map((field) => (
                      <div key={field.name} style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                        <label style={{ fontSize: "12px", fontWeight: 500 }}>
                          {field.name} {field.required && <span style={{ color: "var(--error)" }}>*</span>} ({field.type})
                        </label>
                        <div style={{ fontSize: "11px", color: "var(--text-3)" }}>{field.description}</div>
                        <input
                          type="text"
                          className="input"
                          placeholder={`Enter ${field.name}...`}
                          value={testInputs[`${s.id}_${field.name}`] ?? ""}
                          onChange={(e) =>
                            setTestInputs((prev) => ({ ...prev, [`${s.id}_${field.name}`]: e.target.value }))
                          }
                        />
                      </div>
                    ))}

                    <button
                      className="btn sm primary"
                      style={{ alignSelf: "flex-start", marginTop: 4 }}
                      onClick={() => void handleRunSkill(s)}
                      disabled={isRunning || !s.enabled}
                    >
                      <Play size={12} style={{ marginRight: 4 }} /> {isRunning ? "Running..." : "Run Skill Live"}
                    </button>

                    {res && (
                      <div style={{ marginTop: 8, padding: 8, background: "var(--bg)", borderRadius: 6, border: "1px solid var(--border)" }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 6, fontWeight: 600, fontSize: "12px", color: res.error ? "var(--error)" : "var(--success)" }}>
                          {res.error ? <AlertCircle size={14} /> : <CheckCircle size={14} />}
                          {res.error ? "Execution Error" : `Success (${res.durationMs}ms)`}
                        </div>
                        {res.summary && <div style={{ fontSize: "12px", marginTop: 4 }}>{res.summary}</div>}
                        <pre style={{ fontSize: "11px", marginTop: 6, maxHeight: 120, overflowY: "auto", whiteSpace: "pre-wrap" }}>
                          {res.error ? res.error : JSON.stringify(res.output, null, 2)}
                        </pre>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Execution History Section */}
      <div className="set-group">
        <h4><History size={16} style={{ display: "inline", marginRight: 6 }} />Skill Execution History ({history.length})</h4>
        <div style={{ display: "flex", flexDirection: "column", gap: 6, marginTop: 10, maxHeight: 240, overflowY: "auto" }}>
          {history.length === 0 ? (
            <div className="note">No skill executions recorded yet.</div>
          ) : (
            history.map((h) => (
              <div key={h.id} style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 10px", background: "var(--bg-2)", borderRadius: 6, fontSize: "12px" }}>
                <span className="tag">{h.skill_id}</span>
                <span style={{ flex: 1, wordBreak: "break-all" }}>{h.input_summary}</span>
                <span style={{ color: "var(--text-3)" }}>{h.duration_ms}ms</span>
                <span style={{ color: h.status === "success" ? "var(--success)" : "var(--error)", fontWeight: 500 }}>
                  {h.status}
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
