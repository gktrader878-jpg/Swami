import { Mic, RefreshCw, Volume2, VolumeX } from "lucide-react";
import { useEffect, useState } from "react";
import { useStore } from "../store";
import type {
  Settings as SettingsT,
  VoiceMode,
  VoiceProviderPreference,
  VoiceSttProvider,
  VoiceTtsProvider,
} from "../types";
import { listAudioInputDevices } from "../voice/audio";

type Save = (patch: Partial<SettingsT>) => Promise<void>;

export function VoiceSettingsSection({ s, save }: { s: SettingsT; save: Save }) {
  const voiceCapabilities = useStore((st) => st.voiceCapabilities);
  const refreshVoiceCapabilities = useStore((st) => st.refreshVoiceCapabilities);
  const speakMessageAloud = useStore((st) => st.speakMessageAloud);
  const stopVoiceSpeaking = useStore((st) => st.stopVoiceSpeaking);
  const voiceState = useStore((st) => st.voiceState);

  const [micDevices, setMicDevices] = useState<MediaDeviceInfo[]>([]);
  const [loadingDevices, setLoadingDevices] = useState(false);

  const loadDevices = async () => {
    setLoadingDevices(true);
    try {
      const devs = await listAudioInputDevices();
      setMicDevices(devs);
    } finally {
      setLoadingDevices(false);
    }
  };

  useEffect(() => {
    void refreshVoiceCapabilities();
    void loadDevices();
  }, [refreshVoiceCapabilities]);

  const samplePhrase =
    s.voice_language === "hi-IN"
      ? "नमस्ते, मैं स्वामी हूँ। आपकी आवाज़ सेटिंग्स अब तैयार हैं।"
      : "Hello, I am SWAMI. Your real-time voice settings are configured and ready.";

  const testingVoice = voiceState === "speaking";

  return (
    <>
      <div className="set-group">
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10 }}>
          <h4>Real-time Voice AI</h4>
          <button
            className="btn sm"
            type="button"
            onClick={() => {
              void refreshVoiceCapabilities();
              void loadDevices();
            }}
          >
            <RefreshCw size={13} /> Refresh status
          </button>
        </div>

        <div className="voice-caps-grid">
          <div className="voice-cap-item">
            <span className="k">Gemini Live Audio</span>
            <span className={`health-label ${voiceCapabilities?.gemini_live_available ? "healthy" : "unconfigured"}`}>
              {voiceCapabilities?.gemini_live_available ? "ready" : s.offline_mode ? "offline" : "needs Gemini key"}
            </span>
          </div>
          <div className="voice-cap-item">
            <span className="k">Server STT</span>
            <span className="v">{voiceCapabilities?.recommended_stt ?? "browser"}</span>
          </div>
          <div className="voice-cap-item">
            <span className="k">Server TTS</span>
            <span className="v">{voiceCapabilities?.recommended_tts ?? "browser"}</span>
          </div>
          <div className="voice-cap-item">
            <span className="k">Browser Fallback</span>
            <span className="health-label healthy">available</span>
          </div>
        </div>

        <div className="field">
          <div className="txt">
            <div className="name">Enable Voice AI</div>
            <div className="help">Shows microphone dictation and real-time voice conversation controls in the chat composer.</div>
          </div>
          <div className="ctl">
            <button
              className="switch"
              role="switch"
              aria-checked={s.voice_enabled}
              aria-label="Enable Voice AI"
              onClick={() => void save({ voice_enabled: !s.voice_enabled })}
            />
          </div>
        </div>

        <div className="field">
          <div className="txt">
            <div className="name">Conversation style</div>
            <div className="help">
              Hands-free listens automatically after each reply; Push-to-talk transmits only while holding the Speak button.
            </div>
          </div>
          <div className="ctl">
            <div className="choice" role="radiogroup">
              {(
                [
                  { id: "conversation", label: "Hands-free" },
                  { id: "push_to_talk", label: "Push-to-talk" },
                ] as Array<{ id: VoiceMode; label: string }>
              ).map((o) => (
                <button
                  key={o.id}
                  role="radio"
                  aria-checked={s.voice_mode === o.id}
                  className={s.voice_mode === o.id ? "on" : ""}
                  onClick={() => void save({ voice_mode: o.id })}
                >
                  {o.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="set-group">
        <h4>Voice providers &amp; language</h4>

        <div className="field">
          <div className="txt">
            <div className="name">Voice engine</div>
            <div className="help">
              Auto uses Gemini Live bidirectional audio when available, or routes through your selected Model Router model (OpenAI, Claude, Groq, Ollama, etc.).
            </div>
          </div>
          <div className="ctl">
            <select
              className="select"
              aria-label="Voice engine"
              value={s.voice_provider}
              onChange={(e) => void save({ voice_provider: e.target.value as VoiceProviderPreference })}
            >
              <option value="auto">Auto (Best available)</option>
              <option value="gemini_live">Gemini Live API (WebSocket)</option>
              <option value="router_pipeline">Router Pipeline (Any active model)</option>
            </select>
          </div>
        </div>

        <div className="field">
          <div className="txt">
            <div className="name">Speech-to-Text (STT) provider</div>
            <div className="help">Used by Router Pipeline and composer microphone dictation.</div>
          </div>
          <div className="ctl">
            <select
              className="select"
              aria-label="Speech-to-Text provider"
              value={s.voice_stt_provider}
              onChange={(e) => void save({ voice_stt_provider: e.target.value as VoiceSttProvider })}
            >
              <option value="auto">Auto (Gemini → Groq → OpenAI → Browser)</option>
              <option value="gemini">Google Gemini STT</option>
              <option value="openai">OpenAI Whisper</option>
              <option value="groq">Groq Whisper</option>
              <option value="browser">Browser SpeechRecognition</option>
            </select>
          </div>
        </div>

        <div className="field">
          <div className="txt">
            <div className="name">Text-to-Speech (TTS) provider</div>
            <div className="help">Automatically falls back to Browser SpeechSynthesis if cloud TTS is unavailable.</div>
          </div>
          <div className="ctl">
            <select
              className="select"
              aria-label="Text-to-Speech provider"
              value={s.voice_tts_provider}
              onChange={(e) => void save({ voice_tts_provider: e.target.value as VoiceTtsProvider })}
            >
              <option value="auto">Auto (Gemini → OpenAI → Browser)</option>
              <option value="gemini">Google Gemini TTS</option>
              <option value="openai">OpenAI TTS</option>
              <option value="browser">Browser SpeechSynthesis</option>
            </select>
          </div>
        </div>

        <div className="field">
          <div className="txt">
            <div className="name">Spoken language</div>
            <div className="help">Supports English (India / US) and Hindi for speech recognition and spoken replies.</div>
          </div>
          <div className="ctl">
            <select
              className="select"
              aria-label="Spoken language"
              value={s.voice_language}
              onChange={(e) => void save({ voice_language: e.target.value })}
            >
              {(voiceCapabilities?.languages ?? [
                { code: "en-IN", label: "English (India)" },
                { code: "en-US", label: "English (US)" },
                { code: "hi-IN", label: "Hindi" },
                { code: "auto", label: "Auto-detect (English / Hindi)" },
              ]).map((lang) => (
                <option key={lang.code} value={lang.code}>
                  {lang.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="field">
          <div className="txt">
            <div className="name">Voice character</div>
            <div className="help">Used when Gemini Live, Gemini TTS, or OpenAI TTS synthesizes responses.</div>
          </div>
          <div className="ctl" style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <select
              className="select"
              aria-label="Voice character"
              value={s.voice_name}
              onChange={(e) => void save({ voice_name: e.target.value })}
            >
              {(voiceCapabilities?.voices ?? []).map((v) => (
                <option key={v.id} value={v.id}>
                  {v.name} ({v.provider})
                </option>
              ))}
            </select>
            <button
              className="btn sm"
              type="button"
              onClick={() => {
                if (testingVoice) stopVoiceSpeaking();
                else void speakMessageAloud(samplePhrase, "voice-settings-test");
              }}
            >
              {testingVoice ? <VolumeX size={14} /> : <Volume2 size={14} />}
              {testingVoice ? "Stop" : "Test voice"}
            </button>
          </div>
        </div>
      </div>

      <div className="set-group">
        <h4>Playback, interruption &amp; microphone</h4>

        <div className="field">
          <div className="txt">
            <div className="name">Speaking speed ({s.voice_speed.toFixed(2)}x)</div>
            <div className="help">Adjust playback tempo from 0.6x (slower) to 2.0x (faster).</div>
          </div>
          <div className="ctl">
            <input
              type="range"
              aria-label="Speaking speed"
              min={0.6}
              max={2.0}
              step={0.05}
              value={s.voice_speed}
              onChange={(e) => void save({ voice_speed: Number(e.target.value) })}
            />
          </div>
        </div>

        <div className="field">
          <div className="txt">
            <div className="name">Voice volume ({Math.round(s.voice_volume * 100)}%)</div>
          </div>
          <div className="ctl">
            <input
              type="range"
              aria-label="Voice volume"
              min={0}
              max={1}
              step={0.05}
              value={s.voice_volume}
              onChange={(e) => void save({ voice_volume: Number(e.target.value) })}
            />
          </div>
        </div>

        <div className="field">
          <div className="txt">
            <div className="name">Automatic listening after reply</div>
            <div className="help">Keep the voice conversation flowing without pressing buttons for each turn.</div>
          </div>
          <div className="ctl">
            <button
              className="switch"
              role="switch"
              aria-checked={s.voice_auto_listen}
              aria-label="Automatic listening after reply"
              onClick={() => void save({ voice_auto_listen: !s.voice_auto_listen })}
            />
          </div>
        </div>

        <div className="field">
          <div className="txt">
            <div className="name">Allow speaking interruption (barge-in)</div>
            <div className="help">
              Lets you cut off SWAMI mid-sentence by clicking Interrupt or speaking loudly above the output echo gate.
            </div>
          </div>
          <div className="ctl">
            <button
              className="switch"
              role="switch"
              aria-checked={s.voice_interrupt_enabled}
              aria-label="Allow speaking interruption"
              onClick={() => void save({ voice_interrupt_enabled: !s.voice_interrupt_enabled })}
            />
          </div>
        </div>

        <div className="field">
          <div className="txt">
            <div className="name">Voice activity sensitivity ({s.voice_vad_sensitivity.toFixed(2)})</div>
            <div className="help">Higher values pick up quieter speech; lower values reject background room noise.</div>
          </div>
          <div className="ctl">
            <input
              type="range"
              aria-label="Voice activity sensitivity"
              min={0.1}
              max={1.0}
              step={0.05}
              value={s.voice_vad_sensitivity}
              onChange={(e) => void save({ voice_vad_sensitivity: Number(e.target.value) })}
            />
          </div>
        </div>

        <div className="field">
          <div className="txt">
            <div className="name">End-of-speech pause (ms)</div>
            <div className="help">How long SWAMI waits after you pause speaking before sending your turn (400–3500 ms).</div>
          </div>
          <div className="ctl">
            <input
              className="input num"
              type="number"
              aria-label="End-of-speech pause milliseconds"
              min={400}
              max={3500}
              step={100}
              value={s.voice_silence_ms}
              onChange={(e) => void save({ voice_silence_ms: Number(e.target.value) || 1150 })}
            />
          </div>
        </div>

        <div className="field">
          <div className="txt">
            <div className="name">Microphone input device</div>
            <div className="help">
              Audio streams are processed live for transcription only and are never permanently recorded or stored.
            </div>
          </div>
          <div className="ctl" style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <Mic size={15} />
            <select
              className="select"
              aria-label="Microphone input device"
              value={s.voice_mic_device_id}
              onChange={(e) => void save({ voice_mic_device_id: e.target.value })}
            >
              <option value="">System default microphone</option>
              {micDevices.map((d, idx) => (
                <option key={d.deviceId || idx} value={d.deviceId}>
                  {d.label || `Microphone ${idx + 1}`}
                </option>
              ))}
            </select>
            {loadingDevices && <span style={{ fontSize: 12, color: "var(--text-3)" }}>Scanning…</span>}
          </div>
        </div>
      </div>
    </>
  );
}
