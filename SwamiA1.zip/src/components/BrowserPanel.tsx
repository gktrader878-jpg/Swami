import { useEffect, useState } from "react";
import { useStore } from "../store";
import { Globe, Shield, Play, Square, Camera, CheckCircle, XCircle, AlertTriangle, Download, ArrowRight } from "lucide-react";

interface InteractiveElement {
  tag: string;
  type?: string;
  text: string;
  selector: string;
  href?: string;
}

interface BrowserAction {
  id: string;
  type: string;
  target: string;
  detail: string;
  status: string;
  requiresApproval?: boolean;
}

interface BrowserDownload {
  filename: string;
  size: number;
  savedAt: number;
}

interface PendingApproval {
  actionId: string;
  type: string;
  target: string;
  reason: string;
  maskedValue?: string;
}

interface BrowserSessionState {
  id: string;
  url: string;
  title: string;
  actions: BrowserAction[];
  elements: InteractiveElement[];
  links: Array<{ text: string; href: string }>;
  screenshotUrl?: string;
  extractedText?: string;
  downloads: BrowserDownload[];
  pendingApproval: PendingApproval | null;
  status: string;
  error?: string;
}

export function BrowserAutomationPanel() {
  const [allowedDomains, setAllowedDomains] = useState<string[]>([]);
  const [allowLocalhost, setAllowLocalhost] = useState(false);
  const [newDomain, setNewDomain] = useState("");
  const [targetUrl, setTargetUrl] = useState("https://wikipedia.org");
  const [actionType, setActionType] = useState<string>("extract");
  const [actionTarget, setActionTarget] = useState("body");
  const [actionValue, setActionValue] = useState("");
  const [sessions, setSessions] = useState<BrowserSessionState[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const toast = useStore((s) => s.toast);

  const loadConfig = async () => {
    try {
      const resp = await fetch("/api/v1/browser/config");
      if (resp.ok) {
        const data = (await resp.json()) as { allowedDomains: string[]; allowLocalhost: boolean };
        setAllowedDomains(data.allowedDomains);
        setAllowLocalhost(data.allowLocalhost);
      }
    } catch {
      // ignore
    }
  };

  const loadSessions = async () => {
    try {
      const resp = await fetch("/api/v1/browser/sessions");
      if (resp.ok) {
        const data = (await resp.json()) as { sessions: BrowserSessionState[] };
        setSessions(data.sessions);
        if (data.sessions.length > 0 && !activeSessionId) {
          setActiveSessionId(data.sessions[0].id);
        }
      }
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    void loadConfig();
    void loadSessions();
  }, []);

  const saveConfig = async (domains: string[], localhost: boolean) => {
    try {
      const resp = await fetch("/api/v1/browser/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ allowedDomains: domains, allowLocalhost: localhost }),
      });
      if (resp.ok) {
        const data = (await resp.json()) as { allowedDomains: string[]; allowLocalhost: boolean };
        setAllowedDomains(data.allowedDomains);
        setAllowLocalhost(data.allowLocalhost);
        toast("Browser security settings updated", "success");
      }
    } catch {
      toast("Could not update browser config", "error");
    }
  };

  const handleAddDomain = () => {
    const d = newDomain.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, "");
    if (!d) return;
    if (allowedDomains.includes(d)) {
      setNewDomain("");
      return;
    }
    const updated = [...allowedDomains, d];
    setNewDomain("");
    void saveConfig(updated, allowLocalhost);
  };

  const handleRemoveDomain = (d: string) => {
    const updated = allowedDomains.filter((x) => x !== d);
    void saveConfig(updated, allowLocalhost);
  };

  const handleStartSession = async () => {
    if (!targetUrl.trim()) {
      toast("Enter a target URL", "error");
      return;
    }
    setLoading(true);
    try {
      const resp = await fetch("/api/v1/browser/sessions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: targetUrl.trim() }),
      });
      const data = (await resp.json()) as { session?: BrowserSessionState; detail?: string };
      if (resp.ok && data.session) {
        setSessions((prev) => [data.session!, ...prev.filter((s) => s.id !== data.session!.id)]);
        setActiveSessionId(data.session.id);
        toast("Browser session opened", "success");
      } else {
        toast(data.detail || "Could not open URL", "error");
      }
    } catch {
      toast("Network error opening browser session", "error");
    } finally {
      setLoading(false);
      void loadSessions();
    }
  };

  const handleRunAction = async () => {
    if (!activeSessionId) return;
    setLoading(true);
    try {
      const resp = await fetch(`/api/v1/browser/sessions/${activeSessionId}/actions`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          actions: [{ type: actionType, target: actionTarget.trim() || "body", value: actionValue }],
        }),
      });
      const data = (await resp.json()) as { session?: BrowserSessionState; detail?: string };
      if (resp.ok && data.session) {
        setSessions((prev) => prev.map((s) => (s.id === data.session!.id ? data.session! : s)));
        toast("Action executed", "success");
      } else {
        toast(data.detail || "Action failed", "error");
      }
    } catch {
      toast("Could not run browser action", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleResolveApproval = async (actionId: string, approved: boolean) => {
    if (!activeSessionId) return;
    try {
      const resp = await fetch(`/api/v1/browser/sessions/${activeSessionId}/approve`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ actionId, approved }),
      });
      const data = (await resp.json()) as { session?: BrowserSessionState; detail?: string };
      if (resp.ok && data.session) {
        setSessions((prev) => prev.map((s) => (s.id === data.session!.id ? data.session! : s)));
        toast(approved ? "Action approved and resumed" : "Action rejected", "success");
      } else {
        toast(data.detail || "Approval resolution failed", "error");
      }
    } catch {
      toast("Could not submit approval", "error");
    }
  };

  const handleCancelSession = async (id: string) => {
    try {
      const resp = await fetch(`/api/v1/browser/sessions/${id}/cancel`, { method: "POST" });
      if (resp.ok) {
        const data = (await resp.json()) as { session: BrowserSessionState };
        setSessions((prev) => prev.map((s) => (s.id === id ? data.session : s)));
        toast("Browser session stopped", "success");
      }
    } catch {
      toast("Could not stop session", "error");
    }
  };

  const activeSession = sessions.find((s) => s.id === activeSessionId);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      {/* Security & Allowlist Section */}
      <div className="set-group">
        <h4><Shield size={16} style={{ display: "inline", marginRight: 6 }} />Browser Automation & SSRF Guardrails</h4>
        <div className="note">
          Headless Chromium automation runs with strict domain allowlists and approval gates for form submissions and downloads.
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginTop: 10 }}>
          <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: "14px" }}>
            <input
              type="checkbox"
              checked={allowLocalhost}
              onChange={(e) => void saveConfig(allowedDomains, e.target.checked)}
            />
            Allow Localhost Testing (http://127.0.0.1 or localhost)
          </label>
        </div>
        <div style={{ marginTop: 12 }}>
          <div style={{ fontSize: "13px", fontWeight: 500, marginBottom: 6 }}>Allowed Domains ({allowedDomains.length})</div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 8 }}>
            {allowedDomains.map((d) => (
              <span key={d} className="tag" style={{ display: "flex", alignItems: "center", gap: 4 }}>
                {d}
                <button
                  onClick={() => handleRemoveDomain(d)}
                  style={{ background: "none", border: "none", cursor: "pointer", padding: 0, color: "inherit", fontSize: "12px" }}
                >
                  ×
                </button>
              </span>
            ))}
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <input
              type="text"
              className="input"
              placeholder="e.g. github.com"
              value={newDomain}
              onChange={(e) => setNewDomain(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAddDomain()}
              style={{ maxWidth: 260 }}
            />
            <button className="btn sm primary" onClick={handleAddDomain}>Add Domain</button>
          </div>
        </div>
      </div>

      {/* Active Session & Controls */}
      <div className="set-group">
        <h4><Globe size={16} style={{ display: "inline", marginRight: 6 }} />Browser Control & Inspector</h4>
        <div style={{ display: "flex", gap: 8, marginTop: 12, flexWrap: "wrap" }}>
          <input
            type="text"
            className="input"
            value={targetUrl}
            onChange={(e) => setTargetUrl(e.target.value)}
            placeholder="https://example.com"
            style={{ flex: 1, minWidth: 280 }}
          />
          <button className="btn primary" onClick={() => void handleStartSession()} disabled={loading}>
            <Play size={14} style={{ marginRight: 4 }} /> Open URL
          </button>
        </div>

        {sessions.length > 0 && (
          <div style={{ display: "flex", gap: 6, marginTop: 12, overflowX: "auto", paddingBottom: 4 }}>
            {sessions.map((s) => (
              <button
                key={s.id}
                className={`btn sm ${s.id === activeSessionId ? "primary" : "ghost"}`}
                onClick={() => setActiveSessionId(s.id)}
              >
                {s.title.slice(0, 24)} ({s.status})
              </button>
            ))}
          </div>
        )}

        {activeSession && (
          <div className="model-card" style={{ marginTop: 16, display: "flex", flexDirection: "column", gap: 14 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 8 }}>
              <div>
                <div style={{ fontWeight: 600, fontSize: "15px" }}>{activeSession.title}</div>
                <div style={{ fontSize: "12px", color: "var(--text-3)", wordBreak: "break-all" }}>{activeSession.url}</div>
              </div>
              <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <span className={`tag ${activeSession.status === "completed" ? "success" : activeSession.status === "error" ? "error" : ""}`}>
                  {activeSession.status}
                </span>
                {activeSession.status === "running" || activeSession.status === "awaiting_approval" ? (
                  <button className="btn sm danger" onClick={() => void handleCancelSession(activeSession.id)}>
                    <Square size={12} style={{ marginRight: 4 }} /> Stop
                  </button>
                ) : null}
              </div>
            </div>

            {/* Approval Gate Banner */}
            {activeSession.pendingApproval && (
              <div style={{ padding: 12, background: "rgba(245, 158, 11, 0.12)", border: "1px solid rgba(245, 158, 11, 0.3)", borderRadius: 8 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 6, fontWeight: 600, color: "var(--amber-600, #d97706)", marginBottom: 4 }}>
                  <AlertTriangle size={16} /> Approval Required
                </div>
                <div style={{ fontSize: "13px", marginBottom: 8 }}>{activeSession.pendingApproval.reason}</div>
                <div style={{ display: "flex", gap: 8 }}>
                  <button
                    className="btn sm primary"
                    onClick={() => void handleResolveApproval(activeSession.pendingApproval!.actionId, true)}
                  >
                    <CheckCircle size={14} style={{ marginRight: 4 }} /> Approve & Continue
                  </button>
                  <button
                    className="btn sm ghost"
                    onClick={() => void handleResolveApproval(activeSession.pendingApproval!.actionId, false)}
                  >
                    <XCircle size={14} style={{ marginRight: 4 }} /> Reject Action
                  </button>
                </div>
              </div>
            )}

            {/* Action Runner Bar */}
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center", background: "var(--bg-2)", padding: 10, borderRadius: 8 }}>
              <select
                className="select"
                value={actionType}
                onChange={(e) => setActionType(e.target.value)}
                style={{ width: 130 }}
              >
                <option value="extract">Extract</option>
                <option value="click">Click</option>
                <option value="fill">Fill Input</option>
                <option value="scroll">Scroll</option>
                <option value="screenshot">Screenshot</option>
                <option value="navigate">Navigate</option>
              </select>
              <input
                type="text"
                className="input"
                placeholder={actionType === "click" || actionType === "fill" ? "CSS Selector (e.g. #submit-btn)" : "Target / URL"}
                value={actionTarget}
                onChange={(e) => setActionTarget(e.target.value)}
                style={{ flex: 1, minWidth: 180 }}
              >
              </input>
              {actionType === "fill" && (
                <input
                  type="text"
                  className="input"
                  placeholder="Value to fill"
                  value={actionValue}
                  onChange={(e) => setActionValue(e.target.value)}
                  style={{ width: 140 }}
                />
              )}
              <button className="btn sm primary" onClick={() => void handleRunAction()} disabled={loading}>
                Run <ArrowRight size={14} style={{ marginLeft: 2 }} />
              </button>
            </div>

            {/* Screenshot Preview */}
            {activeSession.screenshotUrl && (
              <div>
                <div style={{ fontSize: "13px", fontWeight: 500, marginBottom: 6, display: "flex", alignItems: "center", gap: 6 }}>
                  <Camera size={14} /> Live Page Snapshot
                </div>
                <div style={{ border: "1px solid var(--border)", borderRadius: 8, overflow: "hidden", background: "#000" }}>
                  <img
                    src={activeSession.screenshotUrl}
                    alt="Browser screenshot"
                    style={{ width: "100%", height: "auto", display: "block", maxHeight: 400, objectFit: "contain" }}
                  />
                </div>
              </div>
            )}

            {/* Extracted Text Preview */}
            {activeSession.extractedText && (
              <div>
                <div style={{ fontSize: "13px", fontWeight: 500, marginBottom: 4 }}>Extracted Text ({activeSession.extractedText.length} chars)</div>
                <pre style={{ background: "var(--bg-2)", padding: 10, borderRadius: 6, fontSize: "12px", maxHeight: 150, overflowY: "auto", whiteSpace: "pre-wrap" }}>
                  {activeSession.extractedText}
                </pre>
              </div>
            )}

            {/* Interactive Elements & Links */}
            {activeSession.elements.length > 0 && (
              <div>
                <div style={{ fontSize: "13px", fontWeight: 500, marginBottom: 6 }}>Detected Interactive Elements ({activeSession.elements.length})</div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 6, maxHeight: 120, overflowY: "auto" }}>
                  {activeSession.elements.map((el, i) => (
                    <button
                      key={i}
                      className="tag"
                      style={{ cursor: "pointer", background: "var(--bg-3)", border: "1px solid var(--border)" }}
                      onClick={() => {
                        setActionType("click");
                        setActionTarget(el.selector);
                      }}
                      title={`Selector: ${el.selector}`}
                    >
                      &lt;{el.tag}&gt; {el.text.slice(0, 24)}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Downloads List */}
            {activeSession.downloads.length > 0 && (
              <div>
                <div style={{ fontSize: "13px", fontWeight: 500, marginBottom: 4, display: "flex", alignItems: "center", gap: 6 }}>
                  <Download size={14} /> Downloaded Files ({activeSession.downloads.length})
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                  {activeSession.downloads.map((d, i) => (
                    <div key={i} style={{ fontSize: "12px", color: "var(--text-2)", display: "flex", justifyContent: "space-between" }}>
                      <span>{d.filename}</span>
                      <span>{Math.round(d.size / 1024)} KB</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Action History Log */}
            <div>
              <div style={{ fontSize: "13px", fontWeight: 500, marginBottom: 6 }}>Action History Log ({activeSession.actions.length})</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 4, maxHeight: 160, overflowY: "auto" }}>
                {activeSession.actions.map((a) => (
                  <div key={a.id} style={{ fontSize: "12px", display: "flex", gap: 8, alignItems: "center", padding: "4px 8px", background: "var(--bg-2)", borderRadius: 4 }}>
                    <span className="tag">{a.type}</span>
                    <span style={{ flex: 1, wordBreak: "break-all" }}>{a.detail}</span>
                    <span style={{ color: a.status === "success" ? "var(--success)" : a.status === "error" ? "var(--error)" : "var(--text-3)" }}>
                      {a.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
