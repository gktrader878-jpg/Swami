import {
  ArrowUp, AudioWaveform, Check, ChevronDown, Columns2, Cpu, FileText, Globe, Hand, Lightbulb, Loader2,
  Mic, Paperclip, PhoneOff, Sparkles, Square, VolumeX, X, Zap,
} from "lucide-react";
import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from "react";
import { bytes } from "../lib/format";
import { useStore } from "../store";
import type { Mode, RoutingPreference, VoiceLifecycleState } from "../types";
import { Popover } from "./Popover";

const VOICE_STATE_LABEL: Record<VoiceLifecycleState, string> = {
  idle: "Idle",
  connecting: "Connecting…",
  listening: "Listening",
  processing: "Processing…",
  speaking: "Speaking",
  interrupted: "Interrupted",
  reconnecting: "Reconnecting…",
  error: "Voice error",
  disconnected: "Disconnected",
};

const MODES: { id: Mode; label: string; short: string; icon: typeof Zap; hint: string }[] = [
  { id: "fast", label: "Fast", short: "Fast", icon: Zap, hint: "Direct response using the selected model or Auto Mode." },
  { id: "think", label: "Think", short: "Think", icon: Lightbulb,
    hint: "Plans, reasons step by step, uses verified tools, and checks calculations." },
  { id: "research", label: "Deep Research", short: "Research", icon: Globe,
    hint: "Searches the web, extracts real pages, and synthesizes a cited report via the Model Router." },
];

const PREFS: Array<{ id: RoutingPreference; label: string }> = [
  { id: "balanced", label: "Balanced" },
  { id: "fastest", label: "Fastest" },
  { id: "capability", label: "Capability" },
  { id: "lowest_cost", label: "Lowest cost" },
];

export interface ComposerHandle {
  focus: () => void;
  setText: (text: string) => void;
}

export const Composer = forwardRef<ComposerHandle>(function Composer(_, ref) {
  const [text, setText] = useState("");
  const [drag, setDrag] = useState(false);
  const area = useRef<HTMLTextAreaElement>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  const composing = useRef(false);

  const mode = useStore((s) => s.mode);
  const setMode = useStore((s) => s.setMode);
  const streaming = useStore((s) => s.streaming);
  const send = useStore((s) => s.send);
  const stop = useStore((s) => s.stop);
  const attach = useStore((s) => s.attach);
  const pending = useStore((s) => s.pendingDocs);
  const removePending = useStore((s) => s.removePending);
  const uploading = useStore((s) => s.uploading);
  const models = useStore((s) => s.models);
  const routableModels = useStore((s) => s.routableModels);
  const status = useStore((s) => s.status);
  const settings = useStore((s) => s.settings);
  const selectModel = useStore((s) => s.selectModel);
  const updateRouting = useStore((s) => s.updateRouting);
  const switching = useStore((s) => s.switchingModel);
  const openSettings = useStore((s) => s.openSettings);
  const setCompareOpen = useStore((s) => s.setCompareOpen);
  const notice = useStore((s) => s.notice);
  const online = useStore((s) => s.online);
  const activeId = useStore((s) => s.activeId);

  const voiceState = useStore((s) => s.voiceState);
  const voiceLiveTranscript = useStore((s) => s.voiceLiveTranscript);
  const voiceInterimTranscript = useStore((s) => s.voiceInterimTranscript);
  const voiceNotice = useStore((s) => s.voiceNotice);
  const voiceMicLevel = useStore((s) => s.voiceMicLevel);
  const voiceSttProvider = useStore((s) => s.voiceSttProvider);
  const voiceTtsProvider = useStore((s) => s.voiceTtsProvider);
  const startVoiceConversation = useStore((s) => s.startVoiceConversation);
  const stopVoiceConversation = useStore((s) => s.stopVoiceConversation);
  const interruptVoice = useStore((s) => s.interruptVoice);
  const stopVoiceSpeaking = useStore((s) => s.stopVoiceSpeaking);
  const setVoicePushToTalkHeld = useStore((s) => s.setVoicePushToTalkHeld);
  const dictateOnce = useStore((s) => s.dictateOnce);
  const [dictating, setDictating] = useState(false);

  useImperativeHandle(ref, () => ({
    focus: () => area.current?.focus(),
    setText: (t: string) => {
      setText(t);
      requestAnimationFrame(() => area.current?.focus());
    },
  }));

  useEffect(() => {
    const resize = () => {
      const el = area.current;
      if (!el) return;
      el.style.height = "auto";
      if (el.scrollHeight > 0) el.style.height = `${Math.min(el.scrollHeight, Math.max(120, window.innerHeight * 0.38))}px`;
    };
    resize();
    window.addEventListener("resize", resize);
    return () => window.removeEventListener("resize", resize);
  }, [text]);

  useEffect(() => {
    area.current?.focus();
  }, [activeId]);

  const installed = models.filter((m) => m.installed);
  const resolvedId = status?.resolved?.model_id ?? "";
  const isAutoMode = settings?.routing_mode === "auto" || resolvedId === "auto";
  const activeRoutable = routableModels.find((r) => r.target === resolvedId);
  const currentCatalog = installed.find((m) => m.id === resolvedId);
  const noModel = installed.length === 0 && routableModels.length === 0;
  const researchBlocked = mode === "research" && (settings?.offline_mode || settings?.web_research_enabled === false);
  const canSend = text.trim().length > 0 && !streaming && !noModel && uploading === 0;

  const activeButtonLabel = (() => {
    if (switching) return "Switching…";
    if (isAutoMode) {
      const prefLabel = PREFS.find((p) => p.id === settings?.routing_preference)?.label ?? "Balanced";
      return `Auto (${prefLabel})`;
    }
    if (activeRoutable) return `${activeRoutable.provider_name} · ${activeRoutable.model_name}`;
    if (currentCatalog) return currentCatalog.name;
    return noModel ? "No model" : "Choose model";
  })();

  const submit = () => {
    if (!canSend) return;
    const value = text;
    setText("");
    void send(value);
  };

  const hint = (() => {
    if (noModel) return "No model configured yet — open Settings → API providers.";
    if (researchBlocked) return "Deep Research is unavailable: web access is switched off in Settings → Privacy.";
    if (mode === "research" && online === false) return "No internet connection detected — Deep Research cannot search right now.";
    if (isAutoMode) {
      return `Auto Model (${settings?.routing_preference ?? "balanced"}) picks the best configured model for each task.`;
    }
    if (activeRoutable) {
      return `${activeRoutable.provider_name} · ${activeRoutable.model_name} (${activeRoutable.is_local ? "Local" : "Cloud"} · ${activeRoutable.health_status})`;
    }
    if (currentCatalog?.runtime === "Gemini API") {
      if (mode === "fast") return `Fast direct answer from ${currentCatalog.name}.`;
      if (mode === "think") return `Adaptive thinking and calculator/memory tools via ${currentCatalog.name}.`;
      return `Searches Google via ${currentCatalog.name} and writes a cited report.`;
    }
    return MODES.find((m) => m.id === mode)?.hint ?? "";
  })();

  const voiceEnabled = settings?.voice_enabled !== false;
  const voiceActive = voiceState !== "idle" && voiceState !== "disconnected";
  const isPttMode = settings?.voice_mode === "push_to_talk";

  const handleDictate = async () => {
    if (dictating || voiceActive) return;
    setDictating(true);
    try {
      const spoken = await dictateOnce();
      if (spoken.trim()) {
        setText((prev) => (prev.trim() ? `${prev.trim()} ${spoken.trim()}` : spoken.trim()));
        requestAnimationFrame(() => area.current?.focus());
      }
    } catch {
      /* surfaced in store toast */
    } finally {
      setDictating(false);
    }
  };

  return (
    <div className="composer-wrap">
      {voiceActive && (
        <div className="voice-bar" role="region" aria-label="Voice conversation controls">
          <div className="voice-bar-top">
            <span className={`voice-state ${voiceState}`}>
              <AudioWaveform size={13} />
              <span>{VOICE_STATE_LABEL[voiceState]}</span>
            </span>
            <div className="voice-meter" aria-label="Microphone audio level">
              <div className="voice-meter-fill" style={{ width: `${Math.min(100, Math.round(voiceMicLevel * 100))}%` }} />
            </div>
            <span className="voice-meta">
              {settings?.voice_language ?? "en-IN"}
              {voiceSttProvider ? ` · STT: ${voiceSttProvider}` : ""}
              {voiceTtsProvider ? ` · TTS: ${voiceTtsProvider}` : ""}
            </span>
            <span className="spacer" />
            {isPttMode && (
              <button
                type="button"
                className="btn sm primary"
                onPointerDown={() => setVoicePushToTalkHeld(true)}
                onPointerUp={() => setVoicePushToTalkHeld(false)}
                onPointerLeave={() => setVoicePushToTalkHeld(false)}
              >
                <Mic size={13} /> Hold to speak
              </button>
            )}
            {(voiceState === "speaking" || voiceState === "processing") && (
              <button type="button" className="btn sm" onClick={interruptVoice} title="Interrupt SWAMI and speak">
                <Hand size={13} /> Interrupt
              </button>
            )}
            {voiceState === "speaking" && (
              <button type="button" className="btn sm" onClick={stopVoiceSpeaking} title="Mute current reply">
                <VolumeX size={13} /> Mute
              </button>
            )}
            <button type="button" className="btn sm danger" onClick={stopVoiceConversation} title="End voice conversation">
              <PhoneOff size={13} /> End
            </button>
          </div>
          {(voiceLiveTranscript || voiceInterimTranscript || voiceNotice) && (
            <div className="voice-bar-sub">
              {voiceLiveTranscript || voiceInterimTranscript ? (
                <span className="voice-tx">
                  {voiceLiveTranscript}
                  {voiceInterimTranscript ? <em> {voiceInterimTranscript}</em> : null}
                </span>
              ) : (
                <span>{voiceNotice}</span>
              )}
            </div>
          )}
        </div>
      )}
      {notice && (
        <div className="routing-banner" role="status">
          <Sparkles size={13} />
          <span>{notice}</span>
        </div>
      )}
      <div
        className={`composer${drag ? " drag" : ""}`}
        onDragOver={(e) => {
          if (e.dataTransfer.types.includes("Files")) {
            e.preventDefault();
            setDrag(true);
          }
        }}
        onDragLeave={() => setDrag(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDrag(false);
          if (e.dataTransfer.files.length) void attach(Array.from(e.dataTransfer.files));
        }}
      >
        {(pending.length > 0 || uploading > 0) && (
          <div className="pending">
            {pending.map((d) => (
              <span key={d.id} className="file-chip">
                <FileText size={14} />
                <span className="name">{d.name}</span>
                <span className="size">{bytes(d.size)}</span>
                <button className="icon-btn sm" style={{ width: 22, height: 22 }} aria-label={`Remove ${d.name}`}
                  onClick={() => void removePending(d.id)}>
                  <X size={13} />
                </button>
              </span>
            ))}
            {uploading > 0 && (
              <span className="file-chip static">
                <Loader2 size={14} className="spin" />
                <span className="name">Reading file…</span>
              </span>
            )}
          </div>
        )}
        <textarea
          ref={area}
          rows={1}
          value={text}
          placeholder={mode === "research" ? "What should I research?" : "Ask anything"}
          aria-label="Message"
          onChange={(e) => setText(e.target.value)}
          onCompositionStart={() => (composing.current = true)}
          onCompositionEnd={() => (composing.current = false)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey && !composing.current && !e.nativeEvent.isComposing) {
              e.preventDefault();
              submit();
            }
          }}
          onPaste={(e) => {
            const files = Array.from(e.clipboardData.files);
            if (files.length) {
              e.preventDefault();
              void attach(files);
            }
          }}
        />
        <div className="bar">
          <input ref={fileInput} type="file" multiple hidden
            accept=".txt,.md,.pdf,.docx,.csv,.tsv,.json,.jsonl,.yaml,.yml,.xml,.html,.log,.py,.js,.ts,.tsx,.jsx,.java,.c,.h,.cpp,.cs,.go,.rs,.rb,.php,.sql,.sh,.ps1,.css,.tex,.toml,.ini,.rst"
            onChange={(e) => {
              if (e.target.files?.length) void attach(Array.from(e.target.files));
              e.target.value = "";
            }} />
          <button className="icon-btn" aria-label="Attach files" title="Attach documents (text, PDF, DOCX, code)"
            onClick={() => fileInput.current?.click()}>
            <Paperclip size={17} />
          </button>
          <div className="seg" role="radiogroup" aria-label="Mode">
            {MODES.map((m) => (
              <button key={m.id} role="radio" aria-checked={mode === m.id} className={mode === m.id ? "on" : ""}
                title={m.hint} disabled={streaming} onClick={() => setMode(m.id)}>
                <m.icon size={14} />
                <span className="lbl-full">{m.label}</span>
                <span className="lbl-short">{m.short}</span>
              </button>
            ))}
          </div>
          <span className="spacer" />
          {voiceEnabled && (
            <>
              <button
                type="button"
                className={`icon-btn${dictating ? " on" : ""}`}
                aria-label="Voice dictation"
                title={dictating ? "Listening for dictation…" : "Dictate message into input"}
                disabled={streaming || voiceActive}
                onClick={() => void handleDictate()}
              >
                {dictating ? <Loader2 size={16} className="spin" /> : <Mic size={16} />}
              </button>
              <button
                type="button"
                className={`icon-btn${voiceActive ? " on" : ""}`}
                aria-label={voiceActive ? "Stop voice conversation" : "Start real-time voice conversation"}
                title={voiceActive ? "Stop voice conversation" : "Start hands-free voice conversation"}
                disabled={streaming}
                onClick={() => (voiceActive ? stopVoiceConversation() : void startVoiceConversation())}
              >
                <AudioWaveform size={16} />
              </button>
            </>
          )}
          <button
            className="icon-btn"
            aria-label="Compare models side-by-side"
            title="Compare up to 4 models side-by-side"
            disabled={streaming}
            onClick={() => setCompareOpen(true)}
          >
            <Columns2 size={16} />
          </button>
          <Popover side="up" align="right"
            trigger={(toggle) => (
              <button className="model-btn" onClick={toggle} aria-label="Choose model" disabled={switching}>
                {switching ? <Loader2 size={13} className="spin" /> : <Cpu size={14} className="model-icon" />}
                <span>{activeButtonLabel}</span>
                <ChevronDown size={14} />
              </button>
            )}>
            {(close) => (
              <div style={{ minWidth: 320, maxWidth: 380 }}>
                <button
                  className="menu-item"
                  role="menuitemradio"
                  aria-checked={isAutoMode}
                  onClick={() => {
                    close();
                    void selectModel("auto");
                  }}
                >
                  <span style={{ flex: 1 }}>
                    <span style={{ display: "flex", alignItems: "center", gap: 6, fontWeight: 600 }}>
                      <Sparkles size={13} /> Auto Model
                    </span>
                    <span className="sub">Routes across configured models with explicit notice</span>
                  </span>
                  {isAutoMode && <Check size={15} className="check" />}
                </button>
                <div className="auto-pref-row">
                  {PREFS.map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      className={`pref-btn${(settings?.routing_preference ?? "balanced") === p.id ? " on" : ""}`}
                      onClick={() => void updateRouting({ routing_mode: "auto", routing_preference: p.id, model_id: "auto" })}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
                <div className="menu-sep" />
                <div className="menu-label">Configured models</div>
                <div className="scroll" style={{ maxHeight: 240 }}>
                  {routableModels.map((opt) => {
                    const selected = !isAutoMode && (opt.target === resolvedId || opt.model_id === resolvedId);
                    const caps = opt.capabilities.verified
                      ? [
                          opt.capabilities.vision ? "Vision" : "",
                          opt.capabilities.reasoning ? "Reasoning" : "",
                          opt.capabilities.tools ? "Tools" : "",
                        ].filter(Boolean).join(" · ")
                      : "Unverified capabilities";
                    return (
                      <button
                        key={opt.target}
                        className="menu-item"
                        role="menuitemradio"
                        aria-checked={selected}
                        onClick={() => {
                          close();
                          void selectModel(opt.target);
                        }}
                      >
                        <span style={{ flex: 1, minWidth: 0 }}>
                          <span style={{ display: "block", fontWeight: 500 }}>
                            {opt.model_name}
                            {opt.is_default ? " · Default" : opt.is_fallback ? " · Fallback" : ""}
                          </span>
                          <span className="sub">
                            {opt.provider_name} · {opt.is_local ? "Local" : "Cloud"} · {opt.health_status}
                            {caps ? ` · ${caps}` : ""}
                          </span>
                        </span>
                        {selected && <Check size={15} className="check" />}
                      </button>
                    );
                  })}
                  {routableModels.length === 0 && installed.map((m) => (
                    <button key={m.id} className="menu-item" role="menuitemradio" aria-checked={m.id === resolvedId}
                      onClick={() => {
                        close();
                        if (m.id !== resolvedId) void selectModel(m.id);
                      }}>
                      <span>
                        {m.name} <span style={{ color: "var(--text-3)" }}>{m.quantization}</span>
                        <span className="sub">{m.compatibility.message}</span>
                      </span>
                      {m.id === resolvedId && <Check size={15} className="check" />}
                    </button>
                  ))}
                  {noModel && <div className="sb-empty">No models configured yet.</div>}
                </div>
                <div className="menu-sep" />
                <button className="menu-item" onClick={() => { close(); setCompareOpen(true); }}>
                  <Columns2 size={14} />
                  <span>Compare models side-by-side…</span>
                </button>
                <button className="menu-item" onClick={() => { close(); openSettings("api"); }}>
                  <span>
                    Manage providers &amp; API keys…
                    <span className="sub">Gemini, OpenAI, Claude, OpenRouter, Ollama, LM Studio</span>
                  </span>
                </button>
              </div>
            )}
          </Popover>
          {streaming ? (
            <button className="send" onClick={() => void stop()} aria-label="Stop generating" title="Stop (Esc)">
              <Square size={13} fill="currentColor" />
            </button>
          ) : (
            <button className="send" onClick={submit} disabled={!canSend} aria-label="Send message" title="Send (Enter)">
              <ArrowUp size={18} strokeWidth={2.4} />
            </button>
          )}
        </div>
      </div>
      <div className="composer-hint">{hint}</div>
    </div>
  );
});

