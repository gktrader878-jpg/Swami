/** SWAMI's compact mark. */
export function Logo({ size = 22 }: { size?: number }) {
  return <img src="/swami-logo.jpg" width={size} height={size} alt="SWAMI" aria-hidden="true"
    style={{ display: "block", objectFit: "cover", borderRadius: Math.max(2, Math.round(size * 0.1)) }} />;
}
