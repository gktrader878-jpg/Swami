import {
  AlertTriangle, Brain, CheckCircle2, ChevronDown, ChevronRight, Cpu, Download, Globe, Info, KeyRound, Mic, Pause,
  Pencil, Plus, RefreshCw, Search, Shield, SlidersHorizontal, Sparkles, Trash2, Upload, Wrench, X,
} from "lucide-react";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { api } from "../api";
import { bytes, mb } from "../lib/format";
import { useStore, type SettingsSection } from "../store";
import type {
  ApiProtocol, Memory, MemoryCategory, ModelGenerationParams, ModelInfo, ProviderConfig, ProviderModelConfig,
  RoutingMode, RoutingPreference, Settings as SettingsT,
} from "../types";
import { BrowserAutomationPanel } from "./BrowserPanel";
import { SkillsPanel } from "./SkillsPanel";
import { VoiceSettingsSection } from "./VoiceSettingsSection";

const SECTIONS: { id: SettingsSection; label: string; icon: typeof Cpu }[] = [
  { id: "general", label: "General", icon: Sparkles },
  { id: "api", label: "API providers", icon: KeyRound },
  { id: "voice", label: "Voice", icon: Mic },
  { id: "models", label: "Models & hardware", icon: Cpu },
  { id: "generation", label: "Generation", icon: SlidersHorizontal },
  { id: "research", label: "Research", icon: Globe },
  { id: "tools", label: "Tools", icon: Wrench },
  { id: "memory", label: "Memory", icon: Brain },
  { id: "skills", label: "Skills", icon: Wrench },
  { id: "browser", label: "Browser", icon: Globe },
  { id: "privacy", label: "Privacy & data", icon: Shield },
  { id: "about", label: "About", icon: Info },
];

/* ---------------------------------------------------------------- controls */
function Field({ name, help, warn, children, col }: {
  name: string; help?: ReactNode; warn?: ReactNode; children: ReactNode; col?: boolean;
}) {
  return (
    <div className={`field${col ? " col" : ""}`}>
      <div className="txt">
        <div className="name">{name}</div>
        {help && <div className="help">{help}</div>}
        {warn && <div className="help warn">{warn}</div>}
      </div>
      <div className="ctl">{children}</div>
    </div>
  );
}

function Switch({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return <button className="switch" role="switch" aria-checked={checked} aria-label={label} onClick={() => onChange(!checked)} />;
}

function Choice<T extends string>({ value, options, onChange }: {
  value: T; options: { id: T; label: string }[]; onChange: (v: T) => void;
}) {
  return (
    <div className="choice" role="radiogroup">
      {options.map((o) => (
        <button key={o.id} role="radio" aria-checked={value === o.id} className={value === o.id ? "on" : ""}
          onClick={() => onChange(o.id)}>
          {o.label}
        </button>
      ))}
    </div>
  );
}

/** Numeric input that commits on blur/Enter so half-typed values are never saved. */
function Num({ value, onCommit, min, max, step = 1, placeholder, label }: {
  value: number | null; onCommit: (v: number | null) => void; min: number; max: number; step?: number;
  placeholder?: string; label: string;
}) {
  const [draft, setDraft] = useState(value == null ? "" : String(value));
  useEffect(() => setDraft(value == null ? "" : String(value)), [value]);
  const commit = () => {
    if (draft.trim() === "") {
      if (placeholder !== undefined) onCommit(null);
      else setDraft(value == null ? "" : String(value));
      return;
    }
    const n = Number(draft);
    if (Number.isNaN(n)) {
      setDraft(value == null ? "" : String(value));
      return;
    }
    const clamped = Math.min(max, Math.max(min, n));
    setDraft(String(clamped));
    if (clamped !== value) onCommit(clamped);
  };
  return (
    <input className="input num" type="number" inputMode="decimal" aria-label={label} value={draft} min={min} max={max}
      step={step} placeholder={placeholder} onChange={(e) => setDraft(e.target.value)} onBlur={commit}
      onKeyDown={(e) => e.key === "Enter" && e.currentTarget.blur()} />
  );
}

function Text({ value, onCommit, placeholder, label, type = "text", width = 260 }: {
  value: string; onCommit: (v: string) => void; placeholder?: string; label: string; type?: string; width?: number;
}) {
  const [draft, setDraft] = useState(value);
  useEffect(() => setDraft(value), [value]);
  return (
    <input className="input" style={{ width }} type={type} aria-label={label} value={draft} placeholder={placeholder}
      autoComplete="off" spellCheck={false} onChange={(e) => setDraft(e.target.value)}
      onBlur={() => draft !== value && onCommit(draft.trim())}
      onKeyDown={(e) => e.key === "Enter" && e.currentTarget.blur()} />
  );
}

type Save = (patch: Partial<SettingsT>) => Promise<void>;

/* ----------------------------------------------------------------- general */
function General({ s, save }: { s: SettingsT; save: Save }) {
  const [instructions, setInstructions] = useState(s.custom_instructions);
  return (
    <>
      <div className="set-group">
        <h4>Appearance</h4>
        <Field name="Theme">
          <Choice value={s.theme} onChange={(theme) => void save({ theme })}
            options={[{ id: "system", label: "System" }, { id: "light", label: "Light" }, { id: "dark", label: "Dark" }]} />
        </Field>
        <Field name="Density" help="Compact tightens spacing in the sidebar and conversation.">
          <Choice value={s.density} onChange={(density) => void save({ density })}
            options={[{ id: "comfortable", label: "Comfortable" }, { id: "compact", label: "Compact" }]} />
        </Field>
        <Field name="Text size">
          <Choice value={String(s.font_scale)} onChange={(v) => void save({ font_scale: Number(v) })}
            options={[{ id: "92", label: "Small" }, { id: "100", label: "Default" }, { id: "110", label: "Large" }]} />
        </Field>
      </div>
      <div className="set-group">
        <h4>Assistant</h4>
        <Field name="Conversational style"
          help="Changes tone and level of detail only. It does not switch safety behaviour on or off.">
          <select className="select" value={s.style} aria-label="Conversational style"
            onChange={(e) => void save({ style: e.target.value as SettingsT["style"] })}>
            <option value="balanced">Balanced</option>
            <option value="direct">Direct</option>
            <option value="creative">Creative</option>
            <option value="technical">Technical</option>
          </select>
        </Field>
        <Field name="Custom instructions" col
          help="Added to every conversation. For example: “Reply in Hinglish”, or “I am a second-year CS student”.">
          <textarea className="textarea" rows={4} maxLength={2000} value={instructions} aria-label="Custom instructions"
            placeholder="How should SWAMI respond to you?" onChange={(e) => setInstructions(e.target.value)}
            onBlur={() => instructions !== s.custom_instructions && void save({ custom_instructions: instructions })} />
        </Field>
        <Field name="Show model reasoning"
          help="When the model reasons before answering (Think and Deep Research), keep its reasoning text available under each reply.">
          <Switch checked={s.show_reasoning} label="Show model reasoning" onChange={(v) => void save({ show_reasoning: v })} />
        </Field>
      </div>
    </>
  );
}

/* ------------------------------------------------------------------ models */
function ModelCard({ m, activeId }: { m: ModelInfo; activeId: string }) {
  const refreshModels = useStore((s) => s.refreshModels);
  const selectModel = useStore((s) => s.selectModel);
  const switching = useStore((s) => s.switchingModel);
  const toast = useStore((s) => s.toast);
  const settings = useStore((s) => s.settings);
  const [confirm, setConfirm] = useState(false);
  const d = m.download;
  const downloading = d?.state === "downloading";
  const act = async (fn: () => Promise<unknown>) => {
    try {
      await fn();
    } catch (e) {
      toast(e instanceof Error ? e.message : "Action failed.", "error");
    }
    await refreshModels();
  };
  const CompatIcon = m.compatibility.level === "ok" ? CheckCircle2 : AlertTriangle;
  return (
    <div className="model-card">
      <div className="row1">
        <span className="nm">{m.name}</span>
        <span className="tag">{m.quantization}</span>
        <span className="tag">{m.tier}</span>
        {m.adapter && <span className="tag gold">Thrones fine-tune</span>}
        {m.experimental && <span className="tag">Experimental</span>}
        {m.loaded && <span className="tag gold">In memory</span>}
        {!m.loaded && m.id === activeId && m.installed && <span className="tag gold">Selected</span>}
        <span style={{ flex: 1 }} />
        {m.runtime === "api" ? (
          m.installed ? (
            m.id !== activeId && <button className="btn sm" disabled={switching || !!settings?.offline_mode} onClick={() => void selectModel(m.id)}>Use this model</button>
          ) : <button className="btn sm" onClick={() => useStore.getState().openSettings("api")}>Configure API key</button>
        ) : m.installed ? (
          <>
            {m.id !== activeId && (
              <button
                className="btn sm"
                disabled={switching || (m.runtime === "Gemini API" && !!settings?.offline_mode)}
                onClick={() => void selectModel(m.id)}
              >
                Use this model
              </button>
            )}
            {m.runtime === "Ollama" || m.runtime === "Gemini API" ? null : confirm ? (
              <>
                <button className="btn sm danger" onClick={() => { setConfirm(false); void act(() => api.deleteModel(m.id)); }}>
                  Delete {bytes(m.size_bytes)}
                </button>
                <button className="btn sm ghost" onClick={() => setConfirm(false)}>Keep</button>
              </>
            ) : (
              <button className="icon-btn sm" aria-label={`Delete ${m.name} from disk`} title="Delete from disk"
                disabled={m.loaded} onClick={() => setConfirm(true)}>
                <Trash2 size={15} />
              </button>
            )}
          </>
        ) : downloading ? (
          <button className="btn sm" onClick={() => void act(() => api.cancelDownload(m.id))}>
            <Pause size={13} /> Pause
          </button>
        ) : (
          <button className="btn sm primary" disabled={m.compatibility.level === "bad" && m.runtime !== "Ollama"}
            onClick={() => void act(() => api.downloadModel(m.id))}>
            <Download size={13} /> {d?.state === "paused" || d?.state === "error" ? "Resume" : "Download"} · {bytes(m.size_bytes)}
          </button>
        )}
      </div>
      <div className="meta">
        {m.publisher} · {m.parameters} parameters · {m.license} · native context {m.native_context.toLocaleString()}
        {m.base_repo && (
          <>
            {" · "}
            <a href={m.base_repo} target="_blank" rel="noreferrer noopener">
              {m.runtime === "Gemini API" ? "API docs" : "model card"}
            </a>
          </>
        )}
        {m.gguf_repo && (
          <>
            {" · "}
            <a href={m.gguf_repo} target="_blank" rel="noreferrer noopener">
              {m.runtime === "Ollama" ? "Ollama library" : "GGUF source"}
            </a>
          </>
        )}
      </div>
      <div className="meta">{m.notes}</div>
      <div className={`compat ${m.compatibility.level}`}>
        <CompatIcon size={14} /> {m.compatibility.message}
      </div>
      {d && d.state !== "done" && (
        <>
          <div className="progress"><i style={{ width: `${d.total ? (d.received / d.total) * 100 : 0}%` }} /></div>
          <div className="meta">
            {d.state === "error" ? <span style={{ color: "var(--danger)" }}>{d.error}</span>
              : `${bytes(d.received)} of ${bytes(d.total)}${downloading ? ` · ${bytes(d.speed_bps)}/s` : " · paused"}`}
          </div>
        </>
      )}
    </div>
  );
}

function Models({ s, save }: { s: SettingsT; save: Save }) {
  const status = useStore((st) => st.status);
  const models = useStore((st) => st.models);
  const refreshModels = useStore((st) => st.refreshModels);
  const refreshStatus = useStore((st) => st.refreshStatus);
  const streaming = useStore((st) => st.streaming);
  const toast = useStore((st) => st.toast);
  const anyDownloading = models.some((m) => m.download?.state === "downloading");

  useEffect(() => {
    void refreshModels();
    void refreshStatus();
    const t = window.setInterval(() => {
      void refreshModels();
      void refreshStatus();
    }, anyDownloading ? 1000 : 4000);
    return () => window.clearInterval(t);
  }, [anyDownloading, refreshModels, refreshStatus]);

  if (!status) return null;
  const hw = status.hardware;
  const gpu = hw.gpus[0];
  const engine = status.engine;
  const resolved = status.resolved;
  const profiles = [
    { id: "auto", label: "Automatic", description: `Picks for this PC: ${status.profiles[status.recommended_profile]?.label}.` },
    ...Object.entries(status.profiles).map(([id, p]) => ({ id, label: p.label, description: p.description })),
  ];
  const needsReload = engine.loaded && resolved && !resolved.error &&
    (engine.model_id !== resolved.model_id || engine.context_length !== resolved.context_length ||
      engine.gpu_layers !== resolved.gpu_layers);

  const applyNow = async () => {
    try {
      await api.loadEngine();
    } catch (e) {
      toast(e instanceof Error ? e.message : "Could not load the model.", "error");
    }
    await refreshStatus();
  };

  return (
    <>
      <div className="set-group">
        <h4>This PC — measured now</h4>
        <div className="hw-grid">
          <div>
            <div className="k">Graphics</div>
            <div className="v" title={gpu?.name}>{gpu ? gpu.name.replace("NVIDIA GeForce ", "") : "No supported GPU"}</div>
            <div className="s">{gpu ? `${mb(gpu.vram_used_mb)} of ${mb(gpu.vram_total_mb)} VRAM in use` : "Models will run on the CPU"}</div>
          </div>
          <div>
            <div className="k">Processor</div>
            <div className="v" title={hw.cpu}>{hw.cpu.replace(/\(R\)|\(TM\)|CPU|@.*$/g, "").replace(/\s+/g, " ").trim()}</div>
            <div className="s">{hw.cpu_cores} cores · {hw.cpu_threads} threads</div>
          </div>
          <div>
            <div className="k">Memory</div>
            <div className="v">{hw.ram_total_gb} GB RAM</div>
            <div className="s">{hw.ram_available_gb} GB available</div>
          </div>
        </div>
        <div className="note">
          {engine.loaded ? (
            <>
              <b>{engine.model_name} {engine.quantization}</b> is in memory via {engine.provider} · context{" "}
              {engine.context_length?.toLocaleString()} tokens · {engine.gpu_layers ? "GPU offload on" : "CPU only"} · loaded in{" "}
              {engine.load_seconds}s{engine.model_vram_mb != null ? ` · about ${mb(engine.model_vram_mb)} VRAM taken at load` : ""}.
              {engine.warnings?.map((w) => <div key={w} style={{ color: "var(--warn)" }}>{w}</div>)}
              {engine.fallback && (
                <div style={{ marginTop: 6 }}>
                  The full settings did not fit, usually because other apps were using memory. Close them and press
                  “Apply new settings now” to retry.
                  {engine.last_load_failure && (
                    <details style={{ marginTop: 4 }}>
                      <summary style={{ cursor: "pointer" }}>Engine error</summary>
                      <span className="path">{engine.last_load_failure}</span>
                    </details>
                  )}
                </div>
              )}
            </>
          ) : engine.loading ? "A model is loading…" : "No model is in memory. It loads automatically when you send a message."}
          <div style={{ display: "flex", gap: 8, marginTop: 9 }}>
            {needsReload && <button className="btn sm primary" disabled={streaming} onClick={() => void applyNow()}>Apply new settings now</button>}
            {!engine.loaded && resolved && !resolved.error && (
              <button className="btn sm" disabled={!!engine.loading} onClick={() => void applyNow()}>Load {resolved.model_name} now</button>
            )}
            {engine.loaded && (
              <button className="btn sm" disabled={streaming}
                onClick={() => void api.unloadEngine().then(refreshStatus).catch((e) => toast(e.message, "error"))}>
                Unload and free memory
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="set-group">
        <h4>Performance profile</h4>
        <div className="profiles">
          {profiles.map((p) => (
            <button key={p.id} className={`profile${s.profile === p.id ? " on" : ""}`} aria-pressed={s.profile === p.id}
              onClick={() => void save({ profile: p.id, model_id: "", context_length: 0 })}>
              <span className="n">{p.label}</span>
              <span className="d">{p.description}</span>
            </button>
          ))}
        </div>
        {resolved?.error
          ? <div className="note warn">{resolved.error}</div>
          : resolved && (
            <div className="help" style={{ marginTop: 8, fontSize: "var(--text-sm)", color: "var(--text-3)" }}>
              Current selection: {resolved.model_name}, {resolved.context_length?.toLocaleString()} token context
              {resolved.profile ? ` (${status.profiles[resolved.profile]?.label} profile)` : ""}.
            </div>
          )}
        <Field name="Context length"
          help="How much conversation and document text the model can see at once. Larger uses more memory. 0 follows the profile.">
          <Num label="Context length" value={s.context_length} min={0} max={131072} step={1024}
            onCommit={(v) => void save({ context_length: v ?? 0 })} />
        </Field>
        <Field name="GPU layers" help="-1 puts as much of the model on the GPU as fits. 0 forces CPU only.">
          <Num label="GPU layers" value={s.gpu_layers} min={-1} max={999} onCommit={(v) => void save({ gpu_layers: v ?? -1 })} />
        </Field>
        <Field name="Unload when idle" help="Minutes without use before the model is removed from memory. 0 keeps it loaded.">
          <Num label="Idle unload minutes" value={s.idle_unload_minutes} min={0} max={720}
            onCommit={(v) => void save({ idle_unload_minutes: v ?? 0 })} />
        </Field>
      </div>

      <div className="set-group">
        <h4>Models</h4>
        {!status.runtime_installed && (
          <div className="note warn">No local model runtime is responding. Install and start Ollama for Qwen models, or add llama.cpp for GGUF models.</div>
        )}
        {models.map((m) => <ModelCard key={m.id} m={m} activeId={resolved?.model_id ?? ""} />)}
        <div className="note">
          These are unmodified third-party open-weight models, each under its own license. SWAMI is the application
          around them; it does not ship or claim its own trained model. Files are stored in <span className="path">{status.paths.models}</span>
        </div>
      </div>
    </>
  );
}

/* -------------------------------------------------------------- generation */
function Generation({ s, save }: { s: SettingsT; save: Save }) {
  return (
    <>
      <div className="set-group">
        <h4>Sampling</h4>
        <Field name="Temperature" help="Leave empty to use the recommended value for each mode (0.6–1.0).">
          <Num label="Temperature" value={s.temperature} min={0} max={2} step={0.05} placeholder="auto"
            onCommit={(v) => void save({ temperature: v })} />
        </Field>
        <Field name="Top-p" help="Leave empty for the mode default.">
          <Num label="Top-p" value={s.top_p} min={0.05} max={1} step={0.05} placeholder="auto" onCommit={(v) => void save({ top_p: v })} />
        </Field>
        <Field name="Top-k" help="Leave empty for the mode default (20).">
          <Num label="Top-k" value={s.top_k} min={1} max={200} placeholder="auto" onCommit={(v) => void save({ top_k: v })} />
        </Field>
        <Field name="Maximum response length" help="Upper limit in tokens for one reply, including any reasoning.">
          <Num label="Maximum tokens" value={s.max_tokens} min={256} max={32768} step={256}
            onCommit={(v) => void save({ max_tokens: v ?? 4096 })} />
        </Field>
      </div>
      <div className="set-group">
        <h4>Think mode budgets</h4>
        <Field name="Verify answers" help="After answering, run a second independent pass that re-checks logic and recomputes numbers, and rewrite the answer if it finds an error.">
          <Switch checked={s.think_verify} label="Verify answers" onChange={(v) => void save({ think_verify: v })} />
        </Field>
        <Field name="Tool calls per answer" help="Most calculator or Python calls allowed while solving one request.">
          <Num label="Tool calls" value={s.think_max_tool_calls} min={0} max={20} onCommit={(v) => void save({ think_max_tool_calls: v ?? 6 })} />
        </Field>
        <Field name="Time budget (seconds)" help="After this, no new tool calls or checks are started.">
          <Num label="Think time budget" value={s.think_time_budget_s} min={20} max={1800} step={10}
            onCommit={(v) => void save({ think_time_budget_s: v ?? 180 })} />
        </Field>
        <Field name="Reasoning limit per step (tokens)"
          help="Small models can reason in circles and never answer. After this many thinking tokens the engine makes the model stop and answer. 0 = no limit. Applies the next time the model loads.">
          <Num label="Reasoning limit" value={s.think_reasoning_budget} min={0} max={32768} step={256}
            onCommit={(v) => void save({ think_reasoning_budget: v ?? 2048 })} />
        </Field>
        <Field name="Token budget" help="Total tokens the model may generate across planning, solving and checking.">
          <Num label="Think token budget" value={s.think_token_budget} min={1000} max={60000} step={500}
            onCommit={(v) => void save({ think_token_budget: v ?? 8000 })} />
        </Field>
      </div>
    </>
  );
}

/* ---------------------------------------------------------------- api providers */
const CORE_PROVIDER_IDS = new Set([
  "gemini", "openai", "anthropic", "openrouter", "groq", "deepseek", "xai", "ollama", "lmstudio", "custom",
]);

function ApiProviders({ s }: { s: SettingsT; save: Save }) {
  const toast = useStore((st) => st.toast);
  const providers = useStore((st) => st.providers);
  const routableModels = useStore((st) => st.routableModels);
  const usageStats = useStore((st) => st.usageStats);
  const windowsLocalGuide = useStore((st) => st.windowsLocalGuide);
  const refreshProviders = useStore((st) => st.refreshProviders);
  const refreshModels = useStore((st) => st.refreshModels);
  const refreshStatus = useStore((st) => st.refreshStatus);
  const updateRouting = useStore((st) => st.updateRouting);

  const [selectedId, setSelectedId] = useState<string>(() => s.default_provider_id || s.api_provider || "gemini");
  const [nameDraft, setNameDraft] = useState("");
  const [baseUrlDraft, setBaseUrlDraft] = useState("");
  const [protocolDraft, setProtocolDraft] = useState<"openai" | "anthropic" | "gemini">("openai");
  const [defaultModelDraft, setDefaultModelDraft] = useState("");
  const [enabledDraft, setEnabledDraft] = useState(true);
  const [keyDraft, setKeyDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const [testing, setTesting] = useState(false);
  const [discovering, setDiscovering] = useState(false);

  const [showAddCustom, setShowAddCustom] = useState(false);
  const [customName, setCustomName] = useState("");
  const [customUrl, setCustomUrl] = useState("https://");
  const [customProtocol, setCustomProtocol] = useState<"openai" | "anthropic" | "gemini">("openai");
  const [customModel, setCustomModel] = useState("");
  const [customKey, setCustomKey] = useState("");

  const [newModelId, setNewModelId] = useState("");
  const [newModelName, setNewModelName] = useState("");
  const [expandedParamModel, setExpandedParamModel] = useState<string | null>(null);
  const [paramDraft, setParamDraft] = useState<ModelGenerationParams>({});

  const [localStatus, setLocalStatus] = useState<Awaited<ReturnType<typeof api.v1LocalStatus>> | null>(null);
  const [checkingLocal, setCheckingLocal] = useState(false);

  useEffect(() => {
    void refreshProviders();
  }, [refreshProviders]);

  const selected: ProviderConfig | undefined =
    providers.find((p) => p.id === selectedId) ?? providers[0];

  useEffect(() => {
    if (!selected) return;
    if (selected.id !== selectedId) setSelectedId(selected.id);
    setNameDraft(selected.name);
    setBaseUrlDraft(selected.base_url);
    setProtocolDraft(selected.protocol);
    setDefaultModelDraft(selected.default_model);
    setEnabledDraft(selected.enabled);
    setKeyDraft("");
    setExpandedParamModel(null);
  }, [selected?.id, selected?.updated_at]); // eslint-disable-line react-hooks/exhaustive-deps

  const refreshLocal = async () => {
    setCheckingLocal(true);
    try {
      const res = await api.v1LocalStatus();
      setLocalStatus(res);
      await refreshProviders();
    } catch (e) {
      toast(e instanceof Error ? e.message : "Could not check local AI services.", "error");
    } finally {
      setCheckingLocal(false);
    }
  };

  useEffect(() => {
    void api.v1LocalStatus().then(setLocalStatus).catch(() => {});
  }, []);

  const syncAll = async () => {
    await Promise.all([refreshProviders(), refreshModels(), refreshStatus()]);
  };

  const saveSelectedProvider = async () => {
    if (!selected) return;
    setBusy(true);
    try {
      await api.v1SaveProvider({
        id: selected.id,
        preset_id: selected.preset_id,
        name: nameDraft.trim() || selected.name,
        protocol: protocolDraft,
        base_url: baseUrlDraft.trim(),
        enabled: enabledDraft,
        default_model: defaultModelDraft.trim(),
        ...(keyDraft.trim() ? { api_key: keyDraft.trim() } : {}),
      });
      setKeyDraft("");
      await syncAll();
      toast(`Saved ${nameDraft.trim() || selected.name}.`, "success");
    } catch (e) {
      toast(e instanceof Error ? e.message : "Could not save provider.", "error");
    } finally {
      setBusy(false);
    }
  };

  const clearProviderKey = async () => {
    if (!selected) return;
    setBusy(true);
    try {
      await api.v1UpdateProvider(selected.id, { clear_key: true });
      setKeyDraft("");
      await syncAll();
      toast(`Removed stored API key for ${selected.name}.`, "success");
    } catch (e) {
      toast(e instanceof Error ? e.message : "Could not clear API key.", "error");
    } finally {
      setBusy(false);
    }
  };

  const deleteCustomProvider = async () => {
    if (!selected || CORE_PROVIDER_IDS.has(selected.id)) return;
    setBusy(true);
    try {
      const res = await api.v1DeleteProvider(selected.id);
      const nextId = res.providers[0]?.id ?? "gemini";
      setSelectedId(nextId);
      await syncAll();
      toast(`Deleted ${selected.name}.`, "success");
    } catch (e) {
      toast(e instanceof Error ? e.message : "Could not delete provider.", "error");
    } finally {
      setBusy(false);
    }
  };

  const testSelectedProvider = async () => {
    if (!selected) return;
    setTesting(true);
    try {
      const res = await api.v1TestProvider(selected.id, {
        base_url: baseUrlDraft.trim() || undefined,
        ...(keyDraft.trim() ? { api_key: keyDraft.trim() } : {}),
        model: defaultModelDraft.trim() || undefined,
        protocol: protocolDraft as ApiProtocol,
      });
      await refreshProviders();
      toast(`${res.message}${res.latencyMs ? ` (${res.latencyMs} ms)` : ""}`, res.ok ? "success" : "error");
    } catch (e) {
      toast(e instanceof Error ? e.message : "Health probe failed.", "error");
    } finally {
      setTesting(false);
    }
  };

  const discoverSelectedModels = async () => {
    if (!selected) return;
    setDiscovering(true);
    try {
      const res = await api.v1DiscoverProviderModels(selected.id, {
        base_url: baseUrlDraft.trim() || undefined,
        ...(keyDraft.trim() ? { api_key: keyDraft.trim() } : {}),
        protocol: protocolDraft as ApiProtocol,
      });
      await syncAll();
      toast(res.message, res.ok ? "success" : "error");
    } catch (e) {
      toast(e instanceof Error ? e.message : "Model discovery failed.", "error");
    } finally {
      setDiscovering(false);
    }
  };

  const createCustomProvider = async () => {
    if (!customName.trim() || !customUrl.trim()) return;
    setBusy(true);
    try {
      const res = await api.v1SaveProvider({
        preset_id: "custom",
        name: customName.trim(),
        protocol: customProtocol,
        base_url: customUrl.trim(),
        enabled: true,
        default_model: customModel.trim(),
        ...(customKey.trim() ? { api_key: customKey.trim() } : {}),
      });
      setCustomName("");
      setCustomUrl("https://");
      setCustomModel("");
      setCustomKey("");
      setShowAddCustom(false);
      setSelectedId(res.provider.id);
      await syncAll();
      toast(`Added custom provider ${res.provider.name}.`, "success");
    } catch (e) {
      toast(e instanceof Error ? e.message : "Could not add custom provider.", "error");
    } finally {
      setBusy(false);
    }
  };

  const addModelToSelected = async () => {
    if (!selected || !newModelId.trim()) return;
    setBusy(true);
    try {
      await api.v1AddProviderModel(selected.id, {
        model_id: newModelId.trim(),
        name: newModelName.trim() || newModelId.trim(),
      });
      setNewModelId("");
      setNewModelName("");
      await syncAll();
      toast(`Added model ${newModelId.trim()}.`, "success");
    } catch (e) {
      toast(e instanceof Error ? e.message : "Could not add model.", "error");
    } finally {
      setBusy(false);
    }
  };

  const toggleModelEnabled = async (m: ProviderModelConfig) => {
    if (!selected) return;
    try {
      await api.v1UpdateProviderModel(selected.id, { model_id: m.id, enabled: !m.enabled });
      await syncAll();
    } catch (e) {
      toast(e instanceof Error ? e.message : "Could not update model.", "error");
    }
  };

  const saveModelParams = async (modelId: string) => {
    if (!selected) return;
    setBusy(true);
    try {
      await api.v1UpdateProviderModel(selected.id, { model_id: modelId, params: paramDraft });
      await syncAll();
      setExpandedParamModel(null);
      toast(`Updated parameters for ${modelId}.`, "success");
    } catch (e) {
      toast(e instanceof Error ? e.message : "Could not update model parameters.", "error");
    } finally {
      setBusy(false);
    }
  };

  const deleteModelFromSelected = async (modelId: string) => {
    if (!selected) return;
    setBusy(true);
    try {
      await api.v1DeleteProviderModel(selected.id, modelId);
      await syncAll();
      toast(`Removed ${modelId}.`, "success");
    } catch (e) {
      toast(e instanceof Error ? e.message : "Could not remove model.", "error");
    } finally {
      setBusy(false);
    }
  };

  const defaultTarget =
    s.default_provider_id && s.default_model_id ? `${s.default_provider_id}::${s.default_model_id}` : "";
  const fallbackTarget =
    s.fallback_provider_id && s.fallback_model_id ? `${s.fallback_provider_id}::${s.fallback_model_id}` : "";

  const onDefaultTargetChange = (target: string) => {
    if (!target) {
      void updateRouting({ default_provider_id: "", default_model_id: "" });
      return;
    }
    const [pid, ...rest] = target.split("::");
    const mid = rest.join("::");
    void updateRouting({
      default_provider_id: pid,
      default_model_id: mid,
      ...(s.routing_mode === "manual" ? { model_id: target } : {}),
    });
  };

  const onFallbackTargetChange = (target: string) => {
    if (!target) {
      void updateRouting({ fallback_provider_id: "", fallback_model_id: "" });
      return;
    }
    const [pid, ...rest] = target.split("::");
    const mid = rest.join("::");
    void updateRouting({ fallback_provider_id: pid, fallback_model_id: mid });
  };

  return (
    <>
      {/* 1. Provider Directory */}
      <div className="set-group">
        <div className="row-head">
          <h4>Providers ({providers.length})</h4>
          <button
            type="button"
            className="btn sm"
            onClick={() => setShowAddCustom((v) => !v)}
          >
            <Plus size={14} /> Add custom endpoint
          </button>
        </div>
        <div className="note" style={{ marginTop: 6 }}>
          Configure cloud APIs (Gemini, OpenAI, Claude, OpenRouter, Groq, DeepSeek, xAI) and local servers (Ollama, LM Studio). Keys are encrypted at rest on the server and never returned to the UI.
        </div>

        {showAddCustom && (
          <div className="provider-custom-box">
            <div className="provider-custom-grid">
              <input
                className="input"
                placeholder="Display name (e.g. Together AI)"
                aria-label="Custom provider name"
                value={customName}
                onChange={(e) => setCustomName(e.target.value)}
              />
              <input
                className="input"
                placeholder="Base URL (https://api.example.com/v1)"
                aria-label="Custom provider base URL"
                value={customUrl}
                onChange={(e) => setCustomUrl(e.target.value)}
              />
              <select
                className="select"
                aria-label="Custom provider protocol"
                value={customProtocol}
                onChange={(e) => setCustomProtocol(e.target.value as "openai" | "anthropic" | "gemini")}
              >
                <option value="openai">OpenAI-compatible</option>
                <option value="anthropic">Anthropic Messages</option>
                <option value="gemini">Google Gemini SDK</option>
              </select>
              <input
                className="input"
                placeholder="Default model ID (optional)"
                aria-label="Custom provider default model"
                value={customModel}
                onChange={(e) => setCustomModel(e.target.value)}
              />
              <input
                className="input"
                type="password"
                autoComplete="new-password"
                placeholder="API key (optional for local)"
                aria-label="Custom provider API key"
                value={customKey}
                onChange={(e) => setCustomKey(e.target.value)}
              />
            </div>
            <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
              <button
                type="button"
                className="btn sm primary"
                disabled={busy || !customName.trim() || !customUrl.trim()}
                onClick={() => void createCustomProvider()}
              >
                Save custom provider
              </button>
              <button type="button" className="btn sm" onClick={() => setShowAddCustom(false)}>
                Cancel
              </button>
            </div>
          </div>
        )}

        <div className="provider-tab-grid" role="tablist" aria-label="Configured AI providers">
          {providers.map((p) => (
            <button
              key={p.id}
              type="button"
              role="tab"
              aria-selected={selected?.id === p.id}
              className={`provider-tab${selected?.id === p.id ? " on" : ""}`}
              onClick={() => setSelectedId(p.id)}
            >
              <div className="p-top">
                <span className="p-name">{p.name}</span>
                <span className={`health-label ${p.health_status}`}>{p.health_status}</span>
              </div>
              <div className="p-meta">
                <span>{p.is_local ? "Local" : "Cloud"}</span>
                <span>·</span>
                <span>{p.key_configured ? "Key saved" : p.is_local ? "No key needed" : "No key"}</span>
                {p.last_latency_ms != null && (
                  <>
                    <span>·</span>
                    <span className="tabular">{p.last_latency_ms} ms</span>
                  </>
                )}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* 2. Selected Provider Configuration */}
      {selected && (
        <div className="set-group">
          <div className="row-head">
            <h4>{selected.name} configuration</h4>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span className={`health-label ${selected.health_status}`}>{selected.health_status}</span>
              {selected.health_message && (
                <span className="help" style={{ fontSize: 12 }}>{selected.health_message}</span>
              )}
            </div>
          </div>

          <Field name="Enable provider" help="Disabled providers are excluded from routing, Auto Model, and comparisons.">
            <Switch
              checked={enabledDraft}
              label={`Enable ${selected.name}`}
              onChange={(v) => setEnabledDraft(v)}
            />
          </Field>

          <Field name="Display name">
            <input
              className="input"
              style={{ width: 280 }}
              aria-label="Provider display name"
              value={nameDraft}
              onChange={(e) => setNameDraft(e.target.value)}
            />
          </Field>

          <Field name="Base URL" help="Remote providers require HTTPS. Localhost/127.0.0.1 permitted for Ollama/LM Studio.">
            <input
              className="input"
              style={{ width: 320 }}
              aria-label="Provider base URL"
              value={baseUrlDraft}
              onChange={(e) => setBaseUrlDraft(e.target.value)}
            />
          </Field>

          <Field name="Protocol">
            <select
              className="select"
              style={{ width: 220 }}
              aria-label="Provider protocol"
              value={protocolDraft}
              onChange={(e) => setProtocolDraft(e.target.value as "openai" | "anthropic" | "gemini")}
            >
              <option value="openai">OpenAI-compatible</option>
              <option value="anthropic">Anthropic Messages</option>
              <option value="gemini">Google Gemini SDK</option>
            </select>
          </Field>

          <Field
            name="API key"
            help={
              selected.key_configured
                ? "Encrypted key saved on server. Paste a new key only to replace it."
                : selected.is_local
                  ? "Optional for local servers unless authentication is enabled."
                  : "Encrypted with AES-256-GCM at rest; never sent back to the browser."
            }
          >
            <input
              className="input"
              style={{ width: 300 }}
              type="password"
              autoComplete="new-password"
              aria-label={`${selected.name} API key`}
              value={keyDraft}
              placeholder={selected.key_configured ? "Saved — enter a new key to replace" : "Paste API key"}
              onChange={(e) => setKeyDraft(e.target.value)}
            />
          </Field>

          <Field name="Default model ID" help="Primary model used when this provider is selected.">
            <input
              className="input"
              style={{ width: 280 }}
              aria-label="Provider default model ID"
              value={defaultModelDraft}
              placeholder="e.g. gemini-2.5-flash, gpt-4.1-mini"
              onChange={(e) => setDefaultModelDraft(e.target.value)}
            />
          </Field>

          <div style={{ display: "flex", gap: 8, marginTop: 12, flexWrap: "wrap" }}>
            <button
              type="button"
              className="btn primary"
              disabled={busy}
              onClick={() => void saveSelectedProvider()}
            >
              {busy ? "Saving…" : "Save provider & key"}
            </button>
            <button
              type="button"
              className="btn"
              disabled={testing || (!selected.is_local && s.offline_mode)}
              onClick={() => void testSelectedProvider()}
            >
              {testing ? "Testing…" : "Test connection"}
            </button>
            <button
              type="button"
              className="btn"
              disabled={discovering || (!selected.is_local && s.offline_mode)}
              onClick={() => void discoverSelectedModels()}
            >
              {discovering ? "Discovering…" : "Discover models"}
            </button>
            {selected.key_configured && (
              <button type="button" className="btn danger" disabled={busy} onClick={() => void clearProviderKey()}>
                Clear key
              </button>
            )}
            {!CORE_PROVIDER_IDS.has(selected.id) && (
              <button type="button" className="btn danger" disabled={busy} onClick={() => void deleteCustomProvider()}>
                Delete provider
              </button>
            )}
          </div>

          {s.offline_mode && !selected.is_local && (
            <div className="help warn" style={{ marginTop: 8 }}>
              Offline mode blocks cloud requests. Local providers (Ollama / LM Studio) remain available.
            </div>
          )}

          {/* 3. Models on selected provider */}
          <div style={{ marginTop: 20 }}>
            <div className="row-head">
              <h4>Models on {selected.name} ({selected.models.length})</h4>
            </div>

            {selected.models.length === 0 ? (
              <div className="note" style={{ marginTop: 8 }}>
                {selected.is_local
                  ? "No local models discovered yet. Start Ollama or LM Studio and click Discover models."
                  : "No models listed yet. Click Discover models or add a model ID below."}
              </div>
            ) : (
              <div className="provider-model-list">
                {selected.models.map((m) => {
                  const target = `${selected.id}::${m.id}`;
                  const isDefault = defaultTarget === target;
                  const isFallback = fallbackTarget === target;
                  const isExpanded = expandedParamModel === m.id;
                  const capSummary = m.capabilities.verified
                    ? [
                        m.capabilities.vision ? "Vision" : "",
                        m.capabilities.reasoning ? "Reasoning" : "",
                        m.capabilities.tools ? "Tools" : "",
                        m.capabilities.context_length ? `${Math.round(m.capabilities.context_length / 1000)}k ctx` : "",
                      ].filter(Boolean).join(" · ") || "Text"
                    : "Unverified capabilities";

                  return (
                    <div key={m.id} className="provider-model-row">
                      <div className="pm-main">
                        <div className="pm-info">
                          <div className="pm-title">
                            <span>{m.name}</span>
                            {m.name !== m.id && <span className="pm-id">{m.id}</span>}
                            {m.custom && <span className="tag">Custom</span>}
                            {isDefault && <span className="tag gold">Default</span>}
                            {isFallback && <span className="tag">Fallback</span>}
                          </div>
                          <div className="pm-caps">{capSummary}</div>
                        </div>
                        <div className="pm-actions">
                          <button
                            type="button"
                            className="btn sm ghost"
                            onClick={() => {
                              if (isExpanded) {
                                setExpandedParamModel(null);
                              } else {
                                setExpandedParamModel(m.id);
                                setParamDraft(m.params ?? {});
                              }
                            }}
                          >
                            {isExpanded ? <ChevronDown size={13} /> : <ChevronRight size={13} />}
                            Params
                          </button>
                          <button
                            type="button"
                            className="btn sm"
                            disabled={isDefault || !m.enabled}
                            onClick={() => onDefaultTargetChange(target)}
                          >
                            {isDefault ? "Default" : "Set default"}
                          </button>
                          <button
                            type="button"
                            className="btn sm"
                            disabled={isFallback || !m.enabled}
                            onClick={() => onFallbackTargetChange(target)}
                          >
                            {isFallback ? "Fallback" : "Set fallback"}
                          </button>
                          <Switch
                            checked={m.enabled}
                            label={`Enable ${m.name}`}
                            onChange={() => void toggleModelEnabled(m)}
                          />
                          <button
                            type="button"
                            className="icon-btn sm"
                            aria-label={`Delete model ${m.name}`}
                            title="Delete model"
                            onClick={() => void deleteModelFromSelected(m.id)}
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </div>

                      {isExpanded && (
                        <div className="param-grid">
                          <label>
                            <span>Temperature</span>
                            <input
                              className="input num"
                              type="number"
                              step="0.05"
                              min={0}
                              max={2}
                              placeholder="default"
                              value={paramDraft.temperature ?? ""}
                              onChange={(e) =>
                                setParamDraft((d) => ({
                                  ...d,
                                  temperature: e.target.value === "" ? null : Number(e.target.value),
                                }))
                              }
                            />
                          </label>
                          <label>
                            <span>Top-p</span>
                            <input
                              className="input num"
                              type="number"
                              step="0.05"
                              min={0}
                              max={1}
                              placeholder="default"
                              value={paramDraft.top_p ?? ""}
                              onChange={(e) =>
                                setParamDraft((d) => ({
                                  ...d,
                                  top_p: e.target.value === "" ? null : Number(e.target.value),
                                }))
                              }
                            />
                          </label>
                          <label>
                            <span>Max tokens</span>
                            <input
                              className="input num"
                              type="number"
                              step={128}
                              min={64}
                              max={131072}
                              placeholder="default"
                              value={paramDraft.max_tokens ?? ""}
                              onChange={(e) =>
                                setParamDraft((d) => ({
                                  ...d,
                                  max_tokens: e.target.value === "" ? null : Number(e.target.value),
                                }))
                              }
                            />
                          </label>
                          <label>
                            <span>Timeout (ms)</span>
                            <input
                              className="input num"
                              type="number"
                              step={1000}
                              min={2000}
                              max={600000}
                              placeholder="default"
                              value={paramDraft.timeout_ms ?? ""}
                              onChange={(e) =>
                                setParamDraft((d) => ({
                                  ...d,
                                  timeout_ms: e.target.value === "" ? null : Number(e.target.value),
                                }))
                              }
                            />
                          </label>
                          <div style={{ display: "flex", alignItems: "flex-end" }}>
                            <button
                              type="button"
                              className="btn sm primary"
                              disabled={busy}
                              onClick={() => void saveModelParams(m.id)}
                            >
                              Save params
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}

            <div style={{ display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" }}>
              <input
                className="input"
                style={{ width: 220 }}
                placeholder="Model ID (e.g. gpt-4.1)"
                aria-label="New model ID"
                value={newModelId}
                onChange={(e) => setNewModelId(e.target.value)}
              />
              <input
                className="input"
                style={{ width: 200 }}
                placeholder="Display name (optional)"
                aria-label="New model display name"
                value={newModelName}
                onChange={(e) => setNewModelName(e.target.value)}
              />
              <button
                type="button"
                className="btn sm"
                disabled={busy || !newModelId.trim()}
                onClick={() => void addModelToSelected()}
              >
                <Plus size={14} /> Add model
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 4. Routing & Failover */}
      <div className="set-group">
        <h4>Routing &amp; failover</h4>
        <Field name="Routing mode" help="Auto picks a configured model per task and announces the selection visibly.">
          <Choice<RoutingMode>
            value={s.routing_mode ?? "manual"}
            options={[
              { id: "manual", label: "Manual" },
              { id: "auto", label: "Auto Model" },
            ]}
            onChange={(routing_mode) =>
              void updateRouting({
                routing_mode,
                model_id: routing_mode === "auto" ? "auto" : (defaultTarget || s.model_id),
              })
            }
          />
        </Field>

        <Field name="Auto preference" help="Tie-breaker used when Auto Model chooses across healthy providers.">
          <Choice<RoutingPreference>
            value={s.routing_preference ?? "balanced"}
            options={[
              { id: "balanced", label: "Balanced" },
              { id: "fastest", label: "Fastest" },
              { id: "capability", label: "Capability" },
              { id: "lowest_cost", label: "Lowest cost" },
            ]}
            onChange={(routing_preference) => void updateRouting({ routing_preference })}
          />
        </Field>

        <Field name="Default model" help="Used first in Manual mode and as anchor when Auto Mode scores peers.">
          <select
            className="select"
            style={{ width: 300 }}
            aria-label="Default routable model"
            value={defaultTarget}
            onChange={(e) => onDefaultTargetChange(e.target.value)}
          >
            <option value="">None selected</option>
            {routableModels.map((opt) => (
              <option key={opt.target} value={opt.target}>
                {opt.provider_name} · {opt.model_name} ({opt.is_local ? "Local" : "Cloud"})
              </option>
            ))}
          </select>
        </Field>

        <Field
          name="Fallback model"
          help="If the primary model fails before producing tokens, SWAMI retries once or switches explicitly with a visible banner."
        >
          <select
            className="select"
            style={{ width: 300 }}
            aria-label="Fallback routable model"
            value={fallbackTarget}
            onChange={(e) => onFallbackTargetChange(e.target.value)}
          >
            <option value="">None (fail directly)</option>
            {routableModels.map((opt) => (
              <option key={opt.target} value={opt.target}>
                {opt.provider_name} · {opt.model_name} ({opt.is_local ? "Local" : "Cloud"})
              </option>
            ))}
          </select>
        </Field>

        <Field name="Request timeout (ms)" help="Maximum wait before timing out an unresponsive provider stream.">
          <Num
            label="Request timeout ms"
            value={s.request_timeout_ms ?? 90000}
            min={5000}
            max={600000}
            step={5000}
            onCommit={(v) => void updateRouting({ request_timeout_ms: v ?? 90000 })}
          />
        </Field>
      </div>

      {/* 5. Local AI (Ollama & LM Studio) */}
      <div className="set-group">
        <div className="row-head">
          <h4>Local AI (Ollama &amp; LM Studio)</h4>
          <button
            type="button"
            className="btn sm"
            disabled={checkingLocal}
            onClick={() => void refreshLocal()}
          >
            <RefreshCw size={13} className={checkingLocal ? "spin" : ""} />
            {checkingLocal ? "Checking…" : "Refresh status"}
          </button>
        </div>

        <div className="hw-grid" style={{ gridTemplateColumns: "1fr 1fr" }}>
          <div>
            <div className="k">Ollama ({localStatus?.ollama?.provider.base_url ?? "http://127.0.0.1:11434"})</div>
            <div className="v" style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 2 }}>
              <span className={`health-label ${localStatus?.ollama?.reachable ? "healthy" : "unreachable"}`}>
                {localStatus?.ollama?.reachable ? "reachable" : "unreachable"}
              </span>
              {localStatus?.ollama?.latencyMs != null && (
                <span className="s">{localStatus.ollama.latencyMs} ms</span>
              )}
            </div>
            <div className="s" style={{ marginTop: 3 }}>
              {localStatus?.ollama?.reachable
                ? `${localStatus.ollama.provider.models.length} installed model(s)`
                : (localStatus?.ollama?.message ?? "Not checked yet")}
            </div>
          </div>

          <div>
            <div className="k">LM Studio ({localStatus?.lmstudio?.provider.base_url ?? "http://127.0.0.1:1234/v1"})</div>
            <div className="v" style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 2 }}>
              <span className={`health-label ${localStatus?.lmstudio?.reachable ? "healthy" : "unreachable"}`}>
                {localStatus?.lmstudio?.reachable ? "reachable" : "unreachable"}
              </span>
              {localStatus?.lmstudio?.latencyMs != null && (
                <span className="s">{localStatus.lmstudio.latencyMs} ms</span>
              )}
            </div>
            <div className="s" style={{ marginTop: 3 }}>
              {localStatus?.lmstudio?.reachable
                ? `${localStatus.lmstudio.provider.models.length} loaded model(s)`
                : (localStatus?.lmstudio?.message ?? "Not checked yet")}
            </div>
          </div>
        </div>

        {windowsLocalGuide && (
          <details className="local-guide">
            <summary>{windowsLocalGuide.title}</summary>
            <div className="local-guide-body">
              <div>
                <strong>Ollama ({windowsLocalGuide.ollama.default_url})</strong>
                <ul>
                  {windowsLocalGuide.ollama.steps.map((step, idx) => <li key={idx}>{step}</li>)}
                </ul>
                <code className="guide-code">{windowsLocalGuide.ollama.env_example}</code>
              </div>
              <div>
                <strong>LM Studio ({windowsLocalGuide.lmstudio.default_url})</strong>
                <ul>
                  {windowsLocalGuide.lmstudio.steps.map((step, idx) => <li key={idx}>{step}</li>)}
                </ul>
              </div>
              <div className="note" style={{ marginTop: 4 }}>{windowsLocalGuide.security_note}</div>
            </div>
          </details>
        )}
      </div>

      {/* 6. Usage & Latency Stats */}
      <div className="set-group">
        <h4>Usage &amp; latency stats (last 7 days)</h4>
        {usageStats.length === 0 ? (
          <div className="note" style={{ marginTop: 8 }}>
            No provider requests recorded yet. Send a message or run a comparison to track latency and tokens.
          </div>
        ) : (
          <div className="table-wrap" style={{ marginTop: 10 }}>
            <table className="stats-table tabular">
              <thead>
                <tr>
                  <th>Provider</th>
                  <th>Model</th>
                  <th>Requests</th>
                  <th>Ok / Err</th>
                  <th>Avg TTFT</th>
                  <th>Avg Total</th>
                  <th>Tokens (in / out)</th>
                </tr>
              </thead>
              <tbody>
                {usageStats.map((u) => (
                  <tr key={`${u.provider_id}::${u.model_id}`}>
                    <td>{u.provider_id}</td>
                    <td>{u.model_id}</td>
                    <td>{u.requests}</td>
                    <td>{u.successes} / {u.errors}</td>
                    <td>{u.avg_first_token_ms ? `${Math.round(u.avg_first_token_ms)} ms` : "—"}</td>
                    <td>{u.avg_total_ms ? `${Math.round(u.avg_total_ms)} ms` : "—"}</td>
                    <td>{u.total_prompt_tokens} / {u.total_completion_tokens}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
}

/* ---------------------------------------------------------------- research */
function Research({ s, save }: { s: SettingsT; save: Save }) {
  const online = useStore((st) => st.online);
  return (
    <>
      <div className="set-group">
        <h4>Web access</h4>
        <Field name="Allow Deep Research to use the internet"
          help="Only Deep Research goes online. It sends your search queries to the search provider and downloads the pages it reads. Fast and Think never use the network."
          warn={s.offline_mode ? "Offline mode is on (Privacy & data), so this has no effect right now." : undefined}>
          <Switch checked={s.web_research_enabled} label="Allow web research" onChange={(v) => void save({ web_research_enabled: v })} />
        </Field>
        <div className="note">
          Connection right now: {s.offline_mode ? "blocked by offline mode" : online == null ? "checking…" : online ? "internet reachable" : "no internet detected"}.
        </div>
      </div>
      <div className="set-group">
        <h4>Search provider</h4>
        <Field name="Provider" col
          help={{
            duckduckgo: "DuckDuckGo — no account or key needed. An unofficial interface, so it can be rate-limited during heavy use.",
            searxng: "SearXNG — your own self-hosted metasearch instance. Most private; you run it yourself.",
            brave: "Brave Search API — official API with a free tier; needs your own key. The key is stored only in the local database.",
          }[s.search_provider]}>
          <Choice value={s.search_provider} onChange={(search_provider) => void save({ search_provider })}
            options={[{ id: "duckduckgo", label: "DuckDuckGo" }, { id: "searxng", label: "SearXNG" }, { id: "brave", label: "Brave API" }]} />
        </Field>
        {s.search_provider === "searxng" && (
          <Field name="SearXNG address" help="Must have the JSON output format enabled.">
            <Text label="SearXNG address" value={s.searxng_url} placeholder="http://localhost:8080" onCommit={(v) => void save({ searxng_url: v })} />
          </Field>
        )}
        {s.search_provider === "brave" && (
          <Field
            name="Brave API key"
            help={s.brave_key_configured ? "Key saved securely on the server. Paste a new key to replace it." : undefined}
          >
            <Text
              label="Brave API key"
              type="password"
              value={s.brave_api_key}
              placeholder={s.brave_key_configured ? "Saved — paste a new key to replace" : "Paste your key"}
              onCommit={(v) => {
                if (v.trim()) void save({ brave_api_key: v.trim() });
              }}
            />
          </Field>
        )}
      </div>
      <div className="set-group">
        <h4>Depth</h4>
        <Field name="Sources to read" help="Pages fetched and analysed per report. More is slower but broader.">
          <Num label="Sources to read" value={s.research_max_sources} min={2} max={15} onCommit={(v) => void save({ research_max_sources: v ?? 8 })} />
        </Field>
        <Field name="Search rounds" help="With 2 or more, the model checks for gaps and searches again if evidence is thin.">
          <Num label="Search rounds" value={s.research_max_rounds} min={1} max={3} onCommit={(v) => void save({ research_max_rounds: v ?? 2 })} />
        </Field>
        <Field name="Time budget (seconds)">
          <Num label="Research time budget" value={s.research_time_budget_s} min={60} max={1800} step={30}
            onCommit={(v) => void save({ research_time_budget_s: v ?? 300 })} />
        </Field>
      </div>
    </>
  );
}

/* ------------------------------------------------------------------- tools */
function Tools({ s, save }: { s: SettingsT; save: Save }) {
  return (
    <div className="set-group">
      <h4>Tools the model can use</h4>
      <Field name="Calculator" help="Exact arithmetic evaluated by Python instead of by the model. Always available in Fast and Think.">
        <span className="tag gold">Always on</span>
      </Field>
      <Field name="Document reading" help="Text, code, CSV, JSON, PDF and DOCX files you attach are indexed locally and quoted to the model. Scanned PDFs need OCR, which is not installed.">
        <span className="tag gold">Always on</span>
      </Field>
      <Field name="Web search and page reading" help="Used only by Deep Research. Configure it under Research.">
        <span className="tag">{s.web_research_enabled && !s.offline_mode ? "Enabled" : "Off"}</span>
      </Field>
      <Field name="Run Python code (Think mode)"
        help="Lets the model write and run short Python scripts for multi-step calculations and data work."
        warn="This is not a security sandbox. Scripts run as your Windows user with a 15-second limit in a temporary folder. Leave it off unless you want this.">
        <Switch checked={s.python_tool_enabled} label="Run Python code" onChange={(v) => void save({ python_tool_enabled: v })} />
      </Field>
      <Field name="External tool servers (MCP)" help="Optional MCP integration is not implemented in this SWAMI build.">
        <span className="tag">Not available</span>
      </Field>
    </div>
  );
}

/* ------------------------------------------------------------------ memory */
const MEMORY_CATEGORY_OPTIONS: { id: MemoryCategory; label: string }[] = [
  { id: "preference", label: "User preferences" },
  { id: "project", label: "Projects" },
  { id: "instruction", label: "Instructions" },
  { id: "fact", label: "Important facts" },
  { id: "learning", label: "Learning context" },
  { id: "general", label: "General knowledge" },
];

function MemorySection({ s, save }: { s: SettingsT; save: Save }) {
  const projects = useStore((st) => st.projects);
  const toast = useStore((st) => st.toast);

  const [items, setItems] = useState<Memory[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [projectFilter, setProjectFilter] = useState<string>("all");

  const [draft, setDraft] = useState("");
  const [draftCategory, setDraftCategory] = useState<MemoryCategory>("preference");
  const [draftProjectId, setDraftProjectId] = useState<string>("");

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState("");
  const [editCategory, setEditCategory] = useState<MemoryCategory>("general");
  const [editProjectId, setEditProjectId] = useState<string>("");

  const [conflictAlert, setConflictAlert] = useState<{ id: string; content: string; newId: string } | null>(null);
  const [confirmClear, setConfirmClear] = useState(false);
  const importInputRef = useRef<HTMLInputElement>(null);

  const load = async (q = searchQuery, category = categoryFilter, projectId = projectFilter) => {
    try {
      const res = await api.memories({
        q: q.trim() || undefined,
        category,
        project_id: projectId,
      });
      setItems(res.memories);
    } catch (e) {
      toast(e instanceof Error ? e.message : "Failed to load memories.", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchQuery, categoryFilter, projectFilter]);

  const handleAdd = async () => {
    const content = draft.trim();
    if (!content) return;
    try {
      const created = await api.addMemory(content, {
        category: draftCategory,
        project_id: draftProjectId || null,
      });
      setDraft("");
      if (created.conflict) {
        setConflictAlert({ id: created.conflict.id, content: created.conflict.content, newId: created.id });
        toast("Memory saved with conflict warning.", "info");
      } else {
        setConflictAlert(null);
        toast("Memory saved.", "success");
      }
      await load();
    } catch (e) {
      toast(e instanceof Error ? e.message : "Could not add memory.", "error");
    }
  };

  const handleSaveEdit = async (id: string) => {
    const content = editText.trim();
    if (!content) return;
    try {
      await api.updateMemory(id, {
        content,
        category: editCategory,
        project_id: editProjectId || null,
      });
      setEditingId(null);
      toast("Memory updated.", "success");
      await load();
    } catch (e) {
      toast(e instanceof Error ? e.message : "Could not update memory.", "error");
    }
  };

  const handleImportFile = async (file: File | undefined) => {
    if (!file) return;
    try {
      const rawText = await file.text();
      const parsed = JSON.parse(rawText) as unknown;
      const list = Array.isArray(parsed)
        ? parsed
        : parsed && typeof parsed === "object" && Array.isArray((parsed as { memories?: unknown }).memories)
          ? (parsed as { memories: unknown[] }).memories
          : null;
      if (!list) {
        toast("Invalid file format. Expected a JSON array or { memories: [...] }.", "error");
        return;
      }
      const res = await api.importMemories(list);
      toast(`Imported ${res.imported} memory item(s)${res.skipped ? ` (${res.skipped} duplicate/empty skipped)` : ""}.`, "success");
      await load();
    } catch (e) {
      toast(e instanceof Error ? e.message : "Could not import memories.", "error");
    } finally {
      if (importInputRef.current) importInputRef.current.value = "";
    }
  };

  const projectName = (pid: string | null) => projects.find((p) => p.id === pid)?.name ?? "Project";

  return (
    <>
      <div className="set-group">
        <h4>Long-term memory</h4>
        <Field name="Use memory"
          help="Relevant saved facts and project context are retrieved across conversations. Everything is persisted in the local database.">
          <Switch checked={s.memory_enabled} label="Use memory" onChange={(v) => void save({ memory_enabled: v })} />
        </Field>
        <Field name="Automatic memory suggestions"
          help="Detect preferences, instructions, project context, and personal facts during chat and ask for your approval before saving.">
          <Switch
            checked={s.memory_auto_suggest}
            label="Automatic memory suggestions"
            onChange={(v) => void save({ memory_auto_suggest: v })}
          />
        </Field>
      </div>

      <div className="set-group">
        <h4>Add memory</h4>
        <div style={{ display: "grid", gap: 8, marginTop: 8 }}>
          <div style={{ display: "flex", gap: 8 }}>
            <input
              className="input"
              style={{ flex: 1 }}
              value={draft}
              maxLength={400}
              aria-label="New memory"
              placeholder="Add something to remember, e.g. “Prefers answers in Hinglish”"
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && draft.trim()) void handleAdd();
              }}
            />
            <button className="btn primary" disabled={!draft.trim()} onClick={() => void handleAdd()}>
              <Plus size={14} /> Add
            </button>
          </div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <select
              className="select"
              aria-label="New memory category"
              value={draftCategory}
              onChange={(e) => setDraftCategory(e.target.value as MemoryCategory)}
            >
              {MEMORY_CATEGORY_OPTIONS.map((c) => (
                <option key={c.id} value={c.id}>{c.label}</option>
              ))}
            </select>
            <select
              className="select"
              aria-label="New memory project scope"
              value={draftProjectId}
              onChange={(e) => setDraftProjectId(e.target.value)}
            >
              <option value="">Global (all conversations)</option>
              {projects.map((p) => (
                <option key={p.id} value={p.id}>Project: {p.name}</option>
              ))}
            </select>
          </div>
        </div>
        {conflictAlert && (
          <div className="note warn" style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
            <span style={{ flex: 1 }}>
              Possible conflict with existing memory: “{conflictAlert.content}”
            </span>
            <button
              className="btn sm"
              onClick={() => {
                void api.deleteMemory(conflictAlert.id).then(() => {
                  setConflictAlert(null);
                  toast("Replaced conflicting memory.", "success");
                  return load();
                });
              }}
            >
              Remove older memory
            </button>
            <button className="btn sm ghost" onClick={() => setConflictAlert(null)}>
              Keep both
            </button>
          </div>
        )}
      </div>

      <div className="set-group">
        <h4>Saved memories ({items.length})</h4>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 8, marginBottom: 8 }}>
          <div style={{ position: "relative", flex: 1, minWidth: 180, display: "flex", alignItems: "center" }}>
            <Search size={14} style={{ position: "absolute", left: 10, color: "var(--text-3)", pointerEvents: "none" }} />
            <input
              className="input"
              style={{ width: "100%", paddingLeft: 30 }}
              value={searchQuery}
              aria-label="Search memories"
              placeholder="Search memories…"
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <select
            className="select"
            aria-label="Filter by category"
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
          >
            <option value="all">All categories</option>
            {MEMORY_CATEGORY_OPTIONS.map((c) => (
              <option key={c.id} value={c.id}>{c.label}</option>
            ))}
          </select>
          <select
            className="select"
            aria-label="Filter by project"
            value={projectFilter}
            onChange={(e) => setProjectFilter(e.target.value)}
          >
            <option value="all">All scopes</option>
            <option value="global">Global only</option>
            {projects.map((p) => (
              <option key={p.id} value={p.id}>Project: {p.name}</option>
            ))}
          </select>
        </div>

        {loading ? (
          <div className="sb-empty" style={{ padding: "14px 0" }}>Loading memories…</div>
        ) : items.length === 0 ? (
          <div className="sb-empty" style={{ padding: "14px 0" }}>
            {searchQuery || categoryFilter !== "all" || projectFilter !== "all"
              ? "No memories match the active filter."
              : "Nothing saved yet."}
          </div>
        ) : null}

        {items.map((m) => (
          <div key={m.id} className="mem-row" style={{ alignItems: "flex-start" }}>
            {editingId === m.id ? (
              <div style={{ flex: 1, display: "grid", gap: 6 }}>
                <input
                  className="input"
                  style={{ width: "100%" }}
                  autoFocus
                  value={editText}
                  maxLength={400}
                  aria-label="Edit memory"
                  onChange={(e) => setEditText(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") void handleSaveEdit(m.id);
                    if (e.key === "Escape") setEditingId(null);
                  }}
                />
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                  <select
                    className="select"
                    aria-label="Edit memory category"
                    value={editCategory}
                    onChange={(e) => setEditCategory(e.target.value as MemoryCategory)}
                  >
                    {MEMORY_CATEGORY_OPTIONS.map((c) => (
                      <option key={c.id} value={c.id}>{c.label}</option>
                    ))}
                  </select>
                  <select
                    className="select"
                    aria-label="Edit memory project"
                    value={editProjectId}
                    onChange={(e) => setEditProjectId(e.target.value)}
                  >
                    <option value="">Global</option>
                    {projects.map((p) => (
                      <option key={p.id} value={p.id}>Project: {p.name}</option>
                    ))}
                  </select>
                  <button className="btn sm primary" onClick={() => void handleSaveEdit(m.id)}>Save</button>
                  <button className="btn sm ghost" onClick={() => setEditingId(null)}>Cancel</button>
                </div>
              </div>
            ) : (
              <div className={`text${m.enabled ? "" : " off"}`}>
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center", marginBottom: 4 }}>
                  <span className="tag">{MEMORY_CATEGORY_OPTIONS.find((c) => c.id === m.category)?.label ?? m.category}</span>
                  {m.project_id && <span className="tag gold">Project: {projectName(m.project_id)}</span>}
                  {m.conflict_with && <span className="tag" style={{ color: "var(--warn)" }}>Conflict detected</span>}
                </div>
                <div>{m.content}</div>
                <div className="src">
                  {m.source === "assistant" ? "Saved by assistant" : m.source === "import" ? "Imported" : "Added by you"}
                  {" · "}Updated {new Date((m.updated_at || m.created_at) * 1000).toLocaleString()}
                </div>
              </div>
            )}
            <div style={{ display: "flex", alignItems: "center", gap: 6, flex: "none" }}>
              {editingId !== m.id && (
                <button
                  className="icon-btn sm"
                  aria-label={`Edit memory: ${m.content}`}
                  title="Edit"
                  onClick={() => {
                    setEditingId(m.id);
                    setEditText(m.content);
                    setEditCategory(m.category || "general");
                    setEditProjectId(m.project_id || "");
                  }}
                >
                  <Pencil size={14} />
                </button>
              )}
              <Switch
                checked={!!m.enabled}
                label={`Use memory: ${m.content}`}
                onChange={(v) => void api.updateMemory(m.id, { enabled: v }).then(() => load())}
              />
              <button
                className="icon-btn sm"
                aria-label={`Delete memory: ${m.content}`}
                title="Delete"
                onClick={() => void api.deleteMemory(m.id).then(() => load())}
              >
                <Trash2 size={15} />
              </button>
            </div>
          </div>
        ))}

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 14 }}>
          {items.length > 0 && (
            confirmClear ? (
              <>
                <button
                  className="btn sm danger"
                  onClick={() => {
                    setConfirmClear(false);
                    void api.clearMemories().then(() => {
                      toast("All memories deleted.", "success");
                      return load();
                    });
                  }}
                >
                  Yes, delete all {items.length}
                </button>
                <button className="btn sm ghost" onClick={() => setConfirmClear(false)}>Cancel</button>
              </>
            ) : (
              <button className="btn sm danger" onClick={() => setConfirmClear(true)}>Delete all memories</button>
            )
          )}
          <a className="btn sm" href="/api/memory/export">
            <Download size={14} /> Export memories
          </a>
          <input
            ref={importInputRef}
            type="file"
            accept=".json,application/json"
            style={{ display: "none" }}
            aria-label="Import memories JSON file"
            onChange={(e) => void handleImportFile(e.target.files?.[0])}
          />
          <button className="btn sm" onClick={() => importInputRef.current?.click()}>
            <Upload size={14} /> Import memories
          </button>
        </div>
      </div>
    </>
  );
}

/* ----------------------------------------------------------------- privacy */
function Privacy({ s, save }: { s: SettingsT; save: Save }) {
  const status = useStore((st) => st.status);
  const newChat = useStore((st) => st.newChat);
  const refresh = useStore((st) => st.refreshConversations);
  const toast = useStore((st) => st.toast);
  const [confirm, setConfirm] = useState(false);
  return (
    <>
      <div className="set-group">
        <h4>Network</h4>
        <Field name="Offline mode" help="Blocks every network feature: Deep Research and model downloads. Chat, Think, documents and memory keep working.">
          <Switch checked={s.offline_mode} label="Offline mode" onChange={(v) => void save({ offline_mode: v })} />
        </Field>
        <Field name="Web research" help="Allow Deep Research to search and read web pages.">
          <Switch checked={s.web_research_enabled} label="Web research" onChange={(v) => void save({ web_research_enabled: v })} />
        </Field>
        <Field name="Online AI models" help="Select an OpenAI-compatible API model under Models & hardware. Requests include the selected conversation and relevant document text.">
          <span className="tag">API key configured: {s.api_key_configured ? "Yes" : "No"}</span>
        </Field>
        <Field name="Diagnostics and telemetry" help="Nothing is collected or sent. A local engine log is kept in the data folder for troubleshooting.">
          <span className="tag">Local log only</span>
        </Field>
        <div className="note">
          Every outbound request SWAMI can make: (1) search queries to your chosen search provider and (2) the web pages
          Deep Research reads — both only during a Deep Research run; (3) chat prompts and selected document passages to your chosen API provider when an online model is selected; (4) model files from huggingface.co or Ollama when you press
          Download. Links you click open in your browser as normal.
        </div>
      </div>
      <div className="set-group">
        <h4>Your data</h4>
        <Field name="Memory persistence" help="Keep saved facts across conversations.">
          <Switch checked={s.memory_enabled} label="Memory persistence" onChange={(v) => void save({ memory_enabled: v })} />
        </Field>
        <Field name="Export everything" help="Conversations, memories, projects and settings as one JSON file. API keys are left out.">
          <a className="btn" href="/api/export"><Download size={14} /> Export</a>
        </Field>
        <Field name="Delete all conversations" help="Removes every chat, research report and attached document from this PC. Memories and settings are kept.">
          {confirm ? (
            <>
              <button className="btn danger" onClick={() => {
                setConfirm(false);
                void api.deleteAllConversations().then(() => { newChat(); void refresh(); toast("All conversations deleted.", "success"); })
                  .catch((e) => toast(e.message, "error"));
              }}>Yes, delete everything</button>
              <button className="btn ghost" onClick={() => setConfirm(false)}>Cancel</button>
            </>
          ) : <button className="btn danger" onClick={() => setConfirm(true)}>Delete all…</button>}
        </Field>
      </div>
      {status && (
        <div className="set-group">
          <h4>Where things are stored</h4>
          <Field name="Conversations, memory and settings" col><span className="path">{status.paths.database}</span></Field>
          <Field name="Uploaded documents" col><span className="path">{status.paths.uploads}</span></Field>
          <Field name="Model files" col><span className="path">{status.paths.models}</span></Field>
        </div>
      )}
    </>
  );
}

/* ------------------------------------------------------------------- about */
function About() {
  const status = useStore((s) => s.status);
  const models = useStore((s) => s.models);
  const active = models.find((m) => m.id === status?.resolved?.model_id);
  return (
    <>
      <div className="set-group">
        <h4>SWAMI {status?.version}</h4>
        <div className="note" style={{ marginTop: 8 }}>
          SWAMI is a local-first AI assistant based on the supplied Thrones application source. It runs open-weight
          models on your own computer and adds reasoning workflows, tools, document reading, memory and web research.
        </div>
        <Field name="What SWAMI is" help="An assistant application built on the MIT-licensed Thrones foundation. Model weights and inference runtimes remain separately licensed.">
          <span className="tag gold">Software</span>
        </Field>
        <Field name="Model limits" help="SWAMI does not train a language model from scratch. Its local model is an open-weight base model made by its publisher. The optional Thrones Adapter 0.2 is a small fine-tune on Qwen3.5 4B; the base weights are unchanged.">
          <span className="tag">Not a from-scratch model</span>
        </Field>
      </div>
      <div className="set-group">
        <h4>Base model in use</h4>
        {active ? (
          <>
            {active.adapter && (
              <Field name={`${active.adapter} (Thrones fine-tune)`}
                help={`A LoRA adapter trained by the Thrones project on licensed and self-generated data, applied on top of ${active.base_name}. File: ${active.lora_file}. Training details and results: training/runs/${(active.lora_file ?? '').replace('.gguf', '')}/MODEL_CARD.md.`}>
                <span className="tag gold">Ours</span>
              </Field>
            )}
            <Field name={`${active.base_name ?? active.name} (${active.quantization})`} help={`${active.publisher} · ${active.parameters} parameters · ${active.license} license`}>
              <a className="btn sm" href={active.base_repo} target="_blank" rel="noreferrer noopener">Model card</a>
            </Field>
            <Field name="Quantized build" help={`${active.file} — a community GGUF conversion of the original weights. Quantization reduces precision to fit consumer hardware.`}>
              <a className="btn sm" href={active.gguf_repo} target="_blank" rel="noreferrer noopener">Source</a>
            </Field>
          </>
        ) : <div className="sb-empty" style={{ padding: "12px 0" }}>No model installed.</div>}
        <Field name="Inference engine" help="llama.cpp (MIT license), running as a local process bound to 127.0.0.1.">
          <a className="btn sm" href="https://github.com/ggml-org/llama.cpp" target="_blank" rel="noreferrer noopener">Project</a>
        </Field>
      </div>
      <div className="set-group">
        <h4>Honest limits</h4>
        <div className="note" style={{ marginTop: 8 }}>
          A 2–9B local model is much smaller than frontier cloud models. It makes more factual and reasoning mistakes,
          and its knowledge stops at its training date. Think mode and Deep Research reduce some errors with tools and
          sources; they do not change the model's weights. Check anything important.
        </div>
      </div>
    </>
  );
}

/* ------------------------------------------------------------------ dialog */
export function SettingsDialog() {
  const section = useStore((s) => s.settingsOpen);
  const open = useStore((s) => s.openSettings);
  const settings = useStore((s) => s.settings);
  const save = useStore((s) => s.saveSettings);
  const dialog = useRef<HTMLDivElement>(null);
  const restore = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!section) return;
    restore.current = document.activeElement as HTMLElement | null;
    dialog.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") open(null);
      if (e.key === "Tab" && dialog.current) {
        const nodes = dialog.current.querySelectorAll<HTMLElement>(
          'button:not(:disabled), a[href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
        if (!nodes.length) return;
        const first = nodes[0];
        const last = nodes[nodes.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("keydown", onKey);
      restore.current?.focus?.();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [!!section]);

  if (!section || !settings) return null;
  const current = SECTIONS.find((x) => x.id === section)!;
  return (
    <div className="scrim" onMouseDown={(e) => e.target === e.currentTarget && open(null)}>
      <div className="dialog" role="dialog" aria-modal="true" aria-label="Settings" ref={dialog} tabIndex={-1}>
        <div className="set-nav">
          <h2>Settings</h2>
          {SECTIONS.map((x) => (
            <button key={x.id} className={x.id === section ? "on" : ""} aria-current={x.id === section ? "page" : undefined}
              onClick={() => open(x.id)}>
              <x.icon size={16} /> {x.label}
            </button>
          ))}
        </div>
        <div className="set-body">
          <div className="set-head">
            <h3>{current.label}</h3>
            <button className="icon-btn" onClick={() => open(null)} aria-label="Close settings"><X size={18} /></button>
          </div>
          <div className="set-content scroll">
            {section === "general" && <General s={settings} save={save} />}
            {section === "models" && <Models s={settings} save={save} />}
            {section === "api" && <ApiProviders s={settings} save={save} />}
            {section === "voice" && <VoiceSettingsSection s={settings} save={save} />}
            {section === "generation" && <Generation s={settings} save={save} />}
            {section === "research" && <Research s={settings} save={save} />}
            {section === "tools" && <Tools s={settings} save={save} />}
            {section === "memory" && <MemorySection s={settings} save={save} />}
            {section === "skills" && <SkillsPanel />}
            {section === "browser" && <BrowserAutomationPanel />}
            {section === "privacy" && <Privacy s={settings} save={save} />}
            {section === "about" && <About />}
          </div>
        </div>
      </div>
    </div>
  );
}
