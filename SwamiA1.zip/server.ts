import fs from "node:fs";
import path from "node:path";
import express from "express";
import multer from "multer";
import { APP_NAME, APP_VERSION, BASE_CATALOG } from "./server/catalog";
import { SUPPORTED_EXTENSIONS } from "./server/documents";
import { executeChatTurn } from "./server/engine";
import {
  type ApiProtocol,
  fetchProviderModels,
  isLocalApiHost,
  normalizeApiBaseUrl,
  PROVIDER_PRESETS,
  testProviderConnection,
} from "./server/providers";
import {
  apiErrorHandler,
  createRateLimiter,
  logEvent,
  requestIdAndLogging,
} from "./server/security/middleware";
import { registerAdvancedApiRoutes } from "./server/routes";
import { redactSensitive } from "./server/security/secrets";
import { validateChatRequest, validateExternalUrl, ValidationError } from "./server/security/validation";
import { formatConversationMarkdown, MemoryConflictError, newId, store, type SwamiStore } from "./server/store";
import { browserEngine } from "./server/browser/service";
import { attachVoiceWebSocketServer } from "./server/voice/live";

const PORT = 3000;
const HOST = "0.0.0.0";
const startedAtMs = Date.now();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 30 * 1024 * 1024 } });

export function createApp(activeStore: SwamiStore = store) {
  const app = express();
  app.use(requestIdAndLogging);
  app.use(express.json({ limit: "4mb" }));

  const chatLimiter = createRateLimiter({ windowMs: 60_000, max: 60, name: "chat" });
  const providerLimiter = createRateLimiter({ windowMs: 60_000, max: 40, name: "providers" });
  const uploadLimiter = createRateLimiter({ windowMs: 60_000, max: 30, name: "upload" });

  // ---- Health & Status ----
  app.get("/api/health", (_req, res) => {
    res.json({
      ok: true,
      version: APP_VERSION,
      db_ok: true,
      schema_version: activeStore.db.getSchemaVersion(),
      uptime_s: Math.round((Date.now() - startedAtMs) / 1000),
    });
  });

  app.get("/api/status", (_req, res) => {
    res.json(activeStore.getStatus());
  });

  app.get("/api/audit", (_req, res) => {
    res.json({ logs: activeStore.listAuditLogs(50) });
  });

  app.get("/api/connectivity", (_req, res) => {
    if (activeStore.settings.offline_mode) {
      return res.json({ online: false, reason: "offline_mode" });
    }
    return res.json({ online: true, reason: "" });
  });

  // ---- Models & Engine ----
  app.get("/api/models", (_req, res) => {
    res.json({ models: activeStore.getModels() });
  });

  app.post("/api/models/:id/download", (req, res) => {
    try {
      res.json(activeStore.startDownload(req.params.id));
    } catch (err) {
      res.status(409).json({ detail: err instanceof Error ? err.message : "Download failed." });
    }
  });

  app.post("/api/models/:id/cancel", (req, res) => {
    activeStore.cancelDownload(req.params.id);
    res.json({ ok: true });
  });

  app.delete("/api/models/:id", (req, res) => {
    try {
      activeStore.deleteModel(req.params.id);
      res.json({ ok: true });
    } catch (err) {
      res.status(409).json({ detail: err instanceof Error ? err.message : "Could not delete model." });
    }
  });

  app.post("/api/engine/load", (req, res) => {
    if (activeStore.activeRuns.size > 0) {
      return res.status(409).json({ detail: "A response is being generated. Stop it before switching models." });
    }
    try {
      const modelId = typeof req.body?.model_id === "string" ? req.body.model_id : "";
      res.json(activeStore.loadEngine(modelId));
    } catch (err) {
      res.status(409).json({ detail: err instanceof Error ? err.message : "Could not load model." });
    }
  });

  app.post("/api/engine/unload", (_req, res) => {
    if (activeStore.activeRuns.size > 0) {
      return res.status(409).json({ detail: "A response is being generated." });
    }
    res.json(activeStore.unloadEngine());
  });

  // ---- Settings & Providers ----
  app.get("/api/settings", (_req, res) => {
    res.json(activeStore.getSettings());
  });

  app.patch("/api/settings", (req, res) => {
    const patch = (req.body ?? {}) as Record<string, unknown>;
    if (
      patch.offline_mode &&
      (activeStore.loaded?.entry.runtime === "api" || activeStore.loaded?.entry.runtime === "Gemini API")
    ) {
      for (const run of activeStore.activeRuns.values()) {
        run.controller.abort();
      }
      activeStore.unloadEngine();
    }
    res.json(activeStore.updateSettings(patch));
  });

  app.post("/api/settings/reset", (_req, res) => {
    res.json(activeStore.resetSettings());
  });

  app.get("/api/providers/presets", (_req, res) => {
    res.json({ presets: PROVIDER_PRESETS });
  });

  app.post("/api/providers/configure", providerLimiter, (req, res, next) => {
    try {
      const {
        base_url = "",
        model = "",
        api_key = "",
        provider_id = "custom",
        protocol = "auto",
        auto_select = true,
      } = (req.body ?? {}) as {
        base_url?: string;
        model?: string;
        api_key?: string;
        provider_id?: string;
        protocol?: ApiProtocol;
        auto_select?: boolean;
      };
      const base = normalizeApiBaseUrl(base_url);
      validateExternalUrl(base, { allowLocalhost: true, requireHttpsForRemote: true });

      if (!model.trim()) {
        throw new ValidationError("Enter any model name from your provider.", 400);
      }
      if (!api_key.trim() && !activeStore.apiKey && !isLocalApiHost(base)) {
        throw new ValidationError("Enter an API key for this online provider.", 400);
      }
      if (activeStore.activeRuns.size > 0) {
        return res.status(409).json({ detail: "Stop the current response before changing API settings." });
      }
      if (api_key.trim()) {
        activeStore.apiKey = api_key.trim();
      } else if (isLocalApiHost(base) && !api_key.trim()) {
        activeStore.apiKey = "";
      }
      const validProtocol: ApiProtocol =
        protocol === "openai" || protocol === "anthropic" || protocol === "gemini" ? protocol : "auto";
      const pid = provider_id || "custom";
      activeStore.upsertProvider({
        id: activeStore.getProvider(pid) ? pid : "custom",
        preset_id: pid,
        name: pid === "custom" ? "Custom Endpoint" : pid,
        protocol: validProtocol,
        base_url: base,
        default_model: model.trim(),
        api_key: api_key.trim() || undefined,
      });
      activeStore.updateSettings({
        api_base_url: base,
        api_model: model.trim(),
        api_provider: pid,
        api_protocol: validProtocol,
        ...(auto_select && !activeStore.settings.offline_mode ? { model_id: "online-api" } : {}),
      });
      activeStore.recordAudit("provider_configured", `Configured ${pid} (${model.trim()})`);
      if (auto_select && !activeStore.settings.offline_mode) {
        try {
          activeStore.loadEngine("online-api");
        } catch {
          // Ignore if offline or not ready
        }
      } else if (activeStore.loaded?.entry.runtime === "api") {
        activeStore.unloadEngine();
      }
      res.json(activeStore.getSettings());
    } catch (err) {
      next(err);
    }
  });

  app.delete("/api/providers/key", (_req, res) => {
    if (activeStore.activeRuns.size > 0) {
      return res.status(409).json({ detail: "Stop the current response before removing the API key." });
    }
    const legacyPid = activeStore.settings.api_provider || "custom";
    activeStore.apiKey = "";
    if (activeStore.getProvider(legacyPid)) {
      activeStore.setProviderApiKey(legacyPid, "");
    }
    activeStore.recordAudit("provider_key_removed", "Removed saved provider API key.");
    if (activeStore.settings.model_id === "online-api") {
      activeStore.updateSettings({ model_id: "" });
    }
    if (activeStore.loaded?.entry.runtime === "api") {
      activeStore.unloadEngine();
      try {
        activeStore.loadEngine("");
      } catch {
        // Fallback silently
      }
    }
    res.json(activeStore.getSettings());
  });

  app.post("/api/providers/models", providerLimiter, async (req, res, next) => {
    try {
      const settings = activeStore.getSettings();
      if (settings.offline_mode) {
        return res.status(409).json({ detail: "Offline mode is on. Turn it off before fetching cloud models." });
      }
      const body = (req.body ?? {}) as { base_url?: string; api_key?: string; protocol?: ApiProtocol };
      const base = normalizeApiBaseUrl(body.base_url || settings.api_base_url);
      const key = (body.api_key || "").trim() || activeStore.apiKey;
      const protocol = body.protocol ?? settings.api_protocol;
      if (!base) {
        throw new ValidationError("Enter an API address first.", 400);
      }
      validateExternalUrl(base, { allowLocalhost: true, requireHttpsForRemote: true });
      if (!key && !isLocalApiHost(base)) {
        return res.status(409).json({ detail: "Enter or save an API key first." });
      }
      const models = await fetchProviderModels({ baseUrl: base, apiKey: key, protocol });
      return res.json({ models });
    } catch (err) {
      if (err instanceof ValidationError) return next(err);
      return res.status(502).json({
        detail: redactSensitive(err instanceof Error ? err.message : "Could not fetch model list from provider."),
      });
    }
  });

  app.post("/api/providers/test", providerLimiter, async (req, res, next) => {
    try {
      const settings = activeStore.getSettings();
      if (settings.offline_mode) {
        return res.status(409).json({ detail: "Offline mode is on. Turn it off before testing a cloud connection." });
      }
      const body = (req.body ?? {}) as { base_url?: string; model?: string; api_key?: string; protocol?: ApiProtocol };
      const base = normalizeApiBaseUrl(body.base_url || settings.api_base_url);
      const model = (body.model ?? settings.api_model).trim();
      const key = (body.api_key || "").trim() || activeStore.apiKey;
      const protocol = body.protocol ?? settings.api_protocol;
      if (!base) {
        throw new ValidationError("Enter an API address first.", 400);
      }
      validateExternalUrl(base, { allowLocalhost: true, requireHttpsForRemote: true });
      if (!key && !isLocalApiHost(base)) {
        return res.status(409).json({ detail: "Enter or save an API key first." });
      }
      const result = await testProviderConnection({ baseUrl: base, apiKey: key, model, protocol });
      activeStore.recordAudit("provider_tested", `Tested provider ${base} (${model || "models"})`);
      return res.json(result);
    } catch (err) {
      if (err instanceof ValidationError) return next(err);
      return res.status(502).json({
        detail: redactSensitive(
          `Could not connect to the provider: ${err instanceof Error ? err.message : "Network error"}.`,
        ),
      });
    }
  });

  // ---- Conversations & Projects ----
  app.get("/api/conversations", (req, res) => {
    const search = typeof req.query.search === "string" ? req.query.search : "";
    res.json({
      conversations: activeStore.listConversations(search),
      projects: activeStore.listProjects(),
    });
  });

  app.get("/api/conversations/:cid", (req, res) => {
    const conv = activeStore.conversations.get(req.params.cid);
    if (!conv) return res.status(404).json({ detail: "Conversation not found." });
    res.json({
      conversation: conv,
      messages: activeStore.messages.get(conv.id) ?? [],
      documents: activeStore.listDocumentsFor(conv.id),
    });
  });

  app.patch("/api/conversations/:cid", (req, res) => {
    const conv = activeStore.conversations.get(req.params.cid);
    if (!conv) return res.status(404).json({ detail: "Conversation not found." });
    const body = (req.body ?? {}) as { title?: string; project_id?: string; clear_project?: boolean };
    const updated = activeStore.updateConversation(conv.id, {
      ...(body.title !== undefined ? { title: body.title } : {}),
      ...(body.project_id !== undefined ? { project_id: body.project_id } : {}),
      ...(body.clear_project ? { project_id: null } : {}),
    });
    res.json({ conversation: updated });
  });

  app.delete("/api/conversations/:cid", (req, res) => {
    activeStore.deleteConversation(req.params.cid);
    res.json({ ok: true });
  });

  app.get("/api/conversations/:cid/export", (req, res) => {
    const conv = activeStore.conversations.get(req.params.cid);
    if (!conv) return res.status(404).json({ detail: "Conversation not found." });
    const messages = activeStore.messages.get(conv.id) ?? [];
    const safe = conv.title.replace(/[^a-zA-Z0-9 _-]/g, "_").slice(0, 60).trim() || "chat";
    const format = req.query.format === "json" ? "json" : "md";
    if (format === "json") {
      res.setHeader("Content-Type", "application/json; charset=utf-8");
      res.setHeader("Content-Disposition", `attachment; filename="${safe}.json"`);
      return res.send(JSON.stringify({ conversation: conv, messages }, null, 2));
    }
    res.setHeader("Content-Type", "text/markdown; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${safe}.md"`);
    return res.send(formatConversationMarkdown(conv, messages));
  });

  app.delete("/api/data/conversations", (_req, res) => {
    activeStore.deleteAllConversations();
    res.json({ ok: true });
  });

  app.post("/api/projects", (req, res) => {
    const name = typeof req.body?.name === "string" ? req.body.name.trim() : "";
    if (!name) return res.status(400).json({ detail: "Project name is required." });
    res.json(activeStore.createProject(name.slice(0, 80)));
  });

  app.patch("/api/projects/:pid", (req, res) => {
    const name = typeof req.body?.name === "string" ? req.body.name.trim() : "";
    if (!name) return res.status(400).json({ detail: "Project name is required." });
    activeStore.renameProject(req.params.pid, name.slice(0, 80));
    res.json({ ok: true });
  });

  app.delete("/api/projects/:pid", (req, res) => {
    activeStore.deleteProject(req.params.pid);
    res.json({ ok: true });
  });

  // ---- Chat Streaming ----
  app.post("/api/chat", chatLimiter, (req, res, next) => {
    let body;
    try {
      body = validateChatRequest(req.body);
    } catch (err) {
      return next(err);
    }

    const runId = newId();
    const controller = new AbortController();
    activeStore.activeRuns.set(runId, { id: runId, controller, startedAt: Date.now() });

    res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.setHeader("X-Accel-Buffering", "no");
    res.flushHeaders?.();

    const writeEvent = (ev: unknown) => {
      if (!res.writableEnded) {
        try {
          res.write(`data: ${JSON.stringify(ev)}\n\n`);
        } catch {
          controller.abort();
        }
      }
    };

    writeEvent({ type: "run", run_id: runId });

    res.on("close", () => {
      if (!res.writableEnded) {
        controller.abort();
      }
    });

    void executeChatTurn(body, runId, writeEvent, controller.signal).finally(() => {
      activeStore.activeRuns.delete(runId);
      if (!res.writableEnded) {
        res.end();
      }
    });
  });

  app.post("/api/chat/:runId/stop", (req, res) => {
    const active = activeStore.activeRuns.get(req.params.runId);
    if (active) {
      active.controller.abort();
      return res.json({ stopped: true });
    }
    return res.json({ stopped: false });
  });

  // ---- Documents ----
  app.post("/api/documents", uploadLimiter, upload.single("file"), (req, res, next) => {
    if (!req.file) {
      return res.status(400).json({ detail: "No file uploaded." });
    }
    const conversationId =
      typeof req.body?.conversation_id === "string" && req.body.conversation_id.trim()
        ? req.body.conversation_id.trim()
        : null;
    try {
      const doc = activeStore.ingestDocument(
        req.file.originalname || "document",
        req.file.buffer,
        conversationId,
        req.file.mimetype || "",
      );
      return res.json(doc);
    } catch (err) {
      return next(err);
    }
  });

  app.get("/api/documents", (req, res) => {
    const cid = typeof req.query.conversation_id === "string" && req.query.conversation_id ? req.query.conversation_id : null;
    res.json({
      documents: activeStore.listDocumentsFor(cid),
      supported: Array.from(SUPPORTED_EXTENSIONS).sort(),
    });
  });

  app.delete("/api/documents/:id", (req, res) => {
    activeStore.deleteDocument(req.params.id);
    res.json({ ok: true });
  });

  // ---- Memory ----
  app.get("/api/memory", (req, res) => {
    const q = typeof req.query.q === "string" ? req.query.q : "";
    const category = typeof req.query.category === "string" ? req.query.category : "all";
    const projectId = typeof req.query.project_id === "string" ? req.query.project_id : undefined;
    res.json({
      memories: activeStore.listMemories(false, { q, category, projectId }),
      enabled: Boolean(activeStore.settings.memory_enabled),
      auto_suggest: Boolean(activeStore.settings.memory_auto_suggest),
    });
  });

  app.get("/api/memory/export", (_req, res) => {
    const payload = {
      app: APP_NAME,
      version: APP_VERSION,
      exported_at: new Date().toISOString().slice(0, 19),
      memories: activeStore.listMemories(),
    };
    res.setHeader("Content-Type", "application/json; charset=utf-8");
    res.setHeader("Content-Disposition", 'attachment; filename="swami-memories.json"');
    res.send(JSON.stringify(payload, null, 2));
  });

  app.post("/api/memory/import", (req, res) => {
    const raw = Array.isArray(req.body) ? req.body : Array.isArray(req.body?.memories) ? req.body.memories : null;
    if (!raw) {
      return res.status(400).json({ detail: "Expected a JSON array or { memories: [...] } payload." });
    }
    const result = activeStore.importMemories(raw);
    return res.json(result);
  });

  app.post("/api/memory", (req, res) => {
    const content = typeof req.body?.content === "string" ? req.body.content.trim() : "";
    if (!content) return res.status(400).json({ detail: "Memory text is empty." });
    const category = typeof req.body?.category === "string" ? req.body.category : undefined;
    const project_id = typeof req.body?.project_id === "string" && req.body.project_id ? req.body.project_id : null;
    const replace_conflict_id =
      typeof req.body?.replace_conflict_id === "string" && req.body.replace_conflict_id
        ? req.body.replace_conflict_id
        : null;
    try {
      const mem = activeStore.addMemory(content, "user", { category, project_id, replace_conflict_id });
      return res.json(mem);
    } catch (err) {
      if (err instanceof MemoryConflictError) {
        return res.status(err.status).json({ detail: err.message, existing: err.existing });
      }
      return res.status(400).json({ detail: err instanceof Error ? err.message : "Could not save memory." });
    }
  });

  app.patch("/api/memory/:mid", (req, res) => {
    const body = (req.body ?? {}) as {
      content?: string;
      enabled?: boolean;
      category?: string;
      project_id?: string | null;
      clear_conflict?: boolean;
    };
    try {
      const updated = activeStore.updateMemory(req.params.mid, body);
      if (!updated) return res.status(404).json({ detail: "Memory not found." });
      return res.json({ ok: true, memory: updated });
    } catch (err) {
      if (err instanceof MemoryConflictError) {
        return res.status(err.status).json({ detail: err.message, existing: err.existing });
      }
      return res.status(400).json({ detail: err instanceof Error ? err.message : "Could not update memory." });
    }
  });

  app.delete("/api/memory/:mid", (req, res) => {
    activeStore.deleteMemory(req.params.mid);
    res.json({ ok: true });
  });

  app.delete("/api/memory", (_req, res) => {
    activeStore.clearMemories();
    res.json({ ok: true });
  });

  // ---- Personal Data Export ----
  app.get("/api/export", (_req, res) => {
    const settings = activeStore.getSettings();
    const safeSettings: Record<string, unknown> = { ...settings };
    delete safeSettings.brave_api_key;
    const convs = activeStore.listConversations();
    const payload = {
      app: APP_NAME,
      version: APP_VERSION,
      exported_at: new Date().toISOString().slice(0, 19),
      catalog_count: BASE_CATALOG.length,
      settings: safeSettings,
      memories: activeStore.listMemories(),
      projects: activeStore.listProjects(),
      conversations: convs.map((c) => ({ ...c, messages: activeStore.messages.get(c.id) ?? [] })),
      documents: activeStore.listDocumentsFor(null),
    };
    res.setHeader("Content-Type", "application/json; charset=utf-8");
    res.setHeader("Content-Disposition", 'attachment; filename="swami-export.json"');
    res.send(JSON.stringify(payload, null, 2));
  });

  registerAdvancedApiRoutes(app, activeStore);

  // Return JSON 404 for unknown /api/* routes & centralized error handling
  app.use("/api", (_req, res) => {
    res.status(404).json({ detail: "Not found.", code: "NOT_FOUND" });
  });
  app.use(apiErrorHandler);

  return app;
}

async function startServer() {
  const app = createApp();
  const isProd = process.env.NODE_ENV === "production";
  const distDir = path.resolve(process.cwd(), "dist");

  if (isProd && fs.existsSync(distDir)) {
    app.use(express.static(distDir));
    app.get("/{*path}", (_req, res) => {
      res.sendFile(path.join(distDir, "index.html"));
    });
  } else {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false },
      appType: "spa",
    });
    app.use(vite.middlewares);
  }

  const server = app.listen(PORT, HOST, () => {
    logEvent("info", "server_started", {
      host: HOST,
      port: PORT,
      db_path: store.db.dbPath,
      schema_version: store.db.getSchemaVersion(),
    });
    console.log(`SWAMI server listening on http://${HOST}:${PORT}`);
  });
  const voiceWs = attachVoiceWebSocketServer(server, store);

  const gracefulShutdown = (signalName: string) => {
    logEvent("info", "server_shutdown", { signal: signalName });
    voiceWs.closeAll();
    store.shutdown();
    void browserEngine.shutdownAll().finally(() => {
      server.close(() => {
        process.exit(0);
      });
      setTimeout(() => process.exit(0), 2000).unref();
    });
  };

  process.once("SIGINT", () => gracefulShutdown("SIGINT"));
  process.once("SIGTERM", () => gracefulShutdown("SIGTERM"));
}

const isTestRun =
  process.env.NODE_ENV === "test" ||
  Boolean(process.env.NODE_TEST_CONTEXT) ||
  process.argv.some((arg) => /\.test\.[cm]?[jt]s$/.test(arg));

if (!isTestRun) {
  void startServer();
}
