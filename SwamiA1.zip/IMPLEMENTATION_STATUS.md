# SWAMI implementation status

This checklist separates source audit findings from completed application work. A feature is marked complete only after implementation and an appropriate check.

## Completed in this work session

- [x] Inventoried and extracted all five supplied archives under `source-audit/`.
- [x] Confirmed Thrones as the foundation by inspecting its README, architecture, FastAPI routes, SQLite schema, llama.cpp manager, React components, and dependencies.
- [x] Inspected Craft Anything's licensing, alpha status, workspace architecture, and integration guidance.
- [x] Inspected REA's README/package metadata and runtime prerequisite; installed Node is below its declared minimum.
- [x] Inspected Awesome LLM Apps examples and LLMs From Scratch references; selected no new runtime dependencies from either.
- [x] Created a clean `source/` working copy of the Thrones application and the source integration map.
- [x] Added SWAMI branding, the user's supplied logo in the UI and Windows icon, a Windows WebView desktop shell, version metadata, portable executable and installer.
- [x] Added Ollama-backed Qwen2.5 7B and Qwen2.5 Coder 3B catalog entries, pull/stream/load/unload/delete adapter, and low-end profile selection.
- [x] Added OpenAI-compatible API settings, model selection, explicit connection test, HTTPS checks for remote endpoints, and Windows Credential Manager storage.
- [x] Added explicit Offline-mode enforcement for cloud models; turning it on cancels an active cloud chat and unloads its provider.
- [x] Added provider regression tests; Windows Credential Manager round-trip passed using a disposable dummy value.
- [x] Backend test suite passes (85 tests); frontend TypeScript check and production build pass.
- [x] Installed `SWAMI-Setup-x64.exe`; verified version 0.1.0 and a desktop shortcut pointing to the installed executable with the SWAMI icon.
- [x] Launched the installed desktop app and verified its lightweight local health endpoint and `/api/status` response.
- [x] Restored the Ollama 0.40.16 command-line runtime from Ollama's official Windows release ZIP after the full installer left its executable missing; verified the official SHA-256 checksum and confirmed the local service responds.

## Not yet implemented or verified

- [ ] Screenshot-matched layout across all screens; source app branding is converted but CHAT / WORK and the full requested screen set are not implemented.
- [ ] Functional coding/project workbench, skills registry, Craft Anything workflows, file creation tools, and optional REA CLI/MCP adapter.
- [ ] LM Studio and arbitrary local OpenAI-compatible endpoint discovery/configuration.
- [ ] API provider connection and streamed chat need a user-owned API key for live verification; native Anthropic and Google API formats are not implemented (OpenAI-compatible endpoints only).
- [ ] Qwen2.5:7b download did not finish: Ollama 0.40.16 errored while cleaning its partial download at 94%, and the model is not listed as installed. Retry after correcting the Ollama download/runtime issue; do not claim local chat or speed verification.
- [ ] Skills registry, file creation tools, and project-scoped coding tools.
- [ ] Optional REA CLI/MCP adapter and Craft Anything workflow integration.
- [x] Windows desktop wrapper, supplied application icon, version metadata, installer, portable executable, installation, and desktop shortcut.
- [x] Python backend tests and frontend production build.
- [x] Rebuilt installer and portable executable with provider integrations and supplied logo; installed and launch-checked the packaged build.
- [ ] Visual review of the complete application window against the supplied screenshot.

## Known initial environment limits

The target machine has an Intel Core i3-3210, 8 GB RAM, and no supported GPU. Qwen2.5 7B can be too slow or memory-constrained on it; no zero-lag claim is made. The Ollama Windows installer and model downloads are separate from SWAMI's installer. REA 6.8.0 declares Node `^22.23.4 || ^24.22.1 || >=26.12.1`, so its CLI/MCP cannot be relied on with installed Node 22.18.0. No Cargo/Rust or .NET SDK was detected in PATH.
