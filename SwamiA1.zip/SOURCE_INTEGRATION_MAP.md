# SWAMI source integration map

Audit date: 2026-11-14. The five supplied archives are retained under `source-audit/` for provenance and inspection. The application source in `source/` starts from the complete Thrones repository.

| Source | Intended responsibility | Audit decision |
|---|---|---|
| Thrones | Main AI assistant | Use as the application foundation. It has a React/TypeScript UI, FastAPI service, SQLite persistence, llama.cpp child-process manager, streaming, document Q&A with FTS5, bounded reasoning tools, and guarded research. Preserve its one-model-at-a-time process lifecycle and data model. |
| Craft Anything | Study, build, compare | Use as a design reference for a staged Study → Plan → Build → Check → Refine workflow, evidence-backed reports, and explicit command approvals. Do not embed its Rust workspace: it is documented as early alpha, is large, and brings separate CLI, MCP, UI, engine, and extensive native/optional integrations. The supplied `AGENTS.md` also prohibits copying its code, schemas, names, assets, and wording. |
| REA | Authorized reverse engineering | Keep optional behind a separate CLI/MCP adapter. Supplied package is `rea-agents` 6.8.0 and requires Node `^22.23.4 || ^24.22.1 || >=26.12.1`; this machine has Node 22.18.0, so the supplied runtime prerequisite is not met. Its CLI and MCP cover targets according to available engines; proprietary/heavy analyzers are separate dependencies. Do not claim those analyses are available by default. |
| Awesome LLM Apps | Agent and workflow references | Reference selectively. Prefer the lightweight, deterministic tool loop and local FTS5 approach already present in Thrones. The archive is a broad example collection with many unrelated frameworks and provider dependencies; do not install it as a runtime dependency. |
| LLMs From Scratch | Model engineering references | Reference Chapter 2 tokenizer concepts and Chapter 4 KV-cache, GQA, and attention material. Keep inference in llama.cpp; do not bring its PyTorch training notebooks or training stack into the desktop app. |

## Existing foundation verified in source

- The backend is one FastAPI process bound to loopback; it starts and owns a separate `llama-server` process, uses one generation slot, and cleans up the child at shutdown.
- Model selection, fallback settings, idle unload, model download, stop/cancel, token streaming, and runtime metrics are implemented in `backend/thrones/runtime/` and `reasoning/`.
- Chats, projects, memories, settings, documents, and FTS5 chunks are in one SQLite database. Documents are parsed locally and retrieved with BM25.
- Research is implemented as a bounded code-driven pipeline. The fetcher guards URLs and redirects, and the citation sanitizer restricts citations to fetched pages.
- The supplied project describes its tested Qwen 2B/4B/9B GGUF choices, but the current workspace does not include the llama.cpp executable or model weights. Model loading therefore requires user-selected files or an installed runtime.
- Existing source has no online chat provider, no desktop window wrapper, and no implemented coding-agent/workbench or skills registry. The current frontend offers Fast, Think, and Deep Research; these are not the requested CHAT/WORK modes.

## Overlap and shared-service policy

Keep one provider boundary, orchestration/tool registry, skills catalog, SQLite database, workspace file boundary, task history, and log path in the Thrones app. Craft Anything and REA remain optional adapters behind those shared services; they must not create second databases or model managers. Third-party tools remain opt-in and report unavailable prerequisites plainly.

## Environment snapshot

- Windows x64; Python 3.12.10 and Node 22.18.0 are present.
- The source's pinned Python requirements are not installed in the selected Python environment.
- The source's llama.cpp runtime and model weights are not present in the application source tree.
- REA's declared minimum Node 22 patch version is newer than the installed runtime.
- No Cargo/Rust toolchain or .NET SDK was detected in PATH, so building Craft Anything or a .NET desktop shell is not currently available.

These observations describe the initial environment only; they do not establish that optional software is unavailable elsewhere on the PC.
