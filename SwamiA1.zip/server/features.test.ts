import assert from "node:assert/strict";
import fs from "node:fs";
import http from "node:http";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import { browserEngine } from "./browser/service";
import { analyzeTabularData, skillRegistry } from "./skills/registry";
import { MemoryConflictError, SwamiStore } from "./store";

function tempDir(prefix: string): string {
  return fs.mkdtempSync(path.join(os.tmpdir(), prefix));
}

test("Feature 4: Advanced Memory persistence, categorization, project isolation, and conflict resolution", () => {
  const dir = tempDir("swami-mem-");
  try {
    const store = new SwamiStore(dir);
    const projA = store.createProject("Project Alpha");
    const projB = store.createProject("Project Beta");

    // 1. Add category and project-scoped memories
    const m1 = store.addMemory("User prefers Python for data science", "user", {
      category: "preference",
      project_id: null,
    });
    assert.equal(m1.category, "preference");
    assert.equal(m1.project_id, null);

    const m2 = store.addMemory("Database uses PostgreSQL 16 on AWS", "user", {
      category: "project",
      project_id: projA.id,
    });
    assert.equal(m2.project_id, projA.id);

    // 2. Project isolation check: retrieving for Project B should NOT return projA memory
    const retrievedA = store.retrieveRelevantMemories("Database setup", projA.id);
    assert.ok(retrievedA.some((m) => m.content.includes("PostgreSQL")));

    const retrievedB = store.retrieveRelevantMemories("Database setup", projB.id);
    assert.equal(retrievedB.some((m) => m.content.includes("PostgreSQL")), false);

    // 3. Duplicate rejection
    assert.throws(() => {
      store.addMemory("User prefers Python for data science", "user", { category: "preference" });
    }, MemoryConflictError);

    // 4. Update memory
    const updated = store.updateMemory(m1.id, { content: "User strongly prefers Python 3.12 for data science" });
    assert.ok(updated?.content.includes("3.12"));

    // 5. Export and Import
    const exported = store.listMemories();
    assert.equal(exported.length >= 2, true);

    store.clearMemories();
    assert.equal(store.listMemories().length, 0);

    const importRes = store.importMemories(exported);
    assert.equal(importRes.imported >= 2, true);

    store.db.close();
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("Feature 7: Tabular Data analysis and Skills Registry execution", async () => {
  const dir = tempDir("swami-skills-");
  try {
    const store = new SwamiStore(dir);

    // 1. Test tabular data analyzer (CSV)
    const csv = "name,age,score\nAlice,30,95.5\nBob,25,82.0\nCharlie,35,88.5";
    const stats = analyzeTabularData(csv);
    assert.equal(stats.rowCount, 3);
    assert.deepEqual(stats.columns, ["name", "age", "score"]);
    assert.equal(stats.numericStats.score.mean, 88.6667);
    assert.equal(stats.numericStats.age.sum, 90);

    // 2. Test math skill execution
    const mathRes = await skillRegistry.executeSkill("math", { expression: "125 * 8 + 50" }, { store });
    assert.equal(mathRes.status, "success");
    assert.equal(mathRes.output.value, 1050);

    // 3. Test productivity skill execution
    const prodRes = await skillRegistry.executeSkill(
      "productivity",
      { notes: "Urgent fix login bug; Update API docs; Deploy staging" },
      { store },
    );
    assert.equal(prodRes.status, "success");
    assert.equal((prodRes.output.tasks as any[]).length, 3);

    // 4. Execution history recorded in store
    const history = skillRegistry.getExecutionHistory(store, 10);
    assert.equal(history.length >= 2, true);

    store.db.close();
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("Feature 6: Browser automation allowlist, localhost switch, and ephemeral webpage testing", async () => {
  // Spin up an ephemeral local HTTP test server
  const server = http.createServer((_req, res) => {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    res.end(`<!DOCTYPE html>
<html>
<head><title>Test Localpage</title></head>
<body>
  <h1>Hello Swami Browser</h1>
  <p>Local automation test content.</p>
  <a href="/other">Other Page</a>
  <button id="click-me">Click Me</button>
  <input id="username" type="text" />
</body>
</html>`);
  });

  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address() as import("net").AddressInfo;
  const localUrl = `http://127.0.0.1:${address.port}`;

  try {
    // 1. Initially localhost should be blocked unless allowLocalhost is true
    browserEngine.setConfig({ allowLocalhost: false });
    assert.throws(() => {
      browserEngine.validateTargetUrl(localUrl);
    }, /localhost URLs are not allowed/i);

    // 2. Enable localhost
    browserEngine.setConfig({ allowLocalhost: true });
    assert.doesNotThrow(() => {
      browserEngine.validateTargetUrl(localUrl);
    });

    // 3. Execute workflow against local server
    const session = browserEngine.createSession(localUrl);
    const updated = await browserEngine.executeWorkflow(session.id, localUrl, [
      { type: "extract", target: "body" },
      { type: "scroll", target: "body", value: "200" },
      { type: "screenshot", target: "viewport" },
    ]);

    assert.equal(updated.status, "completed");
    assert.ok(updated.title.includes("Test Localpage"));
    assert.ok(updated.extractedText?.includes("Hello Swami Browser"));
    assert.ok(updated.screenshotUrl);

    await browserEngine.closeHandle(session.id);
  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
    await browserEngine.shutdownAll();
  }
});
