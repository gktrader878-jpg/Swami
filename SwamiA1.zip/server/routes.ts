import express from "express";
import multer from "multer";
import { browserEngine } from "./browser/service";
import { getLocalAiWindowsGuide, modelRouter } from "./models/router";
import {
  CORE_PROVIDER_PRESETS,
  discoverProviderModels,
  isLocalApiHost,
  normalizeApiBaseUrl,
  probeProviderHealth,
} from "./providers";
import { redactSensitive } from "./security/secrets";
import { validateExternalUrl } from "./security/validation";
import { skillRegistry } from "./skills/registry";
import { store, type SwamiStore } from "./store";
import type {
  CompareModelResult,
  ModelGenerationParams,
  Mode,
  ProviderProtocol,
  VoiceSttProvider,
  VoiceTtsProvider,
} from "./types";
import { GEMINI_LIVE_MODEL, GEMINI_LIVE_TRANSCRIBE_MODEL, voiceSessionManager } from "./voice/engine";
import { sanitizeFilename } from "./security/validation";
import {
  executeVoiceAssistantTurn,
  getVoiceCapabilities,
  synthesizeSpeech,
  transcribeAudio,
} from "./voice/providers";
import {
  analyzeDocumentVisually,
  analyzeImagesWithVisionModel,
  generateOrEditImage,
  getVisionCapabilities,
} from "./vision/service";
import {
  MAX_IMAGES_PER_MESSAGE,
  MAX_TOTAL_VISION_BYTES,
  deleteStoredFiles,
  readAttachmentBytes,
  saveImageAttachment,
  toPublicAttachment,
  VisionValidationError,
} from "./vision/storage";

const voiceAudioUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 15 * 1024 * 1024 },
});

const visionImageUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 12 * 1024 * 1024, files: MAX_IMAGES_PER_MESSAGE },
});

export function registerAdvancedApiRoutes(app: express.Express, activeStore: SwamiStore = store) {
  // ---- Advanced Memory API ----
  app.get("/api/v1/memory/search", (req, res) => {
    const q = typeof req.query.q === "string" ? req.query.q : "";
    const category = typeof req.query.category === "string" ? req.query.category : "all";
    const projectId = typeof req.query.project_id === "string" ? req.query.project_id : null;
    const memories = q
      ? activeStore.searchMemories(q, 20, projectId === "all" || projectId === "global" ? null : projectId)
      : activeStore.listMemories(false, { category, projectId });
    res.json({ memories });
  });

  // ---- Deep Research API ----
  app.post("/api/v1/research", async (req, res) => {
    const { topic = "" } = (req.body ?? {}) as { topic?: string };
    if (!topic.trim()) {
      return res.status(400).json({ detail: "Topic is required." });
    }
    const conv = activeStore.createConversation(topic.slice(0, 60), "research");
    res.json({ conversation_id: conv.id, topic });
  });

  // ---- Browser Automation API ----
  app.get("/api/v1/browser/config", (_req, res) => {
    res.json(browserEngine.getConfig());
  });

  app.post("/api/v1/browser/config", (req, res) => {
    const body = (req.body ?? {}) as { allowedDomains?: string[]; allowLocalhost?: boolean };
    const updated = browserEngine.setConfig(body);
    res.json(updated);
  });

  app.get("/api/v1/browser/sessions", (_req, res) => {
    res.json({ sessions: browserEngine.listSessions() });
  });

  app.post("/api/v1/browser/sessions", async (req, res, next) => {
    try {
      const { url = "", actions = [] } = (req.body ?? {}) as {
        url?: string;
        actions?: Array<{ type: any; target: string; value?: string; detail?: string }>;
      };
      if (!url.trim()) {
        return res.status(400).json({ detail: "URL is required." });
      }
      const session = browserEngine.createSession(url.trim());
      const updated = await browserEngine.executeWorkflow(session.id, url.trim(), actions);
      res.json({ session: updated });
    } catch (err) {
      next(err);
    }
  });

  app.get("/api/v1/browser/sessions/:id", (req, res) => {
    const session = browserEngine.getSession(req.params.id);
    if (!session) return res.status(404).json({ detail: "Browser session not found." });
    res.json({ session });
  });

  app.post("/api/v1/browser/sessions/:id/actions", async (req, res, next) => {
    try {
      const { actions = [] } = (req.body ?? {}) as {
        actions?: Array<{ type: any; target: string; value?: string; detail?: string }>;
      };
      const session = browserEngine.getSession(req.params.id);
      if (!session) return res.status(404).json({ detail: "Browser session not found." });
      const updated = await browserEngine.executeWorkflow(session.id, session.url, actions);
      res.json({ session: updated });
    } catch (err) {
      next(err);
    }
  });

  app.post("/api/v1/browser/sessions/:id/approve", async (req, res, next) => {
    try {
      const { actionId = "", approved = true } = (req.body ?? {}) as { actionId?: string; approved?: boolean };
      if (!actionId) return res.status(400).json({ detail: "actionId is required." });
      const updated = await browserEngine.resolveApproval(req.params.id, actionId, Boolean(approved));
      res.json({ session: updated });
    } catch (err) {
      next(err);
    }
  });

  app.post("/api/v1/browser/sessions/:id/cancel", async (req, res) => {
    const session = await browserEngine.cancelSession(req.params.id);
    if (!session) return res.status(404).json({ detail: "Browser session not found." });
    res.json({ session });
  });

  app.delete("/api/v1/browser/sessions/:id", async (req, res) => {
    await browserEngine.cancelSession(req.params.id);
    res.json({ ok: true });
  });

  app.get("/api/v1/browser/screenshots/:sessionId/:filename", (req, res) => {
    const filePath = browserEngine.getScreenshotFilePath(req.params.sessionId, req.params.filename);
    if (!filePath) return res.status(404).json({ detail: "Screenshot not found." });
    res.sendFile(filePath);
  });

  // ---- Skills System API ----
  app.get("/api/v1/skills", (_req, res) => {
    res.json({ skills: skillRegistry.listSkills() });
  });

  app.get("/api/v1/skills/history", (_req, res) => {
    res.json({ history: skillRegistry.getExecutionHistory(activeStore, 50) });
  });

  app.patch("/api/v1/skills/:id", (req, res) => {
    const { enabled } = (req.body ?? {}) as { enabled?: boolean };
    if (enabled === undefined) {
      return res.status(400).json({ detail: "enabled boolean is required." });
    }
    const ok = skillRegistry.setSkillEnabled(req.params.id, Boolean(enabled));
    if (!ok) {
      return res.status(404).json({ detail: "Skill not found." });
    }
    res.json({ ok: true, skills: skillRegistry.listSkills() });
  });

  app.post("/api/v1/skills/:id/execute", async (req, res, next) => {
    try {
      const input = (req.body ?? {}) as Record<string, unknown>;
      const result = await skillRegistry.executeSkill(req.params.id, input, { store: activeStore });
      res.json(result);
    } catch (err) {
      next(err);
    }
  });

  // ---- Unified Multi-Provider & Model Management API ----
  app.get("/api/v1/providers", (_req, res) => {
    const s = activeStore.getSettings();
    res.json({
      providers: activeStore.listProviders(),
      presets: CORE_PROVIDER_PRESETS,
      usage_stats: activeStore.getUsageStats(),
      routing: {
        routing_mode: s.routing_mode,
        routing_preference: s.routing_preference,
        default_provider_id: s.default_provider_id,
        default_model_id: s.default_model_id,
        fallback_provider_id: s.fallback_provider_id,
        fallback_model_id: s.fallback_model_id,
        request_timeout_ms: s.request_timeout_ms,
        model_id: s.model_id,
      },
      windows_local_guide: getLocalAiWindowsGuide(),
    });
  });

  app.post("/api/v1/providers", (req, res, next) => {
    try {
      const body = (req.body ?? {}) as {
        id?: string;
        preset_id?: string;
        name?: string;
        protocol?: ProviderProtocol;
        base_url?: string;
        enabled?: boolean;
        default_model?: string;
        api_key?: string;
        clear_key?: boolean;
      };
      if (!body.name && !body.preset_id && !body.id) {
        return res.status(400).json({ detail: "Provider name or preset_id is required." });
      }
      const saved = activeStore.upsertProvider({
        id: body.id,
        preset_id: body.preset_id,
        name: body.name || body.preset_id || "Custom Provider",
        protocol: body.protocol,
        base_url: body.base_url || "",
        enabled: body.enabled,
        default_model: body.default_model,
        api_key: body.api_key,
      });
      if (body.clear_key) {
        activeStore.setProviderApiKey(saved.id, "");
      }
      res.json({ provider: activeStore.getProvider(saved.id) ?? saved });
    } catch (err) {
      next(err);
    }
  });

  app.patch("/api/v1/providers/:id", (req, res, next) => {
    try {
      const existing = activeStore.getProvider(req.params.id);
      if (!existing) return res.status(404).json({ detail: "Provider not found." });
      const body = (req.body ?? {}) as {
        name?: string;
        protocol?: ProviderProtocol;
        base_url?: string;
        enabled?: boolean;
        default_model?: string;
        api_key?: string;
        clear_key?: boolean;
      };
      const saved = activeStore.upsertProvider({
        id: existing.id,
        preset_id: existing.preset_id,
        name: body.name ?? existing.name,
        protocol: body.protocol ?? existing.protocol,
        base_url: body.base_url ?? existing.base_url,
        enabled: body.enabled ?? existing.enabled,
        default_model: body.default_model ?? existing.default_model,
        api_key: body.api_key,
      });
      if (body.clear_key) {
        activeStore.setProviderApiKey(existing.id, "");
      }
      res.json({ provider: activeStore.getProvider(existing.id) ?? saved });
    } catch (err) {
      next(err);
    }
  });

  app.delete("/api/v1/providers/:id", (req, res) => {
    if (!activeStore.getProvider(req.params.id)) {
      return res.status(404).json({ detail: "Provider not found." });
    }
    activeStore.removeProvider(req.params.id);
    res.json({ ok: true, providers: activeStore.listProviders() });
  });

  app.post("/api/v1/providers/:id/test", async (req, res, next) => {
    try {
      const provider = activeStore.getProvider(req.params.id);
      if (!provider) return res.status(404).json({ detail: "Provider not found." });
      const settings = activeStore.getSettings();
      if (settings.offline_mode && !provider.is_local) {
        return res.status(409).json({ detail: "Offline mode is on. Disable Offline mode before testing cloud providers." });
      }
      const body = (req.body ?? {}) as { base_url?: string; api_key?: string; model?: string; protocol?: ProviderProtocol };
      const baseUrl = normalizeApiBaseUrl(body.base_url || provider.base_url);
      if (!baseUrl) {
        return res.status(400).json({ detail: "Base URL is required before testing connection." });
      }
      validateExternalUrl(baseUrl, { allowLocalhost: true, requireHttpsForRemote: true });
      const apiKey = (body.api_key || "").trim() || activeStore.getProviderApiKey(provider.id);
      const probe = await probeProviderHealth({
        providerId: provider.id,
        presetId: provider.preset_id,
        baseUrl,
        apiKey,
        model: body.model ?? provider.default_model,
        protocol: body.protocol ?? provider.protocol,
      });

      const updated = probe.models && probe.models.length > 0
        ? activeStore.setProviderDiscovery(provider.id, {
            models: probe.models,
            status: probe.status,
            message: probe.message,
            latencyMs: probe.latencyMs,
          })
        : activeStore.setProviderHealth(provider.id, probe.status, probe.message, probe.latencyMs || null);

      activeStore.recordAudit("provider_tested", `Tested ${provider.name}: ${probe.status}`);
      res.status(probe.ok ? 200 : 502).json({
        ok: probe.ok,
        status: probe.status,
        latencyMs: probe.latencyMs,
        message: probe.message,
        provider: updated,
        models: probe.models ?? updated.models,
      });
    } catch (err) {
      next(err);
    }
  });

  app.post("/api/v1/providers/:id/discover", async (req, res, next) => {
    try {
      const provider = activeStore.getProvider(req.params.id);
      if (!provider) return res.status(404).json({ detail: "Provider not found." });
      const settings = activeStore.getSettings();
      if (settings.offline_mode && !provider.is_local) {
        return res.status(409).json({ detail: "Offline mode is on. Disable Offline mode before discovering cloud models." });
      }
      const body = (req.body ?? {}) as { base_url?: string; api_key?: string; protocol?: ProviderProtocol };
      const baseUrl = normalizeApiBaseUrl(body.base_url || provider.base_url);
      if (!baseUrl) {
        return res.status(400).json({ detail: "Base URL is required to discover models." });
      }
      validateExternalUrl(baseUrl, { allowLocalhost: true, requireHttpsForRemote: true });
      const apiKey = (body.api_key || "").trim() || activeStore.getProviderApiKey(provider.id);
      if (!apiKey && !isLocalApiHost(baseUrl)) {
        return res.status(409).json({ detail: `Enter or save an API key for ${provider.name} first.` });
      }
      try {
        const disc = await discoverProviderModels({
          providerId: provider.id,
          presetId: provider.preset_id,
          baseUrl,
          apiKey,
          protocol: body.protocol ?? provider.protocol,
        });
        const updated = activeStore.setProviderDiscovery(provider.id, {
          models: disc.models,
          status: "healthy",
          message: disc.message,
          latencyMs: disc.latencyMs,
        });
        return res.json({
          ok: true,
          reachable: disc.reachable,
          latencyMs: disc.latencyMs,
          message: disc.message,
          provider: updated,
        });
      } catch (err) {
        const cleanMsg = redactSensitive(err instanceof Error ? err.message : "Could not reach provider.");
        const unreachable = /ECONNREFUSED|ENOTFOUND|ETIMEDOUT|fetch failed|timed out/i.test(cleanMsg);
        const updated = activeStore.setProviderHealth(
          provider.id,
          unreachable ? "unreachable" : "unhealthy",
          cleanMsg,
          null,
        );
        return res.status(502).json({
          ok: false,
          detail: cleanMsg,
          provider: updated,
        });
      }
    } catch (err) {
      next(err);
    }
  });

  app.post("/api/v1/providers/:id/models", (req, res, next) => {
    try {
      const body = (req.body ?? {}) as { id?: string; model_id?: string; name?: string; params?: ModelGenerationParams };
      const modelId = (body.model_id ?? body.id ?? "").trim();
      if (!modelId) return res.status(400).json({ detail: "model_id is required." });
      const updated = activeStore.addProviderModel(req.params.id, modelId, body.name, body.params);
      res.json({ provider: updated });
    } catch (err) {
      next(err);
    }
  });

  app.post("/api/v1/providers/:id/models/update", (req, res, next) => {
    try {
      const body = (req.body ?? {}) as {
        model_id?: string;
        enabled?: boolean;
        name?: string;
        params?: ModelGenerationParams;
      };
      if (!body.model_id?.trim()) return res.status(400).json({ detail: "model_id is required." });
      const updated = activeStore.updateProviderModel(req.params.id, body.model_id.trim(), {
        enabled: body.enabled,
        name: body.name,
        params: body.params,
      });
      res.json({ provider: updated });
    } catch (err) {
      next(err);
    }
  });

  app.patch("/api/v1/providers/:id/models/{*modelId}", (req, res, next) => {
    try {
      const rawParam = (req.params as Record<string, string | string[]>).modelId;
      const modelId = Array.isArray(rawParam) ? rawParam.join("/") : rawParam;
      const body = (req.body ?? {}) as { enabled?: boolean; name?: string; params?: ModelGenerationParams };
      const updated = activeStore.updateProviderModel(req.params.id, decodeURIComponent(modelId || ""), body);
      res.json({ provider: updated });
    } catch (err) {
      next(err);
    }
  });

  app.post("/api/v1/providers/:id/models/delete", (req, res, next) => {
    try {
      const body = (req.body ?? {}) as { model_id?: string };
      if (!body.model_id?.trim()) return res.status(400).json({ detail: "model_id is required." });
      const updated = activeStore.removeProviderModel(req.params.id, body.model_id.trim());
      res.json({ provider: updated });
    } catch (err) {
      next(err);
    }
  });

  app.delete("/api/v1/providers/:id/models/{*modelId}", (req, res, next) => {
    try {
      const rawParam = (req.params as Record<string, string | string[]>).modelId;
      const modelId = Array.isArray(rawParam) ? rawParam.join("/") : rawParam;
      const updated = activeStore.removeProviderModel(req.params.id, decodeURIComponent(modelId || ""));
      res.json({ provider: updated });
    } catch (err) {
      next(err);
    }
  });

  app.get("/api/v1/models/router-options", (_req, res) => {
    const s = activeStore.getSettings();
    const allModels = activeStore.getRoutableModels();
    res.json({
      models: s.offline_mode ? allModels.filter((m) => m.is_local) : allModels,
      offline_mode: Boolean(s.offline_mode),
      routing: {
        routing_mode: s.routing_mode,
        routing_preference: s.routing_preference,
        default_provider_id: s.default_provider_id,
        default_model_id: s.default_model_id,
        fallback_provider_id: s.fallback_provider_id,
        fallback_model_id: s.fallback_model_id,
        request_timeout_ms: s.request_timeout_ms,
        model_id: s.model_id,
      },
    });
  });

  app.post("/api/v1/models/routing", (req, res) => {
    const body = (req.body ?? {}) as Partial<{
      routing_mode: "manual" | "auto";
      routing_preference: "fastest" | "balanced" | "capability" | "lowest_cost";
      default_provider_id: string;
      default_model_id: string;
      fallback_provider_id: string;
      fallback_model_id: string;
      request_timeout_ms: number;
      model_id: string;
    }>;
    const patch: Record<string, unknown> = {};
    if (body.routing_mode === "manual" || body.routing_mode === "auto") {
      patch.routing_mode = body.routing_mode;
    }
    if (
      body.routing_preference === "fastest" ||
      body.routing_preference === "balanced" ||
      body.routing_preference === "capability" ||
      body.routing_preference === "lowest_cost"
    ) {
      patch.routing_preference = body.routing_preference;
    }
    if (typeof body.default_provider_id === "string") patch.default_provider_id = body.default_provider_id.trim();
    if (typeof body.default_model_id === "string") patch.default_model_id = body.default_model_id.trim();
    if (typeof body.fallback_provider_id === "string") patch.fallback_provider_id = body.fallback_provider_id.trim();
    if (typeof body.fallback_model_id === "string") patch.fallback_model_id = body.fallback_model_id.trim();
    if (typeof body.request_timeout_ms === "number" && Number.isFinite(body.request_timeout_ms)) {
      patch.request_timeout_ms = Math.min(300_000, Math.max(5_000, Math.round(body.request_timeout_ms)));
    }
    if (typeof body.model_id === "string") {
      patch.model_id = body.model_id.trim();
    }
    const updatedSettings = activeStore.updateSettings(patch);
    try {
      activeStore.loadEngine(updatedSettings.routing_mode === "auto" ? "auto" : updatedSettings.model_id);
    } catch {
      /* keep settings saved even if local model needs daemon start */
    }
    res.json({ settings: updatedSettings, status: activeStore.getStatus() });
  });

  app.post("/api/v1/models/compare", async (req, res) => {
    const body = (req.body ?? {}) as {
      targets?: string[];
      prompt?: string;
      system_prompt?: string;
      mode?: "fast" | "think" | "research";
    };
    const targets = Array.isArray(body.targets) ? body.targets.filter((t): t is string => typeof t === "string") : [];
    const prompt = typeof body.prompt === "string" ? body.prompt.trim() : "";
    if (targets.length === 0) {
      return res.status(400).json({ detail: "Select at least one model target to compare." });
    }
    if (!prompt) {
      return res.status(400).json({ detail: "Comparison prompt is required." });
    }

    const controller = new AbortController();
    res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.setHeader("X-Accel-Buffering", "no");
    res.flushHeaders?.();

    const write = (payload: unknown) => {
      if (!res.writableEnded) {
        try {
          res.write(`data: ${JSON.stringify(payload)}\n\n`);
        } catch {
          controller.abort();
        }
      }
    };

    res.on("close", () => {
      if (!res.writableEnded) controller.abort();
    });

    try {
      const results = await modelRouter.compareModels({
        activeStore,
        targets,
        prompt,
        systemPrompt: typeof body.system_prompt === "string" ? body.system_prompt : undefined,
        mode: body.mode ?? "fast",
        signal: controller.signal,
        onUpdate: (result, eventType, delta) => {
          write({ type: eventType, target: result.target, result, ...(delta ? { delta } : {}) });
        },
      });
      write({ type: "complete", results });
    } catch (err) {
      write({ type: "error", message: redactSensitive(err instanceof Error ? err.message : "Comparison failed.") });
    } finally {
      if (!res.writableEnded) res.end();
    }
  });

  app.post("/api/v1/models/compare/adopt", (req, res) => {
    const body = (req.body ?? {}) as {
      conversation_id?: string | null;
      project_id?: string | null;
      prompt?: string;
      result?: CompareModelResult;
    };
    const prompt = typeof body.prompt === "string" ? body.prompt.trim() : "";
    const chosen = body.result;
    if (!prompt || !chosen || !chosen.content?.trim()) {
      return res.status(400).json({ detail: "Prompt and chosen non-empty comparison result are required." });
    }
    let conv = body.conversation_id ? activeStore.conversations.get(body.conversation_id) : undefined;
    if (!conv) {
      const title = prompt.replace(/\s+/g, " ").slice(0, 50) || "Compared response";
      conv = activeStore.createConversation(title, "chat", body.project_id ?? null);
    }
    const userMsg = activeStore.addMessage(conv.id, {
      role: "user",
      content: prompt,
      reasoning: "",
      mode: "fast",
      steps: [],
      sources: [],
      metrics: {},
      attachments: [],
      status: "complete",
    });
    const totalSec = Math.max(0.1, Math.round((chosen.total_ms / 1000) * 100) / 100);
    const assistantMsg = activeStore.addMessage(conv.id, {
      role: "assistant",
      content: chosen.content,
      reasoning: chosen.reasoning || "",
      mode: "fast",
      steps: [
        {
          id: "compare-adopt",
          kind: "model",
          title: `Adopted from Compare (${chosen.model_name})`,
          detail: `${chosen.provider_name} · ${chosen.is_local ? "Local" : "Cloud"}`,
          state: "done",
          t: 0,
          t_end: totalSec,
        },
      ],
      sources: [],
      metrics: {
        provider_id: chosen.provider_id,
        provider_name: chosen.provider_name,
        model_id: chosen.model_id,
        model_name: chosen.model_name,
        is_local: chosen.is_local,
        routed_reason: "Adopted from side-by-side model comparison",
        first_token_s: chosen.first_token_ms ? Math.round((chosen.first_token_ms / 1000) * 100) / 100 : totalSec,
        total_s: totalSec,
        prompt_tokens: chosen.prompt_tokens,
        completion_tokens: chosen.completion_tokens,
        total_tokens: chosen.prompt_tokens + chosen.completion_tokens,
        tokens_estimated: chosen.tokens_estimated,
        tokens_per_second: Math.round((chosen.completion_tokens / totalSec) * 10) / 10,
      },
      attachments: [],
      status: "complete",
    });
    res.json({ conversation: conv, user_message: userMsg, assistant_message: assistantMsg });
  });

  app.get("/api/v1/local/status", async (_req, res) => {
    const probeOne = async (id: "ollama" | "lmstudio") => {
      const p = activeStore.getProvider(id);
      if (!p) return null;
      if (!p.base_url) {
        return {
          provider: p,
          reachable: false,
          latencyMs: 0,
          message: "No local endpoint URL configured.",
        };
      }
      try {
        const disc = await discoverProviderModels({
          providerId: id,
          presetId: id,
          baseUrl: p.base_url,
          apiKey: "",
          protocol: "openai",
          timeoutMs: 2500,
        });
        const updated = activeStore.setProviderDiscovery(id, {
          models: disc.models,
          status: "healthy",
          message: disc.message,
          latencyMs: disc.latencyMs,
        });
        return {
          provider: updated,
          reachable: true,
          latencyMs: disc.latencyMs,
          message: disc.message,
        };
      } catch (err) {
        const msg = redactSensitive(err instanceof Error ? err.message : "Local daemon unreachable.");
        const updated = activeStore.setProviderDiscovery(id, {
          models: [],
          status: "unreachable",
          message: msg,
          latencyMs: null,
        });
        return {
          provider: updated,
          reachable: false,
          latencyMs: null,
          message: msg,
        };
      }
    };

    const [ollama, lmstudio] = await Promise.all([probeOne("ollama"), probeOne("lmstudio")]);
    res.json({
      ollama,
      lmstudio,
      windows_local_guide: getLocalAiWindowsGuide(),
    });
  });

  // ---- Real-Time Voice AI API ----
  app.get("/api/v1/voice/capabilities", (_req, res) => {
    res.json(getVoiceCapabilities(activeStore));
  });

  app.post("/api/v1/voice/session", (req, res) => {
    const s = activeStore.getSettings();
    if (!s.voice_enabled) {
      return res.status(409).json({ detail: "Voice AI is disabled in Settings → Voice." });
    }
    const body = (req.body ?? {}) as {
      mode?: "gemini_live" | "gemini_transcribe_live" | "router_pipeline";
      conversation_id?: string | null;
      project_id?: string | null;
      language?: string;
      voice_name?: string;
    };
    const caps = getVoiceCapabilities(activeStore);
    const requestedMode =
      body.mode ||
      (s.voice_provider === "gemini_live"
        ? "gemini_live"
        : s.voice_provider === "router_pipeline"
          ? "router_pipeline"
          : caps.recommended_engine);

    if ((requestedMode === "gemini_live" || requestedMode === "gemini_transcribe_live") && !caps.gemini_live_available) {
      return res.status(409).json({
        detail: s.offline_mode
          ? "Offline mode is active; switch Voice Engine to Router Pipeline with local STT/TTS fallback."
          : "Gemini Live requires a configured Gemini API key.",
      });
    }

    const session = voiceSessionManager.createSession({
      mode: requestedMode,
      conversationId: body.conversation_id ?? null,
      projectId: body.project_id ?? null,
      language: body.language || s.voice_language,
      voiceName: body.voice_name || s.voice_name,
      modelId: requestedMode === "gemini_transcribe_live" ? GEMINI_LIVE_TRANSCRIBE_MODEL : GEMINI_LIVE_MODEL,
    });
    activeStore.recordAudit("voice_session_created", `Started ${session.mode} voice session (${session.language}).`);

    const proto = req.protocol === "https" || req.get("x-forwarded-proto") === "https" ? "wss" : "ws";
    const host = req.get("host") || "localhost:3000";
    res.json({
      session_id: session.id,
      mode: session.mode,
      language: session.language,
      voice_name: session.voiceName,
      expires_at: session.expiresAt,
      ws_url: `${proto}://${host}/ws/voice?session=${encodeURIComponent(session.id)}`,
      capabilities: caps,
    });
  });

  app.delete("/api/v1/voice/session/:id", (req, res) => {
    const removed = voiceSessionManager.endSession(req.params.id);
    res.json({ ok: true, removed });
  });

  app.post("/api/v1/voice/transcribe", voiceAudioUpload.single("audio"), async (req, res) => {
    try {
      let audioBuffer: Buffer | null = req.file?.buffer ?? null;
      let mimeType = req.file?.mimetype || "audio/webm";
      let language = typeof req.body?.language === "string" ? req.body.language : undefined;
      let provider = typeof req.body?.provider === "string" ? (req.body.provider as VoiceSttProvider) : undefined;

      if (!audioBuffer && typeof req.body?.audio_base64 === "string" && req.body.audio_base64.trim()) {
        audioBuffer = Buffer.from(req.body.audio_base64.trim(), "base64");
        if (typeof req.body.mime_type === "string" && req.body.mime_type.trim()) {
          mimeType = req.body.mime_type.trim();
        }
      }
      if (!audioBuffer || audioBuffer.byteLength === 0) {
        return res.status(400).json({ detail: "Audio file or audio_base64 payload is required." });
      }
      if (audioBuffer.byteLength > 15 * 1024 * 1024) {
        return res.status(413).json({ detail: "Audio clip exceeds 15 MB limit." });
      }

      const result = await transcribeAudio({
        activeStore,
        audioBuffer,
        mimeType,
        language,
        preferredProvider: provider,
      });
      res.json(result);
    } catch (err) {
      const msg = redactSensitive(err instanceof Error ? err.message : "Transcription failed.");
      const status = /not configured|offline mode|required|browser speech/i.test(msg) ? 409 : 502;
      res.status(status).json({ detail: msg });
    }
  });

  app.post("/api/v1/voice/tts", async (req, res) => {
    try {
      const body = (req.body ?? {}) as {
        text?: string;
        voice_name?: string;
        speed?: number;
        language?: string;
        provider?: VoiceTtsProvider;
        high_quality?: boolean;
      };
      if (!body.text?.trim()) {
        return res.status(400).json({ detail: "text is required for speech synthesis." });
      }
      const result = await synthesizeSpeech({
        activeStore,
        text: body.text,
        voiceName: body.voice_name,
        speed: body.speed,
        language: body.language,
        preferredProvider: body.provider,
        highQuality: Boolean(body.high_quality),
      });
      res.json(result);
    } catch (err) {
      const msg = redactSensitive(err instanceof Error ? err.message : "Text-to-Speech failed.");
      const status = /not configured|offline mode|browser speechsynthesis/i.test(msg) ? 409 : 502;
      res.status(status).json({ detail: msg, browser_fallback: true });
    }
  });

  app.post("/api/v1/voice/turn", async (req, res) => {
    try {
      const body = (req.body ?? {}) as {
        transcript?: string;
        conversation_id?: string | null;
        project_id?: string | null;
        language?: string;
        mode?: Mode;
        model_id?: string;
        stt_provider?: string;
        tts_provider?: string;
        voice_backend?: string;
      };
      if (!body.transcript?.trim()) {
        return res.status(400).json({ detail: "transcript is required." });
      }
      const result = await executeVoiceAssistantTurn({
        activeStore,
        transcript: body.transcript,
        conversationId: body.conversation_id ?? null,
        projectId: body.project_id ?? null,
        language: body.language,
        mode: body.mode,
        modelId: body.model_id,
        sttProvider: body.stt_provider,
        ttsProvider: body.tts_provider,
        voiceBackend: body.voice_backend,
      });
      res.json(result);
    } catch (err) {
      const msg = redactSensitive(err instanceof Error ? err.message : "Voice turn failed.");
      const status = /not configured|offline mode|empty/i.test(msg) ? 409 : 502;
      res.status(status).json({ detail: msg });
    }
  });

  // ---- Multimodal Vision Intelligence & Image Generation API ----
  app.get("/api/v1/vision/capabilities", (_req, res) => {
    res.json(getVisionCapabilities(activeStore));
  });

  app.post(
    "/api/v1/vision/upload",
    visionImageUpload.fields([
      { name: "files", maxCount: MAX_IMAGES_PER_MESSAGE },
      { name: "file", maxCount: MAX_IMAGES_PER_MESSAGE },
    ]),
    (req, res) => {
      try {
        const filesMap = (req.files ?? {}) as Record<string, Express.Multer.File[]>;
        const list = [...(filesMap.files ?? []), ...(filesMap.file ?? [])];
        if (list.length === 0) {
          return res.status(400).json({ detail: "Upload at least one JPG, PNG, or WEBP image." });
        }
        if (list.length > MAX_IMAGES_PER_MESSAGE) {
          return res.status(400).json({ detail: `You can upload up to ${MAX_IMAGES_PER_MESSAGE} images at once.` });
        }
        const totalBytes = list.reduce((sum, f) => sum + f.size, 0);
        if (totalBytes > MAX_TOTAL_VISION_BYTES) {
          return res.status(413).json({
            detail: `Total upload size exceeds ${Math.round(MAX_TOTAL_VISION_BYTES / (1024 * 1024))} MB limit.`,
          });
        }
        const rawConvId = typeof req.body?.conversation_id === "string" ? req.body.conversation_id.trim() : null;
        const validConvId = rawConvId && activeStore.conversations.has(rawConvId) ? rawConvId : null;

        const saved = list.map((f) =>
          saveImageAttachment(activeStore.db, {
            filename: f.originalname || "image.png",
            buffer: f.buffer,
            claimedMime: f.mimetype || "",
            conversationId: validConvId,
          }),
        );
        return res.json({ attachments: saved.map(toPublicAttachment) });
      } catch (err) {
        if (err instanceof VisionValidationError) {
          return res.status(err.status).json({ detail: err.message });
        }
        return res.status(400).json({ detail: err instanceof Error ? err.message : "Image upload failed." });
      }
    },
  );

  app.get("/api/v1/vision/attachments/:id", (req, res) => {
    const rec = activeStore.db.getAttachment(req.params.id);
    if (!rec) {
      return res.status(404).json({ detail: "Attachment not found." });
    }
    try {
      const buf = readAttachmentBytes(activeStore.db, rec);
      res.setHeader("Content-Type", rec.mime);
      res.setHeader("X-Content-Type-Options", "nosniff");
      res.setHeader("Cache-Control", "private, max-age=3600");
      res.setHeader("Content-Disposition", `inline; filename="${sanitizeFilename(rec.name)}"`);
      return res.send(buf);
    } catch (err) {
      const status = err instanceof VisionValidationError ? err.status : 404;
      return res.status(status).json({ detail: err instanceof Error ? err.message : "Attachment unavailable." });
    }
  });

  app.delete("/api/v1/vision/attachments/:id", (req, res) => {
    const removed = activeStore.db.deleteAttachment(req.params.id);
    if (removed) {
      deleteStoredFiles(activeStore.db, [removed.storage_path]);
    }
    res.json({ ok: true, removed: Boolean(removed) });
  });

  app.post("/api/v1/vision/analyze", async (req, res) => {
    try {
      const body = (req.body ?? {}) as { image_ids?: string[]; prompt?: string; model_id?: string };
      const imageIds = Array.isArray(body.image_ids)
        ? body.image_ids.filter((x): x is string => typeof x === "string" && x.trim().length > 0)
        : [];
      const result = await analyzeImagesWithVisionModel({
        activeStore,
        imageIds,
        prompt: body.prompt || "",
        modelId: body.model_id,
      });
      res.json(result);
    } catch (err) {
      const msg = redactSensitive(err instanceof Error ? err.message : "Image analysis failed.");
      const status =
        err instanceof VisionValidationError
          ? err.status
          : /not configured|offline mode|does not have verified vision|no vision-capable/i.test(msg)
            ? 409
            : 502;
      res.status(status).json({ detail: msg });
    }
  });

  app.post("/api/v1/vision/documents/:id/analyze", async (req, res) => {
    try {
      const body = (req.body ?? {}) as { prompt?: string; model_id?: string };
      const result = await analyzeDocumentVisually({
        activeStore,
        docId: req.params.id,
        prompt: body.prompt,
        modelId: body.model_id,
      });
      res.json(result);
    } catch (err) {
      const msg = redactSensitive(err instanceof Error ? err.message : "Visual PDF analysis failed.");
      const status =
        err instanceof VisionValidationError
          ? err.status
          : /not configured|offline mode|no pdf-capable/i.test(msg)
            ? 409
            : 502;
      res.status(status).json({ detail: msg });
    }
  });

  app.post("/api/v1/vision/generate", async (req, res) => {
    try {
      const body = (req.body ?? {}) as {
        prompt?: string;
        provider?: "auto" | "gemini" | "openai";
        model?: string;
        aspect_ratio?: string;
        image_size?: "1K" | "2K" | "4K";
        search_grounding?: boolean;
        conversation_id?: string | null;
        project_id?: string | null;
        save_to_conversation?: boolean;
      };
      let conv = body.conversation_id ? activeStore.conversations.get(body.conversation_id) : undefined;
      if (body.save_to_conversation && !conv) {
        const title = (body.prompt || "Generated image").replace(/\s+/g, " ").slice(0, 50);
        conv = activeStore.createConversation(title, "chat", body.project_id ?? null);
      }

      const result = await generateOrEditImage({
        activeStore,
        mode: "generate",
        prompt: body.prompt || "",
        provider: body.provider,
        model: body.model,
        aspectRatio: body.aspect_ratio,
        imageSize: body.image_size,
        searchGrounding: Boolean(body.search_grounding),
        conversationId: conv?.id ?? null,
      });

      if (body.save_to_conversation && conv) {
        const userMsg = activeStore.addMessage(conv.id, {
          role: "user",
          content: `Generate image: ${(body.prompt || "").trim()}`,
          reasoning: "",
          mode: "fast",
          steps: [],
          sources: [],
          metrics: {},
          attachments: [],
          status: "complete",
        });
        const assistantMsg = activeStore.addMessage(conv.id, {
          role: "assistant",
          content: result.caption || `Generated image using **${result.model}**.`,
          reasoning: "",
          mode: "fast",
          steps: [
            {
              id: "vision-gen",
              kind: "tool",
              title: `Image Generated (${result.model})`,
              detail: body.aspect_ratio || "1:1",
              state: "done",
            },
          ],
          sources: [],
          metrics: {
            provider_id: result.provider,
            provider_name: result.provider === "gemini" ? "Google Gemini" : "OpenAI",
            model_id: result.model,
            model_name: result.model,
            is_local: false,
            model_calls: 1,
          },
          attachments: [result.attachment],
          status: "complete",
        });
        activeStore.db.bindAttachmentsToConversation([result.attachment.id], conv.id, assistantMsg.id);
        return res.json({ ...result, conversation: conv, user_message: userMsg, assistant_message: assistantMsg });
      }
      return res.json(result);
    } catch (err) {
      const msg = redactSensitive(err instanceof Error ? err.message : "Image generation failed.");
      const status =
        err instanceof VisionValidationError
          ? err.status
          : /not configured|offline mode|unavailable/i.test(msg)
            ? 409
            : 502;
      return res.status(status).json({ detail: msg });
    }
  });

  app.post("/api/v1/vision/edit", async (req, res) => {
    try {
      const body = (req.body ?? {}) as {
        prompt?: string;
        source_image_ids?: string[];
        provider?: "auto" | "gemini" | "openai";
        model?: string;
        aspect_ratio?: string;
        image_size?: "1K" | "2K" | "4K";
        conversation_id?: string | null;
        project_id?: string | null;
        save_to_conversation?: boolean;
      };
      let conv = body.conversation_id ? activeStore.conversations.get(body.conversation_id) : undefined;
      if (body.save_to_conversation && !conv) {
        const title = (body.prompt || "Edited image").replace(/\s+/g, " ").slice(0, 50);
        conv = activeStore.createConversation(title, "chat", body.project_id ?? null);
      }

      const result = await generateOrEditImage({
        activeStore,
        mode: "edit",
        prompt: body.prompt || "",
        sourceImageIds: Array.isArray(body.source_image_ids) ? body.source_image_ids : [],
        provider: body.provider,
        model: body.model,
        aspectRatio: body.aspect_ratio,
        imageSize: body.image_size,
        conversationId: conv?.id ?? null,
      });

      if (body.save_to_conversation && conv) {
        const sourceAtts = activeStore.db
          .listAttachmentsByIds(Array.isArray(body.source_image_ids) ? body.source_image_ids : [])
          .map(toPublicAttachment);
        const userMsg = activeStore.addMessage(conv.id, {
          role: "user",
          content: `Edit image: ${(body.prompt || "").trim()}`,
          reasoning: "",
          mode: "fast",
          steps: [],
          sources: [],
          metrics: {},
          attachments: sourceAtts,
          status: "complete",
        });
        const assistantMsg = activeStore.addMessage(conv.id, {
          role: "assistant",
          content: result.caption || `Edited image using **${result.model}**.`,
          reasoning: "",
          mode: "fast",
          steps: [
            {
              id: "vision-edit",
              kind: "tool",
              title: `Image Edited (${result.model})`,
              detail: body.aspect_ratio || "1:1",
              state: "done",
            },
          ],
          sources: [],
          metrics: {
            provider_id: result.provider,
            provider_name: result.provider === "gemini" ? "Google Gemini" : "OpenAI",
            model_id: result.model,
            model_name: result.model,
            is_local: false,
            model_calls: 1,
          },
          attachments: [result.attachment],
          status: "complete",
        });
        activeStore.db.bindAttachmentsToConversation(
          [...sourceAtts.map((a) => a.id), result.attachment.id],
          conv.id,
          assistantMsg.id,
        );
        return res.json({ ...result, conversation: conv, user_message: userMsg, assistant_message: assistantMsg });
      }
      return res.json(result);
    } catch (err) {
      const msg = redactSensitive(err instanceof Error ? err.message : "Image editing failed.");
      const status =
        err instanceof VisionValidationError
          ? err.status
          : /not configured|offline mode|unavailable/i.test(msg)
            ? 409
            : 502;
      return res.status(status).json({ detail: msg });
    }
  });
}

