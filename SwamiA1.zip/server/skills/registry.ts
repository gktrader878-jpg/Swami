import { GoogleGenAI } from "@google/genai";
import { browserEngine } from "../browser/service";
import { computeLoanEmi, evaluateArithmetic } from "../calculator";
import { buildDocumentContext, searchDocumentChunks } from "../documents";
import { modelRouter, type PromptTaskType } from "../models/router";
import { runDeepResearch } from "../research/service";
import { redactSensitive } from "../security/secrets";
import { store, type SwamiStore } from "../store";
import type { Step } from "../types";

export interface SkillFieldSchema {
  name: string;
  type: "string" | "number" | "boolean" | "object";
  required: boolean;
  description: string;
}

export interface SkillExecutionContext {
  store?: SwamiStore;
  conversationId?: string | null;
  projectId?: string | null;
  documentIds?: string[];
  signal?: AbortSignal;
  onStep?: (step: Step) => void;
}

export interface SkillExecutionResult {
  skillId: string;
  status: "success" | "error";
  summary: string;
  output: Record<string, unknown>;
  durationMs: number;
  error?: string;
}

export interface SkillDefinition {
  id: string;
  name: string;
  description: string;
  version: string;
  instructions: string;
  category:
    | "research"
    | "coding"
    | "math"
    | "writing"
    | "document"
    | "data"
    | "study"
    | "browser"
    | "image"
    | "productivity";
  enabled: boolean;
  requiredTools: string[];
  requiredPermissions: string[];
  inputSchema: SkillFieldSchema[];
  outputSchema: SkillFieldSchema[];
  execute: (input: Record<string, unknown>, ctx: SkillExecutionContext) => Promise<{
    summary: string;
    output: Record<string, unknown>;
  }>;
}

export type PublicSkillDefinition = Omit<SkillDefinition, "execute">;

export class SkillExecutionError extends Error {
  status: number;
  code: string;
  constructor(message: string, status = 400, code = "SKILL_ERROR") {
    super(message);
    this.status = status;
    this.code = code;
  }
}

export function validateSkillInput(skill: SkillDefinition, rawInput: unknown): Record<string, unknown> {
  if (!rawInput || typeof rawInput !== "object" || Array.isArray(rawInput)) {
    throw new SkillExecutionError(`Skill '${skill.id}' requires a JSON object input.`, 400, "INVALID_SKILL_INPUT");
  }
  const input = rawInput as Record<string, unknown>;
  for (const field of skill.inputSchema) {
    const val = input[field.name];
    if (field.required && (val === undefined || val === null || (typeof val === "string" && !val.trim()))) {
      throw new SkillExecutionError(
        `Missing required field '${field.name}' for skill '${skill.id}'.`,
        400,
        "INVALID_SKILL_INPUT",
      );
    }
    if (val !== undefined && val !== null) {
      if (field.type === "string" && typeof val !== "string") {
        throw new SkillExecutionError(`Field '${field.name}' must be a string.`, 400, "INVALID_SKILL_INPUT");
      }
      if (field.type === "number" && typeof val !== "number") {
        throw new SkillExecutionError(`Field '${field.name}' must be a number.`, 400, "INVALID_SKILL_INPUT");
      }
      if (field.type === "boolean" && typeof val !== "boolean") {
        throw new SkillExecutionError(`Field '${field.name}' must be a boolean.`, 400, "INVALID_SKILL_INPUT");
      }
    }
  }
  return input;
}

async function runActiveLlmText(
  activeStore: SwamiStore,
  systemPrompt: string,
  userPrompt: string,
  signal?: AbortSignal,
  taskType: PromptTaskType = "general",
): Promise<string> {
  const settings = activeStore.getSettings();
  const routable = activeStore.getRoutableModels();
  const usablePool = settings.offline_mode ? routable.filter((m) => m.is_local) : routable;

  if (usablePool.length === 0) {
    throw new SkillExecutionError(
      settings.offline_mode
        ? "Offline mode is enabled and no local Ollama/LM Studio model is available."
        : "No configured provider/model is active (add an API key or local Ollama/LM Studio under Settings → API providers).",
      settings.offline_mode ? 403 : 409,
      settings.offline_mode ? "OFFLINE_BLOCKED" : "NO_MODEL_CONFIGURED",
    );
  }

  const res = await modelRouter.generateText({
    activeStore,
    mode: "fast",
    systemPrompt,
    userPrompt,
    taskType,
    timeoutMs: 30000,
    signal: signal ?? AbortSignal.timeout(30000),
  });
  return res.text;
}

export function analyzeTabularData(rawText: string): {
  format: "json" | "csv";
  rowCount: number;
  columns: string[];
  numericStats: Record<string, { count: number; min: number; max: number; sum: number; mean: number }>;
  sampleRows: Array<Record<string, unknown>>;
} {
  const trimmed = rawText.trim();
  if (!trimmed) {
    throw new SkillExecutionError("Input data is empty.", 400, "EMPTY_DATA");
  }

  let rows: Array<Record<string, unknown>> = [];
  let format: "json" | "csv" = "csv";

  if (trimmed.startsWith("[") || trimmed.startsWith("{")) {
    let parsed: unknown;
    try {
      parsed = JSON.parse(trimmed);
    } catch {
      throw new SkillExecutionError("Invalid JSON data provided.", 400, "INVALID_DATA");
    }
    const arr = Array.isArray(parsed) ? parsed : [parsed];
    rows = arr.filter((x): x is Record<string, unknown> => Boolean(x) && typeof x === "object" && !Array.isArray(x));
    format = "json";
  } else {
    const lines = trimmed.split(/\r?\n/).filter((l) => l.trim().length > 0);
    if (lines.length < 2) {
      throw new SkillExecutionError("CSV/TSV data needs a header row and at least one data row.", 400, "INVALID_DATA");
    }
    const delimiter = lines[0].includes("\t") ? "\t" : ",";
    const headers = lines[0].split(delimiter).map((h) => h.trim().replace(/^"|"$/g, ""));
    for (let i = 1; i < lines.length; i++) {
      const cells = lines[i].split(delimiter).map((c) => c.trim().replace(/^"|"$/g, ""));
      const obj: Record<string, unknown> = {};
      headers.forEach((h, idx) => {
        const raw = cells[idx] ?? "";
        const num = raw !== "" && !Number.isNaN(Number(raw)) ? Number(raw) : raw;
        obj[h || `col_${idx + 1}`] = num;
      });
      rows.push(obj);
    }
  }

  if (rows.length === 0) {
    throw new SkillExecutionError("No structured rows found in data input.", 400, "EMPTY_DATA");
  }

  const columnSet = new Set<string>();
  for (const r of rows) {
    for (const k of Object.keys(r)) columnSet.add(k);
  }
  const columns = Array.from(columnSet);
  const numericStats: Record<string, { count: number; min: number; max: number; sum: number; mean: number }> = {};

  for (const col of columns) {
    const nums = rows
      .map((r) => r[col])
      .filter((v): v is number => typeof v === "number" && Number.isFinite(v));
    if (nums.length > 0) {
      const sum = nums.reduce((a, b) => a + b, 0);
      const min = Math.min(...nums);
      const max = Math.max(...nums);
      numericStats[col] = {
        count: nums.length,
        min,
        max,
        sum: Math.round(sum * 10000) / 10000,
        mean: Math.round((sum / nums.length) * 10000) / 10000,
      };
    }
  }

  return {
    format,
    rowCount: rows.length,
    columns,
    numericStats,
    sampleRows: rows.slice(0, 5),
  };
}

export class SkillRegistry {
  private skills = new Map<string, SkillDefinition>();

  constructor() {
    this.registerDefaults();
  }

  private registerDefaults() {
    const defaults: SkillDefinition[] = [
      {
        id: "research",
        name: "Research Skill",
        description: "Executes multi-step web searches, extracts real webpage content, and builds cited reports.",
        version: "1.1.0",
        instructions: "Decompose query, query search provider, read pages, and verify citations.",
        category: "research",
        enabled: true,
        requiredTools: ["web_search", "page_fetch"],
        requiredPermissions: ["web_search"],
        inputSchema: [{ name: "query", type: "string", required: true, description: "Research question or topic" }],
        outputSchema: [
          { name: "report", type: "string", required: true, description: "Markdown report with verified citations" },
          { name: "sources", type: "object", required: true, description: "Retrieved source records" },
        ],
        execute: async (input, ctx) => {
          const activeStore = ctx.store ?? store;
          const s = activeStore.getSettings();
          if (s.offline_mode || !s.web_research_enabled) {
            throw new SkillExecutionError("Web research is blocked while Offline mode is on or Web research is off.", 403, "PERMISSION_DENIED");
          }
          const query = String(input.query).trim();
          const result = await runDeepResearch({
            topic: query,
            searchProvider: s.search_provider,
            searxngUrl: s.searxng_url,
            braveApiKey: activeStore.braveApiKey,
            maxSources: Math.min(6, s.research_max_sources || 6),
            maxRounds: s.research_max_rounds || 2,
            synthesisModel:
              activeStore.getRoutableModels().length > 0
                ? { kind: "router", activeStore }
                : { kind: "local-extract" },
            signal: ctx.signal ?? AbortSignal.timeout(45000),
            callbacks: {
              elapsedSec: () => 0,
              onStep: (step) => ctx.onStep?.(step),
              onSources: () => {},
              onToken: () => {},
            },
          });
          return {
            summary: `Completed research across ${result.sources.length} real source(s).`,
            output: {
              report: result.report,
              sources: result.sources,
              subQueries: result.subQueries,
              failedUrls: result.failedUrls,
            },
          };
        },
      },
      {
        id: "coding",
        name: "Coding Skill",
        description: "Generates and reviews modular code, algorithms, and unit tests.",
        version: "1.1.0",
        instructions: "Produce clean, well-typed code with deterministic test cases.",
        category: "coding",
        enabled: true,
        requiredTools: ["llm"],
        requiredPermissions: [],
        inputSchema: [{ name: "task", type: "string", required: true, description: "Coding task or code snippet to review" }],
        outputSchema: [{ name: "solution", type: "string", required: true, description: "Code and explanation" }],
        execute: async (input, ctx) => {
          const activeStore = ctx.store ?? store;
          const task = String(input.task).trim();
          const solution = await runActiveLlmText(
            activeStore,
            "You are a senior software engineer. Provide clean, modular, accurate code and unit test cases.",
            task,
            ctx.signal,
          );
          return {
            summary: `Generated code solution (${solution.length} chars).`,
            output: { solution },
          };
        },
      },
      {
        id: "math",
        name: "Mathematics Skill",
        description: "Evaluates exact arithmetic expressions and reducing-balance loan EMI formulas deterministically.",
        version: "1.1.0",
        instructions: "Use deterministic calculator evaluation for arithmetic and EMI; use LLM for symbolic proofs.",
        category: "math",
        enabled: true,
        requiredTools: ["calculator"],
        requiredPermissions: ["calculator"],
        inputSchema: [{ name: "expression", type: "string", required: true, description: "Math expression or math problem" }],
        outputSchema: [{ name: "result", type: "string", required: true, description: "Evaluated numerical or symbolic answer" }],
        execute: async (input, ctx) => {
          const activeStore = ctx.store ?? store;
          const expr = String(input.expression).trim();
          const calc = evaluateArithmetic(expr);
          if (calc.ok) {
            return {
              summary: `${expr} = ${calc.formatted}`,
              output: { expression: expr, value: calc.value, formatted: calc.formatted, result: calc.formatted },
            };
          }
          if (/emi|loan/i.test(expr)) {
            const pMatch = expr.match(/([\d,]{4,})/);
            const rMatch = expr.match(/(\d+(?:\.\d+)?)\s*%/);
            const yMatch = expr.match(/(\d+(?:\.\d+)?)\s*years?/i);
            const P = pMatch ? Number(pMatch[1].replace(/,/g, "")) : 850000;
            const rate = rMatch ? Number(rMatch[1]) : 9.5;
            const years = yMatch ? Number(yMatch[1]) : 7;
            const emi = computeLoanEmi(P, rate, years);
            return {
              summary: `EMI = ${emi.emi.toFixed(2)} (Total Interest = ${emi.totalInterest.toFixed(2)})`,
              output: { ...emi, result: emi.emi.toFixed(2) },
            };
          }
          const solved = await runActiveLlmText(
            activeStore,
            "Solve this mathematical problem accurately step-by-step.",
            expr,
            ctx.signal,
          );
          return { summary: "Solved with active model.", output: { result: solved } };
        },
      },
      {
        id: "writing",
        name: "Writing Skill",
        description: "Drafts, rewrites, edits, and refines prose with requested tone.",
        version: "1.1.0",
        instructions: "Improve clarity, flow, and tone without altering core meaning.",
        category: "writing",
        enabled: true,
        requiredTools: ["llm"],
        requiredPermissions: [],
        inputSchema: [
          { name: "text", type: "string", required: true, description: "Text to write, edit, or rewrite" },
          { name: "tone", type: "string", required: false, description: "Optional tone (direct, technical, creative, balanced)" },
        ],
        outputSchema: [{ name: "draft", type: "string", required: true, description: "Refined text" }],
        execute: async (input, ctx) => {
          const activeStore = ctx.store ?? store;
          const text = String(input.text).trim();
          const tone = typeof input.tone === "string" && input.tone.trim() ? input.tone.trim() : activeStore.settings.style;
          const draft = await runActiveLlmText(
            activeStore,
            `You are an expert editor. Respond in a ${tone} tone. Keep prose clear and concise.`,
            text,
            ctx.signal,
          );
          return { summary: `Drafted ${tone} response (${draft.length} chars).`, output: { draft, tone } };
        },
      },
      {
        id: "document",
        name: "Document Analysis Skill",
        description: "Searches uploaded text, CSV, JSON, PDF, and DOCX documents and quotes matching passages.",
        version: "1.1.0",
        instructions: "Query indexed document chunks and return grounded excerpts.",
        category: "document",
        enabled: true,
        requiredTools: ["document_search"],
        requiredPermissions: ["document_read"],
        inputSchema: [{ name: "question", type: "string", required: true, description: "Question about uploaded documents" }],
        outputSchema: [
          { name: "passages", type: "object", required: true, description: "Matched document chunks" },
          { name: "context", type: "string", required: true, description: "Extracted document context" },
        ],
        execute: async (input, ctx) => {
          const activeStore = ctx.store ?? store;
          const docIds =
            ctx.documentIds && ctx.documentIds.length > 0
              ? ctx.documentIds
              : activeStore.listDocumentsFor(ctx.conversationId ?? null).map((d) => d.id);
          if (docIds.length === 0) {
            throw new SkillExecutionError("No uploaded documents found to analyze.", 404, "NO_DOCUMENTS");
          }
          const question = String(input.question).trim();
          const hits = searchDocumentChunks(question, docIds, activeStore.documents, activeStore.chunks, 6);
          const { contextBlock, used } = buildDocumentContext(
            question,
            docIds,
            activeStore.documents,
            activeStore.chunks,
            6000,
          );
          return {
            summary: `Matched ${hits.length} passage(s) across ${docIds.length} document(s).`,
            output: {
              passages: hits.map((h) => ({ doc: h.name, chunk: h.chunk_index, score: h.score, text: h.text })),
              used,
              context: contextBlock,
            },
          };
        },
      },
      {
        id: "data",
        name: "Data Analysis Skill",
        description: "Parses real CSV, TSV, or JSON datasets and computes row counts, column names, and numeric statistics.",
        version: "1.1.0",
        instructions: "Compute deterministic column/numeric statistics from tabular payloads or uploaded CSV/JSON files.",
        category: "data",
        enabled: true,
        requiredTools: ["tabular_parser"],
        requiredPermissions: [],
        inputSchema: [{ name: "data", type: "string", required: true, description: "Raw CSV, TSV, or JSON array string" }],
        outputSchema: [
          { name: "rowCount", type: "number", required: true, description: "Number of records" },
          { name: "columns", type: "object", required: true, description: "Column names" },
          { name: "numericStats", type: "object", required: true, description: "Min/max/sum/mean per numeric column" },
        ],
        execute: async (input) => {
          const rawData = String(input.data);
          const stats = analyzeTabularData(rawData);
          return {
            summary: `Analyzed ${stats.rowCount} ${stats.format.toUpperCase()} row(s) across ${stats.columns.length} column(s).`,
            output: stats,
          };
        },
      },
      {
        id: "study",
        name: "Study Assistant Skill",
        description: "Breaks complex topics into intuitive explanations, analogies, and quick self-check questions.",
        version: "1.1.0",
        instructions: "Teach step-by-step with clear analogies and 3 check-your-understanding questions.",
        category: "study",
        enabled: true,
        requiredTools: ["llm"],
        requiredPermissions: [],
        inputSchema: [{ name: "topic", type: "string", required: true, description: "Topic or concept to study" }],
        outputSchema: [{ name: "guide", type: "string", required: true, description: "Structured study guide" }],
        execute: async (input, ctx) => {
          const activeStore = ctx.store ?? store;
          const topic = String(input.topic).trim();
          const guide = await runActiveLlmText(
            activeStore,
            "You are a patient tutor. Explain clearly with an everyday analogy, core concepts, and 3 self-check quiz questions.",
            topic,
            ctx.signal,
          );
          return { summary: `Built study guide for "${topic.slice(0, 60)}".`, output: { guide } };
        },
      },
      {
        id: "browser",
        name: "Browser Automation Skill",
        description: "Opens allowlisted webpages in headless Chromium, extracts structured content, and captures screenshots.",
        version: "1.1.0",
        instructions: "Create a browser session on an allowlisted URL and extract content or execute safe actions.",
        category: "browser",
        enabled: true,
        requiredTools: ["playwright_browser"],
        requiredPermissions: ["browser_automation"],
        inputSchema: [{ name: "url", type: "string", required: true, description: "Allowlisted HTTP/HTTPS URL to inspect" }],
        outputSchema: [
          { name: "session", type: "object", required: true, description: "Browser session state with extracted text" },
        ],
        execute: async (input, ctx) => {
          const activeStore = ctx.store ?? store;
          if (activeStore.getSettings().offline_mode) {
            throw new SkillExecutionError("Browser automation is disabled while Offline mode is enabled.", 403, "OFFLINE_BLOCKED");
          }
          const url = String(input.url).trim();
          const session = browserEngine.createSession(url);
          const updated = await browserEngine.executeWorkflow(session.id, url, [{ type: "extract", target: "body" }]);
          await browserEngine.closeHandle(session.id);
          if (updated.status === "error") {
            throw new SkillExecutionError(updated.error || "Browser navigation failed.", 502, "BROWSER_ERROR");
          }
          return {
            summary: `Opened ${updated.url} (${updated.title})`,
            output: { session: updated },
          };
        },
      },
      {
        id: "image",
        name: "Image Analysis Skill",
        description: "Analyzes base64/data-URL images via Gemini multimodal vision when GEMINI_API_KEY is configured.",
        version: "1.1.0",
        instructions: "Inspect provided image data URL and return structured visual description and OCR text.",
        category: "image",
        enabled: true,
        requiredTools: ["gemini_vision"],
        requiredPermissions: ["vision"],
        inputSchema: [
          { name: "imageDataUrl", type: "string", required: true, description: "Base64 data URL (e.g. data:image/png;base64,...)" },
          { name: "prompt", type: "string", required: false, description: "Question about the image" },
        ],
        outputSchema: [{ name: "analysis", type: "string", required: true, description: "Visual inspection result" }],
        execute: async (input, ctx) => {
          const activeStore = ctx.store ?? store;
          if (activeStore.getSettings().offline_mode) {
            throw new SkillExecutionError("Image vision API is disabled in Offline mode.", 403, "OFFLINE_BLOCKED");
          }
          const rawUrl = String(input.imageDataUrl).trim();
          const match = rawUrl.match(/^data:(image\/(?:png|jpeg|jpg|webp|gif));base64,([A-Za-z0-9+/=]+)$/i);
          if (!match) {
            throw new SkillExecutionError(
              "Provide a valid base64 image data URL (data:image/png|jpeg|webp;base64,...).",
              400,
              "INVALID_IMAGE",
            );
          }
          const apiKey = activeStore.getProviderApiKey("gemini") || process.env.GEMINI_API_KEY?.trim();
          if (!apiKey) {
            throw new SkillExecutionError(
              "A configured Gemini API key is required for multimodal image analysis.",
              409,
              "MISSING_API_KEY",
            );
          }
          const ai = new GoogleGenAI({ apiKey, httpOptions: { headers: { "User-Agent": "aistudio-build" } } });
          const question = typeof input.prompt === "string" && input.prompt.trim()
            ? input.prompt.trim()
            : "Describe this image accurately and extract any visible text.";
          const resp = await ai.models.generateContent({
            model: "gemini-3.1-flash-lite",
            contents: [
              {
                role: "user",
                parts: [
                  { text: question },
                  { inlineData: { mimeType: match[1].toLowerCase(), data: match[2] } },
                ],
              },
            ],
            config: { abortSignal: ctx.signal ?? AbortSignal.timeout(30000) },
          });
          const analysis = resp.text ?? "";
          return { summary: `Analyzed ${match[1]} image.`, output: { analysis } };
        },
      },
      {
        id: "productivity",
        name: "Productivity Skill",
        description: "Turns goals, notes, or brainstorms into prioritized action items and structured milestones.",
        version: "1.1.0",
        instructions: "Extract concrete action items, owners/timeframes, and priorities.",
        category: "productivity",
        enabled: true,
        requiredTools: ["task_planner"],
        requiredPermissions: [],
        inputSchema: [{ name: "notes", type: "string", required: true, description: "Tasks, goals, or unstructured notes" }],
        outputSchema: [
          { name: "tasks", type: "object", required: true, description: "Prioritized task breakdown" },
        ],
        execute: async (input) => {
          const notes = String(input.notes).trim();
          const rawLines = notes
            .split(/[\n;]+/)
            .map((l) => l.replace(/^[-*\d.)\s]+/, "").trim())
            .filter((l) => l.length > 2);
          const tasks = (rawLines.length > 0 ? rawLines : [notes]).map((item, idx) => ({
            priority: /\b(urgent|asap|critical|today|blocker|fix)\b/i.test(item)
              ? "high"
              : idx === 0
                ? "medium"
                : "normal",
            title: item,
            status: "todo",
          }));
          return {
            summary: `Organized ${tasks.length} prioritized action item(s).`,
            output: { tasks },
          };
        },
      },
    ];

    for (const s of defaults) {
      this.skills.set(s.id, s);
    }
  }

  listSkills(): PublicSkillDefinition[] {
    return Array.from(this.skills.values()).map(({ execute: _exec, ...rest }) => rest);
  }

  getSkill(id: string): SkillDefinition | undefined {
    return this.skills.get(id);
  }

  setSkillEnabled(id: string, enabled: boolean): boolean {
    const s = this.skills.get(id);
    if (!s) return false;
    s.enabled = enabled;
    return true;
  }

  detectRelevantSkills(prompt: string, options: { hasDocuments?: boolean; mode?: string } = {}): string[] {
    const q = prompt.toLowerCase();
    const chosen: string[] = [];
    const addIfEnabled = (id: string) => {
      const sk = this.skills.get(id);
      if (sk?.enabled && !chosen.includes(id)) chosen.push(id);
    };

    if (options.mode === "research" || /\b(research|investigate|compare sources|citations)\b/.test(q)) {
      addIfEnabled("research");
    }
    if (options.hasDocuments) {
      addIfEnabled("document");
    }
    if (/\b(csv|json|dataset|average|mean|min|max|table|tabular|rows|columns)\b/.test(q)) {
      addIfEnabled("data");
    }
    if (/\d\s*[+\-*/^]\s*\d|\b(emi|loan|calculate|compute|arithmetic)\b/.test(q)) {
      addIfEnabled("math");
    }
    if (/\b(https?:\/\/|open url|browse:|screenshot|webpage|website)\b/.test(q)) {
      addIfEnabled("browser");
    }
    if (/\b(function|algorithm|typescript|python|react|code|refactor|bug|unit test)\b/.test(q)) {
      addIfEnabled("coding");
    }
    if (/\b(rewrite|draft|email|tone|polish|proofread|essay)\b/.test(q)) {
      addIfEnabled("writing");
    }
    if (/\b(explain|study|quiz|analogy|flashcard|learn)\b/.test(q)) {
      addIfEnabled("study");
    }
    if (/\b(todo|action items|roadmap|checklist|prioritize|schedule|tasks)\b/.test(q)) {
      addIfEnabled("productivity");
    }
    return chosen;
  }

  async executeSkill(
    id: string,
    rawInput: Record<string, unknown>,
    ctx: SkillExecutionContext = {},
  ): Promise<SkillExecutionResult> {
    const activeStore = ctx.store ?? store;
    const skill = this.skills.get(id);
    if (!skill) {
      throw new SkillExecutionError(`Skill '${id}' not found.`, 404, "SKILL_NOT_FOUND");
    }
    if (!skill.enabled) {
      throw new SkillExecutionError(`Skill '${skill.name}' is currently disabled.`, 403, "SKILL_DISABLED");
    }

    const started = performance.now();
    const inputSummary = redactSensitive(JSON.stringify(rawInput)).slice(0, 400);

    try {
      const validated = validateSkillInput(skill, rawInput);
      const res = await skill.execute(validated, { ...ctx, store: activeStore });
      const durationMs = Math.max(1, Math.round(performance.now() - started));

      try {
        activeStore.recordSkillExecution({
          skill_id: skill.id,
          status: "success",
          input_summary: inputSummary,
          output_summary: res.summary,
          error: null,
          duration_ms: durationMs,
        });
      } catch {
        /* ignore if store DB closed */
      }

      return {
        skillId: skill.id,
        status: "success",
        summary: res.summary,
        output: res.output,
        durationMs,
      };
    } catch (err) {
      const durationMs = Math.max(1, Math.round(performance.now() - started));
      const errMsg = redactSensitive(err instanceof Error ? err.message : "Skill execution failed.");
      try {
        activeStore.recordSkillExecution({
          skill_id: skill.id,
          status: "error",
          input_summary: inputSummary,
          output_summary: "",
          error: errMsg,
          duration_ms: durationMs,
        });
      } catch {
        /* ignore if store DB closed */
      }
      if (err instanceof SkillExecutionError) throw err;
      throw new SkillExecutionError(errMsg, 500, "SKILL_EXECUTION_FAILED");
    }
  }

  getExecutionHistory(activeStore: SwamiStore = store, limit = 40) {
    return activeStore.listSkillExecutions(limit);
  }
}

export const skillRegistry = new SkillRegistry();
