import assert from "node:assert/strict";
import http from "node:http";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import { WebSocket } from "ws";
import { createApp } from "../server";
import { SwamiStore } from "./store";
import {
  classifyVoiceIntent,
  computePcm16Rms,
  formatTextForSpeech,
  isVadSpeechActive,
  pcm16ToWavBuffer,
  resolveVoiceLanguage,
  VoiceSessionManager,
  voiceSessionManager,
} from "./voice/engine";
import { attachVoiceWebSocketServer } from "./voice/live";

function createTestStore(): { store: SwamiStore; dir: string } {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "swami-voice-test-"));
  const store = new SwamiStore(dir, "voice-test.db");
  return { store, dir };
}

function listenServer(server: http.Server): Promise<{ port: number; close: () => Promise<void> }> {
  return new Promise((resolve) => {
    server.listen(0, "127.0.0.1", () => {
      const addr = server.address();
      const port = typeof addr === "object" && addr ? addr.port : 0;
      resolve({
        port,
        close: () =>
          new Promise<void>((res) => {
            server.close(() => res());
          }),
      });
    });
  });
}

test("VoiceEngine: intent classification, speech markdown formatting, PCM16/WAV & VAD helpers", () => {
  assert.equal(classifyVoiceIntent("Research the latest developments in solid state batteries").kind, "research");
  assert.equal(classifyVoiceIntent("Remember that I prefer concise replies in Hindi").kind, "memory_save");
  assert.equal(classifyVoiceIntent("Remember that I prefer concise replies in Hindi").memoryFact, "I prefer concise replies in Hindi");
  assert.equal(classifyVoiceIntent("Open website https://evil.example.com").kind, "browser");
  assert.equal(classifyVoiceIntent("Open website https://evil.example.com").extractedUrl, "https://evil.example.com");
  assert.equal(classifyVoiceIntent("Calculate 18% of 4250").kind, "skill");
  assert.equal(classifyVoiceIntent("Explain quantum tunneling simply").kind, "chat");

  const formatted = formatTextForSpeech(
    "## Quantum Summary\nHere is **key** info [1]: visit https://example.com.\n```ts\nconsole.log('hi');\n```",
    400,
  );
  assert.equal(formatted.includes("##"), false);
  assert.equal(formatted.includes("**"), false);
  assert.equal(formatted.includes("[1]"), false);
  assert.equal(formatted.includes("https://example.com"), false);
  assert.match(formatted, /Quantum Summary/);
  assert.match(formatted, /Code example omitted for voice playback/);

  assert.equal(resolveVoiceLanguage("hi-IN").bcp47, "hi-IN");
  assert.equal(resolveVoiceLanguage("unknown-xx").code, "en-IN");

  // Silent PCM buffer vs active tone buffer
  const silentPcm = Buffer.alloc(640);
  assert.equal(computePcm16Rms(silentPcm), 0);
  assert.equal(isVadSpeechActive(computePcm16Rms(silentPcm), 0.55), false);

  const loudPcm = Buffer.alloc(640);
  for (let i = 0; i < 320; i++) {
    loudPcm.writeInt16LE(Math.round(Math.sin(i / 4) * 18000), i * 2);
  }
  const rms = computePcm16Rms(loudPcm);
  assert.ok(rms > 0.3);
  assert.equal(isVadSpeechActive(rms, 0.55), true);

  const wav = pcm16ToWavBuffer(loudPcm, 24000, 1);
  assert.equal(wav.subarray(0, 4).toString("ascii"), "RIFF");
  assert.equal(wav.subarray(8, 12).toString("ascii"), "WAVE");
  assert.equal(wav.byteLength, 44 + loudPcm.byteLength);
});

test("VoiceSessionManager: creates ephemeral sessions, validates TTL expiry, and cleans up", () => {
  const mgr = new VoiceSessionManager(50);
  const s = mgr.createSession({
    mode: "gemini_live",
    conversationId: "conv-1",
    language: "hi-IN",
    voiceName: "Kore",
  });
  assert.ok(s.id.startsWith("vs_"));
  assert.equal(mgr.activeCount(), 1);
  assert.equal(mgr.getSession(s.id)?.language, "hi-IN");
  assert.equal(mgr.endSession(s.id), true);
  assert.equal(mgr.activeCount(), 0);
});

test("Voice HTTP routes: capabilities, STT, TTS, voice turn persistence, memory, and browser allowlist", async () => {
  const { store, dir } = createTestStore();

  // Ephemeral mock OpenAI-compatible Chat + Whisper STT + TTS endpoint on localhost
  const mockOpenAiServer = http.createServer(async (req, res) => {
    const chunks: Buffer[] = [];
    for await (const c of req) chunks.push(c as Buffer);
    const body = Buffer.concat(chunks);

    if (req.url?.endsWith("/audio/transcriptions")) {
      res.setHeader("Content-Type", "application/json");
      res.end(JSON.stringify({ text: "What is my preferred programming language?" }));
      return;
    }
    if (req.url?.endsWith("/audio/speech")) {
      const samplePcm = Buffer.alloc(320);
      const wav = pcm16ToWavBuffer(samplePcm, 24000, 1);
      res.setHeader("Content-Type", "audio/wav");
      res.end(wav);
      return;
    }
    if (req.url?.endsWith("/chat/completions")) {
      const parsed = JSON.parse(body.toString("utf-8")) as { stream?: boolean; messages?: Array<{ role: string; content: string }> };
      const sysMsg = parsed.messages?.find((m) => m.role === "system")?.content ?? "";
      const reply = sysMsg.includes("Rust")
        ? "Your saved preference is **Rust** [1]."
        : "Received your voice message clearly.";

      if (parsed.stream) {
        res.setHeader("Content-Type", "text/event-stream");
        res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: reply } }] })}\n\n`);
        res.write(`data: ${JSON.stringify({ usage: { prompt_tokens: 18, completion_tokens: 9, total_tokens: 27 } })}\n\n`);
        res.write("data: [DONE]\n\n");
        res.end();
      } else {
        res.setHeader("Content-Type", "application/json");
        res.end(JSON.stringify({ choices: [{ message: { content: reply } }] }));
      }
      return;
    }
    res.statusCode = 404;
    res.end("Not found");
  });
  const mockInfo = await listenServer(mockOpenAiServer);

  // Configure local OpenAI provider + memory + enable voice
  store.upsertProvider({
    id: "custom-voice-test",
    preset_id: "custom",
    name: "Local Test LLM",
    protocol: "openai",
    base_url: `http://127.0.0.1:${mockInfo.port}/v1`,
    enabled: true,
    default_model: "voice-test-model",
    api_key: "sk-local-test-secret",
  });
  store.upsertProvider({
    id: "openai",
    preset_id: "openai",
    name: "OpenAI",
    protocol: "openai",
    base_url: `http://127.0.0.1:${mockInfo.port}/v1`,
    enabled: true,
    default_model: "gpt-4.1-mini",
    api_key: "sk-openai-test-secret",
  });
  store.updateSettings({
    routing_mode: "manual",
    model_id: "custom-voice-test::voice-test-model",
    voice_enabled: true,
    voice_stt_provider: "openai",
    voice_tts_provider: "openai",
    voice_language: "en-IN",
    voice_speed: 1.15,
  });
  store.addMemory("My preferred programming language is Rust", "user", { category: "preference" });

  const app = createApp(store);
  const apiServer = http.createServer(app);
  const apiInfo = await listenServer(apiServer);
  const baseUrl = `http://127.0.0.1:${apiInfo.port}`;

  try {
    // 1. Capabilities endpoint hides secrets and reflects real configuration
    const capsRes = await fetch(`${baseUrl}/api/v1/voice/capabilities`);
    assert.equal(capsRes.status, 200);
    const caps = (await capsRes.json()) as {
      openai_stt_available: boolean;
      openai_tts_available: boolean;
      languages: Array<{ code: string }>;
    };
    assert.equal(caps.openai_stt_available, true);
    assert.equal(caps.openai_tts_available, true);
    assert.ok(caps.languages.some((l) => l.code === "hi-IN"));
    assert.ok(caps.languages.some((l) => l.code === "en-IN"));

    // 2. Session creation
    const sessRes = await fetch(`${baseUrl}/api/v1/voice/session`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mode: "router_pipeline", language: "hi-IN", voice_name: "Kore" }),
    });
    assert.equal(sessRes.status, 200);
    const sessJson = (await sessRes.json()) as { session_id: string; ws_url: string; language: string };
    assert.ok(sessJson.session_id.startsWith("vs_"));
    assert.equal(sessJson.language, "hi-IN");
    assert.equal(JSON.stringify(sessJson).includes("sk-openai-test-secret"), false);

    // 3. STT audio transcription endpoint
    const dummyWav = pcm16ToWavBuffer(Buffer.alloc(320), 16000, 1);
    const sttRes = await fetch(`${baseUrl}/api/v1/voice/transcribe`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        audio_base64: dummyWav.toString("base64"),
        mime_type: "audio/wav",
        provider: "openai",
        language: "en-IN",
      }),
    });
    assert.equal(sttRes.status, 200);
    const sttJson = (await sttRes.json()) as { transcript: string; provider_used: string };
    assert.equal(sttJson.provider_used, "openai");
    assert.equal(sttJson.transcript, "What is my preferred programming language?");

    // 4. Voice Assistant Turn integrates Memory + Model Router + Persists metadata without storing raw audio
    const turnRes = await fetch(`${baseUrl}/api/v1/voice/turn`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        transcript: sttJson.transcript,
        language: "en-IN",
        stt_provider: "openai",
        tts_provider: "openai",
        voice_backend: "router_pipeline",
      }),
    });
    assert.equal(turnRes.status, 200);
    const turnJson = (await turnRes.json()) as {
      conversation: { id: string };
      assistant_message: { content: string; metrics: { voice_turn?: boolean; voice_language?: string } };
      spoken_text: string;
    };
    assert.match(turnJson.assistant_message.content, /Rust/);
    assert.equal(turnJson.spoken_text.includes("**"), false);
    assert.equal(turnJson.assistant_message.metrics.voice_turn, true);
    assert.equal(turnJson.assistant_message.metrics.voice_language, "en-IN");

    // 5. TTS synthesis returns WAV payload
    const ttsRes = await fetch(`${baseUrl}/api/v1/voice/tts`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        text: turnJson.spoken_text,
        provider: "openai",
        voice_name: "alloy",
        speed: 1.15,
      }),
    });
    assert.equal(ttsRes.status, 200);
    const ttsJson = (await ttsRes.json()) as { audio_base64: string; mime_type: string; provider_used: string };
    assert.equal(ttsJson.provider_used, "openai");
    assert.equal(ttsJson.mime_type, "audio/wav");
    assert.equal(Buffer.from(ttsJson.audio_base64, "base64").subarray(0, 4).toString("ascii"), "RIFF");

    // 6. Browser allowlist policy respected via voice
    const blockedBrowserTurn = await fetch(`${baseUrl}/api/v1/voice/turn`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        transcript: "Open website https://not-in-allowlist.invalid/secret",
        conversation_id: turnJson.conversation.id,
      }),
    });
    assert.equal(blockedBrowserTurn.status, 200);
    const blockedJson = (await blockedBrowserTurn.json()) as { assistant_message: { content: string } };
    assert.match(blockedJson.assistant_message.content, /security rules|allowlist/i);

    // 7. End session cleanup & verify no audio files created in dataDir
    await fetch(`${baseUrl}/api/v1/voice/session/${sessJson.session_id}`, { method: "DELETE" });
    const savedFiles = fs.readdirSync(dir);
    assert.equal(savedFiles.some((f) => /\.(wav|webm|mp3|ogg|pcm)$/i.test(f)), false);
  } finally {
    await apiInfo.close();
    await mockInfo.close();
    store.shutdown();
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("Voice WebSocket (/ws/voice): authenticates ephemeral session, handles missing key cleanly, and closes cleanly", async () => {
  const { store, dir } = createTestStore();
  // Ensure no env Gemini key leaks into this negative auth/key test
  const prevGeminiKey = process.env.GEMINI_API_KEY;
  delete process.env.GEMINI_API_KEY;

  const app = createApp(store);
  const httpServer = http.createServer(app);
  const voiceWsCtrl = attachVoiceWebSocketServer(httpServer, store);
  const info = await listenServer(httpServer);

  try {
    // 1. Invalid session rejected cleanly
    const invalidClosed = await new Promise<{ code: number; msg: string }>((resolve) => {
      const ws = new WebSocket(`ws://127.0.0.1:${info.port}/ws/voice?session=invalid-id`);
      let errMsg = "";
      ws.on("message", (d) => {
        try {
          const parsed = JSON.parse(d.toString()) as { message?: string };
          if (parsed.message) errMsg = parsed.message;
        } catch {
          /* ignore */
        }
      });
      ws.on("close", (code) => resolve({ code, msg: errMsg }));
    });
    assert.equal(invalidClosed.code, 4001);
    assert.match(invalidClosed.msg, /missing or expired/i);

    // 2. Valid session without Gemini key returns structured error & closes cleanly
    const session = voiceSessionManager.createSession({ mode: "gemini_live", language: "en-IN" });
    const noKeyClosed = await new Promise<{ code: number; msg: string }>((resolve) => {
      const ws = new WebSocket(`ws://127.0.0.1:${info.port}/ws/voice?session=${session.id}`);
      let errMsg = "";
      ws.on("message", (d) => {
        try {
          const parsed = JSON.parse(d.toString()) as { code?: string; message?: string };
          if (parsed.message) errMsg = `${parsed.code}:${parsed.message}`;
        } catch {
          /* ignore */
        }
      });
      ws.on("close", (code) => resolve({ code, msg: errMsg }));
    });
    assert.equal(noKeyClosed.code, 4003);
    assert.match(noKeyClosed.msg, /NO_GEMINI_KEY/);
    voiceSessionManager.endSession(session.id);
    assert.equal(voiceWsCtrl.getActiveConnections(), 0);
  } finally {
    if (prevGeminiKey !== undefined) process.env.GEMINI_API_KEY = prevGeminiKey;
    voiceWsCtrl.closeAll();
    await info.close();
    store.shutdown();
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
