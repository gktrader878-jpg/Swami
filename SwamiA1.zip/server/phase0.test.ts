import assert from "node:assert/strict";
import fs from "node:fs";
import type { AddressInfo } from "node:net";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import { createApp } from "../server";
import { decryptSecret, encryptSecret, redactSensitive, resolveMasterKey } from "./security/secrets";
import {
  hasDisallowedExecutableSignature,
  sanitizeFilename,
  validateChatRequest,
  validateExternalUrl,
  ValidationError,
} from "./security/validation";
import { SwamiStore } from "./store";

function tempDir(prefix: string): string {
  return fs.mkdtempSync(path.join(os.tmpdir(), prefix));
}

test("SQLite store persists settings, encrypted secrets, projects, conversations, messages, memories, and documents across restarts", () => {
  const dir = tempDir("swami-p0-persist-");
  try {
    const store1 = new SwamiStore(dir);
    assert.equal(store1.db.getSchemaVersion(), 3);

    store1.updateSettings({ theme: "light", style: "technical", brave_api_key: "brave-secret-xyz" });
    store1.apiKey = "sk-test-super-secret-123456";

    const proj = store1.createProject("Alpha Project");
    const conv = store1.createConversation("Architecture Audit", "chat", proj.id);
    const m1 = store1.addMessage(conv.id, {
      role: "user",
      content: "Summarize SQLite persistence.",
      reasoning: "",
      mode: "fast",
      steps: [],
      sources: [],
      metrics: {},
      attachments: [],
      status: "complete",
    });
    assert.ok(m1.id);

    // Simulate an interrupted streaming message
    const m2 = store1.addMessage(conv.id, {
      role: "assistant",
      content: "Partial...",
      reasoning: "",
      mode: "fast",
      steps: [],
      sources: [],
      metrics: {},
      attachments: [],
      status: "streaming",
    });
    assert.equal(m2.status, "streaming");

    store1.addMemory("User prefers concise TypeScript examples", "user");
    const doc = store1.ingestDocument("spec.md", Buffer.from("SWAMI Phase 0 uses node:sqlite WAL.", "utf-8"), conv.id, "text/markdown");
    assert.equal(doc.n_chunks, 1);

    // Masking check in getSettings
    const s1 = store1.getSettings();
    assert.equal(s1.api_key_configured, true);
    assert.equal(s1.brave_key_configured, true);
    assert.equal(s1.brave_api_key, "");
    store1.db.close();

    // Re-open fresh SwamiStore against the same SQLite directory
    const store2 = new SwamiStore(dir);
    assert.equal(store2.settings.theme, "light");
    assert.equal(store2.settings.style, "technical");
    assert.equal(store2.apiKey, "sk-test-super-secret-123456");
    assert.equal(store2.braveApiKey, "brave-secret-xyz");
    assert.equal(store2.listProjects().length, 1);
    assert.equal(store2.listProjects()[0].name, "Alpha Project");

    const restoredConv = store2.conversations.get(conv.id);
    assert.equal(restoredConv?.title, "Architecture Audit");
    const restoredMsgs = store2.messages.get(conv.id) ?? [];
    assert.equal(restoredMsgs.length, 2);
    assert.equal(restoredMsgs[1].status, "stopped"); // Interrupted stream recovered cleanly!

    const ftsHits = store2.searchMemories("TypeScript");
    assert.equal(ftsHits.length, 1);
    assert.ok(ftsHits[0].content.includes("TypeScript"));

    assert.equal(store2.listDocumentsFor(conv.id).length, 1);
    assert.equal(store2.chunks.get(doc.id)?.length, 1);
    store2.db.close();
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("AES-256-GCM secret encryption and sensitive token redaction protect credentials", () => {
  const dir = tempDir("swami-p0-sec-");
  try {
    const key = resolveMasterKey(dir);
    const enc = encryptSecret("sk-ant-api03-very-secret-value", key);
    assert.ok(enc.startsWith("v1:"));
    assert.equal(enc.includes("very-secret-value"), false);
    assert.equal(decryptSecret(enc, key), "sk-ant-api03-very-secret-value");

    const redacted = redactSensitive(
      "Request failed with Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9 and key sk-ant-api03-abcdefgh12345678 and ?key=AIzaSyAbcdefgh1234567890",
    );
    assert.equal(redacted.includes("eyJhbGciOi"), false);
    assert.equal(redacted.includes("abcdefgh12345678"), false);
    assert.equal(redacted.includes("AIzaSyAbcdefgh"), false);
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("validateExternalUrl prevents SSRF against metadata, private IPs, and non-HTTPS remote URLs while allowing localhost", () => {
  assert.doesNotThrow(() => validateExternalUrl("https://api.openai.com/v1", { allowLocalhost: true }));
  assert.doesNotThrow(() => validateExternalUrl("http://127.0.0.1:11434/v1", { allowLocalhost: true }));
  assert.doesNotThrow(() => validateExternalUrl("http://localhost:1234/v1", { allowLocalhost: true }));

  assert.throws(() => validateExternalUrl("http://169.254.169.254/latest/meta-data", { allowLocalhost: true }), ValidationError);
  assert.throws(() => validateExternalUrl("http://metadata.google.internal/computeMetadata/v1/", { allowLocalhost: true }), ValidationError);
  assert.throws(() => validateExternalUrl("https://10.0.0.5/v1", { allowLocalhost: true }), ValidationError);
  assert.throws(() => validateExternalUrl("https://192.168.1.10/v1", { allowLocalhost: true }), ValidationError);
  assert.throws(() => validateExternalUrl("http://api.openai.com/v1", { allowLocalhost: true }), ValidationError);
  assert.throws(() => validateExternalUrl("file:///etc/passwd", { allowLocalhost: true }), ValidationError);
});

test("upload sanitization and executable signature detection block unsafe payloads", () => {
  assert.equal(sanitizeFilename("../../etc/passwd"), "passwd");
  assert.equal(hasDisallowedExecutableSignature(Buffer.from([0x4d, 0x5a, 0x90, 0x00])), true);
  assert.equal(hasDisallowedExecutableSignature(Buffer.from([0x7f, 0x45, 0x4c, 0x46])), true);
  assert.equal(hasDisallowedExecutableSignature(Buffer.from("# Markdown notes\n", "utf-8")), false);

  assert.throws(() => validateChatRequest({ content: "   ", regenerate: false }), ValidationError);
  const valid = validateChatRequest({ content: "Hello", mode: "think" });
  assert.equal(valid.mode, "think");
  assert.equal(valid.content, "Hello");
});

test("Express API routes return X-Request-Id, mask secrets, enforce validation, and handle uploads cleanly", async () => {
  const dir = tempDir("swami-p0-http-");
  const testStore = new SwamiStore(dir);
  const app = createApp(testStore);
  const server = app.listen(0, "127.0.0.1");
  await new Promise<void>((resolve) => server.once("listening", resolve));
  const port = (server.address() as AddressInfo).port;
  const baseUrl = `http://127.0.0.1:${port}`;

  try {
    // 1. Health & X-Request-Id
    const healthResp = await fetch(`${baseUrl}/api/health`);
    assert.equal(healthResp.status, 200);
    assert.ok(healthResp.headers.get("x-request-id"));
    const health = (await healthResp.json()) as { ok: boolean; db_ok: boolean; schema_version: number };
    assert.equal(health.ok, true);
    assert.equal(health.db_ok, true);
    assert.equal(health.schema_version, 3);

    // 2. Settings secret masking
    const patchResp = await fetch(`${baseUrl}/api/settings`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ brave_api_key: "BSA-secret-123" }),
    });
    assert.equal(patchResp.status, 200);
    const patched = (await patchResp.json()) as { brave_api_key: string; brave_key_configured: boolean };
    assert.equal(patched.brave_api_key, "");
    assert.equal(patched.brave_key_configured, true);

    // 3. SSRF blocked on provider configure
    const ssrfResp = await fetch(`${baseUrl}/api/providers/configure`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ base_url: "http://169.254.169.254/latest", model: "gpt-4o", api_key: "sk-123456" }),
    });
    assert.equal(ssrfResp.status, 400);
    const ssrfBody = (await ssrfResp.json()) as { code: string; request_id: string };
    assert.equal(ssrfBody.code, "SSRF_BLOCKED");
    assert.ok(ssrfBody.request_id);

    // 4. Executable upload rejected cleanly as JSON
    const form = new FormData();
    form.append("file", new Blob([new Uint8Array([0x4d, 0x5a, 0x90, 0x00])]), "payload.txt");
    const badUpload = await fetch(`${baseUrl}/api/documents`, { method: "POST", body: form });
    assert.equal(badUpload.status, 422);
    const badUploadBody = (await badUpload.json()) as { detail: string; code: string };
    assert.equal(badUploadBody.code, "DOCUMENT_ERROR");
    assert.ok(badUploadBody.detail.includes("Executable"));

    // 5. Chat validation returns 400 JSON
    const badChat = await fetch(`${baseUrl}/api/chat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content: "   ", mode: "fast" }),
    });
    assert.equal(badChat.status, 400);
  } finally {
    await new Promise<void>((resolve) => server.close(() => resolve()));
    testStore.db.close();
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
