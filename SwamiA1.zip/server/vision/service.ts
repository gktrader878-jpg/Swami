import { GoogleGenAI } from "@google/genai";
import { modelRouter } from "../models/router";
import { normalizeApiBaseUrl } from "../providers";
import { redactSensitive } from "../security/secrets";
import { validateExternalUrl } from "../security/validation";
import { store, type SwamiStore } from "../store";
import type {
  Attachment,
  MultimodalImageInput,
  StoredAttachmentRecord,
  VisionCapabilities,
  VisionModelOption,
} from "../types";
import {
  MAX_IMAGE_BYTES,
  MAX_IMAGES_PER_MESSAGE,
  MAX_TOTAL_VISION_BYTES,
  readAttachmentBytes,
  saveImageAttachment,
  toPublicAttachment,
  VisionValidationError,
} from "./storage";

export const GEMINI_IMAGE_FAST_MODEL = "gemini-3.1-flash-lite-image";
export const GEMINI_IMAGE_PRO_MODEL = "gemini-nano-banana-2.1";
export const OPENAI_IMAGE_MODEL = "gpt-image-1";

const DEFAULT_ASPECT_RATIOS = ["1:1", "3:4", "4:3", "9:16", "16:9"] as const;
const WIDE_ASPECT_RATIOS = ["1:4", "1:8", "4:1", "8:1"] as const;
const ALL_GEMINI_ASPECT_RATIOS = new Set<string>([...DEFAULT_ASPECT_RATIOS, ...WIDE_ASPECT_RATIOS]);
const VALID_IMAGE_SIZES = new Set(["1K", "2K", "4K"]);

export function getVisionCapabilities(activeStore: SwamiStore = store): VisionCapabilities {
  const settings = activeStore.getSettings();
  const offline = Boolean(settings.offline_mode);
  const routable = activeStore.getRoutableModels();
  const eligible = offline ? routable.filter((m) => m.is_local) : routable;

  const analysisModels: VisionModelOption[] = eligible
    .filter((m) => m.capabilities.verified && m.capabilities.vision)
    .map((m) => ({
      target: m.target,
      provider_id: m.provider_id,
      provider_name: m.provider_name,
      model_id: m.model_id,
      model_name: m.model_name,
      is_local: m.is_local,
    }));

  const geminiKey = activeStore.getProviderApiKey("gemini");
  const openaiKey = activeStore.getProviderApiKey("openai");
  const geminiEnabled = activeStore.getProvider("gemini")?.enabled !== false;
  const openaiEnabled = activeStore.getProvider("openai")?.enabled !== false;

  const geminiGenAvailable = !offline && geminiEnabled && Boolean(geminiKey);
  const openaiGenAvailable = !offline && openaiEnabled && Boolean(openaiKey);

  const generationModels: VisionCapabilities["generation_models"] = [];
  if (geminiGenAvailable) {
    generationModels.push(
      {
        id: GEMINI_IMAGE_FAST_MODEL,
        name: "Gemini 3.1 Flash Lite Image",
        provider: "gemini",
        supports_edit: true,
        supports_4k: false,
        supports_wide_ratios: false,
        default_ratios: [...DEFAULT_ASPECT_RATIOS],
      },
      {
        id: GEMINI_IMAGE_PRO_MODEL,
        name: "Gemini Nano Banana 2.1 (Pro / 4K)",
        provider: "gemini",
        supports_edit: true,
        supports_4k: true,
        supports_wide_ratios: true,
        default_ratios: [...DEFAULT_ASPECT_RATIOS, ...WIDE_ASPECT_RATIOS],
      },
    );
  }
  if (openaiGenAvailable) {
    generationModels.push({
      id: OPENAI_IMAGE_MODEL,
      name: "OpenAI GPT Image 1",
      provider: "openai",
      supports_edit: true,
      supports_4k: false,
      supports_wide_ratios: false,
      default_ratios: ["1:1", "3:4", "4:3"],
    });
  }

  return {
    offline_mode: offline,
    supported_formats: ["image/jpeg", "image/png", "image/webp"],
    max_image_bytes: MAX_IMAGE_BYTES,
    max_images_per_message: MAX_IMAGES_PER_MESSAGE,
    max_total_bytes: MAX_TOTAL_VISION_BYTES,
    analysis_available: analysisModels.length > 0,
    analysis_models: analysisModels,
    generation_available: generationModels.length > 0,
    gemini_generation_available: geminiGenAvailable,
    openai_generation_available: openaiGenAvailable,
    generation_models: generationModels,
  };
}

export function loadStoredImagesAsInputs(
  activeStore: SwamiStore,
  imageIds: string[],
): { records: StoredAttachmentRecord[]; inputs: MultimodalImageInput[] } {
  if (imageIds.length === 0) return { records: [], inputs: [] };
  if (imageIds.length > MAX_IMAGES_PER_MESSAGE) {
    throw new VisionValidationError(`You can attach up to ${MAX_IMAGES_PER_MESSAGE} images per request.`, 400);
  }
  const records = activeStore.db.listAttachmentsByIds(imageIds);
  if (records.length !== imageIds.length) {
    const found = new Set(records.map((r) => r.id));
    const missing = imageIds.find((id) => !found.has(id));
    throw new VisionValidationError(`Attachment '${missing}' was not found or has expired.`, 404);
  }
  const totalBytes = records.reduce((sum, r) => sum + r.size, 0);
  if (totalBytes > MAX_TOTAL_VISION_BYTES) {
    throw new VisionValidationError(
      `Combined image attachments exceed the ${Math.round(MAX_TOTAL_VISION_BYTES / (1024 * 1024))} MB total payload limit.`,
      413,
    );
  }
  const inputs: MultimodalImageInput[] = records.map((rec) => {
    const buf = readAttachmentBytes(activeStore.db, rec);
    return {
      id: rec.id,
      name: rec.name,
      mimeType: rec.mime,
      base64: buf.toString("base64"),
      width: rec.width,
      height: rec.height,
    };
  });
  return { records, inputs };
}

export function buildVisionInstructionAddendum(images: MultimodalImageInput[]): string {
  if (images.length === 0) return "";
  const list = images
    .map(
      (img, idx) =>
        `  - Image #${idx + 1}: "${img.name}" (${img.mimeType}${img.width && img.height ? `, ${img.width}x${img.height}px` : ""})`,
    )
    .join("\n");

  return (
    `\n\n[MULTIMODAL VISION CONTEXT — ${images.length} attachment(s) provided in exact order:]\n${list}\n` +
    "Vision Analysis Rules:\n" +
    "- Inspect every attached image carefully. Refer to multiple images accurately as Image #1, Image #2, etc.\n" +
    "- For screenshots, UI layouts, code, logs, or error screens: transcribe exact error messages, symbols, layout hierarchy, and actionable fixes.\n" +
    "- For charts, graphs, tables, or technical diagrams: clearly separate exact labels/numbers read directly from the graphic vs. approximate visual estimates, and explicitly state when text or values are too blurry, cropped, or ambiguous to read with certainty."
  );
}

export async function analyzeImagesWithVisionModel(params: {
  activeStore?: SwamiStore;
  imageIds: string[];
  prompt: string;
  modelId?: string;
  signal?: AbortSignal;
}): Promise<{
  text: string;
  reasoning: string;
  provider_id: string;
  provider_name: string;
  model_id: string;
  model_name: string;
  attachments: Attachment[];
}> {
  const activeStore = params.activeStore ?? store;
  const { records, inputs } = loadStoredImagesAsInputs(activeStore, params.imageIds);
  if (inputs.length === 0) {
    throw new VisionValidationError("Select at least one uploaded image to analyze.", 400);
  }
  const cleanPrompt = (params.prompt || "").trim() || "Analyze the attached image(s) in detail.";
  const controller = new AbortController();
  const signal = params.signal ?? controller.signal;
  const settings = activeStore.getSettings();
  const target = params.modelId?.trim() || (settings.routing_mode === "auto" ? "auto" : settings.model_id);

  const systemPrompt =
    "You are SWAMI Vision Intelligence. Provide accurate, structured visual analysis grounded only in what is visibly present in the attached image(s)." +
    buildVisionInstructionAddendum(inputs);

  const routed = await modelRouter.stream({
    activeStore,
    requestedTarget: target || undefined,
    mode: "fast",
    systemPrompt,
    messages: [{ role: "user", content: cleanPrompt, images: inputs }],
    promptForRouting: cleanPrompt,
    taskType: "vision",
    requiresVision: true,
    signal,
    onToken: () => {},
    onReasoning: () => {},
  });

  return {
    text: routed.text,
    reasoning: routed.reasoning,
    provider_id: routed.provider_id,
    provider_name: routed.provider_name,
    model_id: routed.model_id,
    model_name: routed.model_name,
    attachments: records.map(toPublicAttachment),
  };
}

export async function analyzeDocumentVisually(params: {
  activeStore?: SwamiStore;
  docId: string;
  prompt?: string;
  modelId?: string;
  signal?: AbortSignal;
}): Promise<{
  document: NonNullable<ReturnType<SwamiStore["updateDocumentVisualChunks"]>>;
  summary: string;
  provider_id: string;
  model_id: string;
}> {
  const activeStore = params.activeStore ?? store;
  const doc = activeStore.documents.get(params.docId);
  if (!doc) {
    throw new VisionValidationError("Document not found.", 404);
  }
  if (!doc.attachment_id) {
    throw new VisionValidationError(
      "This document does not have an attached visual PDF source. Re-upload the PDF to run visual OCR analysis.",
      400,
    );
  }
  const att = activeStore.db.getAttachment(doc.attachment_id);
  if (!att) {
    throw new VisionValidationError("Stored PDF source is unavailable.", 404);
  }
  const settings = activeStore.getSettings();
  if (settings.offline_mode) {
    throw new VisionValidationError(
      "Visual PDF inspection requires a cloud multimodal model capable of PDF input (Gemini or Claude). Turn off Offline mode.",
      409,
    );
  }

  const pdfBuf = readAttachmentBytes(activeStore.db, att);
  const base64Pdf = pdfBuf.toString("base64");
  const pdfInput: MultimodalImageInput = {
    id: att.id,
    name: doc.name,
    mimeType: "application/pdf",
    base64: base64Pdf,
  };

  // Prefer a Gemini or Anthropic PDF-capable model
  const routable = activeStore.getRoutableModels();
  const preferredPdfModel =
    (params.modelId && routable.find((m) => m.target === params.modelId || m.model_id === params.modelId)?.target) ||
    routable.find((m) => m.protocol === "gemini" && m.capabilities.vision)?.target ||
    routable.find((m) => m.protocol === "anthropic" && m.capabilities.vision)?.target ||
    "";

  if (!preferredPdfModel) {
    throw new VisionValidationError(
      "No PDF-capable multimodal model (Google Gemini or Anthropic Claude) is configured in Settings → API providers.",
      409,
    );
  }

  const ocrPrompt =
    (params.prompt || "").trim() ||
    `Inspect "${doc.name}" visually page by page. Extract all readable text, headings, tables, and concise descriptions of charts or figures. Prefix each page section clearly with [Page 1], [Page 2], etc.`;

  const controller = new AbortController();
  const routed = await modelRouter.stream({
    activeStore,
    requestedTarget: preferredPdfModel,
    mode: "fast",
    systemPrompt:
      "You are SWAMI Document Vision OCR. Transcribe document text accurately preserving page numbers like [Page 1], [Page 2], and describe tables, diagrams, or scanned regions faithfully without inventing unreadable text.",
    messages: [{ role: "user", content: ocrPrompt, images: [pdfInput] }],
    promptForRouting: ocrPrompt,
    taskType: "vision",
    requiresVision: true,
    signal: params.signal ?? controller.signal,
    onToken: () => {},
    onReasoning: () => {},
  });

  const updatedDoc = activeStore.updateDocumentVisualChunks(doc.id, routed.text);
  if (!updatedDoc) {
    throw new VisionValidationError("Document could not be updated.", 500);
  }
  activeStore.recordAudit("document_visual_ocr", `Ran visual OCR on ${doc.name} (${updatedDoc.n_chunks} chunk(s))`);

  return {
    document: updatedDoc,
    summary: routed.text,
    provider_id: routed.provider_id,
    model_id: routed.model_id,
  };
}

export interface GenerateOrEditImageParams {
  activeStore?: SwamiStore;
  mode: "generate" | "edit";
  prompt: string;
  provider?: "auto" | "gemini" | "openai";
  model?: string;
  aspectRatio?: string;
  imageSize?: "1K" | "2K" | "4K";
  searchGrounding?: boolean;
  sourceImageIds?: string[];
  conversationId?: string | null;
  messageId?: string | null;
  signal?: AbortSignal;
}

export interface GenerateOrEditImageResult {
  attachment: Attachment;
  caption: string;
  provider: "gemini" | "openai";
  model: string;
}

function selectGeminiImageModel(params: {
  requestedModel?: string;
  aspectRatio?: string;
  imageSize?: string;
  searchGrounding?: boolean;
}): string {
  if (params.requestedModel === GEMINI_IMAGE_PRO_MODEL) return GEMINI_IMAGE_PRO_MODEL;
  if (params.requestedModel === GEMINI_IMAGE_FAST_MODEL) {
    // Only upgrade if options require Nano Banana 2.1 capabilities
    if (
      (params.imageSize && params.imageSize !== "1K") ||
      (params.aspectRatio && (WIDE_ASPECT_RATIOS as readonly string[]).includes(params.aspectRatio)) ||
      params.searchGrounding
    ) {
      return GEMINI_IMAGE_PRO_MODEL;
    }
    return GEMINI_IMAGE_FAST_MODEL;
  }
  if (
    (params.imageSize && VALID_IMAGE_SIZES.has(params.imageSize)) ||
    (params.aspectRatio && (WIDE_ASPECT_RATIOS as readonly string[]).includes(params.aspectRatio)) ||
    params.searchGrounding
  ) {
    return GEMINI_IMAGE_PRO_MODEL;
  }
  return GEMINI_IMAGE_FAST_MODEL;
}

function mapAspectRatioToOpenAiSize(aspectRatio?: string): "1024x1024" | "1024x1536" | "1536x1024" {
  if (aspectRatio === "9:16" || aspectRatio === "3:4" || aspectRatio === "1:4" || aspectRatio === "1:8") {
    return "1024x1536";
  }
  if (aspectRatio === "16:9" || aspectRatio === "4:3" || aspectRatio === "4:1" || aspectRatio === "8:1") {
    return "1536x1024";
  }
  return "1024x1024";
}

export async function generateOrEditImage(params: GenerateOrEditImageParams): Promise<GenerateOrEditImageResult> {
  const activeStore = params.activeStore ?? store;
  const settings = activeStore.getSettings();
  if (settings.offline_mode) {
    throw new VisionValidationError(
      "Image generation is unavailable in Offline mode because local GGUF/Ollama text models cannot generate images. Turn off Offline mode and configure Gemini or OpenAI.",
      409,
    );
  }

  const cleanPrompt = (params.prompt || "").trim();
  if (!cleanPrompt) {
    throw new VisionValidationError("Enter a clear prompt describing the image to generate or edit.", 400);
  }

  const sourceIds = (params.sourceImageIds ?? []).slice(0, 4);
  if (params.mode === "edit" && sourceIds.length === 0) {
    throw new VisionValidationError("Attach or select at least one source image to edit.", 400);
  }

  const { inputs: sourceInputs } = sourceIds.length
    ? loadStoredImagesAsInputs(activeStore, sourceIds)
    : { inputs: [] };

  const geminiKey = activeStore.getProviderApiKey("gemini");
  const openaiKey = activeStore.getProviderApiKey("openai");
  const geminiCfg = activeStore.getProvider("gemini");
  const openaiCfg = activeStore.getProvider("openai");
  const geminiEnabled = geminiCfg?.enabled !== false && Boolean(geminiKey);
  const openaiEnabled = openaiCfg?.enabled !== false && Boolean(openaiKey);

  let chosenProvider: "gemini" | "openai";
  if (params.provider === "openai") {
    if (!openaiEnabled) {
      throw new VisionValidationError(
        "OpenAI API key is not configured for image generation. Add your OpenAI key in Settings → API providers.",
        409,
      );
    }
    chosenProvider = "openai";
  } else if (params.provider === "gemini") {
    if (!geminiEnabled) {
      throw new VisionValidationError(
        "Gemini API key is not configured for image generation. Add your Gemini key in Settings → API providers.",
        409,
      );
    }
    chosenProvider = "gemini";
  } else {
    if (params.model === OPENAI_IMAGE_MODEL && openaiEnabled) {
      chosenProvider = "openai";
    } else if (geminiEnabled) {
      chosenProvider = "gemini";
    } else if (openaiEnabled) {
      chosenProvider = "openai";
    } else {
      throw new VisionValidationError(
        "No image generation provider is configured. Add a Google Gemini or OpenAI API key in Settings → API providers.",
        409,
      );
    }
  }

  const aspectRatio = params.aspectRatio && ALL_GEMINI_ASPECT_RATIOS.has(params.aspectRatio)
    ? params.aspectRatio
    : "1:1";

  if (chosenProvider === "gemini") {
    const model = selectGeminiImageModel({
      requestedModel: params.model,
      aspectRatio,
      imageSize: params.imageSize,
      searchGrounding: params.searchGrounding,
    });
    const imageConfig: Record<string, unknown> = { aspectRatio };
    if (model === GEMINI_IMAGE_PRO_MODEL && params.imageSize && VALID_IMAGE_SIZES.has(params.imageSize)) {
      imageConfig.imageSize = params.imageSize;
    }

    const parts: Array<{ text: string } | { inlineData: { mimeType: string; data: string } }> = [
      ...sourceInputs.map((img) => ({
        inlineData: {
          mimeType: img.mimeType,
          data: img.base64,
        },
      })),
      { text: cleanPrompt },
    ];

    const geminiBase = normalizeApiBaseUrl(geminiCfg?.base_url || "https://generativelanguage.googleapis.com/v1beta");
    const isStandardGoogleHost = geminiBase.startsWith("https://generativelanguage.googleapis.com");

    let candidateParts: Array<{ text?: string; inlineData?: { data?: string; mimeType?: string } }> = [];

    if (isStandardGoogleHost) {
      const ai = new GoogleGenAI({
        apiKey: geminiKey,
        httpOptions: { headers: { "User-Agent": "aistudio-build" } },
      });
      const response = await ai.models.generateContent({
        model,
        contents: { parts },
        config: {
          imageConfig,
          ...(model === GEMINI_IMAGE_PRO_MODEL && params.searchGrounding
            ? { tools: [{ googleSearch: { searchTypes: { webSearch: {}, imageSearch: {} } } }] }
            : {}),
          ...(params.signal ? { abortSignal: params.signal } : {}),
        },
      });
      candidateParts = response.candidates?.[0]?.content?.parts ?? [];
    } else {
      validateExternalUrl(geminiBase, { allowLocalhost: true, requireHttpsForRemote: true });
      const resp = await fetch(`${geminiBase}/models/${encodeURIComponent(model)}:generateContent`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": geminiKey,
          "User-Agent": "aistudio-build",
        },
        body: JSON.stringify({
          contents: [{ role: "user", parts }],
          generationConfig: { imageConfig },
        }),
        signal: params.signal,
      });
      if (!resp.ok) {
        const errText = await resp.text().catch(() => "");
        throw new Error(`Gemini image API error ${resp.status}: ${redactSensitive(errText.slice(0, 280))}`);
      }
      const json = (await resp.json()) as {
        candidates?: Array<{ content?: { parts?: Array<{ text?: string; inlineData?: { data?: string; mimeType?: string } }> } }>;
      };
      candidateParts = json.candidates?.[0]?.content?.parts ?? [];
    }

    let imageBase64 = "";
    let imageMime = "image/png";
    const textCaptions: string[] = [];

    for (const part of candidateParts) {
      if (part.inlineData?.data) {
        imageBase64 = part.inlineData.data;
        if (part.inlineData.mimeType) imageMime = part.inlineData.mimeType;
      } else if (part.text) {
        textCaptions.push(part.text);
      }
    }

    if (!imageBase64) {
      throw new Error(
        textCaptions.join(" ").trim() ||
          "The Gemini image model completed without returning an image buffer. Refine your prompt and try again.",
      );
    }

    const imgBuf = Buffer.from(imageBase64, "base64");
    const ext = imageMime.includes("webp") ? ".webp" : imageMime.includes("jpeg") ? ".jpg" : ".png";
    const filename = `${params.mode === "edit" ? "edited" : "generated"}-${Date.now()}${ext}`;
    const saved = saveImageAttachment(activeStore.db, {
      filename,
      buffer: imgBuf,
      claimedMime: imageMime,
      conversationId: params.conversationId ?? null,
      messageId: params.messageId ?? null,
      kind: "generated_image",
      sourceType: params.mode === "edit" ? "edited" : "generated",
    });

    activeStore.recordAudit(
      params.mode === "edit" ? "vision_image_edited" : "vision_image_generated",
      `${model} (${aspectRatio}): ${cleanPrompt.slice(0, 80)}`,
    );

    return {
      attachment: toPublicAttachment(saved),
      caption: textCaptions.join("\n").trim(),
      provider: "gemini",
      model,
    };
  }

  // OpenAI Images API (/images/generations or /images/edits)
  const openaiBase = normalizeApiBaseUrl(openaiCfg?.base_url || "https://api.openai.com/v1");
  validateExternalUrl(openaiBase, { allowLocalhost: true, requireHttpsForRemote: true });
  const size = mapAspectRatioToOpenAiSize(aspectRatio);
  const model = OPENAI_IMAGE_MODEL;

  let b64 = "";
  if (params.mode === "edit" && sourceInputs.length > 0) {
    const primary = sourceInputs[0];
    const srcBytes = Buffer.from(primary.base64, "base64");
    const form = new FormData();
    form.append("model", model);
    form.append("prompt", cleanPrompt);
    form.append("size", size);
    form.append("image", new Blob([srcBytes], { type: primary.mimeType }), primary.name);

    const resp = await fetch(`${openaiBase}/images/edits`, {
      method: "POST",
      headers: { Authorization: `Bearer ${openaiKey}` },
      body: form,
      signal: params.signal,
    });
    if (!resp.ok) {
      const errText = await resp.text().catch(() => "");
      throw new Error(`OpenAI image edit error ${resp.status}: ${redactSensitive(errText.slice(0, 280))}`);
    }
    const json = (await resp.json()) as { data?: Array<{ b64_json?: string; url?: string }> };
    b64 = json.data?.[0]?.b64_json || "";
    if (!b64 && json.data?.[0]?.url) {
      validateExternalUrl(json.data[0].url, { allowLocalhost: true, requireHttpsForRemote: true });
      const imgResp = await fetch(json.data[0].url, { signal: params.signal });
      if (imgResp.ok) {
        b64 = Buffer.from(await imgResp.arrayBuffer()).toString("base64");
      }
    }
  } else {
    const resp = await fetch(`${openaiBase}/images/generations`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${openaiKey}`,
      },
      body: JSON.stringify({
        model,
        prompt: cleanPrompt,
        size,
        response_format: "b64_json",
      }),
      signal: params.signal,
    });
    if (!resp.ok) {
      const errText = await resp.text().catch(() => "");
      throw new Error(`OpenAI image generation error ${resp.status}: ${redactSensitive(errText.slice(0, 280))}`);
    }
    const json = (await resp.json()) as { data?: Array<{ b64_json?: string; url?: string }> };
    b64 = json.data?.[0]?.b64_json || "";
    if (!b64 && json.data?.[0]?.url) {
      validateExternalUrl(json.data[0].url, { allowLocalhost: true, requireHttpsForRemote: true });
      const imgResp = await fetch(json.data[0].url, { signal: params.signal });
      if (imgResp.ok) {
        b64 = Buffer.from(await imgResp.arrayBuffer()).toString("base64");
      }
    }
  }

  if (!b64) {
    throw new Error("OpenAI image API did not return image data.");
  }

  const imgBuf = Buffer.from(b64, "base64");
  const saved = saveImageAttachment(activeStore.db, {
    filename: `${params.mode === "edit" ? "edited" : "generated"}-${Date.now()}.png`,
    buffer: imgBuf,
    claimedMime: "image/png",
    conversationId: params.conversationId ?? null,
    messageId: params.messageId ?? null,
    kind: "generated_image",
    sourceType: params.mode === "edit" ? "edited" : "generated",
  });

  activeStore.recordAudit(
    params.mode === "edit" ? "vision_image_edited" : "vision_image_generated",
    `${model} (${size}): ${cleanPrompt.slice(0, 80)}`,
  );

  return {
    attachment: toPublicAttachment(saved),
    caption: "",
    provider: "openai",
    model,
  };
}
