import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { sanitizeFilename } from "../security/validation";
import type { SwamiDatabase } from "../storage/database";
import type { Attachment, StoredAttachmentRecord } from "../types";

export const SUPPORTED_IMAGE_EXTENSIONS = new Set([".jpg", ".jpeg", ".png", ".webp"]);
export const SUPPORTED_IMAGE_MIMES = new Set(["image/jpeg", "image/png", "image/webp"]);
export const MAX_IMAGE_BYTES = 12 * 1024 * 1024; // 12 MB per image
export const MAX_IMAGES_PER_MESSAGE = 6;
export const MAX_TOTAL_VISION_BYTES = 30 * 1024 * 1024; // 30 MB combined per message/batch
export const TEMP_ATTACHMENT_TTL_SEC = 24 * 3600; // 24 hours for unattached uploads

const PNG_SIGNATURE = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

export class VisionValidationError extends Error {
  status: number;
  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}

export interface DetectedImageInfo {
  mime: "image/jpeg" | "image/png" | "image/webp";
  ext: ".jpg" | ".png" | ".webp";
  width: number | null;
  height: number | null;
}

function assertNotMaliciousBinaryOrScript(buffer: Buffer): void {
  if (buffer.byteLength < 8) {
    throw new VisionValidationError("Uploaded file is empty or truncated.", 400);
  }
  // ELF executable
  if (buffer[0] === 0x7f && buffer[1] === 0x45 && buffer[2] === 0x4c && buffer[3] === 0x46) {
    throw new VisionValidationError("Executable files cannot be uploaded as images.", 400);
  }
  // Windows PE/MZ executable
  if (buffer[0] === 0x4d && buffer[1] === 0x5a) {
    throw new VisionValidationError("Executable files cannot be uploaded as images.", 400);
  }
  // Mach-O
  const magic32 = buffer.readUInt32BE(0);
  if (magic32 === 0xfeedface || magic32 === 0xfeedfacf || magic32 === 0xcffaedfe || magic32 === 0xcefaedfe) {
    throw new VisionValidationError("Executable files cannot be uploaded as images.", 400);
  }
  // Leading SVG / HTML / XML / Script payloads disguised with image extension
  const headText = buffer.subarray(0, Math.min(512, buffer.byteLength)).toString("utf8").trimStart().toLowerCase();
  if (
    headText.startsWith("<svg") ||
    headText.startsWith("<html") ||
    headText.startsWith("<!doctype") ||
    headText.startsWith("<script") ||
    (headText.startsWith("<?xml") && headText.includes("<svg"))
  ) {
    throw new VisionValidationError("SVG, HTML, and script files are blocked for security. Upload JPG, PNG, or WEBP.", 400);
  }
}

function parsePngDimensions(buf: Buffer): { width: number | null; height: number | null } {
  if (buf.byteLength < 24) return { width: null, height: null };
  if (buf.subarray(12, 16).toString("ascii") !== "IHDR") return { width: null, height: null };
  const width = buf.readUInt32BE(16);
  const height = buf.readUInt32BE(20);
  if (!width || !height || width > 32768 || height > 32768) {
    throw new VisionValidationError("Invalid PNG image dimensions.", 400);
  }
  return { width, height };
}

function parseJpegDimensions(buf: Buffer): { width: number | null; height: number | null } {
  let offset = 2; // Skip FF D8
  while (offset + 4 < buf.byteLength) {
    if (buf[offset] !== 0xff) {
      offset += 1;
      continue;
    }
    while (offset < buf.byteLength && buf[offset] === 0xff) offset += 1;
    if (offset >= buf.byteLength) break;
    const marker = buf[offset];
    offset += 1;

    if (marker === 0xd9 || marker === 0xda) break; // EOI or SOS
    if (marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) continue;
    if (offset + 2 > buf.byteLength) break;
    const segLen = buf.readUInt16BE(offset);
    if (segLen < 2 || offset + segLen > buf.byteLength) break;

    const isSof =
      (marker >= 0xc0 && marker <= 0xc3) ||
      (marker >= 0xc5 && marker <= 0xc7) ||
      (marker >= 0xc9 && marker <= 0xcb) ||
      (marker >= 0xcd && marker <= 0xcf);
    if (isSof && segLen >= 7) {
      const height = buf.readUInt16BE(offset + 3);
      const width = buf.readUInt16BE(offset + 5);
      return { width: width || null, height: height || null };
    }
    offset += segLen;
  }
  return { width: null, height: null };
}

function parseWebpDimensions(buf: Buffer): { width: number | null; height: number | null } {
  if (buf.byteLength < 30) return { width: null, height: null };
  const chunk = buf.subarray(12, 16).toString("ascii");
  if (chunk === "VP8X" && buf.byteLength >= 30) {
    const w = 1 + (buf[24] | (buf[25] << 8) | (buf[26] << 16));
    const h = 1 + (buf[27] | (buf[28] << 8) | (buf[29] << 16));
    return { width: w, height: h };
  }
  if (chunk === "VP8 " && buf.byteLength >= 30 && buf[23] === 0x9d && buf[24] === 0x01 && buf[25] === 0x2a) {
    const w = buf.readUInt16LE(26) & 0x3fff;
    const h = buf.readUInt16LE(28) & 0x3fff;
    return { width: w || null, height: h || null };
  }
  if (chunk === "VP8L" && buf.byteLength >= 25 && buf[20] === 0x2f) {
    const bits = buf.readUInt32LE(21);
    const w = (bits & 0x3fff) + 1;
    const h = ((bits >> 14) & 0x3fff) + 1;
    return { width: w, height: h };
  }
  return { width: null, height: null };
}

export function validateAndInspectImageBuffer(
  buffer: Buffer,
  filename: string,
  claimedMime = "",
): DetectedImageInfo {
  if (!Buffer.isBuffer(buffer) || buffer.byteLength === 0) {
    throw new VisionValidationError("Image payload is empty.", 400);
  }
  if (buffer.byteLength > MAX_IMAGE_BYTES) {
    throw new VisionValidationError(
      `Image "${sanitizeFilename(filename)}" exceeds the ${Math.round(MAX_IMAGE_BYTES / (1024 * 1024))} MB per-image limit.`,
      413,
    );
  }
  assertNotMaliciousBinaryOrScript(buffer);

  const ext = path.extname(filename || "").toLowerCase();
  if (ext && !SUPPORTED_IMAGE_EXTENSIONS.has(ext)) {
    throw new VisionValidationError(
      `Unsupported image format (${ext}). Supported formats: JPG, JPEG, PNG, WEBP.`,
      400,
    );
  }

  // Magic-byte inspection
  if (buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) {
    if (ext && ext !== ".jpg" && ext !== ".jpeg") {
      throw new VisionValidationError(`File extension (${ext}) does not match JPEG file contents.`, 400);
    }
    const dims = parseJpegDimensions(buffer);
    return { mime: "image/jpeg", ext: ".jpg", width: dims.width, height: dims.height };
  }

  if (buffer.byteLength >= 8 && buffer.subarray(0, 8).equals(PNG_SIGNATURE)) {
    if (ext && ext !== ".png") {
      throw new VisionValidationError(`File extension (${ext}) does not match PNG file contents.`, 400);
    }
    const dims = parsePngDimensions(buffer);
    return { mime: "image/png", ext: ".png", width: dims.width, height: dims.height };
  }

  if (
    buffer.byteLength >= 12 &&
    buffer.subarray(0, 4).toString("ascii") === "RIFF" &&
    buffer.subarray(8, 12).toString("ascii") === "WEBP"
  ) {
    if (ext && ext !== ".webp") {
      throw new VisionValidationError(`File extension (${ext}) does not match WEBP file contents.`, 400);
    }
    const dims = parseWebpDimensions(buffer);
    return { mime: "image/webp", ext: ".webp", width: dims.width, height: dims.height };
  }

  void claimedMime;
  throw new VisionValidationError(
    "Invalid image file signature. Only genuine JPG, JPEG, PNG, and WEBP images are allowed.",
    400,
  );
}

/**
 * Strip JPEG EXIF/XMP/IPTC/Comment segments (APP1, APP12, APP13, COM) without re-encoding pixels.
 */
export function stripJpegExifMetadata(buffer: Buffer): { buffer: Buffer; stripped: boolean } {
  if (buffer.byteLength < 4 || buffer[0] !== 0xff || buffer[1] !== 0xd8) {
    return { buffer, stripped: false };
  }
  const chunks: Buffer[] = [buffer.subarray(0, 2)];
  let offset = 2;
  let stripped = false;

  while (offset < buffer.byteLength) {
    if (buffer[offset] !== 0xff) {
      // Unexpected byte before SOS; keep remainder safely
      chunks.push(buffer.subarray(offset));
      break;
    }
    const markerStart = offset;
    while (offset < buffer.byteLength && buffer[offset] === 0xff) offset += 1;
    if (offset >= buffer.byteLength) {
      chunks.push(buffer.subarray(markerStart));
      break;
    }
    const marker = buffer[offset];
    offset += 1;

    // SOS (Start Of Scan) or EOI: copy rest of stream untouched
    if (marker === 0xda || marker === 0xd9) {
      chunks.push(buffer.subarray(markerStart));
      break;
    }

    // Standalone markers without length
    if (marker === 0x00 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) {
      chunks.push(buffer.subarray(markerStart, offset));
      continue;
    }

    if (offset + 2 > buffer.byteLength) {
      chunks.push(buffer.subarray(markerStart));
      break;
    }
    const segLen = buffer.readUInt16BE(offset);
    if (segLen < 2 || offset + segLen > buffer.byteLength) {
      chunks.push(buffer.subarray(markerStart));
      break;
    }
    const segEnd = offset + segLen;

    // Strip APP1 (EXIF/GPS/XMP), APP12, APP13 (IPTC), COM (comments)
    if (marker === 0xe1 || marker === 0xec || marker === 0xed || marker === 0xfe) {
      stripped = true;
    } else {
      chunks.push(buffer.subarray(markerStart, segEnd));
    }
    offset = segEnd;
  }

  return {
    buffer: stripped ? Buffer.concat(chunks) : buffer,
    stripped,
  };
}

/**
 * Strip ancillary EXIF/text metadata chunks (eXIf, tEXt, zTXt, iTXt) from PNG buffers cleanly.
 */
export function stripPngMetadata(buffer: Buffer): { buffer: Buffer; stripped: boolean } {
  if (buffer.byteLength < 8 || !buffer.subarray(0, 8).equals(PNG_SIGNATURE)) {
    return { buffer, stripped: false };
  }
  const chunks: Buffer[] = [buffer.subarray(0, 8)];
  let offset = 8;
  let stripped = false;
  const metadataChunks = new Set(["eXIf", "tEXt", "zTXt", "iTXt"]);

  while (offset + 12 <= buffer.byteLength) {
    const length = buffer.readUInt32BE(offset);
    const totalLen = 12 + length;
    if (offset + totalLen > buffer.byteLength) {
      chunks.push(buffer.subarray(offset));
      break;
    }
    const type = buffer.subarray(offset + 4, offset + 8).toString("ascii");
    if (metadataChunks.has(type)) {
      stripped = true;
    } else {
      chunks.push(buffer.subarray(offset, offset + totalLen));
    }
    offset += totalLen;
    if (type === "IEND") break;
  }

  return {
    buffer: stripped ? Buffer.concat(chunks) : buffer,
    stripped,
  };
}

export function stripImageMetadata(
  buffer: Buffer,
  mime: "image/jpeg" | "image/png" | "image/webp",
): { buffer: Buffer; stripped: boolean } {
  if (mime === "image/jpeg") return stripJpegExifMetadata(buffer);
  if (mime === "image/png") return stripPngMetadata(buffer);
  return { buffer, stripped: false };
}

export function getAttachmentsDir(db: SwamiDatabase): string {
  const dir = path.join(db.dataDir, "attachments");
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

export function toPublicAttachment(rec: StoredAttachmentRecord): Attachment {
  return {
    id: rec.id,
    name: rec.name,
    size: rec.size,
    kind: rec.kind === "document_pdf" ? "document" : rec.kind,
    mime: rec.mime,
    width: rec.width,
    height: rec.height,
    url: `/api/v1/vision/attachments/${encodeURIComponent(rec.id)}`,
    source_type: rec.source_type === "document" ? undefined : rec.source_type,
  };
}

export function saveImageAttachment(
  db: SwamiDatabase,
  params: {
    filename: string;
    buffer: Buffer;
    claimedMime?: string;
    conversationId?: string | null;
    messageId?: string | null;
    kind?: "image" | "generated_image";
    sourceType?: "upload" | "generated" | "edited";
  },
): StoredAttachmentRecord {
  const inspected = validateAndInspectImageBuffer(params.buffer, params.filename, params.claimedMime);
  const { buffer: cleanBuf, stripped } = stripImageMetadata(params.buffer, inspected.mime);
  const id = `att_${crypto.randomUUID().replace(/-/g, "")}`;
  const dir = getAttachmentsDir(db);
  const diskFilename = `${id}${inspected.ext}`;
  const fullPath = path.join(dir, diskFilename);
  fs.writeFileSync(fullPath, cleanBuf);

  const now = Date.now() / 1000;
  const rec: StoredAttachmentRecord = {
    id,
    kind: params.kind ?? "image",
    name: sanitizeFilename(params.filename || `image${inspected.ext}`),
    mime: inspected.mime,
    size: cleanBuf.byteLength,
    width: inspected.width,
    height: inspected.height,
    sha256: crypto.createHash("sha256").update(cleanBuf).digest("hex"),
    storage_path: diskFilename,
    conversation_id: params.conversationId ?? null,
    message_id: params.messageId ?? null,
    doc_id: null,
    source_type: params.sourceType ?? "upload",
    exif_stripped: stripped ? 1 : 0,
    created_at: now,
    expires_at: params.conversationId ? null : now + TEMP_ATTACHMENT_TTL_SEC,
  };
  db.insertAttachment(rec);
  return rec;
}

export function savePdfAttachmentForDocument(
  db: SwamiDatabase,
  params: {
    filename: string;
    buffer: Buffer;
    docId: string;
    conversationId: string | null;
  },
): StoredAttachmentRecord {
  if (params.buffer.byteLength < 5 || params.buffer.subarray(0, 5).toString("ascii") !== "%PDF-") {
    throw new VisionValidationError("Invalid PDF signature.", 400);
  }
  const id = `att_${crypto.randomUUID().replace(/-/g, "")}`;
  const dir = getAttachmentsDir(db);
  const diskFilename = `${id}.pdf`;
  fs.writeFileSync(path.join(dir, diskFilename), params.buffer);
  const now = Date.now() / 1000;
  const rec: StoredAttachmentRecord = {
    id,
    kind: "document_pdf",
    name: sanitizeFilename(params.filename || "document.pdf"),
    mime: "application/pdf",
    size: params.buffer.byteLength,
    width: null,
    height: null,
    sha256: crypto.createHash("sha256").update(params.buffer).digest("hex"),
    storage_path: diskFilename,
    conversation_id: params.conversationId ?? null,
    message_id: null,
    doc_id: params.docId,
    source_type: "document",
    exif_stripped: 0,
    created_at: now,
    expires_at: params.conversationId ? null : now + TEMP_ATTACHMENT_TTL_SEC,
  };
  db.insertAttachment(rec);
  return rec;
}

export function resolveSafeAttachmentPath(db: SwamiDatabase, storagePath: string): string {
  const dir = path.resolve(getAttachmentsDir(db));
  const candidate = path.resolve(dir, path.basename(storagePath));
  if (!candidate.startsWith(dir + path.sep) && candidate !== dir) {
    throw new VisionValidationError("Invalid attachment storage path.", 403);
  }
  return candidate;
}

export function readAttachmentBytes(db: SwamiDatabase, record: StoredAttachmentRecord): Buffer {
  const filePath = resolveSafeAttachmentPath(db, record.storage_path);
  if (!fs.existsSync(filePath)) {
    throw new VisionValidationError("Attachment binary is no longer available on disk.", 404);
  }
  return fs.readFileSync(filePath);
}

export function deleteStoredFiles(db: SwamiDatabase, storagePaths: string[]): void {
  for (const rel of storagePaths) {
    if (!rel) continue;
    try {
      const target = resolveSafeAttachmentPath(db, rel);
      if (fs.existsSync(target)) {
        fs.unlinkSync(target);
      }
    } catch {
      /* ignore cleanup errors */
    }
  }
}

export function cleanupExpiredAttachments(db: SwamiDatabase): number {
  const expired = db.deleteExpiredAttachments(Date.now() / 1000);
  if (expired.length > 0) {
    deleteStoredFiles(
      db,
      expired.map((e) => e.storage_path),
    );
  }
  return expired.length;
}
