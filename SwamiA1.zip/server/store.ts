import crypto from "node:crypto";
import path from "node:path";
import {
  APP_NAME,
  APP_VERSION,
  BASE_CATALOG,
  DEFAULT_SETTINGS,
  evaluateCompatibility,
  getHardwareSnapshot,
  PROFILES,
  recommendProfile,
  resolveModelSelection,
} from "./catalog";
import { chunkDocumentPages, chunkDocumentText, DocumentError, extractDocumentWithPages } from "./documents";
import { sanitizeVoiceShortcutsList } from "./voice/shortcuts";
import {
  cleanupExpiredAttachments,
  deleteStoredFiles,
  savePdfAttachmentForDocument,
} from "./vision/storage";
import {
  findConflictingMemories,
  isDuplicateMemory,
  normalizeMemoryCategory,
  rankRelevantMemories,
} from "./memory/engine";
import {
  buildPresetDefaultModels,
  CORE_PROVIDER_PRESETS,
  inferProtocol,
  inferVerifiedModelMetadata,
  isLocalApiHost,
  normalizeApiBaseUrl,
  PROVIDER_PRESETS,
} from "./providers";
import { sanitizeFilename, validateExternalUrl } from "./security/validation";
import { SwamiDatabase, type AuditEntry, type UsageMetricRow } from "./storage/database";
import type {
  CatalogEntry,
  Conversation,
  DocumentChunk,
  DocumentRecord,
  DownloadState,
  EngineStatus,
  Memory,
  MemoryCategory,
  Message,
  ModelGenerationParams,
  ModelInfo,
  Project,
  ProviderConfig,
  ProviderHealthStatus,
  ProviderModelConfig,
  ProviderProtocol,
  ProviderUsageStat,
  RoutableModelOption,
  Settings,
  Status,
} from "./types";

export class MemoryConflictError extends Error {
  status: number;
  existing: Memory;
  constructor(message: string, existing: Memory, status = 409) {
    super(message);
    this.status = status;
    this.existing = existing;
  }
}

export const newId = () => crypto.randomUUID().replace(/-/g, "");
export const nowSec = () => Date.now() / 1000;

export interface LoadedState {
  entry: CatalogEntry;
  context_length: number;
  gpu_layers: number;
  load_seconds: number;
  loaded_at: number;
  warnings: string[];
}

export interface ActiveRun {
  id: string;
  controller: AbortController;
  startedAt: number;
}

export class SwamiStore {
  readonly db: SwamiDatabase;
  settings: Settings = { ...DEFAULT_SETTINGS };
  private _apiKey = "";
  private _braveApiKey = "";
  projects = new Map<string, Project>();
  conversations = new Map<string, Conversation>();
  messages = new Map<string, Message[]>();
  memories = new Map<string, Memory>();
  documents = new Map<string, DocumentRecord>();
  chunks = new Map<string, DocumentChunk[]>();
  providers = new Map<string, Omit<ProviderConfig, "configured" | "key_configured">>();
  installedModels = new Set<string>(["gemini-3.1-flash-lite", "gemini-4-hydrogen", "qwen2.5-coder-3b-ollama"]);
  downloads = new Map<string, DownloadState>();
  downloadTimers = new Map<string, ReturnType<typeof setInterval>>();
  loaded: LoadedState | null = null;
  loadingModelId = "";
  activeRuns = new Map<string, ActiveRun>();
  private attachmentCleanupTimer: ReturnType<typeof setInterval> | null = null;

  constructor(dataDir = process.env.SWAMI_DATA_DIR || "/tmp/swami/data", dbFilename = "swami.db") {
    this.db = new SwamiDatabase(dataDir, dbFilename);
    this.hydrateFromDatabase();
    cleanupExpiredAttachments(this.db);
    this.attachmentCleanupTimer = setInterval(() => {
      cleanupExpiredAttachments(this.db);
    }, 30 * 60 * 1000);
    this.attachmentCleanupTimer.unref?.();

    // Load preferred model (defaulting to fast Gemini 3.1 Flash Lite online, or configured model)
    const hw = getHardwareSnapshot();
    const resolved = resolveModelSelection(this.getSettings(), this.catalogEntries(), this.getInstalledSet(), hw);
    const first =
      resolved.entry ??
      BASE_CATALOG.find((m) => m.id === "gemini-3.1-flash-lite") ??
      BASE_CATALOG.find((m) => m.id === "gemini-4-hydrogen") ??
      BASE_CATALOG.find((m) => m.id === "qwen2.5-coder-3b-ollama");
    if (first) {
      this.loaded = {
        entry: first,
        context_length: first.runtime === "Gemini API" ? 32768 : 4096,
        gpu_layers: hw.has_gpu ? 99 : 0,
        load_seconds: 0.1,
        loaded_at: nowSec(),
        warnings: [],
      };
    }
  }

  get apiKey(): string {
    return this._apiKey;
  }

  set apiKey(value: string) {
    const clean = value.trim();
    this._apiKey = clean;
    this.db.setSecret("provider_api_key", clean);
  }

  get braveApiKey(): string {
    return this._braveApiKey;
  }

  set braveApiKey(value: string) {
    const clean = value.trim();
    this._braveApiKey = clean;
    this.db.setSecret("brave_api_key", clean);
  }

  private hydrateFromDatabase(): void {
    const recovered = this.db.recoverInterruptedMessages();
    if (recovered > 0) {
      this.db.recordAudit("recovery", `Marked ${recovered} interrupted streaming message(s) as stopped on startup.`);
    }

    const savedSettings = this.db.loadSettingsMap();
    const allowedKeys = new Set(Object.keys(DEFAULT_SETTINGS));
    for (const [k, v] of Object.entries(savedSettings)) {
      if (allowedKeys.has(k) && k !== "api_key_configured" && k !== "brave_key_configured" && k !== "brave_api_key") {
        (this.settings as unknown as Record<string, unknown>)[k] =
          k === "voice_shortcuts" ? sanitizeVoiceShortcutsList(v) : v;
      }
    }

    this._apiKey = this.db.getSecret("provider_api_key");
    this._braveApiKey = this.db.getSecret("brave_api_key");

    for (const p of this.db.loadProjects()) {
      this.projects.set(p.id, p);
    }
    for (const c of this.db.loadConversations()) {
      this.conversations.set(c.id, c);
    }
    this.messages = this.db.loadAllMessages();
    for (const m of this.db.loadMemories()) {
      this.memories.set(m.id, m);
    }
    for (const d of this.db.loadDocuments()) {
      this.documents.set(d.id, d);
    }
    this.chunks = this.db.loadChunksMap();

    // Load saved multi-provider configs and seed missing built-in core presets cleanly
    for (const pc of this.db.loadProviderConfigs()) {
      this.providers.set(pc.id, pc);
    }
    this.ensureCoreProvidersSeeded();
  }

  private ensureCoreProvidersSeeded(): void {
    const now = nowSec();
    for (const preset of CORE_PROVIDER_PRESETS) {
      if (!this.providers.has(preset.id)) {
        const cfg: Omit<ProviderConfig, "configured" | "key_configured"> = {
          id: preset.id,
          preset_id: preset.id,
          name: preset.name,
          protocol: preset.protocol,
          base_url: preset.base_url,
          enabled: true,
          is_local: preset.is_local,
          default_model: preset.default_model,
          models: preset.is_local ? [] : buildPresetDefaultModels(preset),
          health_status: "unknown",
          health_message: "",
          last_checked_at: null,
          last_latency_ms: null,
          created_at: now,
          updated_at: now,
        };
        this.providers.set(cfg.id, cfg);
        this.db.upsertProviderConfig(cfg);
      }
    }

    // Migrate legacy single-provider settings + key if configured before multi-provider engine
    const legacyPid = (this.settings.api_provider || "").trim();
    if (this._apiKey && legacyPid) {
      const targetId = this.providers.has(legacyPid) ? legacyPid : "custom";
      const existingKey = this.db.getSecret(`provider_key_${targetId}`);
      if (!existingKey) {
        this.db.setSecret(`provider_key_${targetId}`, this._apiKey);
      }
      const pc = this.providers.get(targetId);
      if (pc && this.settings.api_model) {
        if (!pc.models.some((m) => m.id === this.settings.api_model)) {
          const inferred = inferVerifiedModelMetadata(pc.preset_id, this.settings.api_model);
          pc.models.push({
            id: this.settings.api_model,
            name: inferred.name,
            enabled: true,
            custom: true,
            capabilities: inferred.capabilities,
            tier: inferred.tier,
            cost_tier: inferred.cost_tier,
          });
        }
        if (this.settings.api_base_url) pc.base_url = this.settings.api_base_url;
        pc.default_model = this.settings.api_model;
        this.db.upsertProviderConfig(pc);
      }
    }
  }

  getSettings(): Settings {
    return {
      ...this.settings,
      brave_api_key: "",
      brave_key_configured: Boolean(this._braveApiKey),
      api_key_configured: Boolean(this._apiKey),
    };
  }

  updateSettings(patch: Partial<Settings>): Settings {
    const allowedKeys = new Set(Object.keys(DEFAULT_SETTINGS));
    const toPersist: Record<string, unknown> = {};

    for (const [k, v] of Object.entries(patch)) {
      if (k === "brave_api_key" && typeof v === "string") {
        this.braveApiKey = v;
        continue;
      }
      if (allowedKeys.has(k) && k !== "api_key_configured" && k !== "brave_key_configured") {
        let nextVal = v;
        if (k === "voice_speed" && typeof v === "number" && Number.isFinite(v)) {
          nextVal = Math.min(2.0, Math.max(0.6, Math.round(v * 100) / 100));
        } else if (k === "voice_volume" && typeof v === "number" && Number.isFinite(v)) {
          nextVal = Math.min(1.0, Math.max(0.0, Math.round(v * 100) / 100));
        } else if (k === "voice_vad_sensitivity" && typeof v === "number" && Number.isFinite(v)) {
          nextVal = Math.min(1.0, Math.max(0.1, Math.round(v * 100) / 100));
        } else if (k === "voice_silence_ms" && typeof v === "number" && Number.isFinite(v)) {
          nextVal = Math.min(3500, Math.max(400, Math.round(v)));
        } else if (k === "voice_shortcuts") {
          nextVal = sanitizeVoiceShortcutsList(v);
        }
        (this.settings as unknown as Record<string, unknown>)[k] = nextVal;
        toPersist[k] = nextVal;
      }
    }
    if (Object.keys(toPersist).length > 0) {
      this.db.saveSettingsEntries(toPersist);
    }
    return this.getSettings();
  }

  resetSettings(): Settings {
    this.settings = { ...DEFAULT_SETTINGS };
    this.db.clearSettings();
    this.db.recordAudit("settings_reset", "Reset settings to defaults.");
    return this.getSettings();
  }

  catalogEntries(): CatalogEntry[] {
    const preset = PROVIDER_PRESETS.find((p) => p.id === this.settings.api_provider);
    const proto = inferProtocol(this.settings.api_base_url, this.settings.api_protocol);
    return BASE_CATALOG.map((raw) => {
      if (raw.runtime === "api") {
        return {
          ...raw,
          api_model: this.settings.api_model || "",
          name: this.settings.api_model || "Online API model",
          publisher: preset?.name ?? "Configured API provider",
          parameters: proto === "anthropic" ? "Anthropic API" : proto === "gemini" ? "Gemini SDK" : "OpenAI-compatible",
        };
      }
      return { ...raw };
    });
  }

  hasOnlineProviderConfigured(): boolean {
    return Boolean(this.settings.api_model && (this._apiKey || isLocalApiHost(this.settings.api_base_url)));
  }

  isModelInstalled(entry: CatalogEntry): boolean {
    if (entry.runtime === "Gemini API") {
      return true;
    }
    if (entry.runtime === "api") {
      return this.hasOnlineProviderConfigured();
    }
    return this.installedModels.has(entry.id);
  }

  getInstalledSet(): Set<string> {
    const set = new Set<string>(this.installedModels);
    set.add("gemini-3.1-flash-lite");
    set.add("gemini-4-hydrogen");
    if (this.hasOnlineProviderConfigured()) {
      set.add("online-api");
    }
    return set;
  }

  getModels(): ModelInfo[] {
    const hw = getHardwareSnapshot();
    return this.catalogEntries().map((entry) => ({
      ...entry,
      installed: this.isModelInstalled(entry),
      loaded: Boolean(this.loaded && this.loaded.entry.id === entry.id),
      compatibility: evaluateCompatibility(entry, hw),
      download: this.downloads.get(entry.id) ?? null,
    }));
  }

  getEngineStatus(): EngineStatus {
    if (!this.loaded) {
      return {
        loaded: false,
        loading: this.loadingModelId,
        provider: "Local Runtime",
        busy: this.activeRuns.size > 0,
      };
    }
    return {
      loaded: true,
      loading: this.loadingModelId,
      provider: this.loaded.entry.runtime === "api" ? "Online API" : this.loaded.entry.runtime,
      model_id: this.loaded.entry.id,
      model_name: this.loaded.entry.name,
      runtime: this.loaded.entry.runtime,
      quantization: this.loaded.entry.quantization,
      context_length: this.loaded.context_length,
      gpu_layers: this.loaded.gpu_layers,
      load_seconds: this.loaded.load_seconds,
      model_vram_mb: null,
      warnings: this.loaded.warnings,
      fallback: false,
      last_load_failure: "",
      busy: this.activeRuns.size > 0,
    };
  }

  getStatus(): Status {
    const hw = getHardwareSnapshot();
    const settings = this.getSettings();
    const resolved = resolveModelSelection(settings, this.catalogEntries(), this.getInstalledSet(), hw);
    const activeTarget = this.resolveTargetDetails(settings.model_id);
    const isAutoMode = settings.routing_mode === "auto" || settings.model_id === "auto";
    return {
      app: APP_NAME,
      version: APP_VERSION,
      engine: this.getEngineStatus(),
      hardware: hw,
      recommended_profile: recommendProfile(hw),
      resolved: isAutoMode
        ? {
            model_id: "auto",
            model_name: `Auto Model (${settings.routing_preference})`,
            provider_id: "router",
            provider_name: "Model Router",
            is_local: false,
            context_length: 128000,
            gpu_layers: resolved.gpu_layers,
            profile: resolved.profile,
          }
        : activeTarget
          ? {
              model_id: activeTarget.target,
              model_name: activeTarget.model.name,
              provider_id: activeTarget.provider.id,
              provider_name: activeTarget.provider.name,
              is_local: activeTarget.provider.is_local,
              context_length: activeTarget.model.capabilities.context_length ?? 32768,
              gpu_layers: resolved.gpu_layers,
              profile: resolved.profile,
            }
          : resolved.error
            ? { error: resolved.error }
            : {
                model_id: resolved.model_id,
                model_name: resolved.model_name,
                context_length: resolved.context_length,
                gpu_layers: resolved.gpu_layers,
                profile: resolved.profile,
              },
      runtime_installed: true,
      paths: {
        data: this.db.dataDir,
        models: path.join(path.dirname(this.db.dataDir), "models"),
        database: this.db.dbPath,
        uploads: path.join(path.dirname(this.db.dataDir), "uploads"),
      },
      profiles: PROFILES,
    };
  }

  loadEngine(modelOverride = ""): EngineStatus {
    const hw = getHardwareSnapshot();
    const settings = this.getSettings();
    const candidate = (modelOverride || (settings.routing_mode === "auto" && !modelOverride ? "auto" : settings.model_id) || "").trim();

    if (candidate === "auto") {
      const routable = this.getRoutableModels();
      const filtered = settings.offline_mode ? routable.filter((r) => r.is_local) : routable;
      if (filtered.length > 0 || !settings.offline_mode) {
        this.loaded = {
          entry: {
            id: "auto",
            name: "Auto Model",
            family: "router",
            publisher: "Model Router",
            base_repo: "",
            gguf_repo: "",
            file: "auto",
            size_bytes: 0,
            license: "Configured",
            parameters: settings.routing_preference,
            quantization: "Router",
            tier: "balanced",
            native_context: 128000,
            min_vram_gb: 0,
            min_ram_gb: 0,
            runtime: "api",
            notes: "Intelligent routing across configured models.",
          },
          context_length: 128000,
          gpu_layers: hw.has_gpu ? 99 : 0,
          load_seconds: 0.05,
          loaded_at: nowSec(),
          warnings: [],
        };
        return this.getEngineStatus();
      }
    }

    if (candidate.includes("::")) {
      const det = this.resolveTargetDetails(candidate);
      if (!det) {
        const [pid] = candidate.split("::");
        const prov = this.getProvider(pid);
        if (prov && !prov.configured) {
          throw new Error(`Provider '${prov.name}' needs an API key before using '${candidate}'.`);
        }
        throw new Error(`Model '${candidate}' is not configured or enabled.`);
      }
      if (settings.offline_mode && !det.provider.is_local) {
        throw new Error("Offline mode is on. Select a local Ollama/LM Studio model or turn off Offline mode.");
      }
      this.loaded = {
        entry: {
          id: det.target,
          name: det.model.name,
          family: det.provider.id,
          publisher: det.provider.name,
          base_repo: det.provider.base_url,
          gguf_repo: "",
          file: det.model.id,
          size_bytes: 0,
          license: "Provider",
          parameters: det.provider.is_local ? "Local" : "Cloud",
          quantization: det.provider.protocol.toUpperCase(),
          tier: det.model.tier === "fast" ? "lite" : det.model.tier === "high" ? "high" : "balanced",
          native_context: det.model.capabilities.context_length ?? 32768,
          min_vram_gb: 0,
          min_ram_gb: 0,
          runtime: det.provider.protocol === "gemini" && det.provider.id === "gemini" ? "Gemini API" : "api",
          notes: `${det.provider.name} · ${det.model.name}`,
          api_model: det.model.id,
        },
        context_length: det.model.capabilities.context_length ?? 32768,
        gpu_layers: hw.has_gpu ? 99 : 0,
        load_seconds: 0.05,
        loaded_at: nowSec(),
        warnings: [],
      };
      return this.getEngineStatus();
    }

    const resolved = resolveModelSelection(settings, this.catalogEntries(), this.getInstalledSet(), hw, modelOverride);
    if (resolved.error || !resolved.entry) {
      throw new Error(resolved.error || "No model available to load.");
    }
    if (resolved.entry.runtime === "Gemini API" && settings.offline_mode) {
      throw new Error("Offline mode is on. Select a local model or turn off Offline mode to use Gemini AI.");
    }
    if (resolved.entry.runtime === "api" && settings.offline_mode) {
      throw new Error("Offline mode is on. Select a local model or turn off Offline mode to use an API provider.");
    }
    this.loaded = {
      entry: resolved.entry,
      context_length: resolved.context_length ?? 4096,
      gpu_layers: resolved.gpu_layers ?? 0,
      load_seconds: 0.35,
      loaded_at: nowSec(),
      warnings: [],
    };
    return this.getEngineStatus();
  }

  unloadEngine(): EngineStatus {
    this.loaded = null;
    return this.getEngineStatus();
  }

  startDownload(modelId: string): DownloadState {
    const entry = this.catalogEntries().find((m) => m.id === modelId);
    if (!entry) throw new Error("Unknown model.");
    if (this.settings.offline_mode) {
      throw new Error("Offline mode is on. Turn it off in Settings > Privacy to download models.");
    }
    if (this.isModelInstalled(entry)) {
      return { state: "done", received: entry.size_bytes, total: entry.size_bytes, speed_bps: 0, error: "" };
    }
    const existing = this.downloads.get(modelId);
    if (existing && existing.state === "downloading") {
      return existing;
    }
    const total = entry.size_bytes || 1_000_000_000;
    const prevReceived = existing?.state === "paused" ? existing.received : 0;
    const state: DownloadState = {
      state: "downloading",
      received: prevReceived,
      total,
      speed_bps: Math.round(total / 3),
      error: "",
    };
    this.downloads.set(modelId, state);

    const existingTimer = this.downloadTimers.get(modelId);
    if (existingTimer) clearInterval(existingTimer);

    const timer = setInterval(() => {
      const cur = this.downloads.get(modelId);
      if (!cur || cur.state !== "downloading") {
        clearInterval(timer);
        this.downloadTimers.delete(modelId);
        return;
      }
      const increment = Math.max(Math.round(cur.total / 5), 100_000_000);
      cur.received = Math.min(cur.total, cur.received + increment);
      if (cur.received >= cur.total) {
        cur.state = "done";
        cur.speed_bps = 0;
        this.installedModels.add(modelId);
        clearInterval(timer);
        this.downloadTimers.delete(modelId);
      }
    }, 250);
    this.downloadTimers.set(modelId, timer);

    return state;
  }

  cancelDownload(modelId: string): void {
    const timer = this.downloadTimers.get(modelId);
    if (timer) {
      clearInterval(timer);
      this.downloadTimers.delete(modelId);
    }
    const cur = this.downloads.get(modelId);
    if (cur && cur.state === "downloading") {
      cur.state = "paused";
      cur.speed_bps = 0;
    }
  }

  deleteModel(modelId: string): void {
    const entry = this.catalogEntries().find((m) => m.id === modelId);
    if (!entry) throw new Error("Unknown model.");
    if (entry.runtime === "Gemini API" || entry.runtime === "api") {
      throw new Error("Built-in cloud models cannot be deleted from disk.");
    }
    if (this.loaded && this.loaded.entry.id === modelId) {
      throw new Error("This model is loaded. Switch to another model before deleting it.");
    }
    this.cancelDownload(modelId);
    this.downloads.delete(modelId);
    this.installedModels.delete(modelId);
  }

  // ---- Projects ----
  listProjects(): Project[] {
    return Array.from(this.projects.values()).sort((a, b) => a.created_at - b.created_at);
  }

  createProject(name: string): Project {
    const project: Project = { id: newId(), name: name.trim() || "Untitled", created_at: nowSec() };
    this.projects.set(project.id, project);
    this.db.upsertProject(project);
    return project;
  }

  renameProject(id: string, name: string): void {
    const p = this.projects.get(id);
    if (p) {
      p.name = name.trim() || "Untitled";
      this.db.upsertProject(p);
    }
  }

  deleteProject(id: string): void {
    this.projects.delete(id);
    for (const c of this.conversations.values()) {
      if (c.project_id === id) c.project_id = null;
    }
    for (const m of Array.from(this.memories.values())) {
      if (m.project_id === id) this.memories.delete(m.id);
    }
    this.db.deleteProject(id);
  }

  // ---- Conversations & Messages ----
  createConversation(title = "New chat", kind: "chat" | "research" = "chat", projectId: string | null = null): Conversation {
    const t = nowSec();
    const conv: Conversation = {
      id: newId(),
      title,
      kind,
      project_id: projectId,
      created_at: t,
      updated_at: t,
    };
    this.conversations.set(conv.id, conv);
    this.messages.set(conv.id, []);
    this.db.upsertConversation(conv);
    return conv;
  }

  listConversations(search = ""): Conversation[] {
    const q = search.trim().toLowerCase();
    let list = Array.from(this.conversations.values());
    if (q) {
      list = list.filter((c) => {
        if (c.title.toLowerCase().includes(q)) return true;
        const msgs = this.messages.get(c.id) ?? [];
        return msgs.some((m) => m.content.toLowerCase().includes(q));
      });
    }
    return list.sort((a, b) => b.updated_at - a.updated_at).slice(0, 500);
  }

  updateConversation(id: string, patch: Partial<Conversation>): Conversation | null {
    const c = this.conversations.get(id);
    if (!c) return null;
    if (patch.title !== undefined) c.title = patch.title.trim().slice(0, 120) || "Untitled";
    if (patch.kind !== undefined) c.kind = patch.kind;
    if ("project_id" in patch) c.project_id = patch.project_id ?? null;
    c.updated_at = nowSec();
    this.db.upsertConversation(c);
    return c;
  }

  deleteConversation(id: string): void {
    this.conversations.delete(id);
    this.messages.delete(id);
    for (const doc of Array.from(this.documents.values())) {
      if (doc.conversation_id === id) {
        this.documents.delete(doc.id);
        this.chunks.delete(doc.id);
      }
    }
    const paths = this.db.deleteConversation(id);
    deleteStoredFiles(this.db, paths);
  }

  deleteAllConversations(): void {
    this.conversations.clear();
    this.messages.clear();
    this.documents.clear();
    this.chunks.clear();
    const paths = this.db.deleteAllConversations();
    deleteStoredFiles(this.db, paths);
    this.db.recordAudit("conversations_cleared", "Deleted all conversations, attached documents, and images.");
  }

  addMessage(conversationId: string, msg: Omit<Message, "id" | "conversation_id" | "created_at">): Message {
    const full: Message = {
      ...msg,
      id: newId(),
      conversation_id: conversationId,
      created_at: nowSec(),
    };
    const arr = this.messages.get(conversationId) ?? [];
    const seq = arr.length;
    arr.push(full);
    this.messages.set(conversationId, arr);
    this.db.insertMessage(full, seq);
    const conv = this.conversations.get(conversationId);
    if (conv) {
      conv.updated_at = nowSec();
      this.db.upsertConversation(conv);
    }
    return full;
  }

  updateMessage(conversationId: string, messageId: string, patch: Partial<Message>): Message | null {
    const arr = this.messages.get(conversationId) ?? [];
    const idx = arr.findIndex((m) => m.id === messageId);
    if (idx < 0) return null;
    const target = arr[idx];
    Object.assign(target, patch);
    this.db.insertMessage(target, idx);
    return target;
  }

  replaceConversationMessages(conversationId: string, nextMessages: Message[]): void {
    this.messages.set(conversationId, nextMessages);
    this.db.replaceConversationMessages(conversationId, nextMessages);
  }

  // ---- Memories ----
  listMemories(onlyEnabled = false, filters?: { q?: string; category?: string; projectId?: string | null }): Memory[] {
    let list = Array.from(this.memories.values());
    if (onlyEnabled) list = list.filter((m) => m.enabled === 1);
    if (filters?.category && filters.category !== "all") {
      list = list.filter((m) => m.category === filters.category);
    }
    if (filters?.projectId !== undefined) {
      if (filters.projectId === "global") {
        list = list.filter((m) => m.project_id === null);
      } else if (filters.projectId !== "all" && filters.projectId !== null) {
        list = list.filter((m) => m.project_id === filters.projectId);
      }
    }
    if (filters?.q?.trim()) {
      const needle = filters.q.trim().toLowerCase();
      list = list.filter((m) => m.content.toLowerCase().includes(needle) || m.category.toLowerCase().includes(needle));
    }
    return list.sort((a, b) => b.updated_at - a.updated_at || b.created_at - a.created_at);
  }

  addMemory(
    content: string,
    source = "user",
    options: {
      category?: MemoryCategory | string;
      project_id?: string | null;
      replace_conflict_id?: string | null;
      skip_duplicate_error?: boolean;
    } = {},
  ): Memory & { conflict?: { id: string; content: string } | null } {
    const clean = content.trim().slice(0, 600);
    if (!clean) {
      throw new Error("Memory text cannot be empty.");
    }
    if (source === "assistant" && !this.settings.memory_enabled) {
      throw new Error("Memory saving is disabled in Settings.");
    }

    const projectId = options.project_id && this.projects.has(options.project_id) ? options.project_id : null;
    const all = Array.from(this.memories.values());

    if (options.replace_conflict_id && this.memories.has(options.replace_conflict_id)) {
      this.deleteMemory(options.replace_conflict_id);
    }

    const currentAll = Array.from(this.memories.values());
    const duplicate = isDuplicateMemory(clean, projectId, currentAll);
    if (duplicate) {
      if (options.skip_duplicate_error) {
        return { ...duplicate, conflict: null };
      }
      throw new MemoryConflictError("An identical memory already exists in this scope.", duplicate, 409);
    }

    const conflict = findConflictingMemories(clean, projectId, currentAll);
    const category = normalizeMemoryCategory(options.category, clean, projectId);
    const t = nowSec();
    const mem: Memory = {
      id: newId(),
      content: clean,
      category,
      project_id: projectId,
      conflict_with: conflict?.id ?? null,
      enabled: 1,
      source,
      created_at: t,
      updated_at: t,
    };
    this.memories.set(mem.id, mem);
    this.db.upsertMemory(mem);
    void all;
    return {
      ...mem,
      conflict: conflict ? { id: conflict.id, content: conflict.content } : null,
    };
  }

  updateMemory(
    id: string,
    patch: {
      content?: string;
      enabled?: boolean;
      category?: MemoryCategory | string;
      project_id?: string | null;
      clear_conflict?: boolean;
    },
  ): Memory | null {
    const mem = this.memories.get(id);
    if (!mem) return null;
    const nextProjectId =
      patch.project_id !== undefined
        ? patch.project_id && this.projects.has(patch.project_id)
          ? patch.project_id
          : null
        : mem.project_id;
    const nextContent = patch.content !== undefined ? patch.content.trim().slice(0, 600) : mem.content;
    if (!nextContent) {
      throw new Error("Memory text cannot be empty.");
    }

    if (patch.content !== undefined || patch.project_id !== undefined) {
      const dup = isDuplicateMemory(nextContent, nextProjectId, Array.from(this.memories.values()), id);
      if (dup) {
        throw new MemoryConflictError("Another identical memory already exists in this scope.", dup, 409);
      }
    }

    mem.content = nextContent;
    mem.project_id = nextProjectId;
    if (patch.category !== undefined) {
      mem.category = normalizeMemoryCategory(patch.category, mem.content, mem.project_id);
    }
    if (patch.enabled !== undefined) mem.enabled = patch.enabled ? 1 : 0;
    if (patch.clear_conflict) {
      mem.conflict_with = null;
    } else if (patch.content !== undefined || patch.project_id !== undefined) {
      const conflict = findConflictingMemories(mem.content, mem.project_id, Array.from(this.memories.values()), id);
      mem.conflict_with = conflict?.id ?? null;
    }
    mem.updated_at = nowSec();
    this.db.upsertMemory(mem);
    return mem;
  }

  deleteMemory(id: string): void {
    this.memories.delete(id);
    for (const m of this.memories.values()) {
      if (m.conflict_with === id) m.conflict_with = null;
    }
    this.db.deleteMemory(id);
  }

  clearMemories(): void {
    this.memories.clear();
    this.db.clearMemories();
    this.db.recordAudit("memories_cleared", "Cleared all saved memories.");
  }

  searchMemories(query: string, limit = 10, projectId: string | null = null): Memory[] {
    return this.db.searchMemoriesFts(query, limit, projectId);
  }

  retrieveRelevantMemories(query: string, projectId: string | null = null, limit = 8): Memory[] {
    if (!this.settings.memory_enabled) return [];
    const ftsHits = this.db.searchMemoriesFts(query, Math.max(limit * 2, 12), projectId);
    return rankRelevantMemories(query, projectId, Array.from(this.memories.values()), ftsHits, limit);
  }

  importMemories(
    items: Array<{ content?: unknown; category?: unknown; project_id?: unknown; enabled?: unknown; source?: unknown }>,
  ): { imported: number; skipped: number; memories: Memory[] } {
    let imported = 0;
    let skipped = 0;
    const created: Memory[] = [];
    for (const raw of items) {
      const text = typeof raw?.content === "string" ? raw.content.trim() : "";
      if (!text) {
        skipped += 1;
        continue;
      }
      const proj = typeof raw.project_id === "string" && this.projects.has(raw.project_id) ? raw.project_id : null;
      const existingDup = isDuplicateMemory(text, proj, Array.from(this.memories.values()));
      if (existingDup) {
        skipped += 1;
        continue;
      }
      const mem = this.addMemory(text, typeof raw.source === "string" ? raw.source : "import", {
        category: typeof raw.category === "string" ? raw.category : undefined,
        project_id: proj,
      });
      if (raw.enabled === 0 || raw.enabled === false) {
        this.updateMemory(mem.id, { enabled: false });
      }
      imported += 1;
      created.push(this.memories.get(mem.id) ?? mem);
    }
    return { imported, skipped, memories: created };
  }

  // ---- Documents ----
  ingestDocument(filename: string, buffer: Buffer, conversationId: string | null, mime: string): DocumentRecord {
    const safeName = sanitizeFilename(filename);
    const extracted = extractDocumentWithPages(safeName, buffer);
    const id = newId();
    const chunkRows = chunkDocumentPages(id, extracted.pages);
    if (chunkRows.length === 0) {
      throw new DocumentError("The file contains no readable text.", 422);
    }
    const nChars = chunkRows.reduce((sum, p) => sum + p.text.length, 0);
    const validConvId = conversationId && this.conversations.has(conversationId) ? conversationId : null;

    let attachmentId: string | null = null;
    if (path.extname(safeName).toLowerCase() === ".pdf") {
      try {
        const pdfAtt = savePdfAttachmentForDocument(this.db, {
          filename: safeName,
          buffer,
          docId: id,
          conversationId: validConvId,
        });
        attachmentId = pdfAtt.id;
      } catch {
        attachmentId = null;
      }
    }

    const record: DocumentRecord = {
      id,
      name: safeName,
      mime: (mime || (path.extname(safeName).toLowerCase() === ".pdf" ? "application/pdf" : "")).slice(0, 120),
      size: buffer.byteLength,
      n_chunks: chunkRows.length,
      n_chars: nChars,
      conversation_id: validConvId,
      created_at: nowSec(),
      is_scanned: extracted.isScanned,
      page_count: extracted.pageCount,
      attachment_id: attachmentId,
    };
    this.documents.set(id, record);
    this.chunks.set(id, chunkRows);
    this.db.insertDocument(record, chunkRows);
    return record;
  }

  updateDocumentVisualChunks(docId: string, extractedText: string): DocumentRecord | null {
    const doc = this.documents.get(docId);
    if (!doc) return null;
    const pieces = chunkDocumentText(extractedText);
    const nextChunks: DocumentChunk[] = pieces.map((text, idx) => {
      const pageMatch = text.match(/\[Page\s+(\d+)\]/i);
      return {
        doc_id: docId,
        chunk_index: idx,
        page: pageMatch ? Number(pageMatch[1]) : 1,
        text,
      };
    });
    if (nextChunks.length === 0) return doc;
    this.db.replaceDocumentChunks(docId, nextChunks, false);
    this.chunks.set(docId, nextChunks);
    doc.n_chunks = nextChunks.length;
    doc.n_chars = nextChunks.reduce((sum, c) => sum + c.text.length, 0);
    doc.is_scanned = false;
    return doc;
  }

  attachDocuments(docIds: string[], conversationId: string): void {
    if (!this.conversations.has(conversationId)) return;
    for (const id of docIds) {
      const doc = this.documents.get(id);
      if (doc) {
        doc.conversation_id = conversationId;
        this.db.updateDocumentConversation(id, conversationId);
      }
    }
  }

  listDocumentsFor(conversationId: string | null): DocumentRecord[] {
    const list = Array.from(this.documents.values());
    if (conversationId) {
      return list.filter((d) => d.conversation_id === conversationId).sort((a, b) => a.created_at - b.created_at);
    }
    return list.sort((a, b) => b.created_at - a.created_at);
  }

  deleteDocument(id: string): void {
    this.documents.delete(id);
    this.chunks.delete(id);
    const paths = this.db.deleteDocument(id);
    deleteStoredFiles(this.db, paths);
  }

  // ---- Audit & Usage ----
  recordAudit(action: string, detail: string): void {
    this.db.recordAudit(action, detail);
  }

  listAuditLogs(limit = 50): AuditEntry[] {
    return this.db.listAuditLogs(limit);
  }

  recordUsage(metric: UsageMetricRow): void {
    this.db.recordUsage(metric);
  }

  getUsageStats(windowHours = 24 * 30): ProviderUsageStat[] {
    return this.db.getUsageSummary(windowHours);
  }

  // ---- Multi-Provider & Model Management ----
  getProviderApiKey(providerId: string): string {
    const saved = this.db.getSecret(`provider_key_${providerId}`);
    if (saved) return saved;
    if (providerId === "gemini") {
      return process.env.GEMINI_API_KEY?.trim() || "";
    }
    if (providerId === this.settings.api_provider && this._apiKey) {
      return this._apiKey;
    }
    return "";
  }

  setProviderApiKey(providerId: string, apiKey: string): void {
    const clean = apiKey.trim();
    this.db.setSecret(`provider_key_${providerId}`, clean);
    if (providerId === this.settings.api_provider) {
      this._apiKey = clean;
      this.db.setSecret("provider_api_key", clean);
    }
  }

  private hydratePublicProvider(pc: Omit<ProviderConfig, "configured" | "key_configured">): ProviderConfig {
    const key = this.getProviderApiKey(pc.id);
    const keyConfigured = Boolean(key);
    const localHost = pc.is_local || (Boolean(pc.base_url) && isLocalApiHost(pc.base_url));
    const configured = Boolean(pc.base_url && (keyConfigured || localHost));
    const healthStatus: ProviderHealthStatus =
      !configured && !pc.is_local ? "unconfigured" : pc.health_status;
    return {
      ...pc,
      is_local: localHost,
      key_configured: keyConfigured,
      configured,
      health_status: healthStatus,
    };
  }

  listProviders(): ProviderConfig[] {
    return Array.from(this.providers.values()).map((pc) => this.hydratePublicProvider(pc));
  }

  getProvider(providerId: string): ProviderConfig | undefined {
    const pc = this.providers.get(providerId);
    return pc ? this.hydratePublicProvider(pc) : undefined;
  }

  upsertProvider(input: {
    id?: string;
    preset_id?: string;
    name: string;
    protocol?: ProviderProtocol;
    base_url: string;
    enabled?: boolean;
    default_model?: string;
    api_key?: string;
    models?: ProviderModelConfig[];
  }): ProviderConfig {
    const now = nowSec();
    const presetId = (input.preset_id || input.id || "custom").trim();
    const id = (input.id || (presetId === "custom" ? `custom-${newId().slice(0, 6)}` : presetId)).trim();
    const existing = this.providers.get(id);
    const preset = PROVIDER_PRESETS.find((p) => p.id === presetId);
    const base = normalizeApiBaseUrl(input.base_url || existing?.base_url || preset?.base_url || "");
    if (base) {
      validateExternalUrl(base, { allowLocalhost: true, requireHttpsForRemote: true });
    }
    const resolvedProto = inferProtocol(base || "https://api.openai.com/v1", input.protocol ?? existing?.protocol ?? preset?.protocol);
    const isLocal = Boolean(preset?.is_local) || (Boolean(base) && isLocalApiHost(base));

    let models = input.models ?? existing?.models ?? (preset && !preset.is_local ? buildPresetDefaultModels(preset) : []);
    const defaultModel = (input.default_model ?? existing?.default_model ?? preset?.default_model ?? "").trim();
    if (defaultModel && !models.some((m) => m.id === defaultModel)) {
      const inferred = inferVerifiedModelMetadata(presetId, defaultModel);
      models = [
        ...models,
        {
          id: defaultModel,
          name: inferred.name,
          enabled: true,
          custom: true,
          capabilities: inferred.capabilities,
          tier: inferred.tier,
          cost_tier: isLocal ? "free" : inferred.cost_tier,
        },
      ];
    }

    const record: Omit<ProviderConfig, "configured" | "key_configured"> = {
      id,
      preset_id: presetId,
      name: input.name.trim() || existing?.name || preset?.name || "Custom Endpoint",
      protocol: resolvedProto,
      base_url: base,
      enabled: input.enabled ?? existing?.enabled ?? true,
      is_local: isLocal,
      default_model: defaultModel || models[0]?.id || "",
      models,
      health_status: existing?.health_status ?? "unknown",
      health_message: existing?.health_message ?? "",
      last_checked_at: existing?.last_checked_at ?? null,
      last_latency_ms: existing?.last_latency_ms ?? null,
      created_at: existing?.created_at ?? now,
      updated_at: now,
    };

    this.providers.set(id, record);
    this.db.upsertProviderConfig(record);

    if (typeof input.api_key === "string" && input.api_key.trim()) {
      this.setProviderApiKey(id, input.api_key.trim());
    }
    this.db.recordAudit("provider_saved", `Saved provider '${record.name}' (${id}).`);
    return this.hydratePublicProvider(record);
  }

  removeProvider(providerId: string): void {
    const coreIds = new Set(CORE_PROVIDER_PRESETS.map((p) => p.id));
    this.setProviderApiKey(providerId, "");
    if (coreIds.has(providerId)) {
      const pc = this.providers.get(providerId);
      if (pc) {
        const preset = CORE_PROVIDER_PRESETS.find((p) => p.id === providerId)!;
        pc.base_url = preset.base_url;
        pc.models = preset.is_local ? [] : buildPresetDefaultModels(preset);
        pc.default_model = preset.default_model;
        pc.health_status = "unknown";
        pc.health_message = "";
        pc.last_checked_at = null;
        pc.last_latency_ms = null;
        pc.updated_at = nowSec();
        this.db.upsertProviderConfig(pc);
      }
      this.db.recordAudit("provider_cleared", `Cleared credentials/state for built-in provider '${providerId}'.`);
      return;
    }
    this.providers.delete(providerId);
    this.db.deleteProviderConfig(providerId);
    this.db.recordAudit("provider_deleted", `Deleted custom provider '${providerId}'.`);
  }

  addProviderModel(
    providerId: string,
    modelId: string,
    name?: string,
    params?: ModelGenerationParams,
  ): ProviderConfig {
    const pc = this.providers.get(providerId);
    if (!pc) throw new Error(`Provider '${providerId}' not found.`);
    const cleanId = modelId.trim();
    if (!cleanId) throw new Error("Model ID cannot be empty.");
    const existing = pc.models.find((m) => m.id === cleanId);
    if (existing) {
      if (name?.trim()) existing.name = name.trim();
      if (params) existing.params = { ...existing.params, ...params };
      existing.enabled = true;
    } else {
      const inferred = inferVerifiedModelMetadata(pc.preset_id, cleanId);
      pc.models.push({
        id: cleanId,
        name: name?.trim() || inferred.name,
        enabled: true,
        custom: true,
        capabilities: inferred.capabilities,
        ...(params ? { params } : {}),
        tier: inferred.tier,
        cost_tier: pc.is_local ? "free" : inferred.cost_tier,
      });
    }
    if (!pc.default_model) pc.default_model = cleanId;
    pc.updated_at = nowSec();
    this.db.upsertProviderConfig(pc);
    return this.hydratePublicProvider(pc);
  }

  updateProviderModel(
    providerId: string,
    modelId: string,
    patch: { enabled?: boolean; name?: string; params?: ModelGenerationParams },
  ): ProviderConfig {
    const pc = this.providers.get(providerId);
    if (!pc) throw new Error(`Provider '${providerId}' not found.`);
    const m = pc.models.find((x) => x.id === modelId);
    if (!m) throw new Error(`Model '${modelId}' not found on provider '${providerId}'.`);
    if (patch.enabled !== undefined) m.enabled = Boolean(patch.enabled);
    if (patch.name !== undefined && patch.name.trim()) m.name = patch.name.trim();
    if (patch.params !== undefined) {
      m.params = {
        temperature: patch.params.temperature ?? null,
        top_p: patch.params.top_p ?? null,
        max_tokens: patch.params.max_tokens ?? null,
        timeout_ms: patch.params.timeout_ms ?? null,
      };
    }
    pc.updated_at = nowSec();
    this.db.upsertProviderConfig(pc);
    return this.hydratePublicProvider(pc);
  }

  removeProviderModel(providerId: string, modelId: string): ProviderConfig {
    const pc = this.providers.get(providerId);
    if (!pc) throw new Error(`Provider '${providerId}' not found.`);
    pc.models = pc.models.filter((m) => m.id !== modelId);
    if (pc.default_model === modelId) {
      pc.default_model = pc.models.find((m) => m.enabled)?.id ?? pc.models[0]?.id ?? "";
    }
    pc.updated_at = nowSec();
    this.db.upsertProviderConfig(pc);
    return this.hydratePublicProvider(pc);
  }

  setProviderHealth(
    providerId: string,
    status: ProviderHealthStatus,
    message: string,
    latencyMs: number | null,
  ): ProviderConfig {
    const pc = this.providers.get(providerId);
    if (!pc) throw new Error(`Provider '${providerId}' not found.`);
    pc.health_status = status;
    pc.health_message = message.slice(0, 300);
    pc.last_checked_at = nowSec();
    pc.last_latency_ms = latencyMs;
    pc.updated_at = nowSec();
    this.db.upsertProviderConfig(pc);
    return this.hydratePublicProvider(pc);
  }

  setProviderDiscovery(
    providerId: string,
    discovery: { models: ProviderModelConfig[]; status: ProviderHealthStatus; message: string; latencyMs: number | null },
  ): ProviderConfig {
    const pc = this.providers.get(providerId);
    if (!pc) throw new Error(`Provider '${providerId}' not found.`);
    const prevMap = new Map(pc.models.map((m) => [m.id, m]));
    const customModels = pc.models.filter((m) => m.custom && !discovery.models.some((d) => d.id === m.id));
    const merged: ProviderModelConfig[] = discovery.models.map((d) => {
      const prev = prevMap.get(d.id);
      return prev
        ? {
            ...d,
            enabled: prev.enabled,
            params: prev.params,
          }
        : d;
    });
    pc.models = [...merged, ...customModels];
    if (!pc.default_model || !pc.models.some((m) => m.id === pc.default_model)) {
      pc.default_model = pc.models.find((m) => m.enabled)?.id ?? pc.models[0]?.id ?? "";
    }
    pc.health_status = discovery.status;
    pc.health_message = discovery.message.slice(0, 300);
    pc.last_checked_at = nowSec();
    pc.last_latency_ms = discovery.latencyMs;
    pc.updated_at = nowSec();
    this.db.upsertProviderConfig(pc);
    return this.hydratePublicProvider(pc);
  }

  getRoutableModels(): RoutableModelOption[] {
    const list: RoutableModelOption[] = [];
    const s = this.settings;
    for (const p of this.listProviders()) {
      if (!p.enabled || !p.configured) continue;
      for (const m of p.models) {
        if (!m.enabled) continue;
        const target = `${p.id}::${m.id}`;
        list.push({
          target,
          provider_id: p.id,
          provider_name: p.name,
          preset_id: p.preset_id,
          protocol: p.protocol,
          model_id: m.id,
          model_name: m.name,
          is_local: p.is_local,
          health_status: p.health_status,
          health_message: p.health_message,
          capabilities: m.capabilities,
          params: m.params,
          tier: m.tier ?? "balanced",
          cost_tier: p.is_local ? "free" : (m.cost_tier ?? "medium"),
          is_default: s.default_provider_id === p.id && s.default_model_id === m.id,
          is_fallback: s.fallback_provider_id === p.id && s.fallback_model_id === m.id,
        });
      }
    }
    return list;
  }

  resolveTargetDetails(targetOrModelId: string): {
    target: string;
    provider: ProviderConfig;
    model: ProviderModelConfig;
  } | null {
    const clean = (targetOrModelId || "").trim();
    if (!clean || clean === "auto") return null;

    if (clean.includes("::")) {
      const [pid, ...rest] = clean.split("::");
      const mid = rest.join("::");
      const p = this.getProvider(pid);
      if (p && p.enabled && p.configured) {
        const m = p.models.find((x) => x.id === mid && x.enabled) ?? p.models.find((x) => x.id === mid);
        if (m) {
          return { target: `${p.id}::${m.id}`, provider: p, model: m };
        }
      }
    }

    // Legacy catalog ID mapping (e.g. "gemini-3.1-flash-lite", "gemini-4-hydrogen", "online-api")
    if (clean === "online-api" && this.hasOnlineProviderConfigured()) {
      const pid = this.settings.api_provider || "openai";
      const p = this.getProvider(pid) ?? this.getProvider("custom");
      if (p) {
        const m = p.models.find((x) => x.id === this.settings.api_model) ?? {
          id: this.settings.api_model,
          name: this.settings.api_model,
          enabled: true,
          capabilities: { vision: false, reasoning: false, tools: false, structured_output: false, verified: false },
        };
        return { target: `${p.id}::${m.id}`, provider: p, model: m };
      }
    }

    for (const p of this.listProviders()) {
      if (!p.enabled || !p.configured) continue;
      const m = p.models.find((x) => x.id === clean && x.enabled);
      if (m) {
        return { target: `${p.id}::${m.id}`, provider: p, model: m };
      }
    }
    return null;
  }

  recordSkillExecution(row: {
    skill_id: string;
    status: string;
    input_summary: string;
    output_summary: string;
    error: string | null;
    duration_ms: number;
  }): void {
    this.db.insertSkillExecution({
      id: newId(),
      created_at: nowSec(),
      ...row,
    });
  }

  listSkillExecutions(limit = 40) {
    return this.db.listSkillExecutions(limit);
  }

  shutdown(): void {
    if (this.attachmentCleanupTimer) {
      clearInterval(this.attachmentCleanupTimer);
      this.attachmentCleanupTimer = null;
    }
    for (const run of this.activeRuns.values()) {
      run.controller.abort();
    }
    this.activeRuns.clear();
    for (const timer of this.downloadTimers.values()) {
      clearInterval(timer);
    }
    this.downloadTimers.clear();
    this.db.recoverInterruptedMessages();
    this.db.close();
  }
}

export function formatConversationMarkdown(conv: Conversation, messages: Message[]): string {
  const stamp = new Date().toISOString().slice(0, 16).replace("T", " ");
  const lines: string[] = [`# ${conv.title}`, "", `_Exported from ${APP_NAME} on ${stamp}_`, ""];
  for (const m of messages) {
    const who = m.role === "user" ? "You" : APP_NAME;
    const meta =
      m.role === "assistant" && m.metrics?.model_name
        ? ` · ${m.metrics.model_name} · ${m.mode}`
        : "";
    lines.push(`## ${who}${meta}`, "", m.content.trim(), "");
    const web = (m.sources ?? []).filter((s) => s.kind === "web");
    if (web.length > 0) {
      lines.push("**Sources**");
      for (const s of web) {
        lines.push(`${s.n}. [${s.title}](${s.url})${s.date ? ` — ${s.date}` : ""}`);
      }
      lines.push("");
    }
  }
  return lines.join("\n");
}

export const store = new SwamiStore();
