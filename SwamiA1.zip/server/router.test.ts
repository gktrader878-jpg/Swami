import assert from "node:assert/strict";
import fs from "node:fs";
import http from "node:http";
import type { AddressInfo } from "node:net";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import { createApp } from "../server";
import { ModelRouter, getLocalAiWindowsGuide, selectAutoModel } from "./models/router";
import { SwamiStore } from "./store";

function tempDir(prefix: string): string {
  return fs.mkdtempSync(path.join(os.tmpdir(), prefix));
}

async function startHttpServer(
  handler: (req: http.IncomingMessage, res: http.ServerResponse) => void,
): Promise<{ server: http.Server; baseUrl: string }> {
  const server = http.createServer(handler);
  await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", resolve));
  const port = (server.address() as AddressInfo).port;
  return { server, baseUrl: `http://127.0.0.1:${port}` };
}

function readBody(req: http.IncomingMessage): Promise<string> {
  return new Promise((resolve) => {
    const chunks: Buffer[] = [];
    req.on("data", (c) => chunks.push(Buffer.from(c)));
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf-8")));
  });
}

test("Multi-provider persistence seeds 10 core providers, encrypts keys at rest, and never leaks keys", async () => {
  const dir = tempDir("swami-router-p1-");
  try {
    const store1 = new SwamiStore(dir);
    assert.equal(store1.db.getSchemaVersion(), 3);

    const providers = store1.listProviders();
    const ids = new Set(providers.map((p) => p.id));
    for (const coreId of [
      "gemini", "openai", "anthropic", "openrouter", "groq", "deepseek", "xai", "ollama", "lmstudio", "custom",
    ]) {
      assert.ok(ids.has(coreId), `missing core provider ${coreId}`);
    }

    const secretKey = "sk-proj-secret-never-leak-9999";
    store1.upsertProvider({
      id: "openai",
      name: "OpenAI",
      protocol: "openai",
      base_url: "https://api.openai.com/v1",
      enabled: true,
      default_model: "gpt-4.1-mini",
      api_key: secretKey,
    });

    const openai = store1.getProvider("openai");
    assert.ok(openai);
    assert.equal(openai.key_configured, true);
    assert.equal(openai.configured, true);
    assert.equal(JSON.stringify(openai).includes(secretKey), false);
    assert.equal(store1.getProviderApiKey("openai"), secretKey);

    // Custom OpenAI-compatible provider CRUD + restart persistence
    const custom = store1.upsertProvider({
      preset_id: "custom",
      name: "Lab Gateway",
      protocol: "openai",
      base_url: "http://127.0.0.1:4999/v1",
      enabled: true,
      default_model: "lab-v1",
      api_key: "custom-secret-token",
    });
    store1.addProviderModel(custom.id, "lab-v2", "Lab v2", { temperature: 0.2, max_tokens: 1024 });
    store1.updateProviderModel(custom.id, "lab-v2", { enabled: false });
    store1.db.close();

    const store2 = new SwamiStore(dir);
    assert.equal(store2.getProviderApiKey("openai"), secretKey);
    const restoredCustom = store2.getProvider(custom.id);
    assert.ok(restoredCustom);
    assert.equal(restoredCustom.name, "Lab Gateway");
    assert.equal(store2.getProviderApiKey(custom.id), "custom-secret-token");
    const restoredModel = restoredCustom.models.find((m) => m.id === "lab-v2");
    assert.ok(restoredModel);
    assert.equal(restoredModel.enabled, false);
    assert.equal(restoredModel.params?.temperature, 0.2);

    // Public listings & settings mask all provider secrets
    const serializedProviders = JSON.stringify(store2.listProviders());
    const serializedSettings = JSON.stringify(store2.getSettings());
    assert.equal(serializedProviders.includes(secretKey), false);
    assert.equal(serializedProviders.includes("custom-secret-token"), false);
    assert.equal(serializedSettings.includes(secretKey), false);
    assert.equal(serializedSettings.includes("custom-secret-token"), false);
    store2.db.close();
  } finally {
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("Local AI discovery (Ollama & LM Studio) discovers real models, never fakes offline daemons, and validates SSRF", async () => {
  const dir = tempDir("swami-router-local-");
  const testStore = new SwamiStore(dir);
  const app = createApp(testStore);
  const appServer = app.listen(0, "127.0.0.1");
  await new Promise<void>((resolve) => appServer.once("listening", resolve));
  const appBase = `http://127.0.0.1:${(appServer.address() as AddressInfo).port}`;

  // Mock Ollama server
  const ollamaMock = await startHttpServer((req, res) => {
    if (req.url === "/api/tags") {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ models: [{ name: "qwen2.5-coder:7b", model: "qwen2.5-coder:7b" }] }));
      return;
    }
    if (req.url === "/api/show") {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ capabilities: ["completion", "tools"], model_info: { "general.context_length": 32768 } }));
      return;
    }
    res.writeHead(404).end();
  });

  // Mock LM Studio server
  const lmsMock = await startHttpServer((req, res) => {
    if (req.url === "/v1/models") {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ data: [{ id: "lmstudio-llama-3.1-8b" }] }));
      return;
    }
    res.writeHead(404).end();
  });

  try {
    // 1. SSRF rejection via v1 provider API
    const ssrfResp = await fetch(`${appBase}/api/v1/providers`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        preset_id: "custom",
        name: "Evil Metadata",
        protocol: "openai",
        base_url: "http://169.254.169.254/latest",
      }),
    });
    assert.equal(ssrfResp.status, 400);
    const ssrfJson = (await ssrfResp.json()) as { code: string };
    assert.equal(ssrfJson.code, "SSRF_BLOCKED");

    // 2. Live Ollama discovery
    await fetch(`${appBase}/api/v1/providers/ollama`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ base_url: ollamaMock.baseUrl, enabled: true }),
    });
    const ollamaDisc = await fetch(`${appBase}/api/v1/providers/ollama/discover`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({}),
    });
    assert.equal(ollamaDisc.status, 200);
    const ollamaData = (await ollamaDisc.json()) as { ok: boolean; provider: { models: Array<{ id: string; capabilities: { verified: boolean; tools: boolean } }> } };
    assert.equal(ollamaData.ok, true);
    assert.equal(ollamaData.provider.models.length, 1);
    assert.equal(ollamaData.provider.models[0].id, "qwen2.5-coder:7b");
    assert.equal(ollamaData.provider.models[0].capabilities.verified, true);
    assert.equal(ollamaData.provider.models[0].capabilities.tools, true);

    // 3. Live LM Studio discovery
    await fetch(`${appBase}/api/v1/providers/lmstudio`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ base_url: `${lmsMock.baseUrl}/v1`, enabled: true }),
    });
    const lmsDisc = await fetch(`${appBase}/api/v1/providers/lmstudio/discover`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({}),
    });
    assert.equal(lmsDisc.status, 200);
    const lmsData = (await lmsDisc.json()) as { ok: boolean; provider: { models: Array<{ id: string }> } };
    assert.equal(lmsData.provider.models[0].id, "lmstudio-llama-3.1-8b");

    // 4. Unreachable local daemon returns honest status and 0 simulated models
    const deadServer = await startHttpServer((_req, res) => res.end());
    const deadUrl = `${deadServer.baseUrl}/v1`;
    await new Promise<void>((r) => deadServer.server.close(() => r()));

    await fetch(`${appBase}/api/v1/providers/lmstudio`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ base_url: deadUrl, enabled: true }),
    });
    const localResp = await fetch(`${appBase}/api/v1/local/status`);
    assert.equal(localResp.status, 200);
    const localJson = (await localResp.json()) as {
      lmstudio: { reachable: boolean; provider: { models: unknown[]; health_status: string } };
      windows_local_guide: { ollama: { env_example: string } };
    };
    assert.equal(localJson.lmstudio.reachable, false);
    assert.equal(localJson.lmstudio.provider.health_status, "unreachable");
    assert.equal(localJson.lmstudio.provider.models.length, 0);
    assert.ok(getLocalAiWindowsGuide().ollama.env_example.includes("OLLAMA_HOST"));
  } finally {
    await new Promise<void>((r) => ollamaMock.server.close(() => r()));
    await new Promise<void>((r) => lmsMock.server.close(() => r()));
    await new Promise<void>((r) => appServer.close(() => r()));
    testStore.db.close();
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("ModelRouter handles transient pre-token retry, explicit failover (never silent), abort, and post-token no-failover", async () => {
  const dir = tempDir("swami-router-failover-");
  const store = new SwamiStore(dir);
  const router = new ModelRouter();

  let primaryCalls = 0;
  const primaryServer = await startHttpServer(async (req, res) => {
    await readBody(req);
    primaryCalls += 1;
    // Fail both retry attempts with 503 before any token is emitted
    res.writeHead(503, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ error: { message: "Upstream overloaded" } }));
  });

  const fallbackServer = await startHttpServer(async (req, res) => {
    await readBody(req);
    res.writeHead(200, { "Content-Type": "text/event-stream" });
    res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: "Recovered cleanly" } }] })}\n\n`);
    res.write(
      `data: ${JSON.stringify({ choices: [{ delta: {}, finish_reason: "stop" }], usage: { prompt_tokens: 12, completion_tokens: 4, total_tokens: 16 } })}\n\n`,
    );
    res.write("data: [DONE]\n\n");
    res.end();
  });

  // Mid-stream abort server that emits one token then errors
  const midFailServer = await startHttpServer(async (req, res) => {
    await readBody(req);
    res.writeHead(200, { "Content-Type": "text/event-stream" });
    res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: "Partial token " } }] })}\n\n`);
    // Close connection abnormally mid-SSE or send error chunk? Closing without [DONE] finishes normally in OpenAI client; send HTTP error after chunk? No, test error throwing after token via SSE error frame or close? Let's test via Anthropic/OpenAI SSE error payload!
    res.write(`data: ${JSON.stringify({ error: { message: "Stream interrupted mid-generation" } })}\n\n`);
    res.end();
  });

  try {
    const p1 = store.upsertProvider({
      preset_id: "custom",
      name: "Primary Gateway",
      protocol: "openai",
      base_url: `${primaryServer.baseUrl}/v1`,
      enabled: true,
      default_model: "primary-1",
      api_key: "key-1",
    });
    const p2 = store.upsertProvider({
      preset_id: "custom",
      name: "Backup Gateway",
      protocol: "openai",
      base_url: `${fallbackServer.baseUrl}/v1`,
      enabled: true,
      default_model: "backup-1",
      api_key: "key-2",
    });

    store.updateSettings({
      routing_mode: "manual",
      default_provider_id: p1.id,
      default_model_id: "primary-1",
      fallback_provider_id: p2.id,
      fallback_model_id: "backup-1",
      model_id: `${p1.id}::primary-1`,
    });

    const notices: string[] = [];
    const selectedEvents: Array<{ model_id: string; fallback_from?: string }> = [];
    let out = "";

    const result = await router.stream({
      activeStore: store,
      mode: "fast",
      systemPrompt: "You are concise.",
      messages: [{ role: "user", content: "Hello" }],
      signal: new AbortController().signal,
      onToken: (t) => (out += t),
      onReasoning: () => {},
      onNotice: (n) => notices.push(n),
      onModelSelected: (info) => selectedEvents.push({ model_id: info.model_id, fallback_from: info.fallback_from }),
    });

    assert.equal(primaryCalls, 2); // 1 initial attempt + 1 pre-token transient retry
    assert.equal(out, "Recovered cleanly");
    assert.equal(result.model_id, "backup-1");
    assert.ok(result.fallback_from?.includes("primary-1"));
    assert.equal(result.promptTokens, 12);
    assert.equal(result.completionTokens, 4);
    assert.equal(result.tokensEstimated, false);
    assert.ok(notices.some((n) => n.includes("Switching to fallback")));
    assert.equal(selectedEvents.length, 2);
    assert.ok(selectedEvents[1].fallback_from);

    // Mid-stream failure must NOT silently jump to fallback once tokens started streaming
    const pMid = store.upsertProvider({
      preset_id: "custom",
      name: "Mid-Stream Fail",
      protocol: "openai",
      base_url: `${midFailServer.baseUrl}/v1`,
      enabled: true,
      default_model: "mid-1",
      api_key: "key-mid",
    });
    let switchedAfterToken = false;
    await assert.rejects(async () => {
      await router.stream({
        activeStore: store,
        requestedTarget: `${pMid.id}::mid-1`,
        mode: "fast",
        systemPrompt: "Hi",
        messages: [{ role: "user", content: "Stream" }],
        signal: new AbortController().signal,
        onToken: () => {},
        onReasoning: () => {},
        onModelSelected: (info) => {
          if (info.fallback_from) switchedAfterToken = true;
        },
      });
    });
    assert.equal(switchedAfterToken, false);

    // AbortController cancellation propagates cleanly
    const ac = new AbortController();
    ac.abort();
    await assert.rejects(async () => {
      await router.stream({
        activeStore: store,
        requestedTarget: `${p2.id}::backup-1`,
        mode: "fast",
        systemPrompt: "Hi",
        messages: [{ role: "user", content: "Cancel me" }],
        signal: ac.signal,
        onToken: () => {},
        onReasoning: () => {},
      });
    }, (err: unknown) => err instanceof Error && err.name === "AbortError");
  } finally {
    await new Promise<void>((r) => primaryServer.server.close(() => r()));
    await new Promise<void>((r) => fallbackServer.server.close(() => r()));
    await new Promise<void>((r) => midFailServer.server.close(() => r()));
    store.db.close();
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("Auto Model enforces verified vision capabilities, offline blocking, and preference scoring", () => {
  const dir = tempDir("swami-router-auto-");
  const store = new SwamiStore(dir);
  try {
    store.upsertProvider({
      id: "openai",
      name: "OpenAI",
      protocol: "openai",
      base_url: "https://api.openai.com/v1",
      enabled: true,
      default_model: "gpt-4.1-mini",
      api_key: "sk-test-1",
    });
    store.upsertProvider({
      id: "groq",
      name: "Groq",
      protocol: "openai",
      base_url: "https://api.groq.com/openai/v1",
      enabled: true,
      default_model: "llama-3.1-8b-instant",
      api_key: "gsk_test-1",
    });

    // Fastest prefers fast-tier Groq llama-3.1-8b-instant or mini
    const fastPick = selectAutoModel({
      activeStore: store,
      mode: "fast",
      prompt: "Define recursion in one line.",
      preference: "fastest",
    });
    assert.ok(fastPick);
    assert.ok(fastPick.reason.includes("Auto-selected"));

    // Verified vision rejects if no verified vision model enabled, succeeds when gpt-4.1-mini (verified vision) is present
    const visionPick = selectAutoModel({
      activeStore: store,
      mode: "fast",
      prompt: "Describe this chart",
      requiresVision: true,
      preference: "capability",
    });
    assert.ok(visionPick);
    assert.equal(visionPick.chosen.capabilities.verified, true);
    assert.equal(visionPick.chosen.capabilities.vision, true);

    // Offline mode excludes cloud providers when no local daemon has models
    store.updateSettings({ offline_mode: true });
    const offlinePick = selectAutoModel({
      activeStore: store,
      mode: "fast",
      prompt: "Hello",
    });
    assert.equal(offlinePick, null);

    // Disabling all verified vision models across configured providers -> strict error when requiresVision=true
    store.updateSettings({ offline_mode: false });
    for (const opt of store.getRoutableModels()) {
      if (opt.capabilities.vision) {
        store.updateProviderModel(opt.provider_id, opt.model_id, { enabled: false });
      }
    }
    assert.throws(
      () =>
        selectAutoModel({
          activeStore: store,
          mode: "fast",
          prompt: "Inspect screenshot",
          requiresVision: true,
        }),
      /verified vision capability/i,
    );
  } finally {
    store.db.close();
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

test("Side-by-side comparison runs concurrently with isolated errors, streams SSE, and adopts chosen response", async () => {
  const dir = tempDir("swami-router-compare-");
  const testStore = new SwamiStore(dir);
  const app = createApp(testStore);
  const appServer = app.listen(0, "127.0.0.1");
  await new Promise<void>((resolve) => appServer.once("listening", resolve));
  const appBase = `http://127.0.0.1:${(appServer.address() as AddressInfo).port}`;

  const goodMock = await startHttpServer(async (req, res) => {
    const body = await readBody(req);
    // Verify comparison executes clean prompt without tool definitions injected
    assert.equal(body.includes('"tools"'), false);
    res.writeHead(200, { "Content-Type": "text/event-stream" });
    res.write(`data: ${JSON.stringify({ choices: [{ delta: { content: "Answer A" } }] })}\n\n`);
    res.write(
      `data: ${JSON.stringify({ choices: [{ delta: {}, finish_reason: "stop" }], usage: { prompt_tokens: 9, completion_tokens: 2, total_tokens: 11 } })}\n\n`,
    );
    res.write("data: [DONE]\n\n");
    res.end();
  });

  const failMock = await startHttpServer(async (req, res) => {
    await readBody(req);
    res.writeHead(401, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ error: { message: "Bad API token" } }));
  });

  try {
    const gProv = testStore.upsertProvider({
      preset_id: "custom",
      name: "Compare Good",
      protocol: "openai",
      base_url: `${goodMock.baseUrl}/v1`,
      enabled: true,
      default_model: "good-m",
      api_key: "good-k",
    });
    const bProv = testStore.upsertProvider({
      preset_id: "custom",
      name: "Compare Bad",
      protocol: "openai",
      base_url: `${failMock.baseUrl}/v1`,
      enabled: true,
      default_model: "bad-m",
      api_key: "bad-k",
    });

    const resp = await fetch(`${appBase}/api/v1/models/compare`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        targets: [`${gProv.id}::good-m`, `${bProv.id}::bad-m`],
        prompt: "Compare outputs cleanly.",
        mode: "fast",
      }),
    });
    assert.equal(resp.status, 200);
    const rawSse = await resp.text();
    const frames = rawSse
      .split("\n\n")
      .filter((b) => b.includes("data: "))
      .map((b) => JSON.parse(b.replace(/^data: /, "")) as { type: string; results?: Array<{ target: string; status: string; content: string; error?: string }> });

    const complete = frames.find((f) => f.type === "complete");
    assert.ok(complete?.results);
    const goodRes = complete.results.find((r) => r.target === `${gProv.id}::good-m`);
    const badRes = complete.results.find((r) => r.target === `${bProv.id}::bad-m`);
    assert.equal(goodRes?.status, "complete");
    assert.equal(goodRes?.content, "Answer A");
    assert.equal(badRes?.status, "error");
    assert.ok(badRes?.error);

    // Adopt winning comparison response into conversation
    const adoptResp = await fetch(`${appBase}/api/v1/models/compare/adopt`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        prompt: "Compare outputs cleanly.",
        result: goodRes,
      }),
    });
    assert.equal(adoptResp.status, 200);
    const adopted = (await adoptResp.json()) as {
      conversation: { id: string };
      assistant_message: { content: string; metrics: { model_id: string } };
    };
    assert.equal(adopted.assistant_message.content, "Answer A");
    assert.equal(adopted.assistant_message.metrics.model_id, "good-m");
    assert.equal(testStore.messages.get(adopted.conversation.id)?.length, 2);
  } finally {
    await new Promise<void>((r) => goodMock.server.close(() => r()));
    await new Promise<void>((r) => failMock.server.close(() => r()));
    await new Promise<void>((r) => appServer.close(() => r()));
    testStore.db.close();
    fs.rmSync(dir, { recursive: true, force: true });
  }
});
