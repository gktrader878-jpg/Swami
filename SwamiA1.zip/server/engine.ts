import { runMatchingSkills } from "./agents/orchestrator";
import { computeLoanEmi, evaluateArithmetic } from "./calculator";
import { buildDocumentContext } from "./documents";
import { generateGeminiTitle, runGeminiTurn } from "./gemini";
import { detectMemorySuggestions } from "./memory/engine";
import { modelRouter } from "./models/router";
import { runDeepResearch, type ResearchSynthesisModel } from "./research/service";
import { redactSensitive } from "./security/secrets";
import { newId, store } from "./store";
import type {
  Attachment,
  Conversation,
  MemorySuggestion,
  MemoryUsed,
  Message,
  Metrics,
  Mode,
  MultimodalImageInput,
  ProviderChatMessage,
  Source,
  Step,
  StreamEvent,
} from "./types";
import {
  analyzeImagesWithVisionModel,
  buildVisionInstructionAddendum,
  loadStoredImagesAsInputs,
} from "./vision/service";
import { readAttachmentBytes, toPublicAttachment } from "./vision/storage";

export interface ChatRequestBody {
  conversation_id: string | null;
  content: string;
  mode: Mode;
  model_id: string;
  document_ids: string[];
  image_ids?: string[];
  regenerate: boolean;
  project_id: string | null;
}

type EmitFn = (event: StreamEvent) => void;

const sleep = (ms: number, signal?: AbortSignal) =>
  new Promise<void>((resolve, reject) => {
    if (signal?.aborted) return reject(new DOMException("Aborted", "AbortError"));
    const t = setTimeout(() => {
      signal?.removeEventListener("abort", onAbort);
      resolve();
    }, ms);
    const onAbort = () => {
      clearTimeout(t);
      reject(new DOMException("Aborted", "AbortError"));
    };
    signal?.addEventListener("abort", onAbort, { once: true });
  });

function deriveTitle(question: string): string {
  const cleaned = question.replace(/\s+/g, " ").replace(/[?!.]+$/g, "").trim();
  if (!cleaned) return "New chat";
  const words = cleaned.split(" ").slice(0, 6);
  const title = words.join(" ");
  return title.length > 52 ? `${title.slice(0, 49)}…` : title;
}

function estimateTokens(text: string): number {
  return Math.max(4, Math.round(text.length / 3.6));
}

interface GeneratedPlan {
  reasoning: string;
  answer: string;
  sources: Source[];
  toolStep?: { title: string; detail: string };
}

function buildLocalResponse(
  question: string,
  mode: Mode,
  docContext: string,
  docUsedNames: string[],
  memories: string[],
  skillContext = "",
): GeneratedPlan {
  const q = question.toLowerCase();

  // Check if the user explicitly asked to remember a fact
  const rememberMatch = question.match(/(?:remember|note that|keep in mind)\s+(?:that\s+)?(.+)/i);
  if (rememberMatch && rememberMatch[1] && store.settings.memory_enabled) {
    const fact = rememberMatch[1].trim().replace(/[.]+$/, "");
    if (fact.length >= 4 && fact.length <= 350) {
      store.addMemory(fact, "assistant", { skip_duplicate_error: true });
    }
  }

  // Document-grounded Q&A
  if (docContext && docUsedNames.length > 0) {
    const snippetLines = docContext
      .replace(/<[^>]+>/g, "")
      .split(/\n+/)
      .map((l) => l.trim())
      .filter((l) => l.length > 20)
      .slice(0, 5);
    const preview = snippetLines.map((l) => `> ${l.slice(0, 220)}${l.length > 220 ? "…" : ""}`).join("\n");
    return {
      reasoning:
        mode === "think"
          ? `1. Indexed attached file(s): ${docUsedNames.join(", ")}.\n2. Matched relevant passages against "${question}".\n3. Synthesizing a grounded answer citing the attached text.`
          : "",
      answer:
        `Based on the attached document(s) (**${docUsedNames.join(", ")}**), here are the most relevant details:\n\n` +
        `${preview}\n\n` +
        (skillContext ? `### Skill analysis\n${skillContext}\n\n` : "") +
        `If you'd like me to focus on a specific section, table, or calculation inside **${docUsedNames[0]}**, ask a targeted follow-up question.`,
      sources: [],
      toolStep: { title: "Searched attached documents", detail: `${docUsedNames.join(", ")}` },
    };
  }

  // Loan EMI starter / math calculation
  if (q.includes("emi") || (q.includes("loan") && q.includes("interest"))) {
    const principalMatch = question.match(/(?:₹|rs\.?|inr|\$)?\s*([\d,]{4,})/i);
    const rateMatch = question.match(/(\d+(?:\.\d+)?)\s*%/);
    const yearsMatch = question.match(/(\d+(?:\.\d+)?)\s*years?/i);
    const P = principalMatch ? Number(principalMatch[1].replace(/,/g, "")) : 850000;
    const rate = rateMatch ? Number(rateMatch[1]) : 9.5;
    const years = yearsMatch ? Number(yearsMatch[1]) : 7;
    const res = computeLoanEmi(P, rate, years);
    const emiFmt = Math.round(res.emi).toLocaleString("en-IN");
    const totalPayFmt = Math.round(res.totalPayment).toLocaleString("en-IN");
    const totalIntFmt = Math.round(res.totalInterest).toLocaleString("en-IN");
    const pFmt = res.principal.toLocaleString("en-IN");

    return {
      reasoning:
        mode === "think"
          ? `Principal P = ${P}, annual rate = ${rate}%, tenure = ${years} years (${res.months} months).\nMonthly rate r = ${rate}/12/100 = ${res.monthlyRate.toFixed(6)}.\nUsing EMI = P * r * (1+r)^n / ((1+r)^n - 1) -> EMI ≈ ${res.emi.toFixed(2)}, Total Interest ≈ ${res.totalInterest.toFixed(2)}.`
          : "",
      toolStep: {
        title: "Calculator",
        detail: `EMI = ${res.emi.toFixed(2)}, Total Payment = ${res.totalPayment.toFixed(2)}, Total Interest = ${res.totalInterest.toFixed(2)}`,
      },
      answer:
        `Using the standard reducing-balance EMI formula:\n\n` +
        `$$\\text{EMI} = \\frac{P \\cdot r \\cdot (1 + r)^n}{(1 + r)^n - 1}$$\n\n` +
        `### Inputs\n` +
        `- **Principal ($P$)**: ₹${pFmt}\n` +
        `- **Annual Interest Rate**: ${rate}% $\\implies r = \\frac{${rate}}{12 \\times 100} = ${res.monthlyRate.toFixed(6)}$ per month\n` +
        `- **Tenure ($n$)**: ${years} years = ${res.months} monthly instalments\n\n` +
        `### Result\n` +
        `- **Monthly EMI**: **₹${emiFmt}** (exact: ₹${res.emi.toFixed(2)})\n` +
        `- **Total Amount Paid**: ₹${totalPayFmt}\n` +
        `- **Total Interest Paid**: **₹${totalIntFmt}**\n`,
      sources: [],
    };
  }

  // Standalone arithmetic expression
  const mathCandidate = question.trim().replace(/^(?:what is|calculate|compute|solve|eval)\s+/i, "").replace(/\?$/, "");
  if (/^[0-9+\-*/().^\s,]+$/.test(mathCandidate) && /[+\-*/^]/.test(mathCandidate)) {
    const evalRes = evaluateArithmetic(mathCandidate);
    if (evalRes.ok) {
      return {
        reasoning: mode === "think" ? `Evaluating expression \`${mathCandidate}\` with exact arithmetic.` : "",
        toolStep: { title: "Calculator", detail: `${mathCandidate} = ${evalRes.formatted}` },
        answer: `**Result:** \`${mathCandidate}\` = **${evalRes.formatted}**`,
        sources: [],
      };
    }
  }

  // Transformer starter
  if (q.includes("transformer")) {
    return {
      reasoning:
        mode === "think"
          ? "Structuring explanation around a clear everyday analogy (reading a paragraph with a highlighter across related words) followed by attention, tokens, and next-token prediction."
          : "",
      answer:
        `Think of a **transformer language model** like reading a sentence with a set of smart highlighters:\n\n` +
        `1. **Tokens (Word Pieces)**: Text is split into chunks called tokens—similar to syllables or common words.\n` +
        `2. **Self-Attention (Connecting Context)**: When reading *"The trophy didn't fit in the suitcase because **it** was too big"*, attention lets the model link **"it"** back to **"trophy"** by scoring how strongly every word relates to every other word in the sentence.\n` +
        `3. **Layers of Refinement**: Dozens of stacked attention + feed-forward layers progressively turn raw word patterns into meaning, grammar, and reasoning.\n` +
        `4. **Next-Token Prediction**: At the end, the model outputs a probability score for the next token, picks one, appends it, and repeats—one token at a time.\n`,
      sources: [],
    };
  }

  // Python intervals starter
  if (q.includes("overlapping") && q.includes("interval")) {
    return {
      reasoning:
        mode === "think"
          ? "Sort intervals by start time, iterate once in O(n log n), merge when cur[0] <= merged[-1][1], and include 3 deterministic test cases."
          : "",
      answer:
        `Sort the intervals by start time, then sweep left-to-right and merge whenever the next interval overlaps the last merged one:\n\n` +
        "```python\n" +
        "def merge_intervals(intervals: list[list[int]]) -> list[list[int]]:\n" +
        "    if not intervals:\n" +
        "        return []\n" +
        "    ordered = sorted(intervals, key=lambda x: x[0])\n" +
        "    merged = [ordered[0][:]]\n" +
        "    for start, end in ordered[1:]:\n" +
        "        if start <= merged[-1][1]:\n" +
        "            merged[-1][1] = max(merged[-1][1], end)\n" +
        "        else:\n" +
        "            merged.append([start, end])\n" +
        "    return merged\n\n" +
        "# Test cases\n" +
        "assert merge_intervals([[1, 3], [2, 6], [8, 10], [15, 18]]) == [[1, 6], [8, 10], [15, 18]]\n" +
        "assert merge_intervals([[1, 4], [4, 5]]) == [[1, 5]]\n" +
        "assert merge_intervals([]) == []\n" +
        "```\n\n" +
        `**Complexity:** $O(n \\log n)$ time for sorting and $O(n)$ space for the output.`,
      sources: [],
    };
  }

  // Hinglish starter
  if (q.includes("hinglish") || q.includes("fark")) {
    return {
      reasoning:
        mode === "think"
          ? "User asked in Hinglish for CPU vs GPU difference and why GPUs matter for AI. Keep explanation crisp and relatable."
          : "",
      answer:
        `**CPU** aur **GPU** dono processor hain, bas unka design bilkul alag kaam ke liye hota hai:\n\n` +
        `- **CPU (Central Processing Unit)**: Isko ek *genius manager* samjho—iske paas kam cores hote hain (4–16), lekin har core bahut smart aur fast hota hai. Ek ke baad ek complex tasks (OS chalana, files handle karna) yeh best karta hai.\n` +
        `- **GPU (Graphics Processing Unit)**: Isko *hazaaron workers ki team* samjho—isme thousands of chhote cores hote hain jo ek saath parallel mein simple math kar sakte hain.\n\n` +
        `### AI ke liye GPU kyun zaroori hai?\n` +
        `AI models (jaise LLMs) mein har word generate karne ke liye **crores of matrix multiplications** ek saath karne padte hain. CPU inhe line mein karega toh slow ho jayega, jabki GPU hazaaron calculations ek hi time par parallel mein nipta deta hai—isliye AI inference aur training GPU par kai guna fast chalti hai.`,
      sources: [],
    };
  }

  // Rewrite starter
  if (q.includes("rewrite") && q.includes("launch")) {
    return {
      reasoning: mode === "think" ? "Trim hedging words ('maybe', 'possibly', 'if that's okay') while preserving collaborative tone." : "",
      answer:
        `Here are three crisp options depending on your tone:\n\n` +
        `- **Direct & executive:** *"Let's move the launch date to give the team time to ship cleanly. Let me know if you see any blockers."*\n` +
        `- **Collaborative:** *"I recommend pushing the launch back so we can finalize testing. Please share any concerns by tomorrow."*\n` +
        `- **Ultra-short:** *"Proposing we move the launch date—please flag any conflicts today."*`,
      sources: [],
    };
  }

  // Generic helpful response respecting style & memories
  const styleNote =
    store.settings.style === "direct"
      ? ""
      : store.settings.style === "technical"
        ? "\n\n_Mode: Technical — active local catalog model `" + (store.loaded?.entry.name ?? "Qwen2.5 Coder 3B") + "`._"
        : "";
  const memoryNote =
    memories.length > 0
      ? `\n\n*(Active context includes ${memories.length} saved memory item${memories.length === 1 ? "" : "s"}.)*`
      : "";

  return {
    reasoning:
      mode === "think"
        ? `1. Parsed request: "${question.slice(0, 120)}"\n2. Checked active tools and ${memories.length} memory entries.\n3. Formulating direct response.`
        : "",
    answer:
      `Here is a structured response to your request (**${question.trim().slice(0, 100)}**):\n\n` +
      `- **Active Model**: ${store.loaded?.entry.name ?? "Qwen2.5 Coder 3B"} (${mode.toUpperCase()} mode)\n` +
      `- **Capabilities Ready**: Multi-turn chat persistence, document upload & Q&A, step-by-step Think workflow, calculator tool, and OpenAI-compatible API streaming (via **Settings → API providers**).\n\n` +
      `To run live cloud completions against your own endpoint, add your base URL, model name, and API key under **Settings → API providers** and select the **Online API model**.` +
      styleNote +
      memoryNote,
    sources: [],
  };
}

export async function executeChatTurn(
  req: ChatRequestBody,
  runId: string,
  emit: EmitFn,
  signal: AbortSignal,
): Promise<void> {
  const startMs = performance.now();
  const mode: Mode = req.mode === "think" || req.mode === "research" ? req.mode : "fast";
  const settings = store.getSettings();

  let conv: Conversation | undefined = req.conversation_id
    ? store.conversations.get(req.conversation_id)
    : undefined;
  if (!conv) {
    conv = store.createConversation("New chat", mode === "research" ? "research" : "chat", req.project_id ?? null);
  }
  const cid = conv.id;
  const existingMsgs = store.messages.get(cid) ?? [];
  const isFirstTurn = existingMsgs.length === 0;

  let userMsg: Message;
  let historyMsgs: Message[];
  let attachedImageRecords: ReturnType<typeof loadStoredImagesAsInputs>["records"] = [];
  let attachedImageInputs: MultimodalImageInput[] = [];

  if (req.regenerate) {
    const lastUserIdx = [...existingMsgs].reverse().findIndex((m) => m.role === "user");
    if (lastUserIdx < 0) {
      emit({ type: "error", message: "There is nothing to regenerate." });
      return;
    }
    const actualIdx = existingMsgs.length - 1 - lastUserIdx;
    userMsg = existingMsgs[actualIdx];
    historyMsgs = existingMsgs.slice(0, actualIdx);
    const regenImageIds = (userMsg.attachments ?? [])
      .filter((a) => a.kind === "image" || a.kind === "generated_image")
      .map((a) => a.id);
    if (regenImageIds.length > 0) {
      try {
        const loadedImgs = loadStoredImagesAsInputs(store, regenImageIds);
        attachedImageRecords = loadedImgs.records;
        attachedImageInputs = loadedImgs.inputs;
      } catch {
        /* non-fatal if prior attachment expired */
      }
    }
    store.replaceConversationMessages(cid, existingMsgs.slice(0, actualIdx + 1));
  } else {
    if (req.document_ids?.length) {
      store.attachDocuments(req.document_ids, cid);
    }
    const docAttachments: Attachment[] = (req.document_ids ?? [])
      .map((id) => store.documents.get(id))
      .filter((d): d is NonNullable<typeof d> => Boolean(d))
      .map((d) => ({ id: d.id, name: d.name, size: d.size, kind: "document" as const }));

    if (req.image_ids?.length) {
      const loadedImgs = loadStoredImagesAsInputs(store, req.image_ids);
      attachedImageRecords = loadedImgs.records;
      attachedImageInputs = loadedImgs.inputs;
    }

    const imageAttachments: Attachment[] = attachedImageRecords.map(toPublicAttachment);
    const attachments: Attachment[] = [...docAttachments, ...imageAttachments];
    const effectiveContent =
      req.content.trim() || (imageAttachments.length > 0 ? "Analyze the attached image(s) in detail." : "");

    userMsg = store.addMessage(cid, {
      role: "user",
      content: effectiveContent,
      reasoning: "",
      mode,
      steps: [],
      sources: [],
      metrics: {},
      attachments,
      status: "complete",
    });
    if (attachedImageRecords.length > 0) {
      store.db.bindAttachmentsToConversation(
        attachedImageRecords.map((r) => r.id),
        cid,
        userMsg.id,
      );
    }
    historyMsgs = existingMsgs;
  }

  if (mode === "research" && conv.kind !== "research") {
    store.updateConversation(cid, { kind: "research" });
  }

  const assistantMsg = store.addMessage(cid, {
    role: "assistant",
    content: "",
    reasoning: "",
    mode,
    steps: [],
    sources: [],
    metrics: {},
    attachments: [],
    status: "streaming",
  });

  emit({
    type: "start",
    conversation_id: cid,
    user_message: userMsg,
    assistant_message_id: assistantMsg.id,
    mode,
  });

  const steps: Step[] = [];
  let content = "";
  let reasoning = "";
  let sources: Source[] = [];
  let finalStatus: Message["status"] = "complete";
  let errorMsg = "";
  let firstTokenSec: number | null = null;
  let modelCalls = 1;
  let toolCalls = 0;
  let usedProviderId: string | undefined;
  let usedProviderName: string | undefined;
  let usedModelId: string | undefined;
  let usedModelName: string | undefined;
  let usedIsLocal: boolean | undefined;
  let routedReason: string | undefined;
  let fallbackFrom: string | undefined;
  let exactPromptTokens: number | undefined;
  let exactCompletionTokens: number | undefined;
  let exactTotalTokens: number | undefined;
  let tokensEstimated = true;

  const elapsedSec = () => Math.round(((performance.now() - startMs) / 1000) * 10) / 10;

  const pushStep = (kind: string, title: string, detail = "", state: Step["state"] = "running"): string => {
    const step: Step = { id: newId().slice(0, 10), kind, title, detail, state, t: elapsedSec() };
    steps.push(step);
    emit({ type: "step", step: { ...step } });
    return step.id;
  };

  const updateStep = (id: string, patch: Partial<Step>) => {
    const s = steps.find((x) => x.id === id);
    if (!s) return;
    Object.assign(s, patch, { t_end: elapsedSec() });
    emit({ type: "step", step: { ...s } });
  };

  try {
    const requestedTarget = (
      req.model_id ||
      (settings.routing_mode === "auto" ? "auto" : settings.model_id) ||
      ""
    ).trim();

    // Ensure a model is loaded or switched cleanly if target differs
    if (!store.loaded || (requestedTarget && store.loaded.entry.id !== requestedTarget && requestedTarget !== "auto")) {
      const loadId = pushStep("load", "Selecting model");
      let engineStatus;
      try {
        engineStatus = store.loadEngine(requestedTarget);
      } catch (loadErr) {
        if (!requestedTarget.includes("::") && requestedTarget !== "auto") {
          engineStatus = store.loadEngine("");
        } else {
          throw loadErr;
        }
      }
      updateStep(loadId, {
        title: "Model ready",
        detail: `${engineStatus.model_name ?? "Model"} ready`,
        state: "done",
      });
    }
    emit({ type: "engine", status: store.getEngineStatus() });

    const loaded = store.loaded!;

    // Research offline check
    if (mode === "research" && (settings.offline_mode || !settings.web_research_enabled)) {
      throw new Error("Deep Research is unavailable while Offline mode is enabled or Web research is off.");
    }

    // Build document context if attached
    const convDocs = store.listDocumentsFor(cid);
    const { contextBlock, used } = buildDocumentContext(
      userMsg.content,
      convDocs.map((d) => d.id),
      store.documents,
      store.chunks,
      Math.round((loaded.context_length || 4096) * 1.1),
    );
    const docNames = Array.from(new Set(used.map((u) => u.name)));

    if (used.length > 0) {
      pushStep(
        "documents",
        "Reading attached documents",
        `${docNames.join(", ")} (${used.every((u) => u.whole) ? "full text" : `${used.length} passages`})`,
        "done",
      );
      sources = used
        .filter((u) => !u.whole)
        .map((u) => ({ kind: "document" as const, title: u.label || u.name, url: "", snippet: u.excerpt }));
    }

    const docSources = [...sources];
    const relevantMemories = store.retrieveRelevantMemories(userMsg.content, conv.project_id, 8);
    const activeMemories = relevantMemories.map((m) => m.content);
    const memoriesUsed: MemoryUsed[] = relevantMemories.map((m) => ({
      id: m.id,
      content: m.content,
      category: m.category,
      project_id: m.project_id,
    }));
    if (memoriesUsed.length > 0) {
      pushStep(
        "memory",
        `Using ${memoriesUsed.length} saved ${memoriesUsed.length === 1 ? "memory" : "memories"}`,
        memoriesUsed.map((m) => `[${m.category}] ${m.content}`).join(" · ").slice(0, 180),
        "done",
      );
      emit({ type: "memories_used", memories: memoriesUsed });
    }

    // Run relevant deterministic skills (document / data / productivity)
    const skillResult = await runMatchingSkills({
      prompt: userMsg.content,
      mode,
      conversationId: cid,
      projectId: conv.project_id,
      documentIds: convDocs.map((d) => d.id),
      activeStore: store,
      signal,
    });
    if (skillResult.results.length > 0) {
      toolCalls += skillResult.results.length;
      for (const r of skillResult.results) {
        pushStep("tool", `Skill: ${r.skillId}`, r.summary, "done");
      }
    }

    const combinedDocAndSkillContext = [contextBlock, skillResult.combinedContext].filter(Boolean).join("\n\n");

    // Collect scanned PDF visual inputs (if any scanned PDFs are attached to conversation)
    const scannedPdfInputs: MultimodalImageInput[] = [];
    for (const d of convDocs) {
      if (d.is_scanned && d.attachment_id) {
        const pdfAtt = store.db.getAttachment(d.attachment_id);
        if (pdfAtt && pdfAtt.size <= 12 * 1024 * 1024) {
          try {
            const bytes = readAttachmentBytes(store.db, pdfAtt);
            scannedPdfInputs.push({
              id: pdfAtt.id,
              name: d.name,
              mimeType: "application/pdf",
              base64: bytes.toString("base64"),
            });
          } catch {
            /* ignore missing PDF binary */
          }
        }
      }
    }

    const currentVisualInputs: MultimodalImageInput[] = [...attachedImageInputs, ...scannedPdfInputs];
    const hasImageInput = attachedImageInputs.length > 0;
    const hasAnyVisualInput = currentVisualInputs.length > 0;
    const visionAddendum = buildVisionInstructionAddendum(currentVisualInputs);

    if (hasImageInput) {
      pushStep(
        "vision",
        `Inspecting ${attachedImageInputs.length} attached ${attachedImageInputs.length === 1 ? "image" : "images"}`,
        attachedImageInputs.map((img, i) => `#${i + 1} ${img.name}`).join(", "),
        "done",
      );
    }

    // Load recent historical images (up to 4 images across recent turns) for multi-turn visual follow-ups
    let remainingHistoryImages = 4;
    const recentHistorySlice = historyMsgs.filter((m) => m.role === "user" || m.role === "assistant").slice(-12);
    const hydratedHistory: ProviderChatMessage[] = new Array(recentHistorySlice.length);
    for (let i = recentHistorySlice.length - 1; i >= 0; i--) {
      const m = recentHistorySlice[i];
      const msgImgIds = (m.attachments ?? [])
        .filter((a) => a.kind === "image" || a.kind === "generated_image")
        .map((a) => a.id);
      let msgImgs: MultimodalImageInput[] | undefined;
      if (msgImgIds.length > 0 && remainingHistoryImages > 0) {
        const takeIds = msgImgIds.slice(0, remainingHistoryImages);
        try {
          const loadedHist = loadStoredImagesAsInputs(store, takeIds);
          msgImgs = loadedHist.inputs;
          remainingHistoryImages -= loadedHist.inputs.length;
        } catch {
          msgImgs = undefined;
        }
      }
      hydratedHistory[i] = {
        role: m.role as "user" | "assistant",
        content: m.content,
        ...(msgImgs && msgImgs.length > 0 ? { images: msgImgs } : {}),
      };
    }

    const routableModels = store.getRoutableModels();
    const usableRoutable = settings.offline_mode ? routableModels.filter((m) => m.is_local) : routableModels;
    const explicitResolved = requestedTarget && requestedTarget !== "auto" ? store.resolveTargetDetails(requestedTarget) : null;
    const isAutoRequest = requestedTarget === "auto" || (settings.routing_mode === "auto" && !req.model_id);
    const shouldUseMultiRouter =
      isAutoRequest ||
      requestedTarget.includes("::") ||
      (loaded.entry.runtime === "api" && usableRoutable.length > 0);

    if (mode === "research") {
      // Genuine Deep Research pipeline across configured search provider + real webpage extraction
      let researchTopic = userMsg.content;
      if (hasImageInput) {
        const vrId = pushStep("vision", "Extracting visual context for Deep Research");
        try {
          const visualSummary = await analyzeImagesWithVisionModel({
            activeStore: store,
            imageIds: attachedImageInputs.map((i) => i.id!).filter(Boolean),
            prompt: `Extract key subjects, visible text, product/diagram names, error codes, chart metrics, and research questions relevant to: "${userMsg.content}"`,
            modelId: requestedTarget || undefined,
            signal,
          });
          if (visualSummary.text.trim()) {
            researchTopic = `${userMsg.content}\n\n[Visual context extracted from attached image(s)]:\n${visualSummary.text.slice(0, 1800)}`;
            updateStep(vrId, { state: "done", detail: `Analyzed with ${visualSummary.model_name}` });
          } else {
            updateStep(vrId, { state: "done", detail: "Completed visual scan" });
          }
        } catch (vrErr) {
          const msg = redactSensitive(vrErr instanceof Error ? vrErr.message : "Visual extraction unavailable");
          updateStep(vrId, { state: "error", detail: msg });
        }
      }

      const synthesisModel: ResearchSynthesisModel =
        usableRoutable.length > 0
          ? {
              kind: "router",
              activeStore: store,
              requestedTarget: requestedTarget || undefined,
            }
          : loaded.entry.runtime === "Gemini API" && store.getProviderApiKey("gemini")
            ? { kind: "gemini", modelId: loaded.entry.file, apiKey: store.getProviderApiKey("gemini") }
            : { kind: "local-extract" };

      const researchOut = await runDeepResearch({
        topic: researchTopic,
        searchProvider: settings.search_provider,
        searxngUrl: settings.searxng_url,
        braveApiKey: store.braveApiKey,
        maxSources: settings.research_max_sources || 6,
        maxRounds: settings.research_max_rounds || 2,
        synthesisModel,
        signal,
        callbacks: {
          elapsedSec,
          onStep: (step) => {
            const idx = steps.findIndex((s) => s.id === step.id);
            if (idx >= 0) steps[idx] = { ...step };
            else steps.push({ ...step });
            emit({ type: "step", step: { ...step } });
          },
          onSources: (webSources) => {
            sources = [...docSources, ...webSources];
            emit({ type: "sources", sources });
          },
          onToken: (tok) => {
            if (firstTokenSec === null) firstTokenSec = elapsedSec();
            content += tok;
            emit({ type: "token", text: tok });
          },
          onNotice: (msg) => {
            emit({ type: "notice", message: msg });
          },
        },
      });

      if (researchOut.report !== content) {
        content = researchOut.report;
        emit({ type: "content_replace", text: content });
      }
      sources = [...docSources, ...researchOut.sources];
      modelCalls += 1;
    } else if (
      !shouldUseMultiRouter &&
      (loaded.entry.runtime === "Gemini API" || explicitResolved?.provider.id === "gemini")
    ) {
      if (settings.offline_mode) {
        throw new Error("Offline mode is on. Turn off Offline mode or select a local Ollama/LM Studio model.");
      }

      const geminiModelId = explicitResolved?.model.id ?? loaded.entry.file;
      const geminiModelName = explicitResolved?.model.name ?? loaded.entry.name;
      usedProviderId = "gemini";
      usedProviderName = "Google Gemini";
      usedModelId = geminiModelId;
      usedModelName = geminiModelName;
      usedIsLocal = false;

      emit({
        type: "model_selected",
        provider_id: "gemini",
        provider_name: "Google Gemini",
        model_id: geminiModelId,
        model_name: geminiModelName,
        is_local: false,
        auto_routed: false,
      });

      const systemInstruction =
        `You are SWAMI, an accurate, clear, and helpful AI assistant. Response style: ${settings.style}.` +
        (activeMemories.length ? `\nUser memories:\n${activeMemories.map((m) => `- ${m}`).join("\n")}` : "") +
        (settings.custom_instructions ? `\nCustom instructions: ${settings.custom_instructions}` : "") +
        visionAddendum;

      const userPrompt = combinedDocAndSkillContext
        ? `${combinedDocAndSkillContext}\n\nUser request:\n${userMsg.content}`
        : userMsg.content;

      try {
        const result = await runGeminiTurn({
          modelId: geminiModelId,
          apiKey: store.getProviderApiKey("gemini"),
          mode,
          systemInstruction,
          history: hydratedHistory,
          userPrompt,
          userImages: currentVisualInputs,
          memoryEnabled: Boolean(settings.memory_enabled),
          projectId: conv.project_id,
          signal,
          callbacks: {
            elapsedSec,
            onToken: (tok) => {
              if (firstTokenSec === null) firstTokenSec = elapsedSec();
              content += tok;
              emit({ type: "token", text: tok });
            },
            onReasoning: (rTok) => {
              if (firstTokenSec === null) firstTokenSec = elapsedSec();
              if (settings.show_reasoning) {
                reasoning += rTok;
                emit({ type: "reasoning", text: rTok });
              }
            },
            onStep: (step) => {
              const idx = steps.findIndex((s) => s.id === step.id);
              if (idx >= 0) steps[idx] = { ...step };
              else steps.push({ ...step });
              emit({ type: "step", step: { ...step } });
            },
            onSources: (webSources) => {
              sources = [...docSources, ...webSources];
              emit({ type: "sources", sources });
            },
          },
        });
        modelCalls = result.modelCalls;
        toolCalls += result.toolCalls;
        store.setProviderHealth("gemini", "healthy", `Last request succeeded (${geminiModelName})`, firstTokenSec ? Math.round(firstTokenSec * 1000) : null);
      } catch (gemErr) {
        const isAbort = (gemErr instanceof DOMException || gemErr instanceof Error) && gemErr.name === "AbortError";
        if (isAbort) throw gemErr;
        const cleanMsg = redactSensitive(gemErr instanceof Error ? gemErr.message : "Gemini request failed");
        store.setProviderHealth("gemini", "unhealthy", cleanMsg, null);

        // Explicit failover to configured fallback provider/model ONLY if zero tokens were streamed yet
        const fbTarget =
          settings.fallback_provider_id && settings.fallback_model_id
            ? `${settings.fallback_provider_id}::${settings.fallback_model_id}`
            : "";
        if (!content && !reasoning && fbTarget && fbTarget !== `gemini::${geminiModelId}`) {
          const noticeText = `Primary model ${geminiModelName} (Google Gemini) failed (${cleanMsg}). Switching to fallback model.`;
          emit({ type: "notice", message: noticeText });
          const fbRes = await modelRouter.stream({
            activeStore: store,
            requestedTarget: fbTarget,
            mode,
            systemPrompt: systemInstruction,
            messages: [
              ...hydratedHistory,
              {
                role: "user",
                content: userPrompt,
                ...(currentVisualInputs.length > 0 ? { images: currentVisualInputs } : {}),
              },
            ],
            promptForRouting: userMsg.content,
            taskType: hasAnyVisualInput && mode === "fast" ? "vision" : undefined,
            requiresVision: hasImageInput,
            signal,
            onToken: (tok) => {
              if (firstTokenSec === null) firstTokenSec = elapsedSec();
              content += tok;
              emit({ type: "token", text: tok });
            },
            onReasoning: (rTok) => {
              if (firstTokenSec === null) firstTokenSec = elapsedSec();
              if (settings.show_reasoning) {
                reasoning += rTok;
                emit({ type: "reasoning", text: rTok });
              }
            },
            onModelSelected: (info) => {
              usedProviderId = info.provider_id;
              usedProviderName = info.provider_name;
              usedModelId = info.model_id;
              usedModelName = info.model_name;
              usedIsLocal = info.is_local;
              routedReason = info.reason;
              fallbackFrom = `${geminiModelName} (Google Gemini)`;
              emit({ type: "model_selected", ...info, fallback_from: fallbackFrom });
            },
            onNotice: (m) => emit({ type: "notice", message: m }),
          });
          content = fbRes.text;
          exactPromptTokens = fbRes.promptTokens ?? undefined;
          exactCompletionTokens = fbRes.completionTokens ?? undefined;
          exactTotalTokens = fbRes.totalTokens ?? undefined;
          tokensEstimated = fbRes.tokensEstimated;
        } else {
          throw gemErr;
        }
      }
    } else if (shouldUseMultiRouter && (usableRoutable.length > 0 || requestedTarget.includes("::"))) {
      // Unified multi-model router across OpenAI, Anthropic, Gemini, OpenRouter, Groq, DeepSeek, xAI, Ollama, LM Studio, Custom
      const execId = pushStep("execute", isAutoRequest ? "Routing request via Auto Model" : `Calling ${loaded.entry.name}`);
      const systemPrompt =
        `You are SWAMI, an accurate and helpful AI assistant. Style: ${settings.style}.` +
        (mode === "think" ? " Think step by step carefully before concluding." : "") +
        (activeMemories.length ? `\nUser memories:\n${activeMemories.map((m) => `- ${m}`).join("\n")}` : "") +
        (settings.custom_instructions ? `\nCustom instructions: ${settings.custom_instructions}` : "") +
        visionAddendum;

      const apiMessages: ProviderChatMessage[] = [
        ...hydratedHistory,
        {
          role: "user",
          content: combinedDocAndSkillContext
            ? `${combinedDocAndSkillContext}\n\nUser request:\n${userMsg.content}`
            : userMsg.content,
          ...(currentVisualInputs.length > 0 ? { images: currentVisualInputs } : {}),
        },
      ];

      const routerRes = await modelRouter.stream({
        activeStore: store,
        requestedTarget: requestedTarget || undefined,
        mode,
        systemPrompt,
        messages: apiMessages,
        promptForRouting: userMsg.content,
        taskType: hasAnyVisualInput && mode === "fast" ? "vision" : undefined,
        requiresVision: hasImageInput,
        signal,
        onToken: (tok) => {
          if (firstTokenSec === null) firstTokenSec = elapsedSec();
          content += tok;
          emit({ type: "token", text: tok });
        },
        onReasoning: (rTok) => {
          if (firstTokenSec === null) firstTokenSec = elapsedSec();
          if (settings.show_reasoning) {
            reasoning += rTok;
            emit({ type: "reasoning", text: rTok });
          }
        },
        onModelSelected: (info) => {
          usedProviderId = info.provider_id;
          usedProviderName = info.provider_name;
          usedModelId = info.model_id;
          usedModelName = info.model_name;
          usedIsLocal = info.is_local;
          routedReason = info.reason;
          fallbackFrom = info.fallback_from;
          updateStep(execId, {
            title: `${info.is_local ? "Local" : "Cloud"}: ${info.model_name} (${info.provider_name})`,
            detail: info.fallback_from ? `Fallback from ${info.fallback_from}` : info.reason || "",
          });
          emit({ type: "model_selected", ...info });
        },
        onNotice: (msg) => emit({ type: "notice", message: msg }),
      });

      content = routerRes.text;
      exactPromptTokens = routerRes.promptTokens ?? undefined;
      exactCompletionTokens = routerRes.completionTokens ?? undefined;
      exactTotalTokens = routerRes.totalTokens ?? undefined;
      tokensEstimated = routerRes.tokensEstimated;
      updateStep(execId, { state: "done", detail: usedModelName ? `${usedProviderName} · ${usedModelName}` : "Completed" });
    } else {
      if (hasImageInput) {
        throw new Error(
          settings.offline_mode
            ? "Cannot analyze images: no verified local vision model (such as Ollama LLaVA or Qwen-VL) is configured in Offline mode."
            : "Cannot analyze images: no verified vision-capable model is configured. Add a Gemini, OpenAI, Anthropic, or local Ollama vision model in Settings → API providers.",
        );
      }
      // Local engine execution
      if (mode === "think") {
        const planId = pushStep("plan", "Planning the approach");
        await sleep(140, signal);
        updateStep(planId, {
          state: "done",
          detail: "1. Break down the request. 2. Run calculator/document checks if needed. 3. Verify and format answer.",
        });
        modelCalls += 1;
      }

      const plan = buildLocalResponse(
        userMsg.content,
        mode,
        contextBlock,
        docNames,
        activeMemories,
        skillResult.results.map((r) => `- **${r.skillId}**: ${r.summary}`).join("\n"),
      );

      if (plan.toolStep) {
        toolCalls += 1;
        pushStep("tool", plan.toolStep.title, plan.toolStep.detail, "done");
      }

      if (plan.reasoning && settings.show_reasoning) {
        for (const chunk of plan.reasoning.match(/.{1,32}/g) ?? [plan.reasoning]) {
          if (firstTokenSec === null) firstTokenSec = elapsedSec();
          reasoning += chunk;
          emit({ type: "reasoning", text: chunk });
          await sleep(18, signal);
        }
      }

      const execId = mode === "think" ? pushStep("execute", "Working through the problem") : null;
      const chunks = plan.answer.match(/.{1,48}/gs) ?? [plan.answer];
      for (const piece of chunks) {
        if (firstTokenSec === null) firstTokenSec = elapsedSec();
        content += piece;
        emit({ type: "token", text: piece });
        await sleep(4, signal);
      }
      if (execId) {
        updateStep(execId, {
          state: "done",
          detail: toolCalls > 0 ? `${toolCalls} tool call(s)` : "Completed",
        });
      }

      if (mode === "think" && settings.think_verify) {
        const verId = pushStep("verify", "Checking the answer");
        await sleep(110, signal);
        updateStep(verId, { state: "done", title: "Answer checked", detail: "No errors found" });
        modelCalls += 1;
      }

      if (plan.sources.length > 0) {
        sources = [...sources, ...plan.sources];
      }
    }

    if (sources.length > 0) {
      emit({ type: "sources", sources });
    }

    // Automatic memory suggestions (user-controlled: only when memory_enabled && memory_auto_suggest are on; requires user approval)
    let memorySuggestions: MemorySuggestion[] = [];
    if (settings.memory_enabled && settings.memory_auto_suggest) {
      memorySuggestions = detectMemorySuggestions(
        userMsg.content,
        content,
        conv.project_id,
        Array.from(store.memories.values()),
      );
      if (memorySuggestions.length > 0) {
        emit({ type: "memory_suggestions", suggestions: memorySuggestions });
      }
    }

    if (isFirstTurn && content.trim()) {
      const fallbackTitle = deriveTitle(userMsg.content);
      store.updateConversation(cid, { title: fallbackTitle });
      emit({ type: "title", conversation_id: cid, title: fallbackTitle });
      if (usedProviderId === "gemini" || loaded.entry.runtime === "Gemini API") {
        void generateGeminiTitle(userMsg.content, content, store.getProviderApiKey("gemini")).then((aiTitle) => {
          if (aiTitle && store.conversations.has(cid)) {
            store.updateConversation(cid, { title: aiTitle });
          }
        });
      }
    }

    // Persist memories_used & memory_suggestions on assistantMsg before final done emit
    if (memoriesUsed.length > 0 || memorySuggestions.length > 0) {
      store.updateMessage(cid, assistantMsg.id, {
        ...(memoriesUsed.length > 0 ? { memories_used: memoriesUsed } : {}),
        ...(memorySuggestions.length > 0 ? { memory_suggestions: memorySuggestions } : {}),
      });
    }
  } catch (err) {
    if (err instanceof DOMException && err.name === "AbortError") {
      finalStatus = "stopped";
    } else if (err instanceof Error && err.name === "AbortError") {
      finalStatus = "stopped";
    } else {
      finalStatus = "error";
      errorMsg = redactSensitive(err instanceof Error ? err.message : "Unexpected generation error.");
    }
  }

  for (const s of steps) {
    if (s.state === "running") {
      s.state = finalStatus === "stopped" ? "stopped" : finalStatus === "error" ? "error" : "done";
      s.t_end = elapsedSec();
    }
  }

  const totalSec = Math.max(0.1, Math.round(((performance.now() - startMs) / 1000) * 100) / 100);
  const completionTokens = exactCompletionTokens ?? estimateTokens(content + reasoning);
  const promptTokens = exactPromptTokens ?? estimateTokens(userMsg.content);
  const totalTokens = exactTotalTokens ?? (promptTokens + completionTokens);
  const metrics: Metrics = {
    model_id: usedModelId ?? store.loaded?.entry.id ?? "qwen2.5-coder-3b-ollama",
    model_name: usedModelName ?? store.loaded?.entry.name ?? "Qwen2.5 Coder 3B",
    provider_id: usedProviderId ?? (store.loaded?.entry.runtime === "Gemini API" ? "gemini" : "local"),
    provider_name: usedProviderName ?? (store.loaded?.entry.runtime === "Gemini API" ? "Google Gemini" : store.loaded?.entry.publisher ?? "Local"),
    is_local: usedIsLocal ?? (store.loaded?.entry.runtime !== "Gemini API" && store.loaded?.entry.runtime !== "api"),
    ...(routedReason ? { routed_reason: routedReason } : {}),
    ...(fallbackFrom ? { fallback_from: fallbackFrom } : {}),
    quantization: store.loaded?.entry.quantization ?? "Q4_K_M",
    context_length: store.loaded?.context_length ?? 4096,
    first_token_s: firstTokenSec ?? 0.1,
    total_s: totalSec,
    prompt_tokens: promptTokens,
    completion_tokens: completionTokens,
    total_tokens: totalTokens,
    tokens_estimated: tokensEstimated,
    tokens_per_second: Math.round((completionTokens / totalSec) * 10) / 10,
    model_calls: modelCalls,
    tool_calls: toolCalls,
    peak_vram_mb: null,
    peak_ram_mb: Math.round(process.memoryUsage().rss / (1024 * 1024)),
    load_seconds: null,
  };

  try {
    store.recordUsage({
      ts: Date.now() / 1000,
      model_id: metrics.model_id ?? "unknown",
      provider: metrics.provider_id ?? store.loaded?.entry.runtime ?? "local",
      mode,
      prompt_tokens: promptTokens,
      completion_tokens: completionTokens,
      first_token_ms: Math.round((firstTokenSec ?? 0.1) * 1000),
      total_ms: Math.round(performance.now() - startMs),
      status: finalStatus,
    });
  } catch {
    // Non-fatal if DB closed during shutdown
  }

  const finalMessage =
    store.updateMessage(cid, assistantMsg.id, {
      content,
      reasoning,
      steps,
      sources,
      metrics,
      status: finalStatus,
      ...(errorMsg ? { error: errorMsg } : {}),
    }) ?? assistantMsg;

  if (finalStatus === "error" && errorMsg) {
    emit({ type: "error", message: errorMsg });
  }
  emit({ type: "done", status: finalStatus, message: finalMessage });
  store.activeRuns.delete(runId);
}
