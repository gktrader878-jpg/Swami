import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";

const ALGO = "aes-256-gcm";
const IV_BYTES = 12;
const KEY_BYTES = 32;

export function resolveMasterKey(dataDir: string): Buffer {
  const envKey = process.env.SWAMI_MASTER_KEY?.trim();
  if (envKey) {
    return crypto.createHash("sha256").update(envKey, "utf8").digest();
  }
  fs.mkdirSync(dataDir, { recursive: true });
  const keyFile = path.join(dataDir, ".secret.key");
  try {
    if (fs.existsSync(keyFile)) {
      const hex = fs.readFileSync(keyFile, "utf8").trim();
      const buf = Buffer.from(hex, "hex");
      if (buf.byteLength === KEY_BYTES) {
        return buf;
      }
    }
  } catch {
    // Regenerate key file if unreadable
  }
  const generated = crypto.randomBytes(KEY_BYTES);
  fs.writeFileSync(keyFile, generated.toString("hex"), { encoding: "utf8", mode: 0o600 });
  try {
    fs.chmodSync(keyFile, 0o600);
  } catch {
    // Ignore on filesystems without POSIX chmod support
  }
  return generated;
}

export function encryptSecret(plaintext: string, masterKey: Buffer): string {
  const clean = plaintext.trim();
  if (!clean) return "";
  const iv = crypto.randomBytes(IV_BYTES);
  const cipher = crypto.createCipheriv(ALGO, masterKey, iv);
  const ciphertext = Buffer.concat([cipher.update(clean, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `v1:${iv.toString("base64")}:${tag.toString("base64")}:${ciphertext.toString("base64")}`;
}

export function decryptSecret(payload: string, masterKey: Buffer): string {
  if (!payload) return "";
  const parts = payload.split(":");
  if (parts.length !== 4 || parts[0] !== "v1") {
    return "";
  }
  try {
    const iv = Buffer.from(parts[1], "base64");
    const tag = Buffer.from(parts[2], "base64");
    const ciphertext = Buffer.from(parts[3], "base64");
    const decipher = crypto.createDecipheriv(ALGO, masterKey, iv);
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString("utf8");
  } catch {
    return "";
  }
}

const SECRET_PATTERNS: RegExp[] = [
  /\b(sk-ant-[A-Za-z0-9_-]{8,})\b/g,
  /\b(sk-or-v1-[A-Za-z0-9_-]{8,})\b/g,
  /\b(sk-proj-[A-Za-z0-9_-]{8,})\b/g,
  /\b(sk-[A-Za-z0-9_-]{12,})\b/g,
  /\b(gsk_[A-Za-z0-9_-]{10,})\b/g,
  /\b(xai-[A-Za-z0-9_-]{10,})\b/g,
  /\b(pplx-[A-Za-z0-9_-]{10,})\b/g,
  /\b(fw_[A-Za-z0-9_-]{10,})\b/g,
  /\b(csk-[A-Za-z0-9_-]{10,})\b/g,
  /\b(AIza[0-9A-Za-z_-]{16,})\b/g,
  /\b(AQ\.[0-9A-Za-z_-]{16,})\b/g,
  /(Bearer\s+)[A-Za-z0-9._-]{10,}/gi,
  /([?&]key=)[^&\s]+/gi,
];

export function redactSensitive(text: string): string {
  let out = text;
  for (const rx of SECRET_PATTERNS) {
    out = out.replace(rx, (match, group1?: string) => {
      if (match.toLowerCase().startsWith("bearer ")) return "Bearer [REDACTED]";
      if (match.toLowerCase().includes("key=")) return `${group1 ?? "key="}[REDACTED]`;
      return "[REDACTED_KEY]";
    });
  }
  return out;
}
