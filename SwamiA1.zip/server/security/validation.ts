import net from "node:net";
import path from "node:path";

export class ValidationError extends Error {
  status: number;
  code: string;
  constructor(message: string, status = 400, code = "VALIDATION_ERROR") {
    super(message);
    this.status = status;
    this.code = code;
  }
}

export function isLoopbackHostname(hostname: string): boolean {
  const h = hostname.toLowerCase().replace(/^\[|\]$/g, "");
  return h === "localhost" || h === "127.0.0.1" || h === "::1";
}

function isPrivateOrMetadataIp(ip: string): boolean {
  const clean = ip.replace(/^\[|\]$/g, "").toLowerCase();
  if (net.isIPv4(clean)) {
    const octets = clean.split(".").map(Number);
    const [a, b] = octets;
    if (a === 0) return true; // 0.0.0.0/8
    if (a === 10) return true; // 10.0.0.0/8
    if (a === 127) return true; // 127.0.0.0/8
    if (a === 169 && b === 254) return true; // Link-local / cloud metadata 169.254.169.254
    if (a === 172 && b >= 16 && b <= 31) return true; // 172.16.0.0/12
    if (a === 192 && b === 168) return true; // 192.168.0.0/16
    if (a === 100 && b >= 64 && b <= 127) return true; // CGNAT 100.64.0.0/10
    return false;
  }
  if (net.isIPv6(clean)) {
    if (clean === "::" || clean === "::1") return true;
    if (clean.startsWith("fe80:") || clean.startsWith("fc") || clean.startsWith("fd")) return true;
    if (clean.startsWith("::ffff:")) {
      return isPrivateOrMetadataIp(clean.slice(7));
    }
  }
  return false;
}

const BLOCKED_HOSTNAMES = new Set([
  "metadata.google.internal",
  "metadata.goog",
  "169.254.169.254",
  "0.0.0.0",
]);

export function validateExternalUrl(
  rawUrl: string,
  options: { allowLocalhost?: boolean; requireHttpsForRemote?: boolean } = {},
): URL {
  const allowLocalhost = options.allowLocalhost ?? false;
  const requireHttpsForRemote = options.requireHttpsForRemote ?? true;

  let parsed: URL;
  try {
    parsed = new URL(rawUrl.trim());
  } catch {
    throw new ValidationError("Enter a valid URL (e.g. https://api.openai.com/v1).", 400, "INVALID_URL");
  }

  if (parsed.protocol !== "https:" && parsed.protocol !== "http:") {
    throw new ValidationError("Only HTTP and HTTPS URLs are permitted.", 400, "INVALID_SCHEME");
  }

  if (parsed.username || parsed.password) {
    throw new ValidationError("Embedded URL credentials are not allowed.", 400, "INVALID_URL_CREDENTIALS");
  }

  const host = parsed.hostname.toLowerCase().replace(/^\[|\]$/g, "");
  const loopback = isLoopbackHostname(host);

  if (BLOCKED_HOSTNAMES.has(host) || host.endsWith(".internal")) {
    throw new ValidationError("Access to internal or metadata endpoints is blocked.", 400, "SSRF_BLOCKED");
  }

  if (!loopback && (net.isIP(host) > 0 && isPrivateOrMetadataIp(host))) {
    throw new ValidationError("Private network and link-local IP addresses are blocked.", 400, "SSRF_BLOCKED");
  }

  if (loopback && !allowLocalhost) {
    throw new ValidationError("Localhost URLs are not allowed for this operation.", 400, "SSRF_BLOCKED");
  }

  if (!loopback && requireHttpsForRemote && parsed.protocol !== "https:") {
    throw new ValidationError("Online endpoints must use HTTPS (HTTP is allowed only for localhost).", 400, "HTTPS_REQUIRED");
  }

  return parsed;
}

export function sanitizeFilename(rawName: string): string {
  const base = path.basename(rawName || "document").replace(/[\x00-\x1f<>:"/\\|?*]+/g, "_").trim();
  return (base || "document").slice(0, 180);
}

export function hasDisallowedExecutableSignature(buffer: Buffer): boolean {
  if (buffer.byteLength < 2) return false;
  // Windows PE/MZ executable
  if (buffer[0] === 0x4d && buffer[1] === 0x5a) return true;
  // Linux ELF executable
  if (buffer.byteLength >= 4 && buffer[0] === 0x7f && buffer[1] === 0x45 && buffer[2] === 0x4c && buffer[3] === 0x46) {
    return true;
  }
  // Mach-O executables
  if (
    buffer.byteLength >= 4 &&
    ((buffer[0] === 0xcf && buffer[1] === 0xfa && buffer[2] === 0xed && buffer[3] === 0xfe) ||
      (buffer[0] === 0xfe && buffer[1] === 0xed && buffer[2] === 0xfa && buffer[3] === 0xcf))
  ) {
    return true;
  }
  return false;
}

export function validateChatRequest(raw: unknown): {
  conversation_id: string | null;
  content: string;
  mode: "fast" | "think" | "research";
  model_id: string;
  document_ids: string[];
  image_ids: string[];
  regenerate: boolean;
  project_id: string | null;
} {
  if (!raw || typeof raw !== "object") {
    throw new ValidationError("Request body must be a JSON object.");
  }
  const b = raw as Record<string, unknown>;
  const regenerate = Boolean(b.regenerate);
  const content = typeof b.content === "string" ? b.content : "";
  const image_ids = Array.isArray(b.image_ids)
    ? Array.from(new Set(b.image_ids.filter((x): x is string => typeof x === "string" && x.trim().length > 0).map((x) => x.trim().slice(0, 80))))
    : [];
  if (image_ids.length > 6) {
    throw new ValidationError("You can attach up to 6 images per message.", 400, "TOO_MANY_IMAGES");
  }
  if (!regenerate && !content.trim() && image_ids.length === 0) {
    throw new ValidationError("Message is empty.");
  }
  if (content.length > 100_000) {
    throw new ValidationError("Message exceeds maximum length (100,000 characters).");
  }
  const mode = b.mode === "think" || b.mode === "research" ? b.mode : "fast";
  const conversation_id =
    typeof b.conversation_id === "string" && b.conversation_id.trim() ? b.conversation_id.trim().slice(0, 64) : null;
  const project_id = typeof b.project_id === "string" && b.project_id.trim() ? b.project_id.trim().slice(0, 64) : null;
  const model_id = typeof b.model_id === "string" ? b.model_id.trim().slice(0, 128) : "";
  const document_ids = Array.isArray(b.document_ids)
    ? b.document_ids.filter((x): x is string => typeof x === "string" && x.trim().length > 0).slice(0, 20)
    : [];

  return { conversation_id, content, mode, model_id, document_ids, image_ids, regenerate, project_id };
}
