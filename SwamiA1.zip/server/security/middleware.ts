import crypto from "node:crypto";
import type { NextFunction, Request, Response } from "express";
import multer from "multer";
import { DocumentError } from "../documents";
import { redactSensitive } from "./secrets";
import { ValidationError } from "./validation";

export type LogLevel = "info" | "warn" | "error";

export function logEvent(level: LogLevel, event: string, fields: Record<string, unknown> = {}): void {
  if (process.env.NODE_ENV === "test") return;
  const safeFields: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(fields)) {
    if (typeof v === "string") {
      safeFields[k] = redactSensitive(v);
    } else if (v instanceof Error) {
      safeFields[k] = redactSensitive(v.message);
    } else {
      safeFields[k] = v;
    }
  }
  const line = JSON.stringify({
    ts: new Date().toISOString(),
    level,
    event,
    ...safeFields,
  });
  if (level === "error") {
    console.error(line);
  } else {
    console.log(line);
  }
}

export interface RequestWithId extends Request {
  requestId?: string;
}

export function requestIdAndLogging(req: RequestWithId, res: Response, next: NextFunction): void {
  const incoming = typeof req.headers["x-request-id"] === "string" ? req.headers["x-request-id"].trim() : "";
  const requestId = incoming && /^[a-zA-Z0-9_-]{8,64}$/.test(incoming) ? incoming : crypto.randomUUID();
  req.requestId = requestId;
  res.setHeader("X-Request-Id", requestId);

  const startedAt = performance.now();
  if (req.path.startsWith("/api/")) {
    res.on("finish", () => {
      const durationMs = Math.round(performance.now() - startedAt);
      logEvent(res.statusCode >= 500 ? "error" : res.statusCode >= 400 ? "warn" : "info", "http_request", {
        request_id: requestId,
        method: req.method,
        path: req.path,
        status: res.statusCode,
        duration_ms: durationMs,
      });
    });
  }
  next();
}

export function createRateLimiter(options: { windowMs: number; max: number; name: string }) {
  const hits = new Map<string, number[]>();
  return (req: RequestWithId, res: Response, next: NextFunction): void => {
    const ip = req.ip || req.socket.remoteAddress || "local";
    const key = `${options.name}:${ip}`;
    const now = Date.now();
    const cutoff = now - options.windowMs;
    const list = (hits.get(key) ?? []).filter((ts) => ts > cutoff);
    if (list.length >= options.max) {
      const oldest = list[0] ?? now;
      const retryAfterSec = Math.max(1, Math.ceil((oldest + options.windowMs - now) / 1000));
      res.setHeader("Retry-After", String(retryAfterSec));
      res.status(429).json({
        detail: `Too many requests for ${options.name}. Please wait ${retryAfterSec}s and try again.`,
        code: "RATE_LIMITED",
        retry_after_s: retryAfterSec,
        request_id: req.requestId,
      });
      return;
    }
    list.push(now);
    hits.set(key, list);
    // Keep map bounded
    if (hits.size > 1000) {
      for (const [k, timestamps] of hits) {
        if (timestamps.every((t) => t <= cutoff)) hits.delete(k);
      }
    }
    next();
  };
}

export function apiErrorHandler(err: unknown, req: RequestWithId, res: Response, _next: NextFunction): void {
  const requestId = req.requestId;
  if (err instanceof ValidationError) {
    res.status(err.status).json({ detail: redactSensitive(err.message), code: err.code, request_id: requestId });
    return;
  }
  if (err instanceof DocumentError) {
    res.status(err.status).json({ detail: redactSensitive(err.message), code: "DOCUMENT_ERROR", request_id: requestId });
    return;
  }
  if (err instanceof multer.MulterError) {
    const status = err.code === "LIMIT_FILE_SIZE" ? 413 : 400;
    const msg =
      err.code === "LIMIT_FILE_SIZE"
        ? "Uploaded file exceeds the 30 MB limit."
        : `File upload failed: ${err.message}`;
    res.status(status).json({ detail: msg, code: err.code, request_id: requestId });
    return;
  }
  if (err instanceof SyntaxError && "body" in err) {
    res.status(400).json({ detail: "Malformed JSON request body.", code: "INVALID_JSON", request_id: requestId });
    return;
  }
  const msg = err instanceof Error ? redactSensitive(err.message) : "Internal server error.";
  logEvent("error", "unhandled_api_error", { request_id: requestId, path: req.path, error: msg });
  res.status(500).json({ detail: msg, code: "INTERNAL_ERROR", request_id: requestId });
}
