import test from "node:test";
import assert from "node:assert/strict";
import { ThinkingLevel } from "@google/genai";
import { computeLoanEmi, evaluateArithmetic } from "./calculator";
import { chunkDocumentText, extractDocumentText, searchDocumentChunks } from "./documents";
import { BASE_CATALOG, DEFAULT_SETTINGS, getHardwareSnapshot, resolveModelSelection } from "./catalog";
import { formatConversationMarkdown } from "./store";
import {
  extractGroundingSources,
  formatGeminiError,
  selectGeminiThinkingLevel,
  shouldAttachToolsInFastMode,
} from "./gemini";
import {
  buildOpenAIChatPayload,
  detectProviderFromKey,
  inferProtocol,
  normalizeApiBaseUrl,
} from "./providers";
import type { DocumentChunk, DocumentRecord } from "./types";

test("evaluateArithmetic handles basic math and rejects invalid symbols", () => {
  const res = evaluateArithmetic("(12 + 8) * 3 / 2");
  assert.equal(res.ok, true);
  assert.equal(res.value, 30);

  const bad = evaluateArithmetic("process.exit(1)");
  assert.equal(bad.ok, false);
});

test("computeLoanEmi matches standard reducing-balance EMI formula", () => {
  const res = computeLoanEmi(850000, 9.5, 7);
  assert.equal(res.months, 84);
  assert.ok(Math.abs(res.emi - 13892.42) < 1, `Expected EMI near 13892.42, got ${res.emi}`);
  assert.ok(res.totalInterest > 300000);
});

test("document ingestion chunks text and ranks matching terms", () => {
  const text = extractDocumentText("notes.md", Buffer.from("SWAMI uses Qwen2.5 models.\n\nOther paragraph about coffee.", "utf-8"));
  const pieces = chunkDocumentText(text);
  assert.equal(pieces.length, 1);

  const docs = new Map<string, DocumentRecord>([
    [
      "doc1",
      {
        id: "doc1",
        name: "notes.md",
        mime: "text/markdown",
        size: text.length,
        n_chunks: 1,
        n_chars: text.length,
        conversation_id: "c1",
        created_at: 1,
      },
    ],
  ]);
  const chunks = new Map<string, DocumentChunk[]>([
    ["doc1", [{ doc_id: "doc1", chunk_index: 0, page: 0, text }]],
  ]);
  const hits = searchDocumentChunks("Which Qwen2.5 model?", ["doc1"], docs, chunks);
  assert.equal(hits.length, 1);
  assert.equal(hits[0].name, "notes.md");
});

test("resolveModelSelection falls back to installed model when preferred is absent", () => {
  const hw = getHardwareSnapshot();
  const resolved = resolveModelSelection(
    { ...DEFAULT_SETTINGS, profile: "high" },
    BASE_CATALOG,
    new Set(["qwen2.5-coder-3b-ollama"]),
    hw,
  );
  assert.equal(resolved.model_id, "qwen2.5-coder-3b-ollama");
  assert.ok((resolved.context_length ?? 0) >= 2048);
});

test("resolveModelSelection prefers fast Gemini 3.1 Flash Lite online and switches to local in offline mode", () => {
  const hw = getHardwareSnapshot();
  const installed = new Set(["gemini-3.1-flash-lite", "gemini-4-hydrogen", "qwen2.5-coder-3b-ollama"]);
  const online = resolveModelSelection({ ...DEFAULT_SETTINGS, offline_mode: false }, BASE_CATALOG, installed, hw);
  assert.equal(online.model_id, "gemini-3.1-flash-lite");

  const offline = resolveModelSelection({ ...DEFAULT_SETTINGS, offline_mode: true }, BASE_CATALOG, installed, hw);
  assert.equal(offline.model_id, "qwen2.5-coder-3b-ollama");
});

test("detectProviderFromKey auto-detects major API key prefixes", () => {
  assert.equal(detectProviderFromKey("sk-ant-api03-123")?.id, "anthropic");
  assert.equal(detectProviderFromKey("sk-or-v1-abc")?.id, "openrouter");
  assert.equal(detectProviderFromKey("gsk_abc123")?.id, "groq");
  assert.equal(detectProviderFromKey("xai-abc")?.id, "xai");
  assert.equal(detectProviderFromKey("pplx-abc")?.id, "perplexity");
  assert.equal(detectProviderFromKey("fw_abc")?.id, "fireworks");
  assert.equal(detectProviderFromKey("csk-abc")?.id, "cerebras");
  assert.equal(detectProviderFromKey("AIzaSyAbc")?.id, "gemini");
  assert.equal(detectProviderFromKey("sk-proj-abc")?.id, "openai");
  assert.equal(detectProviderFromKey("custom-token"), null);
});

test("normalizeApiBaseUrl and inferProtocol handle full endpoint pastes and protocols", () => {
  assert.equal(normalizeApiBaseUrl("https://api.openai.com/v1/chat/completions/"), "https://api.openai.com/v1");
  assert.equal(normalizeApiBaseUrl("https://api.anthropic.com/v1/messages"), "https://api.anthropic.com/v1");
  assert.equal(inferProtocol("https://api.anthropic.com/v1", "auto"), "anthropic");
  assert.equal(inferProtocol("https://generativelanguage.googleapis.com/v1beta", "auto"), "gemini");
  assert.equal(inferProtocol("https://openrouter.ai/api/v1", "auto"), "openai");
  assert.equal(inferProtocol("https://my-proxy.example.com", "anthropic"), "anthropic");
});

test("buildOpenAIChatPayload adapts parameters for reasoning vs standard models", () => {
  const std = buildOpenAIChatPayload({
    model: "gpt-4.1-mini",
    messages: [{ role: "user", content: "hi" }],
    temperature: null,
    maxTokens: 2048,
    stream: true,
  });
  assert.equal(std.temperature, 0.7);
  assert.equal(std.max_tokens, 2048);

  const reasoning = buildOpenAIChatPayload({
    model: "o4-mini",
    messages: [{ role: "user", content: "hi" }],
    temperature: 0.7,
    maxTokens: 2048,
    stream: true,
  });
  assert.equal("temperature" in reasoning, false);
  assert.equal(reasoning.max_completion_tokens, 2048);
});

test("selectGeminiThinkingLevel and shouldAttachToolsInFastMode minimize fast-mode latency", () => {
  assert.equal(selectGeminiThinkingLevel("gemini-3.1-flash-lite", "fast"), ThinkingLevel.MINIMAL);
  assert.equal(selectGeminiThinkingLevel("gemini-4-hydrogen", "fast"), ThinkingLevel.LOW);
  assert.equal(selectGeminiThinkingLevel("gemini-4-hydrogen", "think"), ThinkingLevel.HIGH);

  assert.deepEqual(shouldAttachToolsInFastMode("Say hello in 5 words"), { calculator: false, memory: false });
  assert.deepEqual(shouldAttachToolsInFastMode("What is 15% of 240?"), { calculator: true, memory: false });
  assert.deepEqual(shouldAttachToolsInFastMode("Remember that my favorite tea is chai"), {
    calculator: false,
    memory: true,
  });
});

test("extractGroundingSources deduplicates URLs and assigns 1-based citation numbers", () => {
  const sources = extractGroundingSources([
    { web: { uri: "https://www.example.com/a", title: "Example A" } },
    { web: { uri: "https://www.example.com/a", title: "Duplicate A" } },
    { web: { uri: "https://docs.python.org/3/", title: "Python Docs" } },
  ]);
  assert.equal(sources.length, 2);
  assert.deepEqual(
    sources.map((s) => ({ n: s.n, site: s.site, title: s.title })),
    [
      { n: 1, site: "example.com", title: "Example A" },
      { n: 2, site: "docs.python.org", title: "Python Docs" },
    ],
  );
});

test("formatGeminiError maps common API errors to actionable Settings > Secrets messages", () => {
  assert.ok(formatGeminiError(new Error("403 PERMISSION_DENIED: API_KEY_INVALID")).includes("Settings > Secrets"));
  assert.ok(formatGeminiError(new Error("429 RESOURCE_EXHAUSTED")).includes("429"));
  assert.ok(formatGeminiError(new Error("404 NOT_FOUND")).includes("404"));
});

test("formatConversationMarkdown formats user, assistant, and web sources", () => {
  const md = formatConversationMarkdown(
    { id: "c1", title: "Test Topic", kind: "chat", project_id: null, created_at: 1, updated_at: 1 },
    [
      {
        id: "m1",
        conversation_id: "c1",
        role: "user",
        content: "Hello",
        reasoning: "",
        mode: "fast",
        steps: [],
        sources: [],
        metrics: {},
        attachments: [],
        status: "complete",
        created_at: 1,
      },
      {
        id: "m2",
        conversation_id: "c1",
        role: "assistant",
        content: "Hi there [1]",
        reasoning: "",
        mode: "research",
        steps: [],
        sources: [{ n: 1, kind: "web", title: "Docs", url: "https://example.com", date: "2026" }],
        metrics: { model_name: "Qwen2.5 Coder 3B" },
        attachments: [],
        status: "complete",
        created_at: 2,
      },
    ],
  );
  assert.ok(md.includes("# Test Topic"));
  assert.ok(md.includes("## SWAMI · Qwen2.5 Coder 3B · research"));
  assert.ok(md.includes("1. [Docs](https://example.com) — 2026"));
});
