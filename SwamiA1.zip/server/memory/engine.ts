import crypto from "node:crypto";
import type { Memory, MemoryCategory, MemorySuggestion } from "../types";

export const MEMORY_CATEGORIES: ReadonlyArray<{ id: MemoryCategory; label: string }> = [
  { id: "preference", label: "User preferences" },
  { id: "project", label: "Projects" },
  { id: "instruction", label: "Instructions" },
  { id: "fact", label: "Important facts" },
  { id: "learning", label: "Learning context" },
  { id: "general", label: "General knowledge" },
];

export const VALID_MEMORY_CATEGORIES = new Set<MemoryCategory>(
  MEMORY_CATEGORIES.map((c) => c.id),
);

export function normalizeMemoryCategory(raw: unknown, fallbackContent = "", projectId: string | null = null): MemoryCategory {
  if (typeof raw === "string" && VALID_MEMORY_CATEGORIES.has(raw as MemoryCategory)) {
    return raw as MemoryCategory;
  }
  return categorizeMemory(fallbackContent, projectId);
}

export function normalizeMemoryText(text: string): string {
  return text
    .trim()
    .toLowerCase()
    .replace(/[.!?,;:]+$/g, "")
    .replace(/\s+/g, " ");
}

export function categorizeMemory(content: string, projectId: string | null = null): MemoryCategory {
  const lower = content.toLowerCase();
  if (/\b(always|never|must|do not|don't|respond in|format as|use only|instruction)\b/.test(lower)) {
    return "instruction";
  }
  if (/\b(prefer|prefers|preference|favorite|favourite|like|dislike|dark mode|light mode|hinglish|concise|detailed)\b/.test(lower)) {
    return "preference";
  }
  if (projectId || /\b(project|repo|repository|codebase|stack|backend|frontend|deploy|database|app)\b/.test(lower)) {
    return "project";
  }
  if (/\b(learn|learning|study|studying|course|exam|student|understand|practice)\b/.test(lower)) {
    return "learning";
  }
  if (/\b(my name is|i am|i'm|i work|live in|born|role is|years old|timezone|language is)\b/.test(lower)) {
    return "fact";
  }
  return "general";
}

export function isDuplicateMemory(
  candidateContent: string,
  projectId: string | null,
  existingMemories: Memory[],
  excludeId?: string,
): Memory | null {
  const norm = normalizeMemoryText(candidateContent);
  if (!norm) return null;
  for (const mem of existingMemories) {
    if (excludeId && mem.id === excludeId) continue;
    const sameScope = (mem.project_id ?? null) === (projectId ?? null);
    if (!sameScope) continue;
    if (normalizeMemoryText(mem.content) === norm) {
      return mem;
    }
  }
  return null;
}

const STOPWORDS = new Set([
  "the", "a", "an", "is", "are", "was", "were", "be", "to", "of", "and", "or", "in", "on", "for", "with",
  "that", "this", "my", "your", "our", "user", "prefers", "prefer", "always", "never", "use", "using", "like",
  "answers", "reply", "mode", "project", "fact", "should", "must", "will", "about", "from", "into",
]);

const OPPOSITE_PAIRS: Array<[RegExp, RegExp]> = [
  [/\bdark\b/, /\blight\b/],
  [/\bconcise\b|\bshort\b|\bbrief\b/, /\bdetailed\b|\blong\b|\bverbose\b/],
  [/\balways\b/, /\bnever\b/],
  [/\benable\b|\benabled\b|\bon\b/, /\bdisable\b|\bdisabled\b|\boff\b/],
  [/\bpython\b/, /\b(typescript|javascript|rust|go|java)\b/],
  [/\breact\b/, /\b(vue|angular|svelte)\b/],
  [/\bpostgres\b|\bpostgresql\b|\bsql\b/, /\bmongodb\b|\bsqlite\b/],
  [/\benglish\b/, /\b(hinglish|hindi|spanish|french)\b/],
  [/\btabs\b/, /\bspaces\b/],
];

function significantTokens(text: string): Set<string> {
  const words = normalizeMemoryText(text).match(/[a-z0-9_+#]+/g) ?? [];
  return new Set(words.filter((w) => w.length > 2 && !STOPWORDS.has(w)));
}

export function findConflictingMemories(
  newFact: string,
  projectId: string | null,
  existingMemories: Memory[],
  excludeId?: string,
): Memory | null {
  const newNorm = normalizeMemoryText(newFact);
  if (!newNorm) return null;
  const newTokens = significantTokens(newNorm);

  for (const mem of existingMemories) {
    if (!mem.enabled) continue;
    if (excludeId && mem.id === excludeId) continue;
    // Only check within matching scope (global or same project)
    const sameProjectScope = (mem.project_id ?? null) === (projectId ?? null);
    if (!sameProjectScope) continue;

    const oldNorm = normalizeMemoryText(mem.content);
    if (newNorm === oldNorm) continue;

    // 1. Direct opposite-value detection with shared context
    for (const [a, b] of OPPOSITE_PAIRS) {
      if ((a.test(newNorm) && b.test(oldNorm)) || (b.test(newNorm) && a.test(oldNorm))) {
        return mem;
      }
    }

    // 2. High token overlap with different phrasing/values (e.g. "My primary stack is React" vs "My primary stack is Vue")
    const oldTokens = significantTokens(oldNorm);
    if (newTokens.size >= 2 && oldTokens.size >= 2) {
      let common = 0;
      for (const w of newTokens) {
        if (oldTokens.has(w)) common += 1;
      }
      const unionSize = new Set([...newTokens, ...oldTokens]).size;
      const jaccard = unionSize > 0 ? common / unionSize : 0;
      if (common >= 2 && jaccard >= 0.4 && jaccard < 0.99) {
        return mem;
      }
    }
  }
  return null;
}

export function detectMemorySuggestions(
  userPrompt: string,
  _assistantResponse: string,
  projectId: string | null = null,
  existingMemories: Memory[] = [],
): MemorySuggestion[] {
  const cleanPrompt = userPrompt.trim();
  if (cleanPrompt.length < 8 || cleanPrompt.length > 500) return [];
  const lower = cleanPrompt.toLowerCase();
  const candidates: Array<{ content: string; category: MemoryCategory; confidence: number }> = [];

  // Prefer / style / language statements
  const prefMatch = cleanPrompt.match(/\b(?:i prefer|my preference is|i'd rather|i like|please always|always respond|always use)\s+([^.!?\n]{4,220})/i);
  if (prefMatch) {
    const body = prefMatch[0].trim().replace(/[.]+$/, "");
    candidates.push({
      content: body,
      category: lower.includes("always") || lower.includes("respond") ? "instruction" : "preference",
      confidence: 0.9,
    });
  }

  // Never / do not instruction statements
  const instrMatch = cleanPrompt.match(/\b(?:never|do not|don't)\s+(?:use|include|mention|add|write)\s+([^.!?\n]{4,180})/i);
  if (instrMatch) {
    candidates.push({
      content: instrMatch[0].trim().replace(/[.]+$/, ""),
      category: "instruction",
      confidence: 0.88,
    });
  }

  // Project / stack / tech context
  const projMatch = cleanPrompt.match(/\b(?:we are building|my project uses|our stack is|our backend is|i'm working on|this project is)\s+([^.!?\n]{4,220})/i);
  if (projMatch) {
    candidates.push({
      content: projMatch[0].trim().replace(/[.]+$/, ""),
      category: "project",
      confidence: 0.87,
    });
  }

  // Learning context
  const learnMatch = cleanPrompt.match(/\b(?:i am learning|i'm studying|i am a .*student|preparing for)\s+([^.!?\n]{4,200})/i);
  if (learnMatch) {
    candidates.push({
      content: learnMatch[0].trim().replace(/[.]+$/, ""),
      category: "learning",
      confidence: 0.85,
    });
  }

  // Personal facts
  const factMatch = cleanPrompt.match(/\b(?:my name is|i work as|i am based in|my timezone is|i live in)\s+([^.!?\n]{2,160})/i);
  if (factMatch) {
    candidates.push({
      content: factMatch[0].trim().replace(/[.]+$/, ""),
      category: "fact",
      confidence: 0.9,
    });
  }

  // Deduplicate within candidates and against existing scoped memories
  const seenNorm = new Set<string>();
  const suggestions: MemorySuggestion[] = [];
  for (const c of candidates) {
    const norm = normalizeMemoryText(c.content);
    if (!norm || seenNorm.has(norm)) continue;
    seenNorm.add(norm);

    const dup = isDuplicateMemory(c.content, projectId, existingMemories);
    if (dup) continue;

    const conflict = findConflictingMemories(c.content, projectId, existingMemories);
    suggestions.push({
      id: crypto.randomUUID().replace(/-/g, "").slice(0, 12),
      content: c.content.slice(0, 400),
      category: c.category,
      project_id: c.category === "project" ? projectId : null,
      confidence: c.confidence,
      conflict_with: conflict?.id ?? null,
      conflict_content: conflict?.content ?? null,
    });
  }

  return suggestions.slice(0, 3);
}

export function rankRelevantMemories(
  query: string,
  projectId: string | null,
  allMemories: Memory[],
  ftsMatches: Memory[],
  limit = 8,
): Memory[] {
  // Enforce strict project isolation: global memories + memories matching THIS project_id only
  const scoped = allMemories.filter(
    (m) => m.enabled === 1 && (m.project_id === null || (projectId !== null && m.project_id === projectId)),
  );
  if (scoped.length === 0) return [];

  const ftsRank = new Map<string, number>();
  ftsMatches.forEach((m, idx) => {
    ftsRank.set(m.id, Math.max(1, 10 - idx));
  });

  const qTokens = significantTokens(query);
  const scored = scoped.map((m) => {
    let score = 0;
    // FTS match score
    score += (ftsRank.get(m.id) ?? 0) * 3;
    // Token overlap score
    const mTokens = significantTokens(m.content);
    for (const t of qTokens) {
      if (mTokens.has(t)) score += 4;
    }
    // Same-project memories get higher priority inside that project
    if (projectId && m.project_id === projectId) score += 3.5;
    // Standing preferences & instructions remain useful across conversations
    if (m.category === "instruction") score += 2.5;
    if (m.category === "preference") score += 2.0;
    // Slight recency boost
    score += Math.min(1, m.updated_at / 1e10);
    return { mem: m, score };
  });

  // Sort by relevance score descending, then updated_at descending
  scored.sort((a, b) => b.score - a.score || b.mem.updated_at - a.mem.updated_at);

  // If query is specific and we have strong lexical/FTS hits, prioritize matching hits + standing instructions/preferences
  const hasLexicalHit = scored.some((x) => x.score >= 6);
  const selected = hasLexicalHit
    ? scored.filter((x) => x.score >= 2.0).slice(0, limit)
    : scored.slice(0, limit);

  return selected.map((x) => x.mem);
}

export async function summarizeMemoriesWithRouter(
  memories: Memory[],
  activeStore: { getRoutableModels: () => unknown[] },
  topic = "",
  signal?: AbortSignal,
): Promise<{ summary: string; model_name: string; provider_name: string }> {
  if (memories.length === 0) {
    return { summary: "No saved memories to summarize.", model_name: "", provider_name: "" };
  }
  const { modelRouter } = await import("../models/router");
  const lines = memories.slice(0, 40).map((m) => `- [${m.category}] ${m.content}`);
  const res = await modelRouter.generateText({
    activeStore: activeStore as never,
    mode: "fast",
    taskType: "general",
    systemPrompt: "Summarize the user's saved facts concisely into crisp bullet points grouped by theme. Never invent facts.",
    userPrompt: `${topic ? `Topic focus: ${topic}\n\n` : ""}Saved memories:\n${lines.join("\n")}`,
    signal,
  });
  return {
    summary: res.text,
    model_name: res.model_name,
    provider_name: res.provider_name,
  };
}

