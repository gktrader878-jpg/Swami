import { GoogleGenAI, ThinkingLevel } from "@google/genai";
import { redactSensitive } from "./security/secrets";
import { validateExternalUrl } from "./security/validation";
import type {
  ModelCapabilities,
  ProviderChatMessage,
  ProviderHealthStatus,
  ProviderModelConfig,
  ProviderProtocol,
  ResolvedProviderProtocol,
} from "./types";

export type ApiProtocol = ProviderProtocol;
export type ResolvedProtocol = ResolvedProviderProtocol;

export interface ProviderPreset {
  id: string;
  name: string;
  protocol: ResolvedProtocol;
  base_url: string;
  default_model: string;
  models: string[];
  key_placeholder: string;
  notes: string;
  is_local: boolean;
  core: boolean;
}

export const PROVIDER_PRESETS: ProviderPreset[] = [
  {
    id: "gemini",
    name: "Google Gemini",
    protocol: "gemini",
    base_url: "https://generativelanguage.googleapis.com/v1beta",
    default_model: "gemini-3.1-flash-lite",
    models: ["gemini-3.1-flash-lite", "gemini-4-hydrogen", "gemini-2.5-flash", "gemini-2.5-pro"],
    key_placeholder: "AIza... or AQ....",
    notes: "Official Google GenAI SDK supporting Gemini 3.1, Gemini 4 Hydrogen, thinking, vision, tools, and Search grounding.",
    is_local: false,
    core: true,
  },
  {
    id: "openai",
    name: "OpenAI",
    protocol: "openai",
    base_url: "https://api.openai.com/v1",
    default_model: "gpt-4.1-mini",
    models: ["gpt-4.1-mini", "gpt-4.1", "gpt-4o", "gpt-4o-mini", "o4-mini", "o3-mini"],
    key_placeholder: "sk-...",
    notes: "Supports GPT-4.1, GPT-4o, o3, o4-mini, and compatible OpenAI chat models.",
    is_local: false,
    core: true,
  },
  {
    id: "anthropic",
    name: "Anthropic Claude",
    protocol: "anthropic",
    base_url: "https://api.anthropic.com/v1",
    default_model: "claude-sonnet-4-5",
    models: ["claude-sonnet-4-5", "claude-3-7-sonnet-latest", "claude-3-5-haiku-latest", "claude-opus-4-1"],
    key_placeholder: "sk-ant-...",
    notes: "Native Anthropic Messages API (x-api-key) with Claude extended thinking and streaming.",
    is_local: false,
    core: true,
  },
  {
    id: "openrouter",
    name: "OpenRouter",
    protocol: "openai",
    base_url: "https://openrouter.ai/api/v1",
    default_model: "openai/gpt-4.1-mini",
    models: [
      "openai/gpt-4.1-mini",
      "anthropic/claude-sonnet-4",
      "google/gemini-2.5-flash",
      "deepseek/deepseek-chat-v3-0324",
      "meta-llama/llama-3.3-70b-instruct",
    ],
    key_placeholder: "sk-or-v1-...",
    notes: "Unified gateway for 300+ models with live capability discovery via /models.",
    is_local: false,
    core: true,
  },
  {
    id: "groq",
    name: "Groq",
    protocol: "openai",
    base_url: "https://api.groq.com/openai/v1",
    default_model: "llama-3.3-70b-versatile",
    models: ["llama-3.3-70b-versatile", "llama-3.1-8b-instant", "deepseek-r1-distill-llama-70b", "qwen-qwq-32b"],
    key_placeholder: "gsk_...",
    notes: "High-speed Groq LPU inference for Llama, Qwen, and DeepSeek models.",
    is_local: false,
    core: true,
  },
  {
    id: "deepseek",
    name: "DeepSeek",
    protocol: "openai",
    base_url: "https://api.deepseek.com/v1",
    default_model: "deepseek-chat",
    models: ["deepseek-chat", "deepseek-reasoner"],
    key_placeholder: "sk-...",
    notes: "Supports DeepSeek V3 (deepseek-chat) and DeepSeek R1 (deepseek-reasoner).",
    is_local: false,
    core: true,
  },
  {
    id: "xai",
    name: "xAI Grok",
    protocol: "openai",
    base_url: "https://api.x.ai/v1",
    default_model: "grok-3-mini",
    models: ["grok-3-mini", "grok-3", "grok-2-latest"],
    key_placeholder: "xai-...",
    notes: "Supports Grok 3, Grok 3 Mini reasoning, and Grok models.",
    is_local: false,
    core: true,
  },
  {
    id: "ollama",
    name: "Ollama (Local)",
    protocol: "openai",
    base_url: "http://127.0.0.1:11434/v1",
    default_model: "",
    models: [],
    key_placeholder: "No API key needed for local Ollama",
    notes: "Connects to local Ollama at http://127.0.0.1:11434. Models are discovered dynamically from your Ollama daemon.",
    is_local: true,
    core: true,
  },
  {
    id: "lmstudio",
    name: "LM Studio (Local)",
    protocol: "openai",
    base_url: "http://127.0.0.1:1234/v1",
    default_model: "",
    models: [],
    key_placeholder: "No API key needed for LM Studio",
    notes: "Connects to LM Studio local server at http://127.0.0.1:1234/v1. Models are discovered dynamically from LM Studio.",
    is_local: true,
    core: true,
  },
  {
    id: "custom",
    name: "Custom OpenAI-compatible",
    protocol: "openai",
    base_url: "",
    default_model: "",
    models: [],
    key_placeholder: "Paste API key (optional for local)",
    notes: "Any custom OpenAI-compatible, Anthropic-compatible, or Gemini-compatible endpoint URL.",
    is_local: false,
    core: true,
  },
  // Additional compatible presets for key auto-detection
  {
    id: "mistral",
    name: "Mistral AI",
    protocol: "openai",
    base_url: "https://api.mistral.ai/v1",
    default_model: "mistral-small-latest",
    models: ["mistral-small-latest", "mistral-large-latest", "codestral-latest"],
    key_placeholder: "Mistral API key",
    notes: "Mistral & Codestral models.",
    is_local: false,
    core: false,
  },
  {
    id: "together",
    name: "Together AI",
    protocol: "openai",
    base_url: "https://api.together.xyz/v1",
    default_model: "meta-llama/Llama-3.3-70B-Instruct-Turbo",
    models: ["meta-llama/Llama-3.3-70B-Instruct-Turbo", "Qwen/Qwen2.5-72B-Instruct-Turbo"],
    key_placeholder: "Together API key",
    notes: "Open-weight serverless models on Together AI.",
    is_local: false,
    core: false,
  },
  {
    id: "fireworks",
    name: "Fireworks AI",
    protocol: "openai",
    base_url: "https://api.fireworks.ai/inference/v1",
    default_model: "accounts/fireworks/models/llama-v3p3-70b-instruct",
    models: ["accounts/fireworks/models/llama-v3p3-70b-instruct"],
    key_placeholder: "fw_...",
    notes: "Open-weight inference on Fireworks.",
    is_local: false,
    core: false,
  },
  {
    id: "perplexity",
    name: "Perplexity",
    protocol: "openai",
    base_url: "https://api.perplexity.ai",
    default_model: "sonar",
    models: ["sonar", "sonar-pro", "sonar-reasoning-pro"],
    key_placeholder: "pplx-...",
    notes: "Search-grounded Sonar models from Perplexity.",
    is_local: false,
    core: false,
  },
  {
    id: "cerebras",
    name: "Cerebras",
    protocol: "openai",
    base_url: "https://api.cerebras.ai/v1",
    default_model: "llama-3.3-70b",
    models: ["llama-3.3-70b", "llama3.1-8b"],
    key_placeholder: "csk-...",
    notes: "High-speed Cerebras inference.",
    is_local: false,
    core: false,
  },
];

export const CORE_PROVIDER_PRESETS = PROVIDER_PRESETS.filter((p) => p.core);

export function normalizeApiBaseUrl(rawUrl: string): string {
  const trimmed = rawUrl.trim().replace(/\/+$/, "");
  return trimmed
    .replace(/\/chat\/completions$/i, "")
    .replace(/\/responses$/i, "")
    .replace(/\/messages$/i, "")
    .replace(/\/models$/i, "")
    .replace(/\/+$/, "");
}

export function isLocalApiHost(baseUrl: string): boolean {
  try {
    const parsed = new URL(baseUrl);
    return parsed.hostname === "localhost" || parsed.hostname === "127.0.0.1" || parsed.hostname === "::1";
  } catch {
    return false;
  }
}

export function isOllamaEndpoint(presetId: string, baseUrl: string): boolean {
  if (presetId === "ollama") return true;
  try {
    const parsed = new URL(baseUrl);
    return isLocalApiHost(baseUrl) && parsed.port === "11434";
  } catch {
    return false;
  }
}

export function ollamaRootUrl(baseUrl: string): string {
  return normalizeApiBaseUrl(baseUrl).replace(/\/v1$/i, "").replace(/\/+$/, "");
}

export function detectProviderFromKey(apiKey: string): ProviderPreset | null {
  const k = apiKey.trim();
  if (!k) return null;
  if (k.startsWith("sk-ant-")) return PROVIDER_PRESETS.find((p) => p.id === "anthropic") ?? null;
  if (k.startsWith("sk-or-")) return PROVIDER_PRESETS.find((p) => p.id === "openrouter") ?? null;
  if (k.startsWith("gsk_")) return PROVIDER_PRESETS.find((p) => p.id === "groq") ?? null;
  if (k.startsWith("xai-")) return PROVIDER_PRESETS.find((p) => p.id === "xai") ?? null;
  if (k.startsWith("pplx-")) return PROVIDER_PRESETS.find((p) => p.id === "perplexity") ?? null;
  if (k.startsWith("fw_")) return PROVIDER_PRESETS.find((p) => p.id === "fireworks") ?? null;
  if (k.startsWith("csk-")) return PROVIDER_PRESETS.find((p) => p.id === "cerebras") ?? null;
  if (k.startsWith("AIza") || k.startsWith("AQ.")) return PROVIDER_PRESETS.find((p) => p.id === "gemini") ?? null;
  if (k.startsWith("sk-")) return PROVIDER_PRESETS.find((p) => p.id === "openai") ?? null;
  return null;
}

export function inferProtocol(baseUrl: string, explicit?: ApiProtocol): ResolvedProtocol {
  if (explicit && explicit !== "auto") return explicit;
  const lower = baseUrl.toLowerCase();
  if (lower.includes("anthropic.com")) return "anthropic";
  if (lower.includes("generativelanguage.googleapis.com")) return "gemini";
  return "openai";
}

export function isReasoningOpenAIModel(model: string): boolean {
  const m = model.trim().toLowerCase();
  return /^(o1|o3|o4|gpt-5)([-_.\s]|$)/.test(m);
}

/**
 * Only claim vision, reasoning, tools, or structured_output when verified from
 * provider API metadata or well-known official model specifications.
 * Custom / unknown models default to verified: false so the UI & router never overpromise.
 */
export function inferVerifiedModelMetadata(
  providerId: string,
  modelId: string,
  rawMeta?: {
    displayName?: string;
    contextLength?: number;
    capabilities?: string[];
    inputModalities?: string[];
    supportedParameters?: string[];
    supportedGenerationMethods?: string[];
  },
): {
  name: string;
  capabilities: ModelCapabilities;
  tier: "fast" | "balanced" | "high";
  cost_tier: "free" | "low" | "medium" | "high";
} {
  const m = modelId.trim();
  const lower = m.toLowerCase();
  const p = providerId.toLowerCase();

  // 1. Live metadata supplied directly by Ollama /api/show
  if (rawMeta?.capabilities && rawMeta.capabilities.length > 0) {
    const caps = new Set(rawMeta.capabilities.map((c) => c.toLowerCase()));
    const isThinking = caps.has("thinking");
    return {
      name: rawMeta.displayName || m,
      capabilities: {
        vision: caps.has("vision"),
        reasoning: isThinking,
        tools: caps.has("tools"),
        structured_output: false,
        ...(rawMeta.contextLength ? { context_length: rawMeta.contextLength } : {}),
        verified: true,
        source: "ollama:/api/show",
      },
      tier: lower.includes("70b") || lower.includes("72b") || lower.includes("32b") || isThinking ? "high" : lower.includes("3b") || lower.includes("1b") ? "fast" : "balanced",
      cost_tier: "free",
    };
  }

  // 2. Live metadata supplied by OpenRouter /models
  if (rawMeta?.inputModalities || rawMeta?.supportedParameters) {
    const mods = new Set((rawMeta.inputModalities ?? []).map((x) => x.toLowerCase()));
    const sp = new Set((rawMeta.supportedParameters ?? []).map((x) => x.toLowerCase()));
    const reasoning = sp.has("reasoning") || sp.has("include_reasoning");
    return {
      name: rawMeta.displayName || m,
      capabilities: {
        vision: mods.has("image"),
        reasoning,
        tools: sp.has("tools"),
        structured_output: sp.has("structured_outputs") || sp.has("response_format"),
        ...(rawMeta.contextLength ? { context_length: rawMeta.contextLength } : {}),
        verified: true,
        source: "openrouter:/models",
      },
      tier: lower.includes("mini") || lower.includes("flash") || lower.includes("haiku") || lower.includes("8b")
        ? "fast"
        : lower.includes("opus") || lower.includes("pro") || lower.includes("r1") || lower.includes("o3")
          ? "high"
          : "balanced",
      cost_tier: lower.includes(":free") ? "free" : lower.includes("mini") || lower.includes("flash") ? "low" : lower.includes("opus") ? "high" : "medium",
    };
  }

  // 3. Official Google Gemini models
  if (p === "gemini" || lower.startsWith("gemini-")) {
    const isLite = lower.includes("flash-lite") || lower.includes("8b");
    const isPro = lower.includes("pro") || lower.includes("hydrogen");
    const hasGeminiSpecs =
      lower.startsWith("gemini-2.5") ||
      lower.startsWith("gemini-3") ||
      lower.startsWith("gemini-4");
    return {
      name:
        rawMeta?.displayName ||
        (m === "gemini-3.1-flash-lite"
          ? "Gemini 3.1 Flash Lite"
          : m === "gemini-4-hydrogen"
            ? "Gemini 4 Hydrogen"
            : m),
      capabilities: {
        vision: hasGeminiSpecs,
        reasoning: hasGeminiSpecs,
        tools: hasGeminiSpecs,
        structured_output: hasGeminiSpecs,
        context_length: rawMeta?.contextLength ?? (hasGeminiSpecs ? 1_000_000 : undefined),
        verified: hasGeminiSpecs || Boolean(rawMeta?.supportedGenerationMethods?.length),
        source: rawMeta?.supportedGenerationMethods?.length ? "gemini:/v1beta/models" : hasGeminiSpecs ? "gemini-spec" : undefined,
      },
      tier: isLite ? "fast" : isPro ? "high" : "balanced",
      cost_tier: isLite ? "low" : lower.includes("pro") ? "high" : "low",
    };
  }

  // 4. Official OpenAI models
  if (p === "openai") {
    if (/^(gpt-4o|gpt-4\.1)/.test(lower)) {
      const isMini = lower.includes("mini") || lower.includes("nano");
      return {
        name: m,
        capabilities: {
          vision: true,
          reasoning: false,
          tools: true,
          structured_output: true,
          context_length: lower.startsWith("gpt-4.1") ? 1_047_576 : 128_000,
          verified: true,
          source: "openai-spec",
        },
        tier: isMini ? "fast" : "high",
        cost_tier: isMini ? "low" : "medium",
      };
    }
    if (/^(o3|o4-mini)/.test(lower)) {
      return {
        name: m,
        capabilities: {
          vision: lower.startsWith("o4-mini") || lower === "o3",
          reasoning: true,
          tools: true,
          structured_output: true,
          context_length: 200_000,
          verified: true,
          source: "openai-spec",
        },
        tier: "high",
        cost_tier: lower.includes("mini") ? "medium" : "high",
      };
    }
  }

  // 5. Official Anthropic Claude models
  if (p === "anthropic" && /^claude-(3-5|3-7|sonnet-4|opus-4|haiku-4)/.test(lower)) {
    const isHaiku = lower.includes("haiku");
    const isThinking = lower.includes("3-7") || lower.includes("4");
    return {
      name: m,
      capabilities: {
        vision: true,
        reasoning: isThinking,
        tools: true,
        structured_output: false,
        context_length: 200_000,
        verified: true,
        source: "anthropic-spec",
      },
      tier: isHaiku ? "fast" : "high",
      cost_tier: isHaiku ? "low" : lower.includes("opus") ? "high" : "medium",
    };
  }

  // 6. Official DeepSeek models
  if (p === "deepseek" && (lower === "deepseek-chat" || lower === "deepseek-reasoner")) {
    const isReasoner = lower === "deepseek-reasoner";
    return {
      name: m,
      capabilities: {
        vision: false,
        reasoning: isReasoner,
        tools: !isReasoner,
        structured_output: !isReasoner,
        context_length: 64_000,
        verified: true,
        source: "deepseek-spec",
      },
      tier: isReasoner ? "high" : "balanced",
      cost_tier: "low",
    };
  }

  // 7. Official Groq / xAI known models
  if (p === "groq") {
    if (lower === "llama-3.1-8b-instant") {
      return {
        name: m,
        capabilities: { vision: false, reasoning: false, tools: true, structured_output: true, context_length: 131_072, verified: true, source: "groq-spec" },
        tier: "fast",
        cost_tier: "low",
      };
    }
    if (lower === "llama-3.3-70b-versatile") {
      return {
        name: m,
        capabilities: { vision: false, reasoning: false, tools: true, structured_output: true, context_length: 131_072, verified: true, source: "groq-spec" },
        tier: "balanced",
        cost_tier: "low",
      };
    }
    if (lower === "deepseek-r1-distill-llama-70b" || lower === "qwen-qwq-32b") {
      return {
        name: m,
        capabilities: { vision: false, reasoning: true, tools: false, structured_output: false, context_length: 128_000, verified: true, source: "groq-spec" },
        tier: "high",
        cost_tier: "low",
      };
    }
  }

  if (p === "xai" && (lower.startsWith("grok-2-vision") || lower.startsWith("grok-4"))) {
    return {
      name: m,
      capabilities: {
        vision: true,
        reasoning: lower.startsWith("grok-4"),
        tools: true,
        structured_output: true,
        context_length: 131_072,
        verified: true,
        source: "xai-spec",
      },
      tier: "high",
      cost_tier: "medium",
    };
  }

  if (p === "xai" && lower.startsWith("grok-3")) {
    return {
      name: m,
      capabilities: {
        vision: false,
        reasoning: lower.includes("mini"),
        tools: true,
        structured_output: true,
        context_length: 131_072,
        verified: true,
        source: "xai-spec",
      },
      tier: lower.includes("mini") ? "fast" : "high",
      cost_tier: lower.includes("mini") ? "low" : "medium",
    };
  }

  // 8. Local / OpenAI-compatible well-known vision models (Ollama / LM Studio)
  if (
    (p === "ollama" || p === "lmstudio" || p === "groq") &&
    /\b(llava|bakllava|moondream|minicpm-v|pixtral|llama-?3\.2.*vision|llama-?4.*scout|qwen2\.?5?-?vl|qwen3-?vl|internvl)\b/i.test(
      lower,
    )
  ) {
    return {
      name: rawMeta?.displayName || m,
      capabilities: {
        vision: true,
        reasoning: false,
        tools: p === "groq",
        structured_output: false,
        ...(rawMeta?.contextLength ? { context_length: rawMeta.contextLength } : {}),
        verified: true,
        source: p === "groq" ? "groq-spec" : "local-vision-spec",
      },
      tier: lower.includes("mini") || lower.includes("11b") || lower.includes("3b") ? "fast" : "balanced",
      cost_tier: p === "groq" ? "low" : "free",
    };
  }

  // 9. Unknown / Custom / LM Studio unverified model: NEVER fabricate capabilities!
  const localCost = p === "ollama" || p === "lmstudio" ? "free" : "medium";
  return {
    name: rawMeta?.displayName || m,
    capabilities: {
      vision: false,
      reasoning: false,
      tools: false,
      structured_output: false,
      ...(rawMeta?.contextLength ? { context_length: rawMeta.contextLength } : {}),
      verified: false,
    },
    tier: lower.includes("mini") || lower.includes("flash") || lower.includes("3b") || lower.includes("1b")
      ? "fast"
      : lower.includes("opus") || lower.includes("70b") || lower.includes("reason")
        ? "high"
        : "balanced",
    cost_tier: localCost,
  };
}

export function buildPresetDefaultModels(preset: ProviderPreset): ProviderModelConfig[] {
  return preset.models.map((id) => {
    const inferred = inferVerifiedModelMetadata(preset.id, id);
    return {
      id,
      name: inferred.name,
      enabled: true,
      custom: false,
      capabilities: inferred.capabilities,
      tier: inferred.tier,
      cost_tier: inferred.cost_tier,
    };
  });
}

export function buildOpenAIChatPayload(params: {
  model: string;
  messages: Array<{ role: string; content: unknown }>;
  temperature: number | null;
  topP?: number | null;
  maxTokens: number;
  stream: boolean;
  includeUsage?: boolean;
}): Record<string, unknown> {
  const { model, messages, temperature, topP, maxTokens, stream, includeUsage } = params;
  const reasoningModel = isReasoningOpenAIModel(model);
  const payload: Record<string, unknown> = {
    model,
    messages,
    stream,
  };
  if (reasoningModel) {
    payload.max_completion_tokens = maxTokens || 4096;
  } else {
    payload.temperature = temperature ?? 0.7;
    if (topP != null) payload.top_p = topP;
    payload.max_tokens = maxTokens || 4096;
  }
  if (stream && includeUsage) {
    payload.stream_options = { include_usage: true };
  }
  return payload;
}

function buildProviderHeaders(protocol: ResolvedProtocol, apiKey: string, baseUrl: string): Record<string, string> {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (protocol === "anthropic") {
    if (apiKey) headers["x-api-key"] = apiKey;
    headers["anthropic-version"] = "2023-06-01";
    return headers;
  }
  if (apiKey) {
    headers.Authorization = `Bearer ${apiKey}`;
  }
  if (baseUrl.toLowerCase().includes("openrouter.ai")) {
    headers["X-Title"] = "SWAMI";
  }
  return headers;
}

function combineSignals(userSignal?: AbortSignal, timeoutMs?: number): { signal: AbortSignal; cleanup: () => void } {
  const controller = new AbortController();
  let timer: ReturnType<typeof setTimeout> | undefined;
  let timedOut = false;

  const onUserAbort = () => {
    controller.abort(userSignal?.reason ?? new DOMException("Aborted", "AbortError"));
  };
  if (userSignal) {
    if (userSignal.aborted) {
      onUserAbort();
    } else {
      userSignal.addEventListener("abort", onUserAbort, { once: true });
    }
  }
  if (timeoutMs && timeoutMs > 0) {
    timer = setTimeout(() => {
      timedOut = true;
      controller.abort(new Error(`Request timed out after ${Math.round(timeoutMs / 1000)}s.`));
    }, timeoutMs);
  }
  const cleanup = () => {
    if (timer) clearTimeout(timer);
    if (userSignal) userSignal.removeEventListener("abort", onUserAbort);
    void timedOut;
  };
  return { signal: controller.signal, cleanup };
}

export async function discoverProviderModels(params: {
  providerId: string;
  presetId?: string;
  baseUrl: string;
  apiKey: string;
  protocol?: ApiProtocol;
  timeoutMs?: number;
}): Promise<{
  models: ProviderModelConfig[];
  reachable: boolean;
  latencyMs: number;
  message: string;
}> {
  const base = normalizeApiBaseUrl(params.baseUrl);
  validateExternalUrl(base, { allowLocalhost: true, requireHttpsForRemote: true });
  const proto = inferProtocol(base, params.protocol);
  const presetKey = params.presetId || params.providerId;
  const started = performance.now();
  const timeoutMs = params.timeoutMs ?? 12000;

  // 1. Ollama native discovery (/api/tags + /api/show capabilities)
  if (isOllamaEndpoint(presetKey, base)) {
    const root = ollamaRootUrl(base);
    const resp = await fetch(`${root}/api/tags`, { signal: AbortSignal.timeout(timeoutMs) });
    if (!resp.ok) {
      const txt = await resp.text().catch(() => "");
      throw new Error(`Ollama returned HTTP ${resp.status}: ${redactSensitive(txt.slice(0, 180))}`);
    }
    const data = (await resp.json()) as {
      models?: Array<{ name?: string; model?: string; details?: { parameter_size?: string; quantization_level?: string } }>;
    };
    const rawNames = (data.models ?? []).map((m) => m.name || m.model || "").filter(Boolean);
    const models: ProviderModelConfig[] = [];

    for (const name of rawNames.slice(0, 40)) {
      let caps: string[] | undefined;
      let contextLen: number | undefined;
      try {
        const showResp = await fetch(`${root}/api/show`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ model: name }),
          signal: AbortSignal.timeout(3000),
        });
        if (showResp.ok) {
          const showData = (await showResp.json()) as {
            capabilities?: string[];
            model_info?: Record<string, unknown>;
          };
          if (Array.isArray(showData.capabilities)) {
            caps = showData.capabilities;
          }
          if (showData.model_info && typeof showData.model_info === "object") {
            for (const [k, v] of Object.entries(showData.model_info)) {
              if (k.endsWith(".context_length") && typeof v === "number") {
                contextLen = v;
                break;
              }
            }
          }
        }
      } catch {
        // Optional /api/show capability probe failed; keep verified=false
      }
      const inferred = inferVerifiedModelMetadata("ollama", name, {
        capabilities: caps,
        contextLength: contextLen,
      });
      models.push({
        id: name,
        name: inferred.name,
        enabled: true,
        custom: false,
        capabilities: inferred.capabilities,
        tier: inferred.tier,
        cost_tier: "free",
      });
    }

    const latencyMs = Math.round(performance.now() - started);
    return {
      models,
      reachable: true,
      latencyMs,
      message:
        models.length > 0
          ? `Connected to Ollama (${models.length} installed model(s) found).`
          : "Connected to Ollama, but no models are installed yet (run `ollama pull <model>`).",
    };
  }

  // 2. Google Gemini discovery
  if (proto === "gemini") {
    const resp = await fetch(
      `${base.replace(/\/openai$/i, "")}/models?key=${encodeURIComponent(params.apiKey)}`,
      { signal: AbortSignal.timeout(timeoutMs) },
    );
    if (!resp.ok) {
      const txt = await resp.text().catch(() => "");
      throw new Error(`Gemini API returned HTTP ${resp.status}: ${redactSensitive(txt.slice(0, 200))}`);
    }
    const data = (await resp.json()) as {
      models?: Array<{
        name?: string;
        displayName?: string;
        inputTokenLimit?: number;
        supportedGenerationMethods?: string[];
      }>;
    };
    const latencyMs = Math.round(performance.now() - started);
    const models: ProviderModelConfig[] = (data.models ?? [])
      .filter((m) => {
        const id = (m.name ?? "").replace(/^models\//, "");
        return id && !id.includes("embedding") && (m.supportedGenerationMethods?.includes("generateContent") ?? true);
      })
      .map((m) => {
        const id = (m.name ?? "").replace(/^models\//, "");
        const inferred = inferVerifiedModelMetadata("gemini", id, {
          displayName: m.displayName,
          contextLength: m.inputTokenLimit,
          supportedGenerationMethods: m.supportedGenerationMethods,
        });
        return {
          id,
          name: inferred.name,
          enabled: true,
          custom: false,
          capabilities: inferred.capabilities,
          tier: inferred.tier,
          cost_tier: inferred.cost_tier,
        };
      });
    return {
      models,
      reachable: true,
      latencyMs,
      message: `Connected to Google Gemini (${models.length} model(s) discovered).`,
    };
  }

  // 3. Anthropic Messages API (doesn't always guarantee /v1/models on older keys, try /models then fallback cleanly)
  const headers = buildProviderHeaders(proto, params.apiKey, base);
  const resp = await fetch(`${base}/models`, {
    headers,
    signal: AbortSignal.timeout(timeoutMs),
  });
  if (!resp.ok) {
    const txt = await resp.text().catch(() => "");
    throw new Error(`Provider returned HTTP ${resp.status}: ${redactSensitive(txt.slice(0, 200))}`);
  }
  const latencyMs = Math.round(performance.now() - started);
  const body = (await resp.json()) as {
    data?: Array<{
      id?: string;
      name?: string;
      display_name?: string;
      context_length?: number;
      architecture?: { input_modalities?: string[] };
      supported_parameters?: string[];
    }>;
    models?: Array<{ id?: string; name?: string }>;
  };

  const rawItems = body.data ?? body.models ?? [];
  const models: ProviderModelConfig[] = rawItems
    .map((item): ProviderModelConfig | null => {
      const id = item.id || item.name || "";
      if (!id) return null;
      const openRouterItem = item as {
        name?: string;
        display_name?: string;
        context_length?: number;
        architecture?: { input_modalities?: string[] };
        supported_parameters?: string[];
      };
      const inferred = inferVerifiedModelMetadata(presetKey, id, {
        displayName: openRouterItem.display_name || openRouterItem.name,
        contextLength: openRouterItem.context_length,
        inputModalities: openRouterItem.architecture?.input_modalities,
        supportedParameters: openRouterItem.supported_parameters,
      });
      return {
        id,
        name: inferred.name,
        enabled: true,
        custom: false,
        capabilities: inferred.capabilities,
        tier: inferred.tier,
        cost_tier: inferred.cost_tier,
      };
    })
    .filter((x): x is ProviderModelConfig => x !== null)
    .sort((a, b) => a.id.localeCompare(b.id));

  return {
    models,
    reachable: true,
    latencyMs,
    message:
      models.length > 0
        ? `Connected! Discovered ${models.length} model(s).`
        : "Connected, endpoint returned an empty model list.",
  };
}

export async function fetchProviderModels(params: {
  baseUrl: string;
  apiKey: string;
  protocol?: ApiProtocol;
  presetId?: string;
}): Promise<string[]> {
  const res = await discoverProviderModels({
    providerId: params.presetId || "custom",
    presetId: params.presetId,
    baseUrl: params.baseUrl,
    apiKey: params.apiKey,
    protocol: params.protocol,
  });
  return res.models.map((m) => m.id);
}

export async function probeProviderHealth(params: {
  providerId: string;
  presetId?: string;
  baseUrl: string;
  apiKey: string;
  model?: string;
  protocol?: ApiProtocol;
  timeoutMs?: number;
}): Promise<{
  ok: boolean;
  status: ProviderHealthStatus;
  latencyMs: number;
  message: string;
  models?: ProviderModelConfig[];
}> {
  const base = normalizeApiBaseUrl(params.baseUrl);
  validateExternalUrl(base, { allowLocalhost: true, requireHttpsForRemote: true });
  const proto = inferProtocol(base, params.protocol);
  const presetKey = params.presetId || params.providerId;
  const model = (params.model || "").trim();
  const started = performance.now();
  const timeoutMs = params.timeoutMs ?? 12000;

  if (!params.apiKey && !isLocalApiHost(base)) {
    return {
      ok: false,
      status: "unconfigured",
      latencyMs: 0,
      message: "API key is not configured.",
    };
  }

  try {
    if (proto === "gemini") {
      const ai = new GoogleGenAI({
        apiKey: params.apiKey,
        httpOptions: { headers: { "User-Agent": "aistudio-build" } },
      });
      const targetModel = model || "gemini-3.1-flash-lite";
      await ai.models.generateContent({
        model: targetModel,
        contents: "Reply with OK.",
        config: { abortSignal: AbortSignal.timeout(timeoutMs) },
      });
      let discovered: ProviderModelConfig[] | undefined;
      try {
        const res = await discoverProviderModels({
          providerId: params.providerId,
          presetId: presetKey,
          baseUrl: base,
          apiKey: params.apiKey,
          protocol: proto,
          timeoutMs: 6000,
        });
        discovered = res.models;
      } catch {
        /* discovery optional during health probe */
      }
      return {
        ok: true,
        status: "healthy",
        latencyMs: Math.round(performance.now() - started),
        message: `Connected to Google Gemini (${targetModel}).`,
        ...(discovered ? { models: discovered } : {}),
      };
    }

    try {
      const discovered = await discoverProviderModels({
        providerId: params.providerId,
        presetId: presetKey,
        baseUrl: base,
        apiKey: params.apiKey,
        protocol: proto,
        timeoutMs,
      });
      return {
        ok: true,
        status: "healthy",
        latencyMs: discovered.latencyMs,
        message: discovered.message,
        models: discovered.models,
      };
    } catch (discoverErr) {
      if (!model) {
        throw discoverErr;
      }
      const headers = buildProviderHeaders(proto, params.apiKey, base);
      if (proto === "anthropic") {
        const resp = await fetch(`${base}/messages`, {
          method: "POST",
          headers,
          body: JSON.stringify({
            model,
            max_tokens: 16,
            messages: [{ role: "user", content: "Reply OK" }],
          }),
          signal: AbortSignal.timeout(timeoutMs),
        });
        if (!resp.ok) {
          const txt = await resp.text().catch(() => "");
          throw new Error(`Provider returned HTTP ${resp.status}: ${redactSensitive(txt.slice(0, 220))}`);
        }
        return {
          ok: true,
          status: "healthy",
          latencyMs: Math.round(performance.now() - started),
          message: `Connected to Anthropic (${model}).`,
        };
      }

      const resp = await fetch(`${base}/chat/completions`, {
        method: "POST",
        headers,
        body: JSON.stringify(
          buildOpenAIChatPayload({
            model,
            messages: [{ role: "user", content: "Reply OK" }],
            temperature: null,
            maxTokens: 16,
            stream: false,
          }),
        ),
        signal: AbortSignal.timeout(timeoutMs),
      });
      if (!resp.ok) {
        const txt = await resp.text().catch(() => "");
        throw new Error(`Provider returned HTTP ${resp.status}: ${redactSensitive(txt.slice(0, 220))}`);
      }
      return {
        ok: true,
        status: "healthy",
        latencyMs: Math.round(performance.now() - started),
        message: `Connected to ${model}.`,
      };
    }
  } catch (err) {
    const rawMsg = redactSensitive(err instanceof Error ? err.message : "Network error");
    const unreachable =
      /ECONNREFUSED|ENOTFOUND|ETIMEDOUT|fetch failed|timed out/i.test(rawMsg);
    return {
      ok: false,
      status: unreachable ? "unreachable" : "unhealthy",
      latencyMs: Math.round(performance.now() - started),
      message: rawMsg,
    };
  }
}

export async function testProviderConnection(params: {
  baseUrl: string;
  apiKey: string;
  model: string;
  protocol?: ApiProtocol;
  presetId?: string;
}): Promise<{ ok: true; message: string; models?: string[]; latencyMs: number }> {
  const probe = await probeProviderHealth({
    providerId: params.presetId || "custom",
    presetId: params.presetId,
    baseUrl: params.baseUrl,
    apiKey: params.apiKey,
    model: params.model,
    protocol: params.protocol,
  });
  if (!probe.ok) {
    throw new Error(probe.message);
  }
  return {
    ok: true,
    message: probe.message,
    latencyMs: probe.latencyMs,
    ...(probe.models ? { models: probe.models.map((m) => m.id) } : {}),
  };
}

export interface StreamProviderResult {
  text: string;
  reasoning: string;
  promptTokens?: number;
  completionTokens?: number;
  totalTokens?: number;
  tokensEstimated: boolean;
  firstTokenMs: number | null;
  totalMs: number;
}

export async function streamFromProvider(params: {
  baseUrl: string;
  model: string;
  apiKey: string;
  protocol?: ApiProtocol;
  systemPrompt: string;
  messages: ProviderChatMessage[];
  temperature: number | null;
  topP?: number | null;
  maxTokens: number;
  timeoutMs?: number;
  onToken: (text: string) => void;
  onReasoning: (text: string) => void;
  signal: AbortSignal;
}): Promise<StreamProviderResult> {
  const started = performance.now();
  let firstTokenMs: number | null = null;
  const markFirst = () => {
    if (firstTokenMs === null) {
      firstTokenMs = Math.max(1, Math.round(performance.now() - started));
    }
  };

  const base = normalizeApiBaseUrl(params.baseUrl);
  validateExternalUrl(base, { allowLocalhost: true, requireHttpsForRemote: true });
  const proto = inferProtocol(base, params.protocol);

  const { signal, cleanup } = combineSignals(params.signal, params.timeoutMs);

  try {
    if (proto === "gemini") {
      const ai = new GoogleGenAI({
        apiKey: params.apiKey,
        httpOptions: { headers: { "User-Agent": "aistudio-build" } },
      });
      const contents = params.messages.map((m) => {
        const parts: Array<{ text: string } | { inlineData: { mimeType: string; data: string } }> = [];
        for (const img of m.images ?? []) {
          parts.push({
            inlineData: {
              mimeType: img.mimeType,
              data: img.base64,
            },
          });
        }
        parts.push({ text: m.content || (m.images?.length ? "Analyze the attached image(s)." : "") });
        return {
          role: m.role === "assistant" ? ("model" as const) : ("user" as const),
          parts,
        };
      });
      const isGemini4 = params.model.startsWith("gemini-4-");
      const stream = await ai.models.generateContentStream({
        model: params.model,
        contents,
        config: {
          systemInstruction: params.systemPrompt,
          ...(isGemini4
            ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } }
            : params.model.startsWith("gemini-3.1-flash-lite")
              ? { thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL } }
              : {}),
          ...(!isGemini4 && params.temperature != null ? { temperature: params.temperature } : {}),
          ...(!isGemini4 && params.topP != null ? { topP: params.topP } : {}),
          ...(params.maxTokens ? { maxOutputTokens: params.maxTokens } : {}),
          abortSignal: signal,
        },
      });
      let fullText = "";
      let fullReasoning = "";
      let promptTokens: number | undefined;
      let completionTokens: number | undefined;
      let totalTokens: number | undefined;

      for await (const chunk of stream) {
        if (signal.aborted) {
          throw signal.reason instanceof Error ? signal.reason : new DOMException("Aborted", "AbortError");
        }
        const usage = chunk.usageMetadata;
        if (usage) {
          if (typeof usage.promptTokenCount === "number") promptTokens = usage.promptTokenCount;
          if (typeof usage.candidatesTokenCount === "number") completionTokens = usage.candidatesTokenCount;
          if (typeof usage.totalTokenCount === "number") totalTokens = usage.totalTokenCount;
        }
        const parts = chunk.candidates?.[0]?.content?.parts ?? [];
        for (const p of parts) {
          if (p.thought && p.text) {
            markFirst();
            fullReasoning += p.text;
            params.onReasoning(p.text);
          } else if (p.text) {
            markFirst();
            fullText += p.text;
            params.onToken(p.text);
          }
        }
      }
      const totalMs = Math.max(1, Math.round(performance.now() - started));
      return {
        text: fullText,
        reasoning: fullReasoning,
        promptTokens,
        completionTokens,
        totalTokens,
        tokensEstimated: promptTokens === undefined || completionTokens === undefined,
        firstTokenMs,
        totalMs,
      };
    }

    const headers = buildProviderHeaders(proto, params.apiKey, base);

    if (proto === "anthropic") {
      const anthropicMessages = params.messages.map((m) => {
        if (!m.images || m.images.length === 0) {
          return { role: m.role, content: m.content };
        }
        const imageBlocks = m.images
          .filter((img) => img.mimeType !== "application/pdf")
          .map((img) => ({
            type: "image" as const,
            source: {
              type: "base64" as const,
              media_type: img.mimeType,
              data: img.base64,
            },
          }));
        const docBlocks = m.images
          .filter((img) => img.mimeType === "application/pdf")
          .map((img) => ({
            type: "document" as const,
            source: {
              type: "base64" as const,
              media_type: "application/pdf",
              data: img.base64,
            },
          }));
        return {
          role: m.role,
          content: [
            ...docBlocks,
            ...imageBlocks,
            { type: "text" as const, text: m.content || "Analyze the attached image(s)." },
          ],
        };
      });
      const resp = await fetch(`${base}/messages`, {
        method: "POST",
        headers,
        body: JSON.stringify({
          model: params.model,
          system: params.systemPrompt,
          messages: anthropicMessages,
          max_tokens: params.maxTokens || 4096,
          stream: true,
          ...(params.temperature != null ? { temperature: params.temperature } : {}),
          ...(params.topP != null ? { top_p: params.topP } : {}),
        }),
        signal,
      });
      if (!resp.ok || !resp.body) {
        const errText = await resp.text().catch(() => "");
        throw new Error(`Anthropic API error ${resp.status}: ${redactSensitive(errText.slice(0, 280))}`);
      }
      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let fullText = "";
      let fullReasoning = "";
      let promptTokens: number | undefined;
      let completionTokens: number | undefined;

      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        let idx: number;
        while ((idx = buffer.indexOf("\n")) >= 0) {
          const line = buffer.slice(0, idx).trim();
          buffer = buffer.slice(idx + 1);
          if (!line.startsWith("data:")) continue;
          const data = line.slice(5).trim();
          if (!data || data === "[DONE]") continue;
          try {
            const ev = JSON.parse(data) as {
              type?: string;
              message?: { usage?: { input_tokens?: number; output_tokens?: number } };
              usage?: { output_tokens?: number; input_tokens?: number };
              delta?: { type?: string; text?: string; thinking?: string };
              error?: { message?: string };
            };
            if (ev.type === "error" && ev.error?.message) {
              throw new Error(ev.error.message);
            }
            if (ev.type === "message_start" && ev.message?.usage) {
              if (typeof ev.message.usage.input_tokens === "number") promptTokens = ev.message.usage.input_tokens;
              if (typeof ev.message.usage.output_tokens === "number") completionTokens = ev.message.usage.output_tokens;
            }
            if (ev.type === "message_delta" && ev.usage) {
              if (typeof ev.usage.output_tokens === "number") completionTokens = ev.usage.output_tokens;
            }
            if (ev.type === "content_block_delta" && ev.delta) {
              if (ev.delta.type === "thinking_delta" && ev.delta.thinking) {
                markFirst();
                fullReasoning += ev.delta.thinking;
                params.onReasoning(ev.delta.thinking);
              } else if (ev.delta.type === "text_delta" && ev.delta.text) {
                markFirst();
                fullText += ev.delta.text;
                params.onToken(ev.delta.text);
              }
            }
          } catch (err) {
            if (err instanceof Error && !err.message.includes("JSON")) throw err;
          }
        }
      }
      const totalMs = Math.max(1, Math.round(performance.now() - started));
      return {
        text: fullText,
        reasoning: fullReasoning,
        promptTokens,
        completionTokens,
        totalTokens: promptTokens != null && completionTokens != null ? promptTokens + completionTokens : undefined,
        tokensEstimated: promptTokens === undefined || completionTokens === undefined,
        firstTokenMs,
        totalMs,
      };
    }

    // OpenAI & OpenAI-compatible (OpenAI, OpenRouter, Groq, DeepSeek, xAI, Ollama, LM Studio, Custom)
    const serializedMessages: Array<{ role: string; content: unknown }> = [
      { role: "system", content: params.systemPrompt },
      ...params.messages.map((m) => {
        const imgs = (m.images ?? []).filter((img) => img.mimeType !== "application/pdf");
        if (imgs.length === 0) {
          return { role: m.role, content: m.content };
        }
        return {
          role: m.role,
          content: [
            { type: "text", text: m.content || "Analyze the attached image(s)." },
            ...imgs.map((img) => ({
              type: "image_url",
              image_url: {
                url: `data:${img.mimeType};base64,${img.base64}`,
              },
            })),
          ],
        };
      }),
    ];
    const sendChat = (includeUsage: boolean) =>
      fetch(`${base}/chat/completions`, {
        method: "POST",
        headers,
        body: JSON.stringify(
          buildOpenAIChatPayload({
            model: params.model,
            messages: serializedMessages,
            temperature: params.temperature,
            topP: params.topP,
            maxTokens: params.maxTokens,
            stream: true,
            includeUsage,
          }),
        ),
        signal,
      });

    let resp = await sendChat(true);
    // Some strict OpenAI-compatible gateways reject `stream_options`; retry once cleanly without it
    if (resp.status === 400) {
      const errBody = await resp.text().catch(() => "");
      if (/stream_options|unknown field/i.test(errBody)) {
        resp = await sendChat(false);
      } else {
        throw new Error(`API error 400: ${redactSensitive(errBody.slice(0, 280))}`);
      }
    }

    if (!resp.ok || !resp.body) {
      const errText = await resp.text().catch(() => "");
      throw new Error(`API error ${resp.status}: ${redactSensitive(errText.slice(0, 280))}`);
    }

    const contentType = resp.headers.get("content-type") || "";
    if (contentType.includes("application/json")) {
      const body = (await resp.json()) as {
        choices?: Array<{ message?: { content?: string; reasoning_content?: string } }>;
        usage?: { prompt_tokens?: number; completion_tokens?: number; total_tokens?: number };
        error?: { message?: string };
      };
      if (body.error?.message) throw new Error(body.error.message);
      const msg = body.choices?.[0]?.message;
      let fullReasoning = "";
      if (msg?.reasoning_content) {
        markFirst();
        fullReasoning = msg.reasoning_content;
        params.onReasoning(msg.reasoning_content);
      }
      const text = msg?.content ?? "";
      if (text) {
        markFirst();
        params.onToken(text);
      }
      const totalMs = Math.max(1, Math.round(performance.now() - started));
      return {
        text,
        reasoning: fullReasoning,
        promptTokens: body.usage?.prompt_tokens,
        completionTokens: body.usage?.completion_tokens,
        totalTokens: body.usage?.total_tokens,
        tokensEstimated: body.usage?.prompt_tokens === undefined || body.usage?.completion_tokens === undefined,
        firstTokenMs,
        totalMs,
      };
    }

    const reader = resp.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let fullText = "";
    let fullReasoning = "";
    let promptTokens: number | undefined;
    let completionTokens: number | undefined;
    let totalTokens: number | undefined;

    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let idx: number;
      while ((idx = buffer.indexOf("\n")) >= 0) {
        const line = buffer.slice(0, idx).trim();
        buffer = buffer.slice(idx + 1);
        if (!line.startsWith("data:")) continue;
        const data = line.slice(5).trim();
        if (data === "[DONE]") break;
        try {
          const obj = JSON.parse(data) as {
            error?: { message?: string };
            usage?: { prompt_tokens?: number; completion_tokens?: number; total_tokens?: number };
            choices?: Array<{ delta?: { content?: string; reasoning_content?: string; reasoning?: string } }>;
          };
          if (obj.error?.message) {
            throw new Error(obj.error.message);
          }
          if (obj.usage) {
            if (typeof obj.usage.prompt_tokens === "number") promptTokens = obj.usage.prompt_tokens;
            if (typeof obj.usage.completion_tokens === "number") completionTokens = obj.usage.completion_tokens;
            if (typeof obj.usage.total_tokens === "number") totalTokens = obj.usage.total_tokens;
          }
          for (const choice of obj.choices ?? []) {
            const delta = choice.delta ?? {};
            const rTok = delta.reasoning_content ?? delta.reasoning;
            if (rTok) {
              markFirst();
              fullReasoning += rTok;
              params.onReasoning(rTok);
            }
            if (delta.content) {
              markFirst();
              fullText += delta.content;
              params.onToken(delta.content);
            }
          }
        } catch (err) {
          if (err instanceof Error && !err.message.includes("JSON")) throw err;
        }
      }
    }

    const totalMs = Math.max(1, Math.round(performance.now() - started));
    return {
      text: fullText,
      reasoning: fullReasoning,
      promptTokens,
      completionTokens,
      totalTokens,
      tokensEstimated: promptTokens === undefined || completionTokens === undefined,
      firstTokenMs,
      totalMs,
    };
  } finally {
    cleanup();
  }
}
