import { streamFromProvider, type StreamProviderResult } from "../providers";
import { redactSensitive } from "../security/secrets";
import { type SwamiStore } from "../store";
import type {
  CompareModelResult,
  Mode,
  ProviderChatMessage,
  ProviderConfig,
  ProviderModelConfig,
  RoutableModelOption,
  RoutingPreference,
} from "../types";

export type PromptTaskType = "coding" | "research" | "vision" | "reasoning" | "fast_chat" | "general";

export interface LocalAiWindowsGuide {
  title: string;
  ollama: {
    default_url: string;
    steps: string[];
    env_example: string;
  };
  lmstudio: {
    default_url: string;
    steps: string[];
  };
  security_note: string;
}

export function getLocalAiWindowsGuide(): LocalAiWindowsGuide {
  return {
    title: "Connect Local AI on Windows PC (Ollama & LM Studio)",
    ollama: {
      default_url: "http://127.0.0.1:11434/v1",
      steps: [
        "Download and install Ollama for Windows from ollama.com.",
        "Open PowerShell or Command Prompt and pull a model, e.g.: ollama pull qwen2.5-coder:7b",
        "Ensure Ollama is running (check the system tray icon or run: ollama serve).",
        "Click Refresh Local Models in SWAMI — models are discovered live from http://127.0.0.1:11434/api/tags.",
      ],
      env_example: "OLLAMA_HOST=127.0.0.1:11434",
    },
    lmstudio: {
      default_url: "http://127.0.0.1:1234/v1",
      steps: [
        "Open LM Studio on Windows and download a GGUF model from the Discover tab.",
        "Go to the Developer (Local Server) tab on the left sidebar.",
        "Load your chosen model into memory and click Start Server (default port 1234).",
        "Click Refresh Local Models in SWAMI — loaded models are discovered live from http://127.0.0.1:1234/v1/models.",
      ],
    },
    security_note:
      "SWAMI only allows loopback URLs (127.0.0.1 / localhost) for unencrypted HTTP local daemons. Remote endpoints strictly require HTTPS and block private LAN/metadata IPs.",
  };
}

export function parseModelTarget(target: string): { providerId: string; modelId: string } | null {
  const clean = (target || "").trim();
  if (!clean || clean === "auto") return null;
  if (!clean.includes("::")) return null;
  const [providerId, ...rest] = clean.split("::");
  const modelId = rest.join("::");
  if (!providerId || !modelId) return null;
  return { providerId, modelId };
}

export function classifyPromptTask(
  prompt: string,
  mode: Mode,
  requiresVision = false,
): { taskType: PromptTaskType; complexity: "low" | "medium" | "high" } {
  if (requiresVision) {
    return { taskType: "vision", complexity: "high" };
  }
  const q = prompt.trim().toLowerCase();
  if (mode === "research" || /\b(research|cite|sources|literature|benchmark|compare across)\b/.test(q)) {
    return { taskType: "research", complexity: "high" };
  }
  if (
    /\b(function|class|typescript|python|rust|sql|react|debug|refactor|unit test|stack trace|compile|algorithm)\b/.test(
      q,
    ) ||
    prompt.includes("```")
  ) {
    return { taskType: "coding", complexity: prompt.length > 400 || mode === "think" ? "high" : "medium" };
  }
  if (
    mode === "think" ||
    /\b(prove|derive|architecture|root cause|trade-off|tradeoff|math|theorem|step by step|analyze)\b/.test(q) ||
    prompt.length > 900
  ) {
    return { taskType: "reasoning", complexity: "high" };
  }
  if (prompt.length < 160 && mode === "fast") {
    return { taskType: "fast_chat", complexity: "low" };
  }
  return { taskType: "general", complexity: prompt.length > 350 ? "medium" : "low" };
}

export interface AutoSelectionResult {
  chosen: RoutableModelOption;
  reason: string;
}

export function selectAutoModel(params: {
  activeStore: SwamiStore;
  mode: Mode;
  prompt: string;
  taskType?: PromptTaskType;
  requiresVision?: boolean;
  preference?: RoutingPreference;
}): AutoSelectionResult | null {
  const { activeStore, mode, prompt, requiresVision = false } = params;
  const settings = activeStore.getSettings();
  const preference = params.preference ?? settings.routing_preference ?? "balanced";
  const classified = classifyPromptTask(prompt, mode, requiresVision);
  const effectiveTask = params.taskType ?? classified.taskType;

  let pool = activeStore.getRoutableModels();
  if (settings.offline_mode) {
    pool = pool.filter((opt) => opt.is_local);
  }
  if (pool.length === 0) {
    return null;
  }

  if (requiresVision || effectiveTask === "vision") {
    const visionPool = pool.filter((opt) => opt.capabilities.verified && opt.capabilities.vision);
    if (visionPool.length === 0) {
      throw new Error(
        "No configured model has verified vision capability for image inputs. Enable a verified vision model (e.g. Gemini 3.1/4, GPT-4o, Claude Sonnet) first.",
      );
    }
    pool = visionPool;
  }

  // Prefer reachable/healthy/unknown models over explicitly unreachable/unhealthy ones
  const reachablePool = pool.filter((opt) => opt.health_status !== "unreachable" && opt.health_status !== "unhealthy");
  const candidates = reachablePool.length > 0 ? reachablePool : pool;

  const usageStats = activeStore.getUsageStats(24 * 7);
  const statMap = new Map(usageStats.map((s) => [`${s.provider_id}::${s.model_id}`, s]));

  const scored = candidates.map((opt) => {
    let score = 0;
    const reasons: string[] = [];

    if (opt.health_status === "healthy") {
      score += 18;
    } else if (opt.health_status === "unknown") {
      score += 8;
    } else {
      score -= 25;
    }

    if (opt.is_default) {
      score += 6;
    }

    const stat = statMap.get(opt.target);
    const avgTtft = stat && stat.requests > 0 ? stat.avg_first_token_ms : null;

    if (preference === "fastest") {
      if (opt.tier === "fast") {
        score += 30;
        reasons.push("fast-tier latency");
      } else if (opt.tier === "balanced") {
        score += 12;
      } else {
        score -= 5;
      }
      if (avgTtft !== null) {
        score += Math.max(0, 20 - avgTtft / 120);
      }
      if (opt.is_local) score += 6;
    } else if (preference === "capability") {
      if (opt.tier === "high") {
        score += 32;
        reasons.push("high-capability tier");
      } else if (opt.tier === "balanced") {
        score += 16;
      }
      if (opt.capabilities.verified && opt.capabilities.reasoning) {
        score += 14;
        reasons.push("verified reasoning");
      }
      if ((opt.capabilities.context_length ?? 0) >= 128_000) score += 6;
    } else if (preference === "lowest_cost") {
      if (opt.is_local || opt.cost_tier === "free") {
        score += 38;
        reasons.push(opt.is_local ? "zero-cost local model" : "free tier");
      } else if (opt.cost_tier === "low") {
        score += 24;
        reasons.push("low cost tier");
      } else if (opt.cost_tier === "medium") {
        score += 8;
      } else {
        score -= 10;
      }
    } else {
      // balanced
      if (classified.complexity === "high" || effectiveTask === "coding" || effectiveTask === "research") {
        score += opt.tier === "high" ? 24 : opt.tier === "balanced" ? 18 : 6;
      } else if (classified.complexity === "low") {
        score += opt.tier === "fast" ? 22 : opt.tier === "balanced" ? 16 : 6;
      } else {
        score += opt.tier === "balanced" ? 22 : 14;
      }
      if (opt.cost_tier === "low" || opt.cost_tier === "free") score += 6;
    }

    if (effectiveTask === "coding" && /coder|claude|gpt-4\.1|deepseek|gemini-4|qwen/i.test(opt.model_id)) {
      score += 10;
      reasons.push("strong coding fit");
    }
    if (effectiveTask === "reasoning" && opt.capabilities.verified && opt.capabilities.reasoning) {
      score += 14;
      reasons.push("verified reasoning support");
    }
    if (effectiveTask === "research" && (opt.capabilities.context_length ?? 0) >= 64_000) {
      score += 10;
      reasons.push("long-context research fit");
    }

    return { opt, score, reasons };
  });

  scored.sort((a, b) => b.score - a.score || a.opt.provider_id.localeCompare(b.opt.provider_id));
  const top = scored[0];
  if (!top) return null;

  const reasonParts = [
    `preference=${preference}`,
    `task=${effectiveTask}`,
    ...top.reasons.slice(0, 2),
  ];
  return {
    chosen: top.opt,
    reason: `Auto-selected ${top.opt.model_name} (${top.opt.provider_name}): ${reasonParts.join(", ")}.`,
  };
}

export interface RouterCandidate {
  target: string;
  provider: ProviderConfig;
  model: ProviderModelConfig;
  autoRouted: boolean;
  reason?: string;
}

export interface RouterStreamOptions {
  activeStore: SwamiStore;
  requestedTarget?: string;
  mode: Mode;
  systemPrompt: string;
  messages: ProviderChatMessage[];
  promptForRouting?: string;
  taskType?: PromptTaskType;
  requiresVision?: boolean;
  timeoutMs?: number;
  signal: AbortSignal;
  onToken: (text: string) => void;
  onReasoning: (text: string) => void;
  onModelSelected?: (info: {
    provider_id: string;
    provider_name: string;
    model_id: string;
    model_name: string;
    is_local: boolean;
    auto_routed: boolean;
    reason?: string;
    fallback_from?: string;
  }) => void;
  onNotice?: (message: string) => void;
}

export interface RouterStreamResult extends StreamProviderResult {
  provider_id: string;
  provider_name: string;
  model_id: string;
  model_name: string;
  is_local: boolean;
  auto_routed: boolean;
  routed_reason?: string;
  fallback_from?: string;
}

function isAbortError(err: unknown): boolean {
  if (err instanceof DOMException && err.name === "AbortError") return true;
  if (err instanceof Error && err.name === "AbortError") return true;
  return false;
}

function isTransientPreStreamError(err: unknown): boolean {
  if (isAbortError(err)) return false;
  const msg = (err instanceof Error ? err.message : String(err)).toLowerCase();
  if (/http\s*40[0134]|invalid api key|unauthorized|forbidden|not found/i.test(msg)) {
    return false;
  }
  return /429|502|503|504|econnreset|etimedout|socket hang up|temporarily unavailable|rate limit/i.test(msg);
}

export class ModelRouter {
  resolveCandidateChain(params: {
    activeStore: SwamiStore;
    requestedTarget?: string;
    mode: Mode;
    promptForRouting: string;
    taskType?: PromptTaskType;
    requiresVision?: boolean;
  }): RouterCandidate[] {
    const { activeStore, mode, promptForRouting, taskType, requiresVision = false } = params;
    const settings = activeStore.getSettings();
    const rawTarget = (params.requestedTarget ?? "").trim();

    const chain: RouterCandidate[] = [];
    const seenTargets = new Set<string>();

    const pushIfValid = (
      provider: ProviderConfig,
      model: ProviderModelConfig,
      autoRouted: boolean,
      reason?: string,
    ) => {
      const target = `${provider.id}::${model.id}`;
      if (seenTargets.has(target)) return;
      if (settings.offline_mode && !provider.is_local) return;
      if (!provider.enabled || !provider.configured || !model.enabled) return;
      if (requiresVision && !(model.capabilities.verified && model.capabilities.vision)) return;
      seenTargets.add(target);
      chain.push({ target, provider, model, autoRouted, reason });
    };

    const wantsAuto =
      rawTarget === "auto" ||
      (!rawTarget && settings.routing_mode === "auto");

    if (wantsAuto) {
      const auto = selectAutoModel({
        activeStore,
        mode,
        prompt: promptForRouting,
        taskType,
        requiresVision,
        preference: settings.routing_preference,
      });
      if (auto) {
        const det = activeStore.resolveTargetDetails(auto.chosen.target);
        if (det) {
          pushIfValid(det.provider, det.model, true, auto.reason);
        }
      }
    } else {
      const explicitTarget =
        rawTarget ||
        settings.model_id ||
        (settings.default_provider_id && settings.default_model_id
          ? `${settings.default_provider_id}::${settings.default_model_id}`
          : "");

      if (explicitTarget) {
        const det = activeStore.resolveTargetDetails(explicitTarget);
        if (det) {
          if (settings.offline_mode && !det.provider.is_local) {
            throw new Error(
              `Offline mode is enabled: cloud model '${det.model.name}' (${det.provider.name}) cannot be called. Switch to a local Ollama/LM Studio model or turn off Offline mode.`,
            );
          }
          if (requiresVision && !(det.model.capabilities.verified && det.model.capabilities.vision)) {
            throw new Error(
              `Selected model '${det.model.name}' does not have verified vision support for image input.`,
            );
          }
          pushIfValid(det.provider, det.model, false);
        }
      }
    }

    // Add configured default if primary wasn't resolved yet (excluding explicit legacy catalog IDs handled elsewhere)
    if (chain.length === 0 && !rawTarget && settings.default_provider_id && settings.default_model_id) {
      const def = activeStore.resolveTargetDetails(`${settings.default_provider_id}::${settings.default_model_id}`);
      if (def) {
        pushIfValid(def.provider, def.model, false, "Configured default model");
      }
    }

    // Add configured fallback model as secondary failover candidate
    if (chain.length > 0 && settings.fallback_provider_id && settings.fallback_model_id) {
      const fb = activeStore.resolveTargetDetails(`${settings.fallback_provider_id}::${settings.fallback_model_id}`);
      if (fb) {
        pushIfValid(fb.provider, fb.model, false, "Configured fallback model");
      }
    }

    return chain;
  }

  async stream(opts: RouterStreamOptions): Promise<RouterStreamResult> {
    const { activeStore, signal } = opts;
    const settings = activeStore.getSettings();
    const promptForRouting =
      opts.promptForRouting ?? opts.messages[opts.messages.length - 1]?.content ?? "";

    const effectiveRequiresVision =
      Boolean(opts.requiresVision) || opts.messages.some((m) => Array.isArray(m.images) && m.images.length > 0);

    const chain = this.resolveCandidateChain({
      activeStore,
      requestedTarget: opts.requestedTarget,
      mode: opts.mode,
      promptForRouting,
      taskType: opts.taskType,
      requiresVision: effectiveRequiresVision,
    });

    if (chain.length === 0) {
      if (effectiveRequiresVision) {
        throw new Error(
          settings.offline_mode
            ? "No verified local vision model (e.g., Ollama LLaVA or Qwen-VL) is available in Offline mode."
            : "No vision-capable model is configured. Select Auto Model or add a verified vision model (Gemini, GPT-4o/4.1, Claude, or OpenRouter vision).",
        );
      }
      throw new Error(
        settings.offline_mode
          ? "No local Ollama/LM Studio model is available in Offline mode."
          : "No configured provider/model is active for the Model Router.",
      );
    }

    const errors: string[] = [];

    for (let idx = 0; idx < chain.length; idx++) {
      const candidate = chain[idx];
      const isFallback = idx > 0;
      const primaryLabel = `${chain[0].model.name} (${chain[0].provider.name})`;

      if (signal.aborted) {
        throw new DOMException("Aborted", "AbortError");
      }

      if (isFallback) {
        const noticeText = `Primary model ${primaryLabel} failed (${errors[0] || "error"}). Switching to fallback ${candidate.model.name} (${candidate.provider.name}).`;
        opts.onNotice?.(noticeText);
      } else if (candidate.autoRouted && candidate.reason) {
        opts.onNotice?.(candidate.reason);
      }

      opts.onModelSelected?.({
        provider_id: candidate.provider.id,
        provider_name: candidate.provider.name,
        model_id: candidate.model.id,
        model_name: candidate.model.name,
        is_local: candidate.provider.is_local,
        auto_routed: candidate.autoRouted,
        reason: candidate.reason,
        ...(isFallback ? { fallback_from: primaryLabel } : {}),
      });

      const temperature =
        candidate.model.params?.temperature !== undefined
          ? candidate.model.params.temperature
          : settings.temperature;
      const topP =
        candidate.model.params?.top_p !== undefined
          ? candidate.model.params.top_p
          : settings.top_p;
      const maxTokens =
        candidate.model.params?.max_tokens && candidate.model.params.max_tokens > 0
          ? candidate.model.params.max_tokens
          : settings.max_tokens || 4096;
      const timeoutMs =
        opts.timeoutMs ??
        (candidate.model.params?.timeout_ms && candidate.model.params.timeout_ms > 0
          ? candidate.model.params.timeout_ms
          : settings.request_timeout_ms || 60000);

      const apiKey = activeStore.getProviderApiKey(candidate.provider.id);
      if (!apiKey && !candidate.provider.is_local) {
        const msg = `API key missing for ${candidate.provider.name}.`;
        errors.push(msg);
        activeStore.setProviderHealth(candidate.provider.id, "unconfigured", msg, null);
        continue;
      }

      let attempt = 0;
      while (attempt < 2) {
        attempt += 1;
        let streamedAnyOutput = false;
        try {
          const res = await streamFromProvider({
            baseUrl: candidate.provider.base_url,
            model: candidate.model.id,
            apiKey,
            protocol: candidate.provider.protocol,
            systemPrompt: opts.systemPrompt,
            messages: opts.messages,
            temperature: temperature ?? null,
            topP: topP ?? null,
            maxTokens,
            timeoutMs,
            signal,
            onToken: (tok) => {
              streamedAnyOutput = true;
              opts.onToken(tok);
            },
            onReasoning: (rTok) => {
              streamedAnyOutput = true;
              opts.onReasoning(rTok);
            },
          });

          activeStore.setProviderHealth(
            candidate.provider.id,
            "healthy",
            `Last request succeeded (${candidate.model.name})`,
            res.firstTokenMs ?? res.totalMs,
          );

          return {
            ...res,
            provider_id: candidate.provider.id,
            provider_name: candidate.provider.name,
            model_id: candidate.model.id,
            model_name: candidate.model.name,
            is_local: candidate.provider.is_local,
            auto_routed: candidate.autoRouted,
            routed_reason: candidate.reason,
            ...(isFallback ? { fallback_from: primaryLabel } : {}),
          };
        } catch (err) {
          if (isAbortError(err) && signal.aborted) {
            throw err;
          }
          const cleanMsg = redactSensitive(err instanceof Error ? err.message : "Provider request failed");

          // Retry at most once ONLY if zero tokens were emitted yet and the failure looks transient
          if (!streamedAnyOutput && attempt === 1 && isTransientPreStreamError(err) && !signal.aborted) {
            opts.onNotice?.(`Transient error from ${candidate.provider.name}; retrying once…`);
            await new Promise<void>((r) => setTimeout(r, 350));
            continue;
          }

          const isUnreachable = /ECONNREFUSED|ENOTFOUND|ETIMEDOUT|fetch failed|timed out/i.test(cleanMsg);
          activeStore.setProviderHealth(
            candidate.provider.id,
            isUnreachable ? "unreachable" : "unhealthy",
            cleanMsg,
            null,
          );
          errors.push(`${candidate.provider.name}/${candidate.model.id}: ${cleanMsg}`);

          // If tokens already began streaming mid-response, do not jump silently to another model
          if (streamedAnyOutput) {
            throw new Error(cleanMsg);
          }
          break;
        }
      }
    }

    throw new Error(
      errors.length > 1
        ? `All configured models failed — ${errors.join(" | ")}`
        : errors[0] || "Model request failed.",
    );
  }

  async generateText(params: {
    activeStore: SwamiStore;
    requestedTarget?: string;
    mode?: Mode;
    systemPrompt: string;
    userPrompt: string;
    taskType?: PromptTaskType;
    requiresVision?: boolean;
    timeoutMs?: number;
    signal?: AbortSignal;
  }): Promise<RouterStreamResult> {
    const controller = new AbortController();
    const signal = params.signal ?? controller.signal;
    return this.stream({
      activeStore: params.activeStore,
      requestedTarget: params.requestedTarget,
      mode: params.mode ?? "fast",
      systemPrompt: params.systemPrompt,
      messages: [{ role: "user", content: params.userPrompt }],
      promptForRouting: params.userPrompt,
      taskType: params.taskType,
      requiresVision: params.requiresVision,
      timeoutMs: params.timeoutMs,
      signal,
      onToken: () => {},
      onReasoning: () => {},
    });
  }

  async compareModels(params: {
    activeStore: SwamiStore;
    targets: string[];
    prompt: string;
    systemPrompt?: string;
    mode?: Mode;
    signal: AbortSignal;
    onUpdate: (result: CompareModelResult, eventType: "delta" | "reasoning" | "done" | "error", delta?: string) => void;
  }): Promise<CompareModelResult[]> {
    const { activeStore, prompt, signal, onUpdate } = params;
    const uniqueTargets = Array.from(new Set(params.targets.map((t) => t.trim()).filter(Boolean))).slice(0, 4);
    if (uniqueTargets.length === 0) {
      throw new Error("Select at least one model to compare.");
    }
    if (!prompt.trim()) {
      throw new Error("Comparison prompt cannot be empty.");
    }

    const settings = activeStore.getSettings();
    const sys =
      params.systemPrompt ||
      `You are SWAMI, an accurate and helpful AI assistant. Style: ${settings.style}.` +
        (settings.custom_instructions ? `\nCustom instructions: ${settings.custom_instructions}` : "");

    // Tool isolation: comparison strictly prohibits external tools or state-mutating actions (allowTools = false)
    const allowTools = false;
    void allowTools;

    const tasks = uniqueTargets.map(async (target): Promise<CompareModelResult> => {
      const det = activeStore.resolveTargetDetails(target);
      if (!det) {
        const failed: CompareModelResult = {
          target,
          provider_id: "unknown",
          provider_name: "Unknown",
          model_id: target,
          model_name: target,
          is_local: false,
          status: "error",
          content: "",
          reasoning: "",
          error: `Model target '${target}' is not configured or enabled.`,
          first_token_ms: null,
          total_ms: 0,
          prompt_tokens: 0,
          completion_tokens: 0,
          tokens_estimated: true,
        };
        onUpdate(failed, "error");
        return failed;
      }

      if (settings.offline_mode && !det.provider.is_local) {
        const blocked: CompareModelResult = {
          target: det.target,
          provider_id: det.provider.id,
          provider_name: det.provider.name,
          model_id: det.model.id,
          model_name: det.model.name,
          is_local: false,
          status: "error",
          content: "",
          reasoning: "",
          error: "Blocked by Offline mode.",
          first_token_ms: null,
          total_ms: 0,
          prompt_tokens: 0,
          completion_tokens: 0,
          tokens_estimated: true,
        };
        onUpdate(blocked, "error");
        return blocked;
      }

      const apiKey = activeStore.getProviderApiKey(det.provider.id);
      if (!apiKey && !det.provider.is_local) {
        const missing: CompareModelResult = {
          target: det.target,
          provider_id: det.provider.id,
          provider_name: det.provider.name,
          model_id: det.model.id,
          model_name: det.model.name,
          is_local: false,
          status: "error",
          content: "",
          reasoning: "",
          error: `API key missing for ${det.provider.name}.`,
          first_token_ms: null,
          total_ms: 0,
          prompt_tokens: 0,
          completion_tokens: 0,
          tokens_estimated: true,
        };
        onUpdate(missing, "error");
        return missing;
      }

      const state: CompareModelResult = {
        target: det.target,
        provider_id: det.provider.id,
        provider_name: det.provider.name,
        model_id: det.model.id,
        model_name: det.model.name,
        is_local: det.provider.is_local,
        status: "running",
        content: "",
        reasoning: "",
        first_token_ms: null,
        total_ms: 0,
        prompt_tokens: 0,
        completion_tokens: 0,
        tokens_estimated: true,
      };
      const started = performance.now();

      try {
        const res = await streamFromProvider({
          baseUrl: det.provider.base_url,
          model: det.model.id,
          apiKey,
          protocol: det.provider.protocol,
          systemPrompt: sys,
          messages: [{ role: "user", content: prompt }],
          temperature: det.model.params?.temperature ?? settings.temperature,
          topP: det.model.params?.top_p ?? settings.top_p,
          maxTokens: det.model.params?.max_tokens || settings.max_tokens || 2048,
          timeoutMs: det.model.params?.timeout_ms || settings.request_timeout_ms || 60000,
          signal,
          onToken: (tok) => {
            if (state.first_token_ms === null) {
              state.first_token_ms = Math.max(1, Math.round(performance.now() - started));
            }
            state.content += tok;
            onUpdate({ ...state }, "delta", tok);
          },
          onReasoning: (rTok) => {
            if (state.first_token_ms === null) {
              state.first_token_ms = Math.max(1, Math.round(performance.now() - started));
            }
            state.reasoning += rTok;
            onUpdate({ ...state }, "reasoning", rTok);
          },
        });

        state.status = "complete";
        state.total_ms = res.totalMs;
        state.first_token_ms = res.firstTokenMs ?? state.first_token_ms;
        state.prompt_tokens = res.promptTokens ?? Math.max(4, Math.round(prompt.length / 3.6));
        state.completion_tokens = res.completionTokens ?? Math.max(4, Math.round(state.content.length / 3.6));
        state.tokens_estimated = res.tokensEstimated;

        activeStore.setProviderHealth(det.provider.id, "healthy", `Compare succeeded (${det.model.name})`, state.total_ms);
        try {
          activeStore.recordUsage({
            ts: Date.now() / 1000,
            model_id: det.model.id,
            provider: det.provider.id,
            mode: params.mode ?? "fast",
            prompt_tokens: state.prompt_tokens,
            completion_tokens: state.completion_tokens,
            first_token_ms: state.first_token_ms ?? state.total_ms,
            total_ms: state.total_ms,
            status: "complete",
          });
        } catch {
          /* ignore */
        }

        onUpdate({ ...state }, "done");
        return state;
      } catch (err) {
        state.total_ms = Math.max(1, Math.round(performance.now() - started));
        if (isAbortError(err) && signal.aborted) {
          state.status = "stopped";
          onUpdate({ ...state }, "done");
          return state;
        }
        const msg = redactSensitive(err instanceof Error ? err.message : "Comparison error");
        state.status = "error";
        state.error = msg;
        const isUnreachable = /ECONNREFUSED|ENOTFOUND|ETIMEDOUT|fetch failed|timed out/i.test(msg);
        activeStore.setProviderHealth(det.provider.id, isUnreachable ? "unreachable" : "unhealthy", msg, null);
        try {
          activeStore.recordUsage({
            ts: Date.now() / 1000,
            model_id: det.model.id,
            provider: det.provider.id,
            mode: params.mode ?? "fast",
            prompt_tokens: 0,
            completion_tokens: 0,
            first_token_ms: 0,
            total_ms: state.total_ms,
            status: "error",
          });
        } catch {
          /* ignore */
        }
        onUpdate({ ...state }, "error");
        return state;
      }
    });

    const settled = await Promise.all(tasks);
    return settled;
  }
}

export const modelRouter = new ModelRouter();
