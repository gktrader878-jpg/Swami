import path from "node:path";
import { hasDisallowedExecutableSignature, sanitizeFilename } from "./security/validation";
import type { DocumentChunk, DocumentRecord } from "./types";

export const TEXT_EXTENSIONS = new Set([
  ".txt", ".md", ".markdown", ".rst", ".csv", ".tsv", ".json", ".jsonl", ".yaml", ".yml", ".toml", ".ini",
  ".log", ".xml", ".html", ".htm", ".py", ".js", ".ts", ".tsx", ".jsx", ".java", ".c", ".h", ".cpp", ".cs",
  ".go", ".rs", ".rb", ".php", ".sql", ".sh", ".ps1", ".bat", ".css", ".tex", ".toml",
]);

export const SUPPORTED_EXTENSIONS = new Set([...TEXT_EXTENSIONS, ".pdf", ".docx"]);
export const MAX_FILE_BYTES = 30 * 1024 * 1024;
export const CHUNK_CHARS = 1400;
export const CHUNK_OVERLAP = 180;

export class DocumentError extends Error {
  status: number;
  constructor(message: string, status = 422) {
    super(message);
    this.status = status;
  }
}

export interface ExtractedDocumentPage {
  page: number;
  text: string;
}

export interface ExtractedDocumentResult {
  text: string;
  pages: ExtractedDocumentPage[];
  pageCount: number;
  isScanned: boolean;
}

function unescapePdfLiteral(str: string): string {
  return str
    .replace(/\\n/g, "\n")
    .replace(/\\r/g, " ")
    .replace(/\\t/g, " ")
    .replace(/\\\(/g, "(")
    .replace(/\\\)/g, ")")
    .replace(/\\\\/g, "\\");
}

function extractReadablePdfStrings(rawSlice: string): string {
  const parts: string[] = [];
  // 1. Extract literal PDF text operators (...) Tj / TJ
  const litMatches = rawSlice.matchAll(/\(([^()\\]{2,}|(?:\\.|[^()\\]){2,})\)\s*(?:Tj|'|")/g);
  for (const m of litMatches) {
    const clean = unescapePdfLiteral(m[1]).replace(/[^\x20-\x7E\n\u00A0-\u024F\u0900-\u097F]/g, " ").trim();
    if (clean.length >= 2) parts.push(clean);
  }
  const tjArrayMatches = rawSlice.matchAll(/\[((?:[^[\]]|\([^)]*\))*)\]\s*TJ/g);
  for (const m of tjArrayMatches) {
    const inner: string[] = [];
    for (const sub of m[1].matchAll(/\(([^()]*)\)/g)) {
      inner.push(unescapePdfLiteral(sub[1]));
    }
    const joined = inner.join("").replace(/[^\x20-\x7E\n\u00A0-\u024F\u0900-\u097F]/g, " ").trim();
    if (joined.length >= 2) parts.push(joined);
  }
  if (parts.length > 0) {
    return parts.join(" ").replace(/\s+/g, " ").trim();
  }
  // 2. Fallback: printable ASCII runs outside PDF binary streams/dictionaries
  const stripped = rawSlice
    .replace(/stream[\r\n][\s\S]*?endstream/g, (block) => {
      // Only keep uncompressed text streams (containing BT...ET text blocks)
      return /\bBT\b[\s\S]*?\bET\b/.test(block) ? block : " ";
    });
  const matches = stripped.match(/[A-Za-z0-9 ,.;:!?()'"/\-_\n]{6,}/g) ?? [];
  return matches
    .filter((s) => !/^(obj|endobj|xref|trailer|startxref|FlateDecode|Type\s+Page)$/i.test(s.trim()))
    .join(" ")
    .replace(/\s+/g, " ")
    .trim();
}

export function extractDocumentWithPages(filename: string, buffer: Buffer): ExtractedDocumentResult {
  const safeName = sanitizeFilename(filename);
  const ext = path.extname(safeName).toLowerCase();
  if (!SUPPORTED_EXTENSIONS.has(ext)) {
    throw new DocumentError(
      `'${ext || safeName}' files are not supported. Supported: text, code, CSV, JSON, PDF, DOCX.`,
      422,
    );
  }
  if (buffer.byteLength === 0) {
    throw new DocumentError("The uploaded file is empty.", 422);
  }
  if (buffer.byteLength > MAX_FILE_BYTES) {
    throw new DocumentError("File is larger than 30 MB.", 413);
  }
  if (hasDisallowedExecutableSignature(buffer)) {
    throw new DocumentError("Executable binary files are not allowed.", 422);
  }

  if (ext === ".pdf") {
    const raw = buffer.toString("latin1");
    if (!raw.startsWith("%PDF-")) {
      throw new DocumentError("Invalid PDF header signature.", 422);
    }
    // Count declared pages via /Type /Page (excluding /Pages)
    const pageMarkers = raw.match(/\/Type\s*\/Page\b(?!s)/g) ?? [];
    const pageCount = Math.max(1, pageMarkers.length);

    // Split around BT...ET text blocks or page markers to preserve page numbers
    const pageChunks = raw.split(/\/Type\s*\/Page\b(?!s)/);
    const pages: ExtractedDocumentPage[] = [];
    if (pageChunks.length > 1) {
      for (let i = 1; i < pageChunks.length; i++) {
        const extracted = extractReadablePdfStrings(pageChunks[i]);
        if (extracted.length > 0) {
          pages.push({ page: i, text: extracted });
        }
      }
    } else {
      const extracted = extractReadablePdfStrings(raw);
      if (extracted.length > 0) {
        pages.push({ page: 1, text: extracted });
      }
    }

    const totalText = pages.map((p) => p.text).join("\n\n").trim();
    const avgCharsPerPage = totalText.length / Math.max(1, pageCount);
    const isScanned = totalText.length < 80 || avgCharsPerPage < 40;

    if (pages.length === 0) {
      pages.push({
        page: 1,
        text: `[Scanned or compressed visual PDF "${safeName}" (${pageCount} page${pageCount === 1 ? "" : "s"}). Use a vision model or Run Visual OCR to inspect page imagery and extract text.]`,
      });
    }

    return {
      text: pages.map((p) => p.text).join("\n\n"),
      pages,
      pageCount,
      isScanned,
    };
  }

  if (ext === ".docx") {
    const raw = buffer.toString("latin1");
    const matches = raw.match(/[A-Za-z0-9 ,.;:!?()'"/\-_\n]{6,}/g) ?? [];
    const extracted = matches.join(" ").replace(/\s+/g, " ").trim();
    if (!extracted) {
      throw new DocumentError("Could not extract selectable text from DOCX file.", 422);
    }
    return { text: extracted, pages: [{ page: 0, text: extracted }], pageCount: 1, isScanned: false };
  }

  const text = buffer.toString("utf-8").replace(/^\uFEFF/, "");
  if (!text.trim()) {
    throw new DocumentError("The file contains no readable text.", 422);
  }
  return { text, pages: [{ page: 0, text }], pageCount: 1, isScanned: false };
}

export function extractDocumentText(filename: string, buffer: Buffer): string {
  return extractDocumentWithPages(filename, buffer).text;
}

export function chunkDocumentText(rawText: string): string[] {
  const text = rawText.replace(/[ \t]+\n/g, "\n").trim();
  if (!text) return [];
  const chunks: string[] = [];
  let start = 0;
  while (start < text.length) {
    let end = Math.min(text.length, start + CHUNK_CHARS);
    if (end < text.length) {
      const window = text.slice(start, end);
      let cut = Math.max(window.lastIndexOf("\n\n"), window.lastIndexOf(". "), window.lastIndexOf("\n"));
      if (cut < CHUNK_CHARS * 0.5) {
        cut = window.lastIndexOf(" ");
      }
      if (cut > CHUNK_CHARS * 0.3) {
        end = start + cut + 1;
      }
    }
    const piece = text.slice(start, end).trim();
    if (piece) chunks.push(piece);
    if (end >= text.length) break;
    start = Math.max(end - CHUNK_OVERLAP, start + 1);
  }
  return chunks;
}

export function chunkDocumentPages(docId: string, pages: ExtractedDocumentPage[]): DocumentChunk[] {
  const rows: DocumentChunk[] = [];
  let chunkIndex = 0;
  for (const p of pages) {
    const pieces = chunkDocumentText(p.text);
    for (const piece of pieces) {
      rows.push({
        doc_id: docId,
        chunk_index: chunkIndex++,
        page: p.page,
        text: piece,
      });
    }
  }
  return rows;
}

const STOP_WORDS = new Set([
  "the", "a", "an", "of", "to", "in", "is", "are", "was", "were", "and", "or", "for", "on", "with", "what",
  "which", "who", "how", "why", "does", "do", "did", "this", "that", "it", "be", "as", "at", "by", "from",
  "me", "my", "about", "can", "you", "tell", "please", "kya", "hai", "ka", "ki", "ke", "ko", "se",
]);

export function searchDocumentChunks(
  question: string,
  docIds: string[],
  docs: Map<string, DocumentRecord>,
  chunksByDoc: Map<string, DocumentChunk[]>,
  limit = 6,
): Array<DocumentChunk & { name: string; score: number }> {
  if (docIds.length === 0) return [];
  const terms = Array.from(
    new Set(
      (question.toLowerCase().match(/[a-z0-9_]+/g) ?? []).filter((t) => t.length > 1 && !STOP_WORDS.has(t)),
    ),
  );
  const allChunks: Array<DocumentChunk & { name: string; score: number }> = [];
  for (const docId of docIds) {
    const doc = docs.get(docId);
    const list = chunksByDoc.get(docId) ?? [];
    for (const chunk of list) {
      const lower = chunk.text.toLowerCase();
      let score = 0;
      for (const term of terms) {
        if (lower.includes(term)) score += 1;
      }
      allChunks.push({ ...chunk, name: doc?.name ?? "document", score });
    }
  }
  const matched = allChunks.filter((c) => c.score > 0).sort((a, b) => b.score - a.score);
  if (matched.length > 0) return matched.slice(0, limit);
  return allChunks.slice(0, limit);
}

export interface DocumentUsed {
  name: string;
  page: number;
  whole: boolean;
  excerpt: string;
  label?: string;
}

export function buildDocumentContext(
  question: string,
  docIds: string[],
  docs: Map<string, DocumentRecord>,
  chunksByDoc: Map<string, DocumentChunk[]>,
  charBudget: number,
): { contextBlock: string; used: DocumentUsed[] } {
  const attachedDocs = docIds.map((id) => docs.get(id)).filter((d): d is DocumentRecord => Boolean(d));
  if (attachedDocs.length === 0) return { contextBlock: "", used: [] };

  const totalChars = attachedDocs.reduce((sum, d) => sum + d.n_chars, 0);
  const used: DocumentUsed[] = [];
  const blocks: string[] = [];

  if (totalChars <= charBudget) {
    for (const doc of attachedDocs) {
      const list = chunksByDoc.get(doc.id) ?? [];
      blocks.push(`<document name="${doc.name}">\n${list.map((c) => c.text).join("\n")}\n</document>`);
      used.push({ name: doc.name, page: 0, whole: true, excerpt: "" });
    }
  } else {
    const per = Math.max(3, Math.min(10, Math.floor(charBudget / CHUNK_CHARS)));
    const hits = searchDocumentChunks(question, docIds, docs, chunksByDoc, per);
    for (const row of hits) {
      const label = row.page ? `${row.name}, p. ${row.page}` : `${row.name}, part ${row.chunk_index + 1}`;
      blocks.push(`<passage source="${label}">\n${row.text}\n</passage>`);
      used.push({ name: row.name, page: row.page, whole: false, excerpt: row.text.slice(0, 240), label });
    }
  }

  return { contextBlock: blocks.join("\n\n"), used };
}
