import os from "node:os";
import type { CatalogEntry, Hardware, ProfileInfo, Settings } from "./types";
import { DEFAULT_VOICE_SHORTCUTS } from "./voice/shortcuts";

export const APP_NAME = "SWAMI";
export const APP_VERSION = "0.1.0";

export const DEFAULT_SETTINGS: Settings = {
  theme: "dark",
  density: "comfortable",
  font_scale: 100,
  profile: "auto",
  model_id: "",
  routing_mode: "manual",
  routing_preference: "balanced",
  default_provider_id: "",
  default_model_id: "",
  fallback_provider_id: "",
  fallback_model_id: "",
  request_timeout_ms: 60000,
  api_base_url: "https://api.openai.com/v1",
  api_model: "gpt-4.1-mini",
  api_provider: "openai",
  api_protocol: "auto",
  api_key_configured: false,
  context_length: 0,
  gpu_layers: -1,
  idle_unload_minutes: 15,
  temperature: null,
  top_p: null,
  top_k: null,
  max_tokens: 4096,
  style: "balanced",
  custom_instructions: "",
  show_reasoning: true,
  think_max_tool_calls: 6,
  think_time_budget_s: 180,
  think_token_budget: 8000,
  think_verify: true,
  think_reasoning_budget: 2048,
  offline_mode: false,
  web_research_enabled: true,
  search_provider: "duckduckgo",
  searxng_url: "",
  brave_api_key: "",
  research_max_sources: 8,
  research_max_rounds: 2,
  research_time_budget_s: 300,
  python_tool_enabled: false,
  memory_enabled: true,
  memory_auto_suggest: true,
  voice_enabled: true,
  voice_mode: "conversation",
  voice_provider: "auto",
  voice_stt_provider: "auto",
  voice_tts_provider: "auto",
  voice_name: "Zephyr",
  voice_language: "en-IN",
  voice_speed: 1.0,
  voice_volume: 0.95,
  voice_auto_listen: true,
  voice_interrupt_enabled: true,
  voice_vad_sensitivity: 0.55,
  voice_silence_ms: 1150,
  voice_mic_device_id: "",
  voice_shortcuts: DEFAULT_VOICE_SHORTCUTS,
};

export const PROFILES: Record<string, ProfileInfo> = {
  lite: {
    label: "Lite",
    description: "CPU-friendly small model. Slower and less capable, runs on modest PCs.",
    model_id: "qwen2.5-coder-3b-ollama",
    context_length: 4096,
    gpu_layers: -1,
  },
  balanced: {
    label: "Balanced",
    description: "Mid-size model with a moderate context window.",
    model_id: "qwen3.5-4b-q4km",
    context_length: 8192,
    gpu_layers: -1,
  },
  high: {
    label: "High",
    description: "Strongest tested model with a large context window. Needs a 12–16 GB GPU.",
    model_id: "qwen3.5-9b-q4km",
    context_length: 16384,
    gpu_layers: -1,
  },
};

export const BASE_CATALOG: CatalogEntry[] = [
  {
    id: "gemini-3.1-flash-lite",
    runtime: "Gemini API",
    name: "Gemini 3.1 Flash Lite",
    family: "Gemini 3.1",
    publisher: "Google",
    base_repo: "https://ai.google.dev/gemini-api/docs/models",
    gguf_repo: "",
    file: "gemini-3.1-flash-lite",
    size_bytes: 0,
    license: "Google API Terms",
    parameters: "Gemini 3.1 Lite",
    quantization: "Cloud",
    tier: "lite",
    native_context: 1_000_000,
    min_vram_gb: 0,
    min_ram_gb: 0,
    notes: "Ultra-fast Gemini model with minimal thinking overhead for rapid replies.",
  },
  {
    id: "gemini-4-hydrogen",
    runtime: "Gemini API",
    name: "Gemini 4 Hydrogen",
    family: "Gemini 4",
    publisher: "Google",
    base_repo: "https://ai.google.dev/gemini-api/docs/models",
    gguf_repo: "",
    file: "gemini-4-hydrogen",
    size_bytes: 0,
    license: "Google API Terms",
    parameters: "Gemini 4 Flash",
    quantization: "Cloud",
    tier: "balanced",
    native_context: 1_000_000,
    min_vram_gb: 0,
    min_ram_gb: 0,
    notes: "Google Gemini 4 Hydrogen with adaptive thinking, tool calling, and Google Search grounding for Deep Research.",
  },
  {
    id: "qwen2.5-coder-3b-ollama",
    runtime: "Ollama",
    ollama_model: "qwen2.5-coder:3b",
    name: "Qwen2.5 Coder 3B",
    family: "Qwen2.5",
    publisher: "Alibaba Qwen",
    base_repo: "https://huggingface.co/Qwen/Qwen2.5-Coder-3B-Instruct",
    gguf_repo: "https://ollama.com/library/qwen2.5-coder",
    file: "qwen2.5-coder:3b",
    size_bytes: 1_929_379_840,
    license: "Apache-2.0",
    parameters: "3B",
    quantization: "Q4_K_M",
    tier: "lite",
    native_context: 32768,
    min_vram_gb: 3,
    min_ram_gb: 6,
    notes: "Fast, compact coding and general-purpose model tuned for modest CPUs and 8 GB laptops.",
  },
  {
    id: "qwen2.5-7b-ollama",
    runtime: "Ollama",
    ollama_model: "qwen2.5:7b",
    name: "Qwen2.5 7B",
    family: "Qwen2.5",
    publisher: "Alibaba Qwen",
    base_repo: "https://huggingface.co/Qwen/Qwen2.5-7B-Instruct",
    gguf_repo: "https://ollama.com/library/qwen2.5",
    file: "qwen2.5:7b",
    size_bytes: 4_683_075_584,
    license: "Apache-2.0",
    parameters: "7B",
    quantization: "Q4_K_M",
    tier: "balanced",
    native_context: 32768,
    min_vram_gb: 6,
    min_ram_gb: 10,
    notes: "Well-rounded 7B instruction model for reasoning, Hindi/Hinglish, and document analysis.",
  },
  {
    id: "qwen3.5-4b-q4km",
    runtime: "llama.cpp",
    name: "Qwen3.5 4B",
    family: "Qwen3.5",
    publisher: "Alibaba Qwen",
    base_repo: "https://huggingface.co/Qwen/Qwen3-4B",
    gguf_repo: "https://huggingface.co/unsloth/Qwen3-4B-GGUF",
    file: "Qwen3.5-4B-Q4_K_M.gguf",
    size_bytes: 2_684_354_560,
    license: "Apache-2.0",
    parameters: "4B",
    quantization: "Q4_K_M",
    tier: "balanced",
    native_context: 32768,
    min_vram_gb: 4,
    min_ram_gb: 8,
    notes: "Balanced GGUF build with strong step-by-step reasoning and low memory footprint.",
  },
  {
    id: "qwen3.5-9b-q4km",
    runtime: "llama.cpp",
    name: "Qwen3.5 9B",
    family: "Qwen3.5",
    publisher: "Alibaba Qwen",
    base_repo: "https://huggingface.co/Qwen/Qwen3-8B",
    gguf_repo: "https://huggingface.co/unsloth/Qwen3-8B-GGUF",
    file: "Qwen3.5-9B-Q4_K_M.gguf",
    size_bytes: 5_637_144_576,
    license: "Apache-2.0",
    parameters: "9B",
    quantization: "Q4_K_M",
    tier: "high",
    native_context: 32768,
    min_vram_gb: 8,
    min_ram_gb: 16,
    notes: "High-capability local model for complex synthesis, coding, and long-context documents.",
  },
  {
    id: "online-api",
    runtime: "api",
    name: "Online API model",
    family: "OpenAI-compatible API",
    publisher: "Configured provider",
    base_repo: "",
    gguf_repo: "",
    file: "online API",
    size_bytes: 0,
    license: "Provider terms apply",
    parameters: "Cloud model",
    quantization: "Online",
    tier: "high",
    native_context: 32768,
    min_vram_gb: 0,
    min_ram_gb: 0,
    notes: "Sends prompts and selected context to your configured API provider.",
  },
];

export function getHardwareSnapshot(): Hardware {
  const cpus = os.cpus();
  const threads = cpus.length || 2;
  const cores = Math.max(1, Math.floor(threads / 2));
  const totalGb = Math.round((os.totalmem() / 2 ** 30) * 10) / 10;
  const availGb = Math.round((os.freemem() / 2 ** 30) * 10) / 10;
  return {
    os: `${os.type()} ${os.release()}`,
    cpu: cpus[0]?.model || "x86_64 Processor",
    cpu_cores: cores,
    cpu_threads: threads,
    ram_total_gb: totalGb,
    ram_available_gb: availGb,
    gpus: [],
    has_gpu: false,
  };
}

export function recommendProfile(hw: Hardware): "lite" | "balanced" | "high" {
  const vramGb = Math.max(0, ...hw.gpus.map((g) => g.vram_total_mb)) / 1024;
  const ram = hw.ram_total_gb;
  if (vramGb >= 11 && ram >= 12) return "high";
  if (vramGb >= 5 || ram >= 15) return "balanced";
  return "lite";
}

export function evaluateCompatibility(entry: CatalogEntry, hw: Hardware): { level: "ok" | "warn" | "bad"; message: string } {
  if (entry.runtime === "Gemini API") {
    return { level: "ok", message: "Runs via server-side Google Gemini API (GEMINI_API_KEY)." };
  }
  if (entry.runtime === "api") {
    return { level: "ok", message: "Runs remotely via your configured OpenAI-compatible API endpoint." };
  }
  const vram = Math.max(0, ...hw.gpus.map((g) => g.vram_total_mb)) / 1024;
  const ram = hw.ram_total_gb;
  const sizeGb = (entry.size_bytes || 0) / 2 ** 30;
  const needVram = entry.min_vram_gb || 0;
  const needRam = entry.min_ram_gb || 0;
  if (vram >= Math.max(needVram, sizeGb + 1.5)) {
    if (ram < needRam) {
      return {
        level: "warn",
        message: `Fits on the GPU, but also needs about ${needRam} GB of system RAM; this environment has ${ram.toFixed(0)} GB.`,
      };
    }
    return { level: "ok", message: "Fits fully on the GPU." };
  }
  if (vram > 0 && ram + vram >= sizeGb + 4) {
    return { level: "warn", message: "Will be split between GPU and system RAM; expect slower replies." };
  }
  if (ram >= Math.max(needRam, sizeGb + 2)) {
    return { level: "ok", message: "Runs cleanly on CPU memory." };
  }
  return { level: "warn", message: `Needs about ${needRam} GB RAM for smooth CPU execution; runs in compact mode here.` };
}

export interface ResolvedModel {
  entry?: CatalogEntry;
  model_id?: string;
  model_name?: string;
  context_length?: number;
  gpu_layers?: number;
  profile?: string;
  error?: string;
}

export function resolveModelSelection(
  settings: Settings,
  entries: CatalogEntry[],
  installedIds: Set<string>,
  hw: Hardware,
  modelOverride = "",
): ResolvedModel {
  let profile = settings.profile || "auto";
  if (!PROFILES[profile]) {
    profile = recommendProfile(hw);
  }
  const preset = PROFILES[profile];
  const installed = entries.filter((e) => installedIds.has(e.id));
  if (installed.length === 0) {
    return { error: "No model is installed yet. Download one in Settings > Models." };
  }
  const localInstalled = installed.filter((e) => e.runtime !== "Gemini API" && e.runtime !== "api");
  const poolInstalled =
    settings.offline_mode && !modelOverride
      ? localInstalled.length > 0
        ? localInstalled
        : installed
      : installed;
  const wanted =
    modelOverride ||
    settings.model_id ||
    (!settings.offline_mode && installedIds.has("gemini-3.1-flash-lite")
      ? "gemini-3.1-flash-lite"
      : !settings.offline_mode && installedIds.has("gemini-4-hydrogen")
        ? "gemini-4-hydrogen"
        : preset.model_id);
  let entry = poolInstalled.find((e) => e.id === wanted);
  if (!entry) {
    const order: Record<string, number> = { high: 2, balanced: 1, lite: 0 };
    const ceiling = order[profile] ?? 2;
    const pool = poolInstalled.filter((e) => (order[e.tier] ?? 2) <= ceiling);
    const candidates = pool.length > 0 ? pool : poolInstalled;
    entry = candidates.reduce((best, cur) => (cur.size_bytes >= best.size_bytes ? cur : best), candidates[0]);
  }
  const rawCtx = Number(settings.context_length || 0) || preset.context_length;
  const ctx = Math.max(2048, Math.min(rawCtx, entry.native_context || 32768));
  let layers = Number(settings.gpu_layers ?? -1);
  if (layers < 0) layers = hw.has_gpu ? 99 : 0;
  return {
    entry,
    model_id: entry.id,
    model_name: entry.name,
    context_length: ctx,
    gpu_layers: layers,
    profile,
  };
}
