/** Safe arithmetic evaluator and financial calculator for Fast/Think tool steps. */

export function evaluateArithmetic(expression: string): { ok: boolean; value?: number; formatted?: string; error?: string } {
  const cleaned = expression
    .replace(/,/g, "")
    .replace(/₹|\$|€/g, "")
    .replace(/\^/g, "**")
    .trim();

  if (!cleaned) {
    return { ok: false, error: "Empty expression." };
  }
  // Allow only numbers, operators, parentheses, whitespace, and a small set of math functions/constants
  const withoutAllowedWords = cleaned
    .replace(/\b(Math\.)?(sqrt|pow|abs|round|floor|ceil|min|max|log|exp|sin|cos|tan|PI|E)\b/g, "");
  if (/[^0-9+\-*/%().\s]/.test(withoutAllowedWords)) {
    return { ok: false, error: "Unsupported characters in arithmetic expression." };
  }

  const jsExpr = cleaned.replace(
    /\b(sqrt|pow|abs|round|floor|ceil|min|max|log|exp|sin|cos|tan|PI|E)\b/g,
    (m) => (m.startsWith("Math.") ? m : `Math.${m}`),
  );

  try {
    const fn = new Function(`"use strict"; return (${jsExpr});`);
    const result = fn();
    if (typeof result !== "number" || !Number.isFinite(result)) {
      return { ok: false, error: "Expression did not evaluate to a finite number." };
    }
    const rounded = Math.round(result * 1e8) / 1e8;
    return {
      ok: true,
      value: rounded,
      formatted: Number.isInteger(rounded) ? rounded.toLocaleString("en-IN") : rounded.toLocaleString("en-IN", { maximumFractionDigits: 4 }),
    };
  } catch {
    return { ok: false, error: "Invalid mathematical syntax." };
  }
}

export interface LoanEmiResult {
  principal: number;
  annualRatePct: number;
  months: number;
  monthlyRate: number;
  emi: number;
  totalPayment: number;
  totalInterest: number;
}

export function computeLoanEmi(principal: number, annualRatePct: number, years: number): LoanEmiResult {
  const months = Math.round(years * 12);
  const monthlyRate = annualRatePct / 12 / 100;
  let emi = 0;
  if (monthlyRate === 0) {
    emi = principal / months;
  } else {
    const factor = Math.pow(1 + monthlyRate, months);
    emi = (principal * monthlyRate * factor) / (factor - 1);
  }
  const totalPayment = emi * months;
  const totalInterest = totalPayment - principal;
  return {
    principal,
    annualRatePct,
    months,
    monthlyRate,
    emi,
    totalPayment,
    totalInterest,
  };
}
