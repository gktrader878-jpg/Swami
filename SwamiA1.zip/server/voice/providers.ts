import { GoogleGenAI } from "@google/genai";
import { browserEngine } from "../browser/service";
import { buildDocumentContext } from "../documents";
import { detectMemorySuggestions } from "../memory/engine";
import { modelRouter } from "../models/router";
import { normalizeApiBaseUrl } from "../providers";
import { runDeepResearch, type ResearchSynthesisModel } from "../research/service";
import { redactSensitive } from "../security/secrets";
import { validateExternalUrl } from "../security/validation";
import { skillRegistry } from "../skills/registry";
import { runMatchingSkills } from "../agents/orchestrator";
import { store, type SwamiStore } from "../store";
import type {
  Conversation,
  MemorySuggestion,
  MemoryUsed,
  Message,
  Mode,
  Source,
  Step,
  VoiceCapabilities,
  VoiceSttProvider,
  VoiceTtsProvider,
} from "../types";
import { matchVoiceShortcut } from "./shortcuts";
import {
  classifyVoiceIntent,
  formatTextForSpeech,
  GEMINI_STT_MODEL,
  GEMINI_TTS_MODEL,
  GEMINI_TTS_QUALITY_MODEL,
  resolveGeminiVoiceName,
  resolveOpenAiVoiceName,
  resolveVoiceLanguage,
  SUPPORTED_VOICE_LANGUAGES,
  VOICE_CATALOG,
} from "./engine";

function getGeminiKey(activeStore: SwamiStore): string {
  return (activeStore.getProviderApiKey("gemini") || process.env.GEMINI_API_KEY || "").trim();
}

function createGeminiClient(apiKey: string): GoogleGenAI {
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

function getOpenAiVoiceCreds(activeStore: SwamiStore): { baseUrl: string; apiKey: string } | null {
  const provider = activeStore.getProvider("openai");
  const apiKey = activeStore.getProviderApiKey("openai") || (process.env.OPENAI_API_KEY || "").trim();
  if (!apiKey) return null;
  const baseUrl = normalizeApiBaseUrl(provider?.base_url || "https://api.openai.com/v1");
  return { baseUrl, apiKey };
}

function getGroqSttCreds(activeStore: SwamiStore): { baseUrl: string; apiKey: string } | null {
  const provider = activeStore.getProvider("groq");
  const apiKey = activeStore.getProviderApiKey("groq") || (process.env.GROQ_API_KEY || "").trim();
  if (!apiKey) return null;
  const baseUrl = normalizeApiBaseUrl(provider?.base_url || "https://api.groq.com/openai/v1");
  return { baseUrl, apiKey };
}

export function getVoiceCapabilities(activeStore: SwamiStore = store): VoiceCapabilities {
  const s = activeStore.getSettings();
  const offline = Boolean(s.offline_mode);
  const geminiKey = offline ? "" : getGeminiKey(activeStore);
  const openAiCreds = offline ? null : getOpenAiVoiceCreds(activeStore);
  const groqCreds = offline ? null : getGroqSttCreds(activeStore);

  const geminiLiveAvailable = Boolean(geminiKey);
  const geminiSttAvailable = Boolean(geminiKey);
  const geminiTtsAvailable = Boolean(geminiKey);
  const openaiSttAvailable = Boolean(openAiCreds);
  const openaiTtsAvailable = Boolean(openAiCreds);
  const groqSttAvailable = Boolean(groqCreds);

  const recommendedEngine =
    !offline && s.voice_provider !== "router_pipeline" && geminiLiveAvailable
      ? "gemini_live"
      : "router_pipeline";

  const recommendedStt = geminiSttAvailable
    ? "gemini"
    : openaiSttAvailable
      ? "openai"
      : groqSttAvailable
        ? "groq"
        : "browser";

  const recommendedTts = geminiTtsAvailable
    ? "gemini"
    : openaiTtsAvailable
      ? "openai"
      : "browser";

  return {
    voice_enabled: Boolean(s.voice_enabled),
    offline_mode: offline,
    gemini_live_available: geminiLiveAvailable,
    gemini_stt_available: geminiSttAvailable,
    gemini_tts_available: geminiTtsAvailable,
    openai_stt_available: openaiSttAvailable,
    openai_tts_available: openaiTtsAvailable,
    groq_stt_available: groqSttAvailable,
    browser_fallback_available: true,
    recommended_engine: recommendedEngine,
    recommended_stt: recommendedStt,
    recommended_tts: recommendedTts,
    languages: SUPPORTED_VOICE_LANGUAGES,
    voices: VOICE_CATALOG,
  };
}

export interface SttResult {
  transcript: string;
  provider_used: "gemini" | "openai" | "groq";
  language: string;
  latency_ms: number;
  fallback_used: boolean;
  warning?: string;
}

async function transcribeWithOpenAiCompatible(params: {
  baseUrl: string;
  apiKey: string;
  model: string;
  audioBuffer: Buffer;
  mimeType: string;
  languageCode: string;
  providerLabel: "openai" | "groq";
  signal?: AbortSignal;
}): Promise<string> {
  validateExternalUrl(params.baseUrl, { allowLocalhost: true, requireHttpsForRemote: true });
  const ext = params.mimeType.includes("wav")
    ? "wav"
    : params.mimeType.includes("ogg")
      ? "ogg"
      : params.mimeType.includes("mp4") || params.mimeType.includes("m4a")
        ? "m4a"
        : "webm";

  const form = new FormData();
  form.append("file", new Blob([new Uint8Array(params.audioBuffer)], { type: params.mimeType }), `audio.${ext}`);
  form.append("model", params.model);
  const shortLang = params.languageCode === "auto" ? "" : params.languageCode.split("-")[0];
  if (shortLang) form.append("language", shortLang);

  const endpoint = `${params.baseUrl.replace(/\/+$/, "")}/audio/transcriptions`;
  const resp = await fetch(endpoint, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${params.apiKey}`,
    },
    body: form,
    signal: params.signal,
  });
  const bodyText = await resp.text();
  if (!resp.ok) {
    throw new Error(`${params.providerLabel.toUpperCase()} STT failed (${resp.status}): ${redactSensitive(bodyText.slice(0, 220))}`);
  }
  const parsed = JSON.parse(bodyText) as { text?: string };
  return (parsed.text ?? "").trim();
}

export async function transcribeAudio(params: {
  activeStore?: SwamiStore;
  audioBuffer: Buffer;
  mimeType: string;
  language?: string;
  preferredProvider?: VoiceSttProvider;
  signal?: AbortSignal;
}): Promise<SttResult> {
  const activeStore = params.activeStore ?? store;
  const settings = activeStore.getSettings();
  if (settings.offline_mode) {
    throw new Error("Offline mode is enabled. Switch to Browser Speech Recognition or disable Offline mode.");
  }
  if (!params.audioBuffer || params.audioBuffer.byteLength < 64) {
    throw new Error("Captured audio clip was too short or empty.");
  }

  const startedAt = performance.now();
  const lang = resolveVoiceLanguage(params.language || settings.voice_language);
  const pref = params.preferredProvider ?? settings.voice_stt_provider ?? "auto";

  const geminiKey = getGeminiKey(activeStore);
  const openAiCreds = getOpenAiVoiceCreds(activeStore);
  const groqCreds = getGroqSttCreds(activeStore);

  const candidates: Array<"gemini" | "openai" | "groq"> = [];
  if (pref === "gemini") candidates.push("gemini");
  else if (pref === "openai") candidates.push("openai");
  else if (pref === "groq") candidates.push("groq");
  else if (pref === "browser") {
    throw new Error("Browser Speech Recognition selected; client handles speech recognition locally.");
  } else {
    if (geminiKey) candidates.push("gemini");
    if (groqCreds) candidates.push("groq");
    if (openAiCreds) candidates.push("openai");
  }

  if (candidates.length === 0) {
    throw new Error("No cloud Speech-to-Text API key is configured. Add Gemini, OpenAI, or Groq key, or use Browser speech recognition.");
  }

  const errors: string[] = [];
  for (let i = 0; i < candidates.length; i++) {
    const provider = candidates[i];
    try {
      if (provider === "gemini") {
        if (!geminiKey) throw new Error("Gemini API key is not configured.");
        const ai = createGeminiClient(geminiKey);
        const langHint =
          lang.code === "hi-IN"
            ? "The speaker is speaking Hindi (hi-IN, Devanagari or Hinglish). Transcribe accurately without translating."
            : lang.code === "auto"
              ? "Transcribe verbatim in the spoken language (English or Hindi). Do not translate or invent words."
              : `Transcribe verbatim in ${lang.label} (${lang.bcp47}). Do not answer or add commentary.`;

        const res = await ai.models.generateContent({
          model: GEMINI_STT_MODEL,
          contents: [
            { text: `${langHint} Return only the verbatim transcript.` },
            { inlineData: { mimeType: params.mimeType || "audio/webm", data: params.audioBuffer.toString("base64") } },
          ],
        });
        const transcript = (res.text ?? "").trim();
        return {
          transcript,
          provider_used: "gemini",
          language: lang.code,
          latency_ms: Math.round(performance.now() - startedAt),
          fallback_used: i > 0,
          ...(i > 0 && errors.length ? { warning: `Primary STT failed (${errors[0]}); used Gemini fallback.` } : {}),
        };
      }

      if (provider === "openai") {
        if (!openAiCreds) throw new Error("OpenAI API key is not configured.");
        const transcript = await transcribeWithOpenAiCompatible({
          ...openAiCreds,
          model: "whisper-1",
          audioBuffer: params.audioBuffer,
          mimeType: params.mimeType || "audio/webm",
          languageCode: lang.code,
          providerLabel: "openai",
          signal: params.signal,
        });
        return {
          transcript,
          provider_used: "openai",
          language: lang.code,
          latency_ms: Math.round(performance.now() - startedAt),
          fallback_used: i > 0,
          ...(i > 0 && errors.length ? { warning: `Primary STT failed (${errors[0]}); used OpenAI Whisper.` } : {}),
        };
      }

      if (provider === "groq") {
        if (!groqCreds) throw new Error("Groq API key is not configured.");
        const transcript = await transcribeWithOpenAiCompatible({
          ...groqCreds,
          model: "whisper-large-v3-turbo",
          audioBuffer: params.audioBuffer,
          mimeType: params.mimeType || "audio/webm",
          languageCode: lang.code,
          providerLabel: "groq",
          signal: params.signal,
        });
        return {
          transcript,
          provider_used: "groq",
          language: lang.code,
          latency_ms: Math.round(performance.now() - startedAt),
          fallback_used: i > 0,
          ...(i > 0 && errors.length ? { warning: `Primary STT failed (${errors[0]}); used Groq Whisper.` } : {}),
        };
      }
    } catch (err) {
      errors.push(redactSensitive(err instanceof Error ? err.message : String(err)));
    }
  }

  throw new Error(errors.join(" | ") || "Speech transcription failed.");
}

export interface TtsResult {
  audio_base64: string;
  mime_type: string;
  provider_used: "gemini" | "openai";
  voice_name: string;
  latency_ms: number;
  fallback_used: boolean;
  warning?: string;
}

export async function synthesizeSpeech(params: {
  activeStore?: SwamiStore;
  text: string;
  voiceName?: string;
  speed?: number;
  language?: string;
  preferredProvider?: VoiceTtsProvider;
  highQuality?: boolean;
  signal?: AbortSignal;
}): Promise<TtsResult> {
  const activeStore = params.activeStore ?? store;
  const settings = activeStore.getSettings();
  if (settings.offline_mode) {
    throw new Error("Offline mode is enabled; use Browser SpeechSynthesis fallback.");
  }

  const spokenText = formatTextForSpeech(params.text, 1600);
  if (!spokenText) {
    throw new Error("No speakable text provided for synthesis.");
  }

  const startedAt = performance.now();
  const pref = params.preferredProvider ?? settings.voice_tts_provider ?? "auto";
  if (pref === "browser") {
    throw new Error("Browser SpeechSynthesis is selected.");
  }

  const geminiKey = getGeminiKey(activeStore);
  const openAiCreds = getOpenAiVoiceCreds(activeStore);

  const candidates: Array<"gemini" | "openai"> = [];
  if (pref === "gemini") candidates.push("gemini");
  else if (pref === "openai") candidates.push("openai");
  else {
    if (geminiKey) candidates.push("gemini");
    if (openAiCreds) candidates.push("openai");
  }

  if (candidates.length === 0) {
    throw new Error("No cloud Text-to-Speech API key is configured. Use Browser SpeechSynthesis fallback or add Gemini/OpenAI key.");
  }

  const speed = Math.min(2.0, Math.max(0.6, Number(params.speed ?? settings.voice_speed ?? 1.0)));
  const errors: string[] = [];

  for (let i = 0; i < candidates.length; i++) {
    const provider = candidates[i];
    try {
      if (provider === "gemini") {
        if (!geminiKey) throw new Error("Gemini API key is not configured.");
        const ai = createGeminiClient(geminiKey);
        const chosenVoice = resolveGeminiVoiceName(params.voiceName || settings.voice_name);
        const ttsModel = params.highQuality ? GEMINI_TTS_QUALITY_MODEL : GEMINI_TTS_MODEL;
        const resp = await ai.models.generateContent({
          model: ttsModel,
          contents: spokenText,
          config: {
            responseModalities: ["AUDIO"],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: chosenVoice },
              },
            },
          },
        });
        const inlineData = resp.candidates?.[0]?.content?.parts?.[0]?.inlineData;
        if (!inlineData?.data) {
          throw new Error("Gemini TTS returned empty audio payload.");
        }
        return {
          audio_base64: inlineData.data,
          mime_type: inlineData.mimeType || "audio/wav",
          provider_used: "gemini",
          voice_name: chosenVoice,
          latency_ms: Math.round(performance.now() - startedAt),
          fallback_used: i > 0,
          ...(i > 0 && errors.length ? { warning: `Primary TTS failed (${errors[0]}); used Gemini TTS.` } : {}),
        };
      }

      if (provider === "openai") {
        if (!openAiCreds) throw new Error("OpenAI API key is not configured.");
        validateExternalUrl(openAiCreds.baseUrl, { allowLocalhost: true, requireHttpsForRemote: true });
        const chosenVoice = resolveOpenAiVoiceName(params.voiceName || settings.voice_name);
        const endpoint = `${openAiCreds.baseUrl.replace(/\/+$/, "")}/audio/speech`;
        const resp = await fetch(endpoint, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${openAiCreds.apiKey}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: "tts-1",
            voice: chosenVoice,
            input: spokenText,
            response_format: "wav",
            speed,
          }),
          signal: params.signal,
        });
        if (!resp.ok) {
          const errText = await resp.text();
          throw new Error(`OpenAI TTS failed (${resp.status}): ${redactSensitive(errText.slice(0, 220))}`);
        }
        const buf = Buffer.from(await resp.arrayBuffer());
        return {
          audio_base64: buf.toString("base64"),
          mime_type: "audio/wav",
          provider_used: "openai",
          voice_name: chosenVoice,
          latency_ms: Math.round(performance.now() - startedAt),
          fallback_used: i > 0,
          ...(i > 0 && errors.length ? { warning: `Primary TTS failed (${errors[0]}); used OpenAI TTS.` } : {}),
        };
      }
    } catch (err) {
      errors.push(redactSensitive(err instanceof Error ? err.message : String(err)));
    }
  }

  throw new Error(errors.join(" | ") || "Text-to-Speech synthesis failed.");
}

export interface VoiceAssistantTurnResult {
  conversation: Conversation;
  user_message: Message;
  assistant_message: Message;
  spoken_text: string;
  intent: string;
  notice?: string;
  shortcut_executed?: {
    id: string;
    phrase: string;
    action: string;
    param: string;
    captured_arg: string;
  };
}

export async function executeVoiceAssistantTurn(params: {
  activeStore?: SwamiStore;
  transcript: string;
  conversationId?: string | null;
  projectId?: string | null;
  language?: string;
  mode?: Mode;
  modelId?: string;
  sttProvider?: string;
  ttsProvider?: string;
  voiceBackend?: string;
  signal?: AbortSignal;
}): Promise<VoiceAssistantTurnResult> {
  const activeStore = params.activeStore ?? store;
  const cleanTranscript = (params.transcript || "").trim();
  if (!cleanTranscript) {
    throw new Error("Transcript cannot be empty.");
  }

  const startedAt = performance.now();
  const settings = activeStore.getSettings();
  const lang = resolveVoiceLanguage(params.language || settings.voice_language);
  const matchedShortcut = matchVoiceShortcut(cleanTranscript, settings.voice_shortcuts);
  const shortcutAction = matchedShortcut?.shortcut.action;

  const effectiveTranscript =
    shortcutAction === "summarize_conversation"
      ? "Summarize our conversation clearly with key takeaways and action items."
      : shortcutAction === "run_prompt" && matchedShortcut?.shortcut.param
        ? matchedShortcut.shortcut.param.replace(/\{query\}/gi, matchedShortcut.captured_arg || cleanTranscript)
        : shortcutAction === "new_research" && matchedShortcut?.captured_arg
          ? matchedShortcut.captured_arg
          : cleanTranscript;

  const intent = classifyVoiceIntent(effectiveTranscript);
  const effectiveMode: Mode =
    shortcutAction === "new_research" || params.mode === "research" || intent.shouldUseDeepResearch
      ? "research"
      : shortcutAction === "switch_mode" && (matchedShortcut?.shortcut.param === "think" || matchedShortcut?.shortcut.param === "research")
        ? matchedShortcut.shortcut.param
        : params.mode === "think"
          ? "think"
          : "fast";

  let conv =
    shortcutAction === "new_research" || shortcutAction === "new_chat"
      ? undefined
      : params.conversationId
        ? activeStore.conversations.get(params.conversationId)
        : undefined;
  if (!conv) {
    const title =
      shortcutAction === "new_research"
        ? (matchedShortcut?.captured_arg || "New Research Project").slice(0, 50)
        : cleanTranscript.replace(/\s+/g, " ").slice(0, 50) || "Voice chat";
    conv = activeStore.createConversation(
      title,
      effectiveMode === "research" ? "research" : "chat",
      params.projectId ?? null,
    );
  }
  const cid = conv.id;

  const userMsg = activeStore.addMessage(cid, {
    role: "user",
    content: cleanTranscript,
    reasoning: "",
    mode: effectiveMode,
    steps: [],
    sources: [],
    metrics: {
      voice_turn: true,
      voice_backend: params.voiceBackend || "router_pipeline",
      voice_stt_provider: params.sttProvider || "browser",
      voice_language: lang.code,
    },
    attachments: [],
    status: "complete",
  });

  const controller = new AbortController();
  const signal = params.signal ?? controller.signal;
  const steps: Step[] = [];
  let sources: Source[] = [];
  let answerText = "";
  let reasoning = "";
  let notice = "";
  let usedProviderId = "";
  let usedProviderName = "";
  let usedModelId = "";
  let usedModelName = "";
  let usedIsLocal = false;
  let routedReason = "";
  let fallbackFrom = "";
  let promptTokens = Math.max(4, Math.round(cleanTranscript.length / 3.6));
  let completionTokens = 0;
  let tokensEstimated = true;

  // 1. Relevant Memories & Documents
  const relevantMemories = activeStore.retrieveRelevantMemories(cleanTranscript, conv.project_id, 6);
  const memoriesUsed: MemoryUsed[] = relevantMemories.map((m) => ({
    id: m.id,
    content: m.content,
    category: m.category,
    project_id: m.project_id,
  }));

  const convDocs = activeStore.listDocumentsFor(cid);
  const { contextBlock } = buildDocumentContext(
    cleanTranscript,
    convDocs.map((d) => d.id),
    activeStore.documents,
    activeStore.chunks,
    4096,
  );

  // 2. Voice shortcuts (immediate actions) or explicit memory/browser intents
  if (shortcutAction === "new_research" && !matchedShortcut?.captured_arg) {
    steps.push({
      id: "voice-shortcut",
      kind: "tool",
      title: `Voice Shortcut: ${matchedShortcut?.shortcut.phrase}`,
      detail: "Started a new Deep Research project",
      state: "done",
    });
    answerText = "Started a new Deep Research project. What topic would you like me to research?";
  } else if (shortcutAction === "new_chat") {
    steps.push({
      id: "voice-shortcut",
      kind: "tool",
      title: `Voice Shortcut: ${matchedShortcut?.shortcut.phrase}`,
      detail: "Started a new conversation",
      state: "done",
    });
    answerText = "Started a new conversation. How can I help?";
  } else if (intent.kind === "memory_save" && intent.memoryFact) {
    try {
      const saved = activeStore.addMemory(intent.memoryFact, "voice", {
        category: "general",
        project_id: conv.project_id,
      });
      steps.push({
        id: "voice-mem-save",
        kind: "memory",
        title: "Saved memory from voice",
        detail: saved.content,
        state: "done",
      });
      answerText = `Got it. I saved that to memory: "${saved.content}".`;
    } catch (err) {
      answerText = err instanceof Error ? err.message : "Could not save that memory right now.";
    }
  } else if (intent.kind === "browser" && intent.extractedUrl) {
    // Enforce exact Browser Automation allowlist and approval rules
    try {
      const bSession = browserEngine.createSession(intent.extractedUrl);
      const resultSession = await browserEngine.executeWorkflow(bSession.id, intent.extractedUrl, [
        { type: "navigate", target: intent.extractedUrl, detail: "Voice-requested page open" },
        { type: "extract", target: "body", detail: "Read page summary" },
      ]);
      steps.push({
        id: "voice-browser",
        kind: "tool",
        title: `Browser (${resultSession.status})`,
        detail: resultSession.error || resultSession.title || intent.extractedUrl,
        state: resultSession.status === "error" ? "error" : "done",
      });
      if (resultSession.status === "error") {
        answerText = `I couldn't open that page because of SWAMI's browser security rules: ${resultSession.error || "Action blocked."}`;
      } else if (resultSession.status === "awaiting_approval" && resultSession.pendingApproval) {
        answerText = `Browser action requires your manual approval in Settings → Browser: ${resultSession.pendingApproval.reason}.`;
      } else if (resultSession.extractedText) {
        answerText = `Opened ${resultSession.title || intent.extractedUrl}. ${resultSession.extractedText.slice(0, 500)}`;
      } else {
        answerText = `Opened ${resultSession.title || intent.extractedUrl}.`;
      }
    } catch (err) {
      const msg = redactSensitive(err instanceof Error ? err.message : "Blocked by browser security policy.");
      steps.push({ id: "voice-browser-err", kind: "tool", title: "Browser blocked", detail: msg, state: "error" });
      answerText = `I couldn't open that page because of SWAMI's browser security rules: ${msg}`;
    }
  } else if (effectiveMode === "research") {
    if (settings.offline_mode || settings.web_research_enabled === false) {
      answerText = "Deep Research is currently unavailable because web access or offline mode is restricted in Privacy & Research settings.";
    } else {
      const routable = activeStore.getRoutableModels();
      const synthesisModel: ResearchSynthesisModel =
        routable.length > 0
          ? {
              kind: "router",
              activeStore,
              requestedTarget: params.modelId || (settings.routing_mode === "auto" ? "auto" : settings.model_id),
            }
          : { kind: "local-extract" };

      const researchOut = await runDeepResearch({
        topic: cleanTranscript,
        searchProvider: settings.search_provider,
        searxngUrl: settings.searxng_url,
        braveApiKey: activeStore.braveApiKey,
        maxSources: Math.min(5, settings.research_max_sources || 5),
        maxRounds: 1,
        synthesisModel,
        signal,
        callbacks: {
          elapsedSec: () => Math.round(((performance.now() - startedAt) / 1000) * 100) / 100,
          onStep: (step) => {
            const idx = steps.findIndex((s) => s.id === step.id);
            if (idx >= 0) steps[idx] = { ...step };
            else steps.push({ ...step });
          },
          onSources: (webSources) => {
            sources = webSources;
          },
          onToken: () => {},
          onNotice: (msg) => {
            notice = msg;
          },
        },
      });
      answerText = researchOut.report;
      sources = researchOut.sources;
    }
  } else {
    // Run matching deterministic skills + route to Feature 1 ModelRouter
    const skillResult = await runMatchingSkills({
      prompt: cleanTranscript,
      mode: effectiveMode,
      conversationId: cid,
      projectId: conv.project_id,
      documentIds: convDocs.map((d) => d.id),
      activeStore,
      signal,
    });
    if (skillResult.results.length > 0) {
      for (const r of skillResult.results) {
        steps.push({ id: `skill-${r.skillId}`, kind: "tool", title: `Skill: ${r.skillId}`, detail: r.summary, state: "done" });
      }
    }

    const routable = activeStore.getRoutableModels();
    const usable = settings.offline_mode ? routable.filter((m) => m.is_local) : routable;

    if (usable.length > 0) {
      const historyMsgs = (activeStore.messages.get(cid) ?? [])
        .filter((m) => m.id !== userMsg.id && (m.role === "user" || m.role === "assistant"))
        .slice(-10)
        .map((m) => ({ role: m.role as "user" | "assistant", content: m.content }));

      const combinedContext = [contextBlock, skillResult.combinedContext].filter(Boolean).join("\n\n");
      const langDirective =
        lang.code === "hi-IN"
          ? "Reply naturally in Hindi (Devanagari or natural conversational Hindi as spoken) unless asked otherwise."
          : lang.code === "auto"
            ? "Reply in the same language (English or Hindi) the user used."
            : "Reply in clear, concise spoken English suitable for voice playback.";

      const systemPrompt =
        `You are SWAMI, responding in a real-time voice conversation. Keep answers accurate, helpful, and natural to listen to (prefer clear sentences over heavy markdown tables). ${langDirective}` +
        (relevantMemories.length ? `\nRelevant user memories:\n${relevantMemories.map((m) => `- ${m.content}`).join("\n")}` : "") +
        (settings.custom_instructions ? `\nCustom instructions: ${settings.custom_instructions}` : "");

      const reqTarget =
        params.modelId ||
        (settings.routing_mode === "auto" ? "auto" : settings.model_id);

      const routed = await modelRouter.stream({
        activeStore,
        requestedTarget: reqTarget || undefined,
        mode: effectiveMode,
        systemPrompt,
        messages: [
          ...historyMsgs,
          {
            role: "user",
            content: combinedContext ? `${combinedContext}\n\nUser voice request:\n${cleanTranscript}` : cleanTranscript,
          },
        ],
        promptForRouting: cleanTranscript,
        signal,
        onToken: () => {},
        onReasoning: (rTok) => {
          reasoning += rTok;
        },
        onModelSelected: (info) => {
          usedProviderId = info.provider_id;
          usedProviderName = info.provider_name;
          usedModelId = info.model_id;
          usedModelName = info.model_name;
          usedIsLocal = info.is_local;
          routedReason = info.reason ?? "";
          fallbackFrom = info.fallback_from ?? "";
        },
        onNotice: (m) => {
          notice = m;
        },
      });
      answerText = routed.text || "";
      if (routed.reasoning) reasoning = routed.reasoning;
      promptTokens = routed.promptTokens ?? promptTokens;
      completionTokens = routed.completionTokens ?? Math.max(4, Math.round(answerText.length / 3.6));
      tokensEstimated = routed.tokensEstimated;
    } else if (skillResult.results.length > 0) {
      answerText = skillResult.results.map((r) => r.summary).join(" ");
    } else if (relevantMemories.length > 0 && intent.kind === "memory_query") {
      answerText = `Here is what I remember: ${relevantMemories.map((m) => m.content).join("; ")}.`;
    } else {
      throw new Error(
        settings.offline_mode
          ? "No local AI model (Ollama or LM Studio) is configured for offline voice replies."
          : "No AI model provider is configured. Add an API key in Settings → API providers.",
      );
    }
  }

  let memorySuggestions: MemorySuggestion[] = [];
  if (settings.memory_enabled && settings.memory_auto_suggest && answerText.trim()) {
    memorySuggestions = detectMemorySuggestions(
      cleanTranscript,
      answerText,
      conv.project_id,
      Array.from(activeStore.memories.values()),
    );
  }

  const latencyMs = Math.round(performance.now() - startedAt);
  const totalSec = Math.max(0.1, Math.round((latencyMs / 1000) * 100) / 100);
  const finalCompletionTokens = completionTokens || Math.max(4, Math.round(answerText.length / 3.6));

  const assistantMsg = activeStore.addMessage(cid, {
    role: "assistant",
    content: answerText,
    reasoning,
    mode: effectiveMode,
    steps,
    sources,
    memories_used: memoriesUsed.length ? memoriesUsed : undefined,
    memory_suggestions: memorySuggestions.length ? memorySuggestions : undefined,
    metrics: {
      provider_id: usedProviderId || "voice",
      provider_name: usedProviderName || "SWAMI Voice",
      model_id: usedModelId || "voice-assistant",
      model_name: usedModelName || "Voice Assistant",
      is_local: usedIsLocal,
      ...(routedReason ? { routed_reason: routedReason } : {}),
      ...(fallbackFrom ? { fallback_from: fallbackFrom } : {}),
      total_s: totalSec,
      first_token_s: totalSec,
      prompt_tokens: promptTokens,
      completion_tokens: finalCompletionTokens,
      total_tokens: promptTokens + finalCompletionTokens,
      tokens_estimated: tokensEstimated,
      tokens_per_second: Math.round((finalCompletionTokens / totalSec) * 10) / 10,
      model_calls: 1,
      tool_calls: steps.filter((s) => s.kind === "tool").length,
      voice_turn: true,
      voice_backend: params.voiceBackend || "router_pipeline",
      voice_stt_provider: params.sttProvider || "browser",
      voice_tts_provider: params.ttsProvider || "browser",
      voice_language: lang.code,
      voice_latency_ms: latencyMs,
    },
    attachments: [],
    status: "complete",
  });

  // Ensure skill audit compatibility when skill used
  void skillRegistry;

  return {
    conversation: conv,
    user_message: userMsg,
    assistant_message: assistantMsg,
    spoken_text: formatTextForSpeech(answerText, 1400),
    intent: matchedShortcut ? `shortcut:${matchedShortcut.shortcut.action}` : intent.kind,
    ...(notice ? { notice } : {}),
    ...(matchedShortcut
      ? {
          shortcut_executed: {
            id: matchedShortcut.shortcut.id,
            phrase: matchedShortcut.shortcut.phrase,
            action: matchedShortcut.shortcut.action,
            param: matchedShortcut.shortcut.param || "",
            captured_arg: matchedShortcut.captured_arg,
          },
        }
      : {}),
  };
}
