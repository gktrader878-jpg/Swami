import type { Server as HttpServer, IncomingMessage } from "node:http";
import { URL } from "node:url";
import {
  Behavior,
  FunctionResponseScheduling,
  GoogleGenAI,
  Modality,
  Type,
  type FunctionDeclaration,
  type LiveServerMessage,
} from "@google/genai";
import { WebSocket, WebSocketServer } from "ws";
import { browserEngine } from "../browser/service";
import { evaluateArithmetic } from "../calculator";
import { searchDocumentChunks } from "../documents";
import { detectMemorySuggestions } from "../memory/engine";
import { runDeepResearch, type ResearchSynthesisModel } from "../research/service";
import { logEvent } from "../security/middleware";
import { redactSensitive } from "../security/secrets";
import { skillRegistry } from "../skills/registry";
import { store, type SwamiStore } from "../store";
import {
  formatTextForSpeech,
  GEMINI_LIVE_MODEL,
  GEMINI_LIVE_TRANSCRIBE_MODEL,
  resolveGeminiVoiceName,
  resolveVoiceLanguage,
  voiceSessionManager,
} from "./engine";

function getLiveTools(): FunctionDeclaration[] {
  return [
    {
      name: "deep_research",
      description: "Search the live web using SWAMI Deep Research to verify current events, documentation, or multi-source facts.",
      behavior: Behavior.NON_BLOCKING,
      parameters: {
        type: Type.OBJECT,
        properties: {
          topic: { type: Type.STRING, description: "Search topic or question to research online." },
        },
        required: ["topic"],
      },
    },
    {
      name: "save_memory",
      description: "Save a durable user preference, instruction, or personal fact into SWAMI persistent memory.",
      behavior: Behavior.NON_BLOCKING,
      parameters: {
        type: Type.OBJECT,
        properties: {
          fact: { type: Type.STRING, description: "Concise fact to remember." },
          category: { type: Type.STRING, description: "One of preference, project, instruction, fact, learning, general." },
        },
        required: ["fact"],
      },
    },
    {
      name: "search_memory",
      description: "Search SWAMI persistent memory for previously saved user facts, preferences, or project notes.",
      behavior: Behavior.NON_BLOCKING,
      parameters: {
        type: Type.OBJECT,
        properties: {
          query: { type: Type.STRING, description: "Keywords to search in user memories." },
        },
        required: ["query"],
      },
    },
    {
      name: "calculator",
      description: "Evaluate exact math or financial arithmetic expressions accurately.",
      behavior: Behavior.NON_BLOCKING,
      parameters: {
        type: Type.OBJECT,
        properties: {
          expression: { type: Type.STRING, description: "Arithmetic expression to compute." },
        },
        required: ["expression"],
      },
    },
    {
      name: "search_documents",
      description: "Search uploaded documents attached to the current SWAMI conversation.",
      behavior: Behavior.NON_BLOCKING,
      parameters: {
        type: Type.OBJECT,
        properties: {
          query: { type: Type.STRING, description: "Question or keywords to search inside attached documents." },
        },
        required: ["query"],
      },
    },
    {
      name: "browser_open",
      description: "Open an allowed website URL using SWAMI Browser Automation (respects allowlist and approval policies).",
      behavior: Behavior.NON_BLOCKING,
      parameters: {
        type: Type.OBJECT,
        properties: {
          url: { type: Type.STRING, description: "Full https:// URL to open and summarize." },
        },
        required: ["url"],
      },
    },
  ];
}

export interface LiveVoiceWsController {
  closeAll: () => void;
  getActiveConnections: () => number;
}

export function attachVoiceWebSocketServer(
  httpServer: HttpServer,
  activeStore: SwamiStore = store,
): LiveVoiceWsController {
  const wss = new WebSocketServer({ noServer: true });
  const connections = new Set<WebSocket>();

  const onUpgrade = (req: IncomingMessage, socket: import("node:net").Socket, head: Buffer) => {
    try {
      const parsed = new URL(req.url || "/", `http://${req.headers.host || "localhost"}`);
      if (parsed.pathname !== "/ws/voice") return;
      wss.handleUpgrade(req, socket, head, (ws) => {
        wss.emit("connection", ws, req, parsed);
      });
    } catch {
      socket.destroy();
    }
  };

  httpServer.on("upgrade", onUpgrade);

  wss.on("connection", async (ws: WebSocket, _req: IncomingMessage, parsedUrl?: URL) => {
    connections.add(ws);
    const sendJson = (payload: Record<string, unknown>) => {
      if (ws.readyState === WebSocket.OPEN) {
        try {
          ws.send(JSON.stringify(payload));
        } catch {
          /* ignore send error on closing socket */
        }
      }
    };

    const urlObj = parsedUrl ?? new URL(_req.url || "/", "http://localhost");
    const sessionId = urlObj.searchParams.get("session") || "";
    const sessionMeta = sessionId ? voiceSessionManager.getSession(sessionId) : null;
    if (!sessionMeta) {
      sendJson({ type: "error", code: "INVALID_SESSION", message: "Voice session is missing or expired." });
      ws.close(4001, "Invalid session");
      connections.delete(ws);
      return;
    }

    const settings = activeStore.getSettings();
    const apiKey = (activeStore.getProviderApiKey("gemini") || process.env.GEMINI_API_KEY || "").trim();
    if (settings.offline_mode) {
      sendJson({
        type: "error",
        code: "OFFLINE_MODE",
        message: "Offline mode is active; Gemini Live WebSocket cannot connect.",
      });
      ws.close(4003, "Offline mode");
      connections.delete(ws);
      return;
    }
    if (!apiKey) {
      sendJson({
        type: "error",
        code: "NO_GEMINI_KEY",
        message: "Gemini API key is not configured for Live Voice.",
      });
      ws.close(4003, "Missing Gemini key");
      connections.delete(ws);
      return;
    }

    let conversationId = sessionMeta.conversationId;
    const projectId = sessionMeta.projectId;
    const lang = resolveVoiceLanguage(sessionMeta.language);
    const voiceName = resolveGeminiVoiceName(sessionMeta.voiceName);
    const isTranscribeOnly = sessionMeta.mode === "gemini_transcribe_live";

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: { "User-Agent": "aistudio-build" },
      },
    });

    let liveSession: Awaited<ReturnType<typeof ai.live.connect>> | null = null;
    let isClosing = false;
    let currentUserTranscript = "";
    let currentAssistantTranscript = "";
    let turnStartedAt = Date.now();
    const turnSteps: Array<{ id: string; kind: string; title: string; detail: string; state: "done" | "error" }> = [];
    const pendingAudioFrames: string[] = [];

    const heartbeat = setInterval(() => {
      if (ws.readyState === WebSocket.OPEN) {
        sendJson({ type: "heartbeat", ts: Date.now() });
      }
    }, 20_000);

    const persistVoiceTurn = () => {
      const userText = currentUserTranscript.trim();
      const assistantText = currentAssistantTranscript.trim();
      if (!userText && !assistantText) return;

      let conv = conversationId ? activeStore.conversations.get(conversationId) : undefined;
      if (!conv) {
        const title = (userText || assistantText || "Voice chat").replace(/\s+/g, " ").slice(0, 50);
        conv = activeStore.createConversation(title, "chat", projectId);
        conversationId = conv.id;
      }

      const latencyMs = Math.max(100, Date.now() - turnStartedAt);
      const userMsg = userText
        ? activeStore.addMessage(conv.id, {
            role: "user",
            content: userText,
            reasoning: "",
            mode: "fast",
            steps: [],
            sources: [],
            metrics: {
              voice_turn: true,
              voice_backend: "gemini_live",
              voice_stt_provider: "gemini_live",
              voice_language: lang.code,
            },
            attachments: [],
            status: "complete",
          })
        : null;

      let assistantMsg = null;
      if (assistantText) {
        const memorySuggestions =
          settings.memory_enabled && settings.memory_auto_suggest
            ? detectMemorySuggestions(
                userText || assistantText,
                assistantText,
                conv.project_id,
                Array.from(activeStore.memories.values()),
              )
            : [];
        const totalSec = Math.max(0.1, Math.round((latencyMs / 1000) * 100) / 100);
        const completionTokens = Math.max(4, Math.round(assistantText.length / 3.6));
        const promptTokens = Math.max(4, Math.round((userText || "").length / 3.6));
        assistantMsg = activeStore.addMessage(conv.id, {
          role: "assistant",
          content: assistantText,
          reasoning: "",
          mode: "fast",
          steps: [...turnSteps],
          sources: [],
          memory_suggestions: memorySuggestions.length ? memorySuggestions : undefined,
          metrics: {
            provider_id: "gemini",
            provider_name: "Google Gemini",
            model_id: GEMINI_LIVE_MODEL,
            model_name: "Gemini 3.8 Live",
            is_local: false,
            total_s: totalSec,
            first_token_s: totalSec,
            prompt_tokens: promptTokens,
            completion_tokens: completionTokens,
            total_tokens: promptTokens + completionTokens,
            tokens_estimated: true,
            tokens_per_second: Math.round((completionTokens / totalSec) * 10) / 10,
            model_calls: 1,
            tool_calls: turnSteps.length,
            voice_turn: true,
            voice_backend: "gemini_live",
            voice_stt_provider: "gemini_live",
            voice_tts_provider: "gemini_live",
            voice_language: lang.code,
            voice_latency_ms: latencyMs,
          },
          attachments: [],
          status: "complete",
        });
      }

      sendJson({
        type: "turn_persisted",
        conversation: conv,
        user_message: userMsg,
        assistant_message: assistantMsg,
      });

      currentUserTranscript = "";
      currentAssistantTranscript = "";
      turnSteps.length = 0;
      turnStartedAt = Date.now();
    };

    const runToolCall = async (fc: { id?: string; name?: string; args?: Record<string, unknown> }) => {
      const name = fc.name || "";
      const args = fc.args ?? {};
      let result: Record<string, unknown> = {};
      try {
        if (name === "calculator") {
          const expr = String(args.expression || "");
          const val = evaluateArithmetic(expr);
          turnSteps.push({ id: `live-calc-${Date.now()}`, kind: "tool", title: "Calculator", detail: `${expr} = ${val}`, state: "done" });
          result = { value: val };
        } else if (name === "save_memory") {
          const fact = String(args.fact || "").trim();
          const saved = activeStore.addMemory(fact, "voice", {
            category: String(args.category || "general"),
            project_id: projectId,
          });
          turnSteps.push({ id: `live-mem-save-${Date.now()}`, kind: "memory", title: "Memory saved", detail: saved.content, state: "done" });
          result = { saved: true, content: saved.content };
        } else if (name === "search_memory") {
          const q = String(args.query || "");
          const mems = activeStore.retrieveRelevantMemories(q, projectId, 6);
          turnSteps.push({ id: `live-mem-q-${Date.now()}`, kind: "memory", title: `Searched memory (${mems.length})`, detail: q, state: "done" });
          result = { memories: mems.map((m) => ({ category: m.category, content: m.content })) };
        } else if (name === "search_documents") {
          const q = String(args.query || "");
          const docIds = conversationId ? activeStore.listDocumentsFor(conversationId).map((d) => d.id) : [];
          const hits = searchDocumentChunks(q, docIds, activeStore.documents, activeStore.chunks, 4);
          turnSteps.push({ id: `live-doc-${Date.now()}`, kind: "documents", title: `Document search (${hits.length})`, detail: q, state: "done" });
          result = { passages: hits.map((h) => ({ document: h.name, text: h.text.slice(0, 600) })) };
        } else if (name === "deep_research") {
          const topic = String(args.topic || "");
          const synth: ResearchSynthesisModel = { kind: "router", activeStore };
          const ac = new AbortController();
          const researchOut = await runDeepResearch({
            topic,
            searchProvider: settings.search_provider,
            searxngUrl: settings.searxng_url,
            braveApiKey: activeStore.braveApiKey,
            maxSources: 4,
            maxRounds: 1,
            synthesisModel: synth,
            signal: ac.signal,
            callbacks: {
              elapsedSec: () => 0.1,
              onStep: () => {},
              onSources: () => {},
              onToken: () => {},
            },
          });
          turnSteps.push({ id: `live-research-${Date.now()}`, kind: "search", title: "Deep Research", detail: topic, state: "done" });
          result = {
            summary: formatTextForSpeech(researchOut.report, 900),
            sources: researchOut.sources.slice(0, 4).map((s) => ({ title: s.title, url: s.url })),
          };
        } else if (name === "browser_open") {
          const url = String(args.url || "").trim();
          const bSession = browserEngine.createSession(url);
          const executed = await browserEngine.executeWorkflow(bSession.id, url, [
            { type: "navigate", target: url, detail: "Voice-requested page open" },
            { type: "extract", target: "body", detail: "Read content" },
          ]);
          turnSteps.push({
            id: `live-browser-${Date.now()}`,
            kind: "tool",
            title: `Browser (${executed.status})`,
            detail: executed.error || url,
            state: executed.status === "error" ? "error" : "done",
          });
          result =
            executed.status === "error"
              ? { error: executed.error || "Blocked by browser security policy." }
              : {
                  status: executed.status,
                  title: executed.title,
                  requiresApproval: Boolean(executed.pendingApproval),
                  reason: executed.pendingApproval?.reason,
                  summary: executed.extractedText?.slice(0, 600),
                };
        } else if (name === "run_skill") {
          const skillId = String(args.skillId || "");
          const out = await skillRegistry.executeSkill(skillId, args, { store: activeStore, conversationId: conversationId ?? undefined });
          result = { summary: out.summary, output: out.output };
        } else {
          result = { error: `Unknown tool ${name}` };
        }
      } catch (err) {
        const msg = redactSensitive(err instanceof Error ? err.message : String(err));
        turnSteps.push({ id: `live-err-${Date.now()}`, kind: "tool", title: `${name} failed`, detail: msg, state: "error" });
        result = { error: msg };
      }

      if (liveSession && !isClosing && fc.id) {
        try {
          liveSession.sendToolResponse({
            functionResponses: [
              {
                id: fc.id,
                name,
                response: {
                  result,
                  scheduling: FunctionResponseScheduling.INTERRUPT,
                },
              },
            ],
          });
        } catch {
          /* ignore if session closed */
        }
      }
    };

    const memories = activeStore.retrieveRelevantMemories("", projectId, 6);
    const liveSystemInstruction =
      `You are SWAMI, an accurate, natural conversational voice AI assistant. Keep spoken answers crisp, clear, and easy to listen to. Preferred language: ${lang.label} (${lang.bcp47}).` +
      (memories.length ? `\nKnown user memories:\n${memories.map((m) => `- ${m.content}`).join("\n")}` : "") +
      (settings.custom_instructions ? `\nCustom instructions: ${settings.custom_instructions}` : "");

    try {
      liveSession = await ai.live.connect({
        model: isTranscribeOnly ? GEMINI_LIVE_TRANSCRIBE_MODEL : GEMINI_LIVE_MODEL,
        config: isTranscribeOnly
          ? {
              responseModalities: [Modality.TEXT],
              inputAudioTranscription: {},
            }
          : {
              responseModalities: [Modality.AUDIO],
              speechConfig: {
                voiceConfig: {
                  prebuiltVoiceConfig: { voiceName },
                },
              },
              inputAudioTranscription: {},
              outputAudioTranscription: {},
              systemInstruction: liveSystemInstruction,
              tools: [{ functionDeclarations: getLiveTools() }],
            },
        callbacks: {
          onopen: () => {
            logEvent("info", "gemini_live_connected", { sessionId, model: isTranscribeOnly ? GEMINI_LIVE_TRANSCRIBE_MODEL : GEMINI_LIVE_MODEL });
            sendJson({
              type: "ready",
              session_id: sessionId,
              mode: sessionMeta.mode,
              voice_name: voiceName,
              language: lang.code,
            });
            while (pendingAudioFrames.length > 0 && liveSession && !isClosing) {
              const frame = pendingAudioFrames.shift();
              if (frame) {
                liveSession.sendRealtimeInput({
                  audio: { data: frame, mimeType: "audio/pcm;rate=16000" },
                });
              }
            }
          },
          onmessage: (msg: LiveServerMessage) => {
            if (isClosing) return;

            if (msg.serverContent?.interrupted) {
              sendJson({ type: "interrupted" });
            }

            const inputTx = msg.serverContent?.inputTranscription?.text;
            if (inputTx) {
              currentUserTranscript += inputTx;
              sendJson({ type: "input_transcript", text: inputTx, cumulative: currentUserTranscript });
            }

            const outputTx = msg.serverContent?.outputTranscription?.text;
            if (outputTx) {
              currentAssistantTranscript += outputTx;
              sendJson({ type: "output_transcript", text: outputTx, cumulative: currentAssistantTranscript });
            }

            const parts = msg.serverContent?.modelTurn?.parts ?? [];
            for (const part of parts) {
              if (part.inlineData?.data) {
                sendJson({
                  type: "audio",
                  data: part.inlineData.data,
                  mimeType: part.inlineData.mimeType || "audio/pcm;rate=24000",
                  sampleRate: 24000,
                });
              }
              if (part.text && !isTranscribeOnly) {
                if (!outputTx) {
                  currentAssistantTranscript += part.text;
                  sendJson({ type: "output_transcript", text: part.text, cumulative: currentAssistantTranscript });
                }
              }
            }

            if (msg.toolCall?.functionCalls?.length) {
              for (const fc of msg.toolCall.functionCalls) {
                sendJson({ type: "tool_call", name: fc.name, args: fc.args ?? {} });
                void runToolCall(fc);
              }
            }

            if (msg.serverContent?.turnComplete) {
              sendJson({
                type: "turn_complete",
                user_transcript: currentUserTranscript.trim(),
                assistant_transcript: currentAssistantTranscript.trim(),
              });
              persistVoiceTurn();
            }
          },
          onerror: (err: unknown) => {
            const msg = redactSensitive(err instanceof Error ? err.message : "Gemini Live session error.");
            sendJson({ type: "error", code: "GEMINI_LIVE_ERROR", message: msg });
          },
          onclose: () => {
            if (!isClosing) {
              persistVoiceTurn();
              sendJson({ type: "closed" });
              if (ws.readyState === WebSocket.OPEN) {
                ws.close(1000, "Upstream closed");
              }
            }
          },
        },
      });
    } catch (err) {
      const msg = redactSensitive(err instanceof Error ? err.message : "Failed to connect to Gemini Live API.");
      sendJson({ type: "error", code: "GEMINI_LIVE_CONNECT_FAILED", message: msg });
      ws.close(1011, "Live connect failed");
      clearInterval(heartbeat);
      connections.delete(ws);
      return;
    }

    ws.on("message", (raw) => {
      try {
        const msg = JSON.parse(raw.toString()) as {
          type?: string;
          data?: string;
          text?: string;
          mimeType?: string;
        };
        if (msg.type === "ping") {
          sendJson({ type: "pong", ts: Date.now() });
          return;
        }
        if (msg.type === "audio" && typeof msg.data === "string" && msg.data.length > 0) {
          if (!liveSession) {
            if (pendingAudioFrames.length < 40) pendingAudioFrames.push(msg.data);
            return;
          }
          liveSession.sendRealtimeInput({
            audio: {
              data: msg.data,
              mimeType: msg.mimeType || "audio/pcm;rate=16000",
            },
          });
          return;
        }
        if (msg.type === "audio_end") {
          liveSession?.sendRealtimeInput({ audioStreamEnd: true });
          return;
        }
        if (msg.type === "text" && typeof msg.text === "string" && msg.text.trim()) {
          currentUserTranscript = msg.text.trim();
          turnStartedAt = Date.now();
          liveSession?.sendClientContent({
            turns: [{ role: "user", parts: [{ text: msg.text.trim() }] }],
            turnComplete: true,
          });
          return;
        }
        if (msg.type === "interrupt") {
          // Interrupt current spoken output and reset buffered assistant turn
          sendJson({ type: "interrupted", source: "client" });
          liveSession?.sendRealtimeInput({ activityEnd: {} });
          persistVoiceTurn();
          return;
        }
        if (msg.type === "close") {
          isClosing = true;
          persistVoiceTurn();
          liveSession?.close();
          ws.close(1000, "Client requested close");
        }
      } catch {
        sendJson({ type: "error", code: "BAD_FRAME", message: "Invalid JSON control frame." });
      }
    });

    ws.on("close", () => {
      isClosing = true;
      clearInterval(heartbeat);
      connections.delete(ws);
      persistVoiceTurn();
      try {
        liveSession?.close();
      } catch {
        /* ignore */
      }
      liveSession = null;
    });

    ws.on("error", () => {
      isClosing = true;
      clearInterval(heartbeat);
      connections.delete(ws);
      try {
        liveSession?.close();
      } catch {
        /* ignore */
      }
      liveSession = null;
    });
  });

  return {
    closeAll: () => {
      httpServer.off("upgrade", onUpgrade);
      for (const ws of connections) {
        try {
          ws.close(1001, "Server shutdown");
        } catch {
          /* ignore */
        }
      }
      connections.clear();
      try {
        wss.close();
      } catch {
        /* ignore */
      }
    },
    getActiveConnections: () => connections.size,
  };
}
