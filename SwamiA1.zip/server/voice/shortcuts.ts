import type { VoiceShortcut, VoiceShortcutAction } from "../types";

export const DEFAULT_VOICE_SHORTCUTS: VoiceShortcut[] = [
  {
    id: "vs_summarize_this",
    phrase: "Summarize this",
    action: "summarize_conversation",
    param: "",
    enabled: true,
    match_mode: "prefix",
    created_at: 1700000000,
  },
  {
    id: "vs_new_research",
    phrase: "Start new research project",
    action: "new_research",
    param: "",
    enabled: true,
    match_mode: "prefix",
    created_at: 1700000001,
  },
  {
    id: "vs_new_chat",
    phrase: "Start new chat",
    action: "new_chat",
    param: "",
    enabled: true,
    match_mode: "exact",
    created_at: 1700000002,
  },
  {
    id: "vs_think_mode",
    phrase: "Switch to think mode",
    action: "switch_mode",
    param: "think",
    enabled: true,
    match_mode: "exact",
    created_at: 1700000003,
  },
  {
    id: "vs_read_last_reply",
    phrase: "Read last reply",
    action: "read_last_reply",
    param: "",
    enabled: true,
    match_mode: "exact",
    created_at: 1700000004,
  },
  {
    id: "vs_clear_attachments",
    phrase: "Clear attachments",
    action: "clear_attachments",
    param: "",
    enabled: true,
    match_mode: "exact",
    created_at: 1700000005,
  },
];

export const VALID_SHORTCUT_ACTIONS = new Set<VoiceShortcutAction>([
  "summarize_conversation",
  "new_research",
  "new_chat",
  "switch_mode",
  "open_settings",
  "read_last_reply",
  "clear_attachments",
  "run_prompt",
]);

export function normalizeShortcutPhrase(input: string): string {
  return input
    .toLowerCase()
    .replace(/[\u2018\u2019\u201C\u201D'".,!?;:()\[\]{}।]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export interface MatchedVoiceShortcut {
  shortcut: VoiceShortcut;
  captured_arg: string;
}

export function matchVoiceShortcut(
  transcript: string,
  shortcuts: VoiceShortcut[] | undefined,
): MatchedVoiceShortcut | null {
  const list = Array.isArray(shortcuts) ? shortcuts : [];
  const normInput = normalizeShortcutPhrase(transcript);
  if (!normInput) return null;

  // Prefer longest enabled phrase for deterministic specificity
  const candidates = list
    .filter((s) => s && s.enabled && s.phrase && VALID_SHORTCUT_ACTIONS.has(s.action))
    .map((s) => ({ shortcut: s, normPhrase: normalizeShortcutPhrase(s.phrase) }))
    .filter((item) => item.normPhrase.length > 0)
    .sort((a, b) => b.normPhrase.length - a.normPhrase.length);

  for (const { shortcut, normPhrase } of candidates) {
    if (normInput === normPhrase) {
      return { shortcut, captured_arg: "" };
    }
    const mode = shortcut.match_mode ?? "prefix";
    if (mode === "prefix" && normInput.startsWith(`${normPhrase} `)) {
      const rawTail = normInput.slice(normPhrase.length).trim();
      const cleanTail = rawTail.replace(/^(about|on|for|called|named|regarding)\s+/i, "").trim();
      return { shortcut, captured_arg: cleanTail };
    }
  }
  return null;
}

export function sanitizeVoiceShortcutsList(input: unknown): VoiceShortcut[] {
  if (!Array.isArray(input)) return DEFAULT_VOICE_SHORTCUTS.map((s) => ({ ...s }));
  const seenIds = new Set<string>();
  const out: VoiceShortcut[] = [];
  for (const raw of input.slice(0, 50)) {
    if (!raw || typeof raw !== "object") continue;
    const item = raw as Partial<VoiceShortcut>;
    const phrase = typeof item.phrase === "string" ? item.phrase.replace(/\s+/g, " ").trim().slice(0, 120) : "";
    if (!phrase || !item.action || !VALID_SHORTCUT_ACTIONS.has(item.action)) continue;
    let id = typeof item.id === "string" && item.id.trim() ? item.id.trim().slice(0, 64) : `vs_${out.length + 1}`;
    while (seenIds.has(id)) id = `${id}_1`;
    seenIds.add(id);
    out.push({
      id,
      phrase,
      action: item.action,
      param: typeof item.param === "string" ? item.param.trim().slice(0, 500) : "",
      enabled: item.enabled !== false,
      match_mode: item.match_mode === "exact" ? "exact" : "prefix",
      created_at: typeof item.created_at === "number" && Number.isFinite(item.created_at) ? item.created_at : Date.now() / 1000,
    });
  }
  return out;
}
