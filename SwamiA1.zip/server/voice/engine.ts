import crypto from "node:crypto";
import type { VoiceLanguageOption, VoiceOption } from "../types";

export const GEMINI_LIVE_MODEL = "gemini-3.8-live";
export const GEMINI_LIVE_TRANSCRIBE_MODEL = "gemini-3.5-transcribe-live";
export const GEMINI_STT_MODEL = "gemini-3.5-transcribe";
export const GEMINI_TTS_MODEL = "gemini-3.8-flash-lite-tts";
export const GEMINI_TTS_QUALITY_MODEL = "gemini-3.8-flash-tts";

export const SUPPORTED_VOICE_LANGUAGES: VoiceLanguageOption[] = [
  { code: "en-IN", label: "English (India)", native_label: "English (India)", bcp47: "en-IN" },
  { code: "en-US", label: "English (US)", native_label: "English (US)", bcp47: "en-US" },
  { code: "hi-IN", label: "Hindi", native_label: "हिन्दी (Hindi)", bcp47: "hi-IN" },
  { code: "auto", label: "Auto-detect (English / Hindi)", native_label: "Auto (EN / HI)", bcp47: "en-IN" },
];

export const VOICE_CATALOG: VoiceOption[] = [
  { id: "Zephyr", name: "Zephyr", provider: "gemini", description: "Bright, clear conversational voice (Gemini)" },
  { id: "Kore", name: "Kore", provider: "gemini", description: "Warm, balanced assistant voice (Gemini)" },
  { id: "Puck", name: "Puck", provider: "gemini", description: "Lively, upbeat voice (Gemini)" },
  { id: "Charon", name: "Charon", provider: "gemini", description: "Steady, analytical voice (Gemini)" },
  { id: "Fenrir", name: "Fenrir", provider: "gemini", description: "Calm, deeper voice (Gemini)" },
  { id: "alloy", name: "Alloy", provider: "openai", description: "Neutral OpenAI studio voice" },
  { id: "nova", name: "Nova", provider: "openai", description: "Warm expressive OpenAI voice" },
  { id: "shimmer", name: "Shimmer", provider: "openai", description: "Clear crisp OpenAI voice" },
  { id: "echo", name: "Echo", provider: "openai", description: "Resonant OpenAI voice" },
  { id: "browser-default", name: "System Voice", provider: "browser", description: "Built-in browser SpeechSynthesis fallback" },
];

export const GEMINI_VOICE_IDS = new Set(["Zephyr", "Kore", "Puck", "Charon", "Fenrir"]);
export const OPENAI_VOICE_IDS = new Set(["alloy", "echo", "fable", "onyx", "nova", "shimmer"]);

export function resolveVoiceLanguage(code?: string): VoiceLanguageOption {
  const clean = (code || "").trim();
  return (
    SUPPORTED_VOICE_LANGUAGES.find((l) => l.code.toLowerCase() === clean.toLowerCase()) ??
    SUPPORTED_VOICE_LANGUAGES[0]
  );
}

export function resolveGeminiVoiceName(preferred?: string): string {
  if (preferred && GEMINI_VOICE_IDS.has(preferred)) return preferred;
  return "Zephyr";
}

export function resolveOpenAiVoiceName(preferred?: string): string {
  if (preferred && OPENAI_VOICE_IDS.has(preferred.toLowerCase())) return preferred.toLowerCase();
  return "alloy";
}

export type VoiceIntentKind =
  | "research"
  | "memory_save"
  | "memory_query"
  | "browser"
  | "skill"
  | "document"
  | "chat";

export interface VoiceIntentClassification {
  kind: VoiceIntentKind;
  cleanQuery: string;
  extractedUrl?: string;
  memoryFact?: string;
  shouldUseDeepResearch: boolean;
}

export function classifyVoiceIntent(transcript: string): VoiceIntentClassification {
  const clean = transcript.replace(/\s+/g, " ").trim();
  const lower = clean.toLowerCase();

  const urlMatch = clean.match(/https?:\/\/[^\s"'<>]+/i);
  if (
    urlMatch ||
    /\b(open website|open browser|browse to|navigate to|go to website|visit page)\b/i.test(lower)
  ) {
    return {
      kind: "browser",
      cleanQuery: clean,
      extractedUrl: urlMatch?.[0],
      shouldUseDeepResearch: false,
    };
  }

  const rememberMatch = clean.match(
    /^(?:please\s+)?(?:remember(?:\s+that)?|save\s+(?:this\s+)?to\s+memory(?:\s*:|\s+that)?|keep\s+in\s+mind(?:\s+that)?)\s+(.+)/i,
  );
  if (rememberMatch?.[1]?.trim()) {
    return {
      kind: "memory_save",
      cleanQuery: clean,
      memoryFact: rememberMatch[1].trim(),
      shouldUseDeepResearch: false,
    };
  }

  if (/\b(what do you remember|recall my|search memory|check my memories|yaad hai)\b/i.test(lower)) {
    return {
      kind: "memory_query",
      cleanQuery: clean,
      shouldUseDeepResearch: false,
    };
  }

  if (
    /^(?:deep\s+)?research\b|\b(research online|latest news on|search the web for|web search|find latest sources on|investigate online|ताज़ा जानकारी|खोज करो)\b/i.test(
      lower,
    )
  ) {
    return {
      kind: "research",
      cleanQuery: clean,
      shouldUseDeepResearch: true,
    };
  }

  if (/\b(document|pdf|uploaded file|attached file|notes file|summarize the file)\b/i.test(lower)) {
    return {
      kind: "document",
      cleanQuery: clean,
      shouldUseDeepResearch: false,
    };
  }

  if (/\b(calculate|compute|emi|percentage|todo|checklist|summarize notes|run skill)\b/i.test(lower)) {
    return {
      kind: "skill",
      cleanQuery: clean,
      shouldUseDeepResearch: false,
    };
  }

  return {
    kind: "chat",
    cleanQuery: clean,
    shouldUseDeepResearch: false,
  };
}

/**
 * Strip markdown formatting, code blocks, raw URLs, and citation brackets
 * so TTS engines read clear natural speech instead of symbols.
 */
export function formatTextForSpeech(markdownText: string, maxChars = 1400): string {
  if (!markdownText || !markdownText.trim()) return "";
  let text = markdownText
    // Replace code blocks with short spoken placeholder
    .replace(/```[\s\S]*?```/g, " Code example omitted for voice playback. ")
    // Inline code backticks
    .replace(/`([^`]+)`/g, "$1")
    // Markdown links [label](url) -> label
    .replace(/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g, "$1")
    // Raw URLs
    .replace(/https?:\/\/\S+/g, "")
    // Citation tags [1], [12]
    .replace(/\[\d+\]/g, "")
    // Markdown headings & blockquote markers
    .replace(/^\s{0,3}(?:#{1,6}|>|[-*+])\s+/gm, "")
    // Numbered list prefixes keep number smoothly
    .replace(/^\s*(\d+)\.\s+/gm, "$1. ")
    // Bold / italics / strikethrough
    .replace(/(\*\*|__|\*|_|~~)/g, "")
    // Markdown tables separators
    .replace(/^\s*\|?[:\-\s|]+\|?\s*$/gm, " ")
    .replace(/\|/g, ", ")
    // Collapse whitespace
    .replace(/\s+/g, " ")
    .trim();

  if (text.length > maxChars) {
    const slice = text.slice(0, maxChars);
    const sentenceEnd = Math.max(slice.lastIndexOf(". "), slice.lastIndexOf("। "), slice.lastIndexOf("? "), slice.lastIndexOf("! "));
    text = sentenceEnd > maxChars * 0.45 ? slice.slice(0, sentenceEnd + 1) : `${slice.trim()}...`;
  }
  return text;
}

/** Compute normalized RMS (0..1) from signed 16-bit little-endian PCM bytes. */
export function computePcm16Rms(pcmBuffer: Buffer): number {
  const sampleCount = Math.floor(pcmBuffer.byteLength / 2);
  if (sampleCount <= 0) return 0;
  let sumSquares = 0;
  for (let i = 0; i < sampleCount; i++) {
    const sample = pcmBuffer.readInt16LE(i * 2) / 32768;
    sumSquares += sample * sample;
  }
  return Math.sqrt(sumSquares / sampleCount);
}

/** Threshold mapping from user sensitivity (0.1..1.0) to PCM RMS threshold. */
export function vadSensitivityToRmsThreshold(sensitivity = 0.55): number {
  const clamped = Math.min(1, Math.max(0.1, Number(sensitivity) || 0.55));
  // Higher sensitivity => lower threshold to trigger voice detection
  return Math.round((0.048 - clamped * 0.036) * 10000) / 10000;
}

export function isVadSpeechActive(rms: number, sensitivity = 0.55): boolean {
  return rms >= vadSensitivityToRmsThreshold(sensitivity);
}

/** Wrap raw 16-bit signed LE PCM bytes with a standard 44-byte RIFF WAV header. */
export function pcm16ToWavBuffer(pcmBuffer: Buffer, sampleRate = 24000, channels = 1): Buffer {
  const header = Buffer.alloc(44);
  const byteRate = sampleRate * channels * 2;
  const blockAlign = channels * 2;
  header.write("RIFF", 0);
  header.writeUInt32LE(36 + pcmBuffer.byteLength, 4);
  header.write("WAVE", 8);
  header.write("fmt ", 12);
  header.writeUInt32LE(16, 16); // PCM subchunk size
  header.writeUInt16LE(1, 20); // PCM linear format
  header.writeUInt16LE(channels, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE(byteRate, 28);
  header.writeUInt16LE(blockAlign, 32);
  header.writeUInt16LE(16, 34); // bits per sample
  header.write("data", 36);
  header.writeUInt32LE(pcmBuffer.byteLength, 40);
  return Buffer.concat([header, pcmBuffer]);
}

export interface EphemeralVoiceSession {
  id: string;
  mode: "gemini_live" | "gemini_transcribe_live" | "router_pipeline";
  conversationId: string | null;
  projectId: string | null;
  language: string;
  voiceName: string;
  modelId: string;
  createdAt: number;
  expiresAt: number;
  lastActiveAt: number;
}

export class VoiceSessionManager {
  private sessions = new Map<string, EphemeralVoiceSession>();
  private readonly defaultTtlMs: number;

  constructor(defaultTtlMs = 20 * 60 * 1000) {
    this.defaultTtlMs = defaultTtlMs;
  }

  createSession(params: {
    mode: EphemeralVoiceSession["mode"];
    conversationId?: string | null;
    projectId?: string | null;
    language?: string;
    voiceName?: string;
    modelId?: string;
    ttlMs?: number;
  }): EphemeralVoiceSession {
    this.pruneExpired();
    const now = Date.now();
    const id = `vs_${crypto.randomBytes(16).toString("hex")}`;
    const session: EphemeralVoiceSession = {
      id,
      mode: params.mode,
      conversationId: params.conversationId ?? null,
      projectId: params.projectId ?? null,
      language: resolveVoiceLanguage(params.language).code,
      voiceName: params.voiceName || "Zephyr",
      modelId: params.modelId || GEMINI_LIVE_MODEL,
      createdAt: now,
      expiresAt: now + (params.ttlMs ?? this.defaultTtlMs),
      lastActiveAt: now,
    };
    this.sessions.set(id, session);
    return { ...session };
  }

  getSession(id: string): EphemeralVoiceSession | null {
    this.pruneExpired();
    const s = this.sessions.get(id);
    if (!s) return null;
    if (Date.now() > s.expiresAt) {
      this.sessions.delete(id);
      return null;
    }
    s.lastActiveAt = Date.now();
    return { ...s };
  }

  endSession(id: string): boolean {
    return this.sessions.delete(id);
  }

  activeCount(): number {
    this.pruneExpired();
    return this.sessions.size;
  }

  pruneExpired(): number {
    const now = Date.now();
    let removed = 0;
    for (const [id, s] of this.sessions.entries()) {
      if (now > s.expiresAt) {
        this.sessions.delete(id);
        removed += 1;
      }
    }
    return removed;
  }
}

export const voiceSessionManager = new VoiceSessionManager();
