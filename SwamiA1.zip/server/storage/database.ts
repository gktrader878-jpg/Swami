import fs from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import { decryptSecret, encryptSecret, resolveMasterKey } from "../security/secrets";
import type {
  Attachment,
  Conversation,
  DocumentChunk,
  DocumentRecord,
  Memory,
  MemoryCategory,
  MemorySuggestion,
  MemoryUsed,
  Message,
  Metrics,
  Mode,
  Project,
  ProviderConfig,
  ProviderUsageStat,
  Source,
  Step,
  StoredAttachmentRecord,
} from "../types";

export interface AuditEntry {
  id: number;
  ts: number;
  action: string;
  detail: string;
}

export interface UsageMetricRow {
  id?: number;
  ts: number;
  model_id: string;
  provider: string;
  mode: Mode;
  prompt_tokens: number;
  completion_tokens: number;
  first_token_ms: number;
  total_ms: number;
  status: string;
}

function safeJsonParse<T>(raw: string | null | undefined, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export class SwamiDatabase {
  readonly db: DatabaseSync;
  readonly dataDir: string;
  readonly dbPath: string;
  private readonly masterKey: Buffer;

  constructor(dataDir = process.env.SWAMI_DATA_DIR || "/tmp/swami/data", dbFilename = "swami.db") {
    this.dataDir = dataDir;
    const isMemory = dbFilename === ":memory:";
    if (!isMemory) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    this.dbPath = isMemory ? ":memory:" : path.join(dataDir, dbFilename);
    this.masterKey = resolveMasterKey(dataDir);
    this.db = new DatabaseSync(this.dbPath);

    if (!isMemory) {
      this.db.exec("PRAGMA journal_mode = WAL;");
      this.db.exec("PRAGMA synchronous = NORMAL;");
    }
    this.db.exec("PRAGMA foreign_keys = ON;");
    this.db.exec("PRAGMA busy_timeout = 5000;");

    this.migrate();
  }

  private migrate(): void {
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS schema_migrations (
        version INTEGER PRIMARY KEY,
        applied_at REAL NOT NULL
      );
    `);

    const row = this.db.prepare("SELECT COALESCE(MAX(version), 0) AS v FROM schema_migrations").get() as { v: number };
    const current = Number(row?.v ?? 0);

    if (current < 1) {
      this.db.exec(`
        CREATE TABLE IF NOT EXISTS settings_kv (
          key TEXT PRIMARY KEY,
          value_json TEXT NOT NULL,
          updated_at REAL NOT NULL
        );

        CREATE TABLE IF NOT EXISTS secrets (
          name TEXT PRIMARY KEY,
          ciphertext TEXT NOT NULL,
          updated_at REAL NOT NULL
        );

        CREATE TABLE IF NOT EXISTS projects (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          created_at REAL NOT NULL
        );

        CREATE TABLE IF NOT EXISTS conversations (
          id TEXT PRIMARY KEY,
          title TEXT NOT NULL,
          kind TEXT NOT NULL DEFAULT 'chat',
          project_id TEXT NULL REFERENCES projects(id) ON DELETE SET NULL,
          created_at REAL NOT NULL,
          updated_at REAL NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_conversations_updated ON conversations(updated_at DESC);

        CREATE TABLE IF NOT EXISTS messages (
          id TEXT PRIMARY KEY,
          conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
          seq INTEGER NOT NULL,
          role TEXT NOT NULL,
          content TEXT NOT NULL,
          reasoning TEXT NOT NULL DEFAULT '',
          mode TEXT NOT NULL DEFAULT 'fast',
          steps_json TEXT NOT NULL DEFAULT '[]',
          sources_json TEXT NOT NULL DEFAULT '[]',
          metrics_json TEXT NOT NULL DEFAULT '{}',
          attachments_json TEXT NOT NULL DEFAULT '[]',
          status TEXT NOT NULL DEFAULT 'complete',
          error TEXT NULL,
          created_at REAL NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_messages_conv_seq ON messages(conversation_id, seq);

        CREATE TABLE IF NOT EXISTS memories (
          id TEXT PRIMARY KEY,
          content TEXT NOT NULL,
          enabled INTEGER NOT NULL DEFAULT 1,
          source TEXT NOT NULL DEFAULT 'user',
          created_at REAL NOT NULL,
          updated_at REAL NOT NULL
        );

        CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
          memory_id UNINDEXED,
          content
        );

        CREATE TABLE IF NOT EXISTS documents (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          mime TEXT NOT NULL,
          size INTEGER NOT NULL,
          n_chunks INTEGER NOT NULL,
          n_chars INTEGER NOT NULL,
          conversation_id TEXT NULL REFERENCES conversations(id) ON DELETE CASCADE,
          created_at REAL NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_documents_conv ON documents(conversation_id);

        CREATE TABLE IF NOT EXISTS document_chunks (
          doc_id TEXT NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
          chunk_index INTEGER NOT NULL,
          page INTEGER NOT NULL DEFAULT 0,
          text TEXT NOT NULL,
          PRIMARY KEY (doc_id, chunk_index)
        );

        CREATE VIRTUAL TABLE IF NOT EXISTS document_chunks_fts USING fts5(
          doc_id UNINDEXED,
          chunk_index UNINDEXED,
          text
        );

        CREATE TABLE IF NOT EXISTS audit_logs (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          ts REAL NOT NULL,
          action TEXT NOT NULL,
          detail TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS usage_metrics (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          ts REAL NOT NULL,
          model_id TEXT NOT NULL,
          provider TEXT NOT NULL,
          mode TEXT NOT NULL,
          prompt_tokens INTEGER NOT NULL DEFAULT 0,
          completion_tokens INTEGER NOT NULL DEFAULT 0,
          first_token_ms REAL NOT NULL DEFAULT 0,
          total_ms REAL NOT NULL DEFAULT 0,
          status TEXT NOT NULL DEFAULT 'complete'
        );
      `);
      this.db
        .prepare("INSERT INTO schema_migrations (version, applied_at) VALUES (?, ?)")
        .run(1, Date.now() / 1000);
    }

    if (current < 2) {
      const memCols = (this.db.prepare("PRAGMA table_info(memories)").all() as Array<{ name: string }>).map(
        (c) => c.name,
      );
      if (!memCols.includes("category")) {
        this.db.exec("ALTER TABLE memories ADD COLUMN category TEXT NOT NULL DEFAULT 'general';");
      }
      if (!memCols.includes("project_id")) {
        this.db.exec("ALTER TABLE memories ADD COLUMN project_id TEXT NULL;");
      }
      if (!memCols.includes("conflict_with")) {
        this.db.exec("ALTER TABLE memories ADD COLUMN conflict_with TEXT NULL;");
      }
      this.db.exec("CREATE INDEX IF NOT EXISTS idx_memories_project ON memories(project_id);");

      const msgCols = (this.db.prepare("PRAGMA table_info(messages)").all() as Array<{ name: string }>).map(
        (c) => c.name,
      );
      if (!msgCols.includes("memories_used_json")) {
        this.db.exec("ALTER TABLE messages ADD COLUMN memories_used_json TEXT NOT NULL DEFAULT '[]';");
      }
      if (!msgCols.includes("memory_suggestions_json")) {
        this.db.exec("ALTER TABLE messages ADD COLUMN memory_suggestions_json TEXT NOT NULL DEFAULT '[]';");
      }

      this.db.exec(`
        CREATE TABLE IF NOT EXISTS skill_executions (
          id TEXT PRIMARY KEY,
          skill_id TEXT NOT NULL,
          status TEXT NOT NULL,
          input_summary TEXT NOT NULL,
          output_summary TEXT NOT NULL DEFAULT '',
          error TEXT NULL,
          duration_ms INTEGER NOT NULL DEFAULT 0,
          created_at REAL NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_skill_exec_created ON skill_executions(created_at DESC);
      `);

      this.db
        .prepare("INSERT INTO schema_migrations (version, applied_at) VALUES (?, ?)")
        .run(2, Date.now() / 1000);
    }

    if (current < 3) {
      this.db.exec(`
        CREATE TABLE IF NOT EXISTS provider_configs (
          id TEXT PRIMARY KEY,
          preset_id TEXT NOT NULL,
          name TEXT NOT NULL,
          protocol TEXT NOT NULL,
          base_url TEXT NOT NULL,
          enabled INTEGER NOT NULL DEFAULT 1,
          is_local INTEGER NOT NULL DEFAULT 0,
          default_model TEXT NOT NULL DEFAULT '',
          models_json TEXT NOT NULL DEFAULT '[]',
          health_status TEXT NOT NULL DEFAULT 'unknown',
          health_message TEXT NOT NULL DEFAULT '',
          last_checked_at REAL NULL,
          last_latency_ms REAL NULL,
          created_at REAL NOT NULL,
          updated_at REAL NOT NULL
        );
      `);
      this.db
        .prepare("INSERT INTO schema_migrations (version, applied_at) VALUES (?, ?)")
        .run(3, Date.now() / 1000);
    }

    if (current < 4) {
      this.db.exec(`
        CREATE TABLE IF NOT EXISTS attachments (
          id TEXT PRIMARY KEY,
          kind TEXT NOT NULL,
          name TEXT NOT NULL,
          mime TEXT NOT NULL,
          size INTEGER NOT NULL,
          width INTEGER NULL,
          height INTEGER NULL,
          sha256 TEXT NOT NULL,
          storage_path TEXT NOT NULL,
          conversation_id TEXT NULL REFERENCES conversations(id) ON DELETE CASCADE,
          message_id TEXT NULL,
          doc_id TEXT NULL,
          source_type TEXT NOT NULL DEFAULT 'upload',
          exif_stripped INTEGER NOT NULL DEFAULT 0,
          created_at REAL NOT NULL,
          expires_at REAL NULL
        );
        CREATE INDEX IF NOT EXISTS idx_attachments_conv ON attachments(conversation_id);
        CREATE INDEX IF NOT EXISTS idx_attachments_doc ON attachments(doc_id);
        CREATE INDEX IF NOT EXISTS idx_attachments_expires ON attachments(expires_at);
      `);

      const docCols = (this.db.prepare("PRAGMA table_info(documents)").all() as Array<{ name: string }>).map(
        (c) => c.name,
      );
      if (!docCols.includes("is_scanned")) {
        this.db.exec("ALTER TABLE documents ADD COLUMN is_scanned INTEGER NOT NULL DEFAULT 0;");
      }
      if (!docCols.includes("page_count")) {
        this.db.exec("ALTER TABLE documents ADD COLUMN page_count INTEGER NOT NULL DEFAULT 0;");
      }
      if (!docCols.includes("attachment_id")) {
        this.db.exec("ALTER TABLE documents ADD COLUMN attachment_id TEXT NULL;");
      }

      this.db
        .prepare("INSERT INTO schema_migrations (version, applied_at) VALUES (?, ?)")
        .run(4, Date.now() / 1000);
    }
  }

  getSchemaVersion(): number {
    const row = this.db.prepare("SELECT COALESCE(MAX(version), 0) AS v FROM schema_migrations").get() as { v: number };
    return Number(row?.v ?? 0);
  }

  recoverInterruptedMessages(): number {
    const res = this.db
      .prepare(
        "UPDATE messages SET status = 'stopped', error = COALESCE(error, 'Response interrupted by server restart.') WHERE status = 'streaming'",
      )
      .run();
    return Number(res.changes ?? 0);
  }

  // ---- Settings ----
  loadSettingsMap(): Record<string, unknown> {
    const rows = this.db.prepare("SELECT key, value_json FROM settings_kv").all() as Array<{
      key: string;
      value_json: string;
    }>;
    const out: Record<string, unknown> = {};
    for (const r of rows) {
      out[r.key] = safeJsonParse<unknown>(r.value_json, null);
    }
    return out;
  }

  saveSettingsEntries(entries: Record<string, unknown>): void {
    const now = Date.now() / 1000;
    const stmt = this.db.prepare(
      "INSERT INTO settings_kv (key, value_json, updated_at) VALUES (?, ?, ?) ON CONFLICT(key) DO UPDATE SET value_json = excluded.value_json, updated_at = excluded.updated_at",
    );
    this.db.exec("BEGIN");
    try {
      for (const [k, v] of Object.entries(entries)) {
        stmt.run(k, JSON.stringify(v), now);
      }
      this.db.exec("COMMIT");
    } catch (err) {
      this.db.exec("ROLLBACK");
      throw err;
    }
  }

  clearSettings(): void {
    this.db.prepare("DELETE FROM settings_kv").run();
  }

  // ---- Encrypted Secrets ----
  getSecret(name: string): string {
    const row = this.db.prepare("SELECT ciphertext FROM secrets WHERE name = ?").get(name) as
      | { ciphertext: string }
      | undefined;
    if (!row?.ciphertext) return "";
    return decryptSecret(row.ciphertext, this.masterKey);
  }

  setSecret(name: string, plaintext: string): void {
    const clean = plaintext.trim();
    if (!clean) {
      this.db.prepare("DELETE FROM secrets WHERE name = ?").run(name);
      return;
    }
    const ciphertext = encryptSecret(clean, this.masterKey);
    this.db
      .prepare(
        "INSERT INTO secrets (name, ciphertext, updated_at) VALUES (?, ?, ?) ON CONFLICT(name) DO UPDATE SET ciphertext = excluded.ciphertext, updated_at = excluded.updated_at",
      )
      .run(name, ciphertext, Date.now() / 1000);
  }

  // ---- Projects ----
  loadProjects(): Project[] {
    return this.db.prepare("SELECT id, name, created_at FROM projects ORDER BY created_at ASC").all() as unknown as Project[];
  }

  upsertProject(project: Project): void {
    this.db
      .prepare(
        "INSERT INTO projects (id, name, created_at) VALUES (?, ?, ?) ON CONFLICT(id) DO UPDATE SET name = excluded.name",
      )
      .run(project.id, project.name, project.created_at);
  }

  deleteProject(id: string): void {
    this.db.prepare("UPDATE conversations SET project_id = NULL WHERE project_id = ?").run(id);
    this.db.prepare("DELETE FROM memories_fts WHERE memory_id IN (SELECT id FROM memories WHERE project_id = ?)").run(id);
    this.db.prepare("DELETE FROM memories WHERE project_id = ?").run(id);
    this.db.prepare("DELETE FROM projects WHERE id = ?").run(id);
  }

  // ---- Conversations ----
  loadConversations(): Conversation[] {
    return this.db
      .prepare("SELECT id, title, kind, project_id, created_at, updated_at FROM conversations ORDER BY updated_at DESC")
      .all() as unknown as Conversation[];
  }

  upsertConversation(conv: Conversation): void {
    this.db
      .prepare(
        `INSERT INTO conversations (id, title, kind, project_id, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?)
         ON CONFLICT(id) DO UPDATE SET
           title = excluded.title,
           kind = excluded.kind,
           project_id = excluded.project_id,
           updated_at = excluded.updated_at`,
      )
      .run(conv.id, conv.title, conv.kind, conv.project_id, conv.created_at, conv.updated_at);
  }

  deleteConversation(id: string): string[] {
    const paths = (
      this.db.prepare("SELECT storage_path FROM attachments WHERE conversation_id = ?").all(id) as Array<{
        storage_path: string;
      }>
    ).map((r) => r.storage_path);
    this.db.prepare("DELETE FROM document_chunks_fts WHERE doc_id IN (SELECT id FROM documents WHERE conversation_id = ?)").run(id);
    this.db.prepare("DELETE FROM attachments WHERE conversation_id = ?").run(id);
    this.db.prepare("DELETE FROM conversations WHERE id = ?").run(id);
    return paths;
  }

  deleteAllConversations(): string[] {
    const paths = (
      this.db.prepare("SELECT storage_path FROM attachments").all() as Array<{ storage_path: string }>
    ).map((r) => r.storage_path);
    this.db.exec("BEGIN");
    try {
      this.db.exec("DELETE FROM document_chunks_fts;");
      this.db.exec("DELETE FROM document_chunks;");
      this.db.exec("DELETE FROM documents;");
      this.db.exec("DELETE FROM attachments;");
      this.db.exec("DELETE FROM messages;");
      this.db.exec("DELETE FROM conversations;");
      this.db.exec("COMMIT");
    } catch (err) {
      this.db.exec("ROLLBACK");
      throw err;
    }
    return paths;
  }

  // ---- Messages ----
  loadAllMessages(): Map<string, Message[]> {
    const rows = this.db
      .prepare(
        `SELECT id, conversation_id, role, content, reasoning, mode, steps_json, sources_json, metrics_json, attachments_json, memories_used_json, memory_suggestions_json, status, error, created_at
         FROM messages ORDER BY conversation_id, seq ASC, created_at ASC`,
      )
      .all() as Array<{
      id: string;
      conversation_id: string;
      role: "user" | "assistant";
      content: string;
      reasoning: string;
      mode: Mode;
      steps_json: string;
      sources_json: string;
      metrics_json: string;
      attachments_json: string;
      memories_used_json?: string;
      memory_suggestions_json?: string;
      status: Message["status"];
      error: string | null;
      created_at: number;
    }>;

    const map = new Map<string, Message[]>();
    for (const r of rows) {
      const memoriesUsed = safeJsonParse<MemoryUsed[]>(r.memories_used_json, []);
      const memorySuggestions = safeJsonParse<MemorySuggestion[]>(r.memory_suggestions_json, []);
      const msg: Message = {
        id: r.id,
        conversation_id: r.conversation_id,
        role: r.role,
        content: r.content,
        reasoning: r.reasoning,
        mode: r.mode,
        steps: safeJsonParse<Step[]>(r.steps_json, []),
        sources: safeJsonParse<Source[]>(r.sources_json, []),
        metrics: safeJsonParse<Metrics>(r.metrics_json, {}),
        attachments: safeJsonParse<Attachment[]>(r.attachments_json, []),
        ...(memoriesUsed.length > 0 ? { memories_used: memoriesUsed } : {}),
        ...(memorySuggestions.length > 0 ? { memory_suggestions: memorySuggestions } : {}),
        status: r.status,
        created_at: r.created_at,
        ...(r.error ? { error: r.error } : {}),
      };
      const arr = map.get(msg.conversation_id) ?? [];
      arr.push(msg);
      map.set(msg.conversation_id, arr);
    }
    return map;
  }

  insertMessage(msg: Message, seq: number): void {
    this.db
      .prepare(
        `INSERT INTO messages (id, conversation_id, seq, role, content, reasoning, mode, steps_json, sources_json, metrics_json, attachments_json, memories_used_json, memory_suggestions_json, status, error, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(id) DO UPDATE SET
           content = excluded.content,
           reasoning = excluded.reasoning,
           steps_json = excluded.steps_json,
           sources_json = excluded.sources_json,
           metrics_json = excluded.metrics_json,
           memories_used_json = excluded.memories_used_json,
           memory_suggestions_json = excluded.memory_suggestions_json,
           status = excluded.status,
           error = excluded.error`,
      )
      .run(
        msg.id,
        msg.conversation_id,
        seq,
        msg.role,
        msg.content,
        msg.reasoning,
        msg.mode,
        JSON.stringify(msg.steps ?? []),
        JSON.stringify(msg.sources ?? []),
        JSON.stringify(msg.metrics ?? {}),
        JSON.stringify(msg.attachments ?? []),
        JSON.stringify(msg.memories_used ?? []),
        JSON.stringify(msg.memory_suggestions ?? []),
        msg.status,
        msg.error ?? null,
        msg.created_at,
      );
  }

  replaceConversationMessages(conversationId: string, messages: Message[]): void {
    this.db.exec("BEGIN");
    try {
      this.db.prepare("DELETE FROM messages WHERE conversation_id = ?").run(conversationId);
      messages.forEach((msg, idx) => this.insertMessage(msg, idx));
      this.db.exec("COMMIT");
    } catch (err) {
      this.db.exec("ROLLBACK");
      throw err;
    }
  }

  // ---- Memories ----
  loadMemories(): Memory[] {
    const rows = this.db
      .prepare("SELECT id, content, category, project_id, conflict_with, enabled, source, created_at, updated_at FROM memories ORDER BY created_at ASC")
      .all() as Array<{
      id: string;
      content: string;
      category?: string;
      project_id?: string | null;
      conflict_with?: string | null;
      enabled: number;
      source: string;
      created_at: number;
      updated_at: number;
    }>;
    return rows.map((r) => ({
      id: r.id,
      content: r.content,
      category: (r.category as MemoryCategory) || "general",
      project_id: r.project_id ?? null,
      conflict_with: r.conflict_with ?? null,
      enabled: r.enabled,
      source: r.source,
      created_at: r.created_at,
      updated_at: r.updated_at,
    }));
  }

  upsertMemory(mem: Memory): void {
    this.db.exec("BEGIN");
    try {
      this.db
        .prepare(
          `INSERT INTO memories (id, content, category, project_id, conflict_with, enabled, source, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(id) DO UPDATE SET
             content = excluded.content,
             category = excluded.category,
             project_id = excluded.project_id,
             conflict_with = excluded.conflict_with,
             enabled = excluded.enabled,
             updated_at = excluded.updated_at`,
        )
        .run(
          mem.id,
          mem.content,
          mem.category ?? "general",
          mem.project_id ?? null,
          mem.conflict_with ?? null,
          mem.enabled,
          mem.source,
          mem.created_at,
          mem.updated_at,
        );
      this.db.prepare("DELETE FROM memories_fts WHERE memory_id = ?").run(mem.id);
      this.db.prepare("INSERT INTO memories_fts (memory_id, content) VALUES (?, ?)").run(mem.id, mem.content);
      this.db.exec("COMMIT");
    } catch (err) {
      this.db.exec("ROLLBACK");
      throw err;
    }
  }

  deleteMemory(id: string): void {
    this.db.prepare("DELETE FROM memories_fts WHERE memory_id = ?").run(id);
    this.db.prepare("UPDATE memories SET conflict_with = NULL WHERE conflict_with = ?").run(id);
    this.db.prepare("DELETE FROM memories WHERE id = ?").run(id);
  }

  clearMemories(): void {
    this.db.exec("DELETE FROM memories_fts;");
    this.db.exec("DELETE FROM memories;");
  }

  searchMemoriesFts(query: string, limit = 10, projectId: string | null = null): Memory[] {
    const tokens = (query.match(/[a-zA-Z0-9_]+/g) ?? []).slice(0, 8);
    if (tokens.length === 0) return [];
    const ftsQuery = tokens.map((t) => `"${t}"`).join(" OR ");
    const rows = (
      projectId
        ? this.db
            .prepare(
              `SELECT m.id, m.content, m.category, m.project_id, m.conflict_with, m.enabled, m.source, m.created_at, m.updated_at
               FROM memories_fts f
               JOIN memories m ON m.id = f.memory_id
               WHERE memories_fts MATCH ? AND m.enabled = 1 AND (m.project_id IS NULL OR m.project_id = ?)
               ORDER BY bm25(memories_fts)
               LIMIT ?`,
            )
            .all(ftsQuery, projectId, limit)
        : this.db
            .prepare(
              `SELECT m.id, m.content, m.category, m.project_id, m.conflict_with, m.enabled, m.source, m.created_at, m.updated_at
               FROM memories_fts f
               JOIN memories m ON m.id = f.memory_id
               WHERE memories_fts MATCH ? AND m.enabled = 1 AND m.project_id IS NULL
               ORDER BY bm25(memories_fts)
               LIMIT ?`,
            )
            .all(ftsQuery, limit)
    ) as Array<{
      id: string;
      content: string;
      category?: string;
      project_id?: string | null;
      conflict_with?: string | null;
      enabled: number;
      source: string;
      created_at: number;
      updated_at: number;
    }>;
    return rows.map((r) => ({
      id: r.id,
      content: r.content,
      category: (r.category as MemoryCategory) || "general",
      project_id: r.project_id ?? null,
      conflict_with: r.conflict_with ?? null,
      enabled: r.enabled,
      source: r.source,
      created_at: r.created_at,
      updated_at: r.updated_at,
    }));
  }

  // ---- Skill Executions ----
  insertSkillExecution(row: {
    id: string;
    skill_id: string;
    status: string;
    input_summary: string;
    output_summary: string;
    error: string | null;
    duration_ms: number;
    created_at: number;
  }): void {
    this.db
      .prepare(
        `INSERT INTO skill_executions (id, skill_id, status, input_summary, output_summary, error, duration_ms, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(
        row.id,
        row.skill_id,
        row.status,
        row.input_summary.slice(0, 500),
        row.output_summary.slice(0, 1000),
        row.error ? row.error.slice(0, 500) : null,
        row.duration_ms,
        row.created_at,
      );
  }

  listSkillExecutions(limit = 40): Array<{
    id: string;
    skill_id: string;
    status: string;
    input_summary: string;
    output_summary: string;
    error: string | null;
    duration_ms: number;
    created_at: number;
  }> {
    return this.db
      .prepare(
        "SELECT id, skill_id, status, input_summary, output_summary, error, duration_ms, created_at FROM skill_executions ORDER BY created_at DESC LIMIT ?",
      )
      .all(limit) as Array<{
      id: string;
      skill_id: string;
      status: string;
      input_summary: string;
      output_summary: string;
      error: string | null;
      duration_ms: number;
      created_at: number;
    }>;
  }

  // ---- Documents & Chunks ----
  loadDocuments(): DocumentRecord[] {
    const rows = this.db
      .prepare(
        "SELECT id, name, mime, size, n_chunks, n_chars, conversation_id, created_at, is_scanned, page_count, attachment_id FROM documents ORDER BY created_at ASC",
      )
      .all() as Array<{
      id: string;
      name: string;
      mime: string;
      size: number;
      n_chunks: number;
      n_chars: number;
      conversation_id: string | null;
      created_at: number;
      is_scanned?: number;
      page_count?: number;
      attachment_id?: string | null;
    }>;
    return rows.map((r) => ({
      id: r.id,
      name: r.name,
      mime: r.mime,
      size: r.size,
      n_chunks: r.n_chunks,
      n_chars: r.n_chars,
      conversation_id: r.conversation_id,
      created_at: r.created_at,
      is_scanned: Boolean(r.is_scanned),
      page_count: Number(r.page_count ?? 0),
      attachment_id: r.attachment_id ?? null,
    }));
  }

  loadChunksMap(): Map<string, DocumentChunk[]> {
    const rows = this.db
      .prepare("SELECT doc_id, chunk_index, page, text FROM document_chunks ORDER BY doc_id, chunk_index ASC")
      .all() as unknown as DocumentChunk[];
    const map = new Map<string, DocumentChunk[]>();
    for (const r of rows) {
      const arr = map.get(r.doc_id) ?? [];
      arr.push(r);
      map.set(r.doc_id, arr);
    }
    return map;
  }

  insertDocument(record: DocumentRecord, chunks: DocumentChunk[]): void {
    this.db.exec("BEGIN");
    try {
      this.db
        .prepare(
          `INSERT INTO documents (id, name, mime, size, n_chunks, n_chars, conversation_id, created_at, is_scanned, page_count, attachment_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        )
        .run(
          record.id,
          record.name,
          record.mime,
          record.size,
          record.n_chunks,
          record.n_chars,
          record.conversation_id,
          record.created_at,
          record.is_scanned ? 1 : 0,
          record.page_count ?? 0,
          record.attachment_id ?? null,
        );
      const chunkStmt = this.db.prepare(
        "INSERT INTO document_chunks (doc_id, chunk_index, page, text) VALUES (?, ?, ?, ?)",
      );
      const ftsStmt = this.db.prepare("INSERT INTO document_chunks_fts (doc_id, chunk_index, text) VALUES (?, ?, ?)");
      for (const c of chunks) {
        chunkStmt.run(c.doc_id, c.chunk_index, c.page, c.text);
        ftsStmt.run(c.doc_id, c.chunk_index, c.text);
      }
      this.db.exec("COMMIT");
    } catch (err) {
      this.db.exec("ROLLBACK");
      throw err;
    }
  }

  replaceDocumentChunks(docId: string, chunks: DocumentChunk[], isScanned = false): void {
    const nChars = chunks.reduce((sum, c) => sum + c.text.length, 0);
    this.db.exec("BEGIN");
    try {
      this.db.prepare("DELETE FROM document_chunks_fts WHERE doc_id = ?").run(docId);
      this.db.prepare("DELETE FROM document_chunks WHERE doc_id = ?").run(docId);
      const chunkStmt = this.db.prepare(
        "INSERT INTO document_chunks (doc_id, chunk_index, page, text) VALUES (?, ?, ?, ?)",
      );
      const ftsStmt = this.db.prepare("INSERT INTO document_chunks_fts (doc_id, chunk_index, text) VALUES (?, ?, ?)");
      for (const c of chunks) {
        chunkStmt.run(c.doc_id, c.chunk_index, c.page, c.text);
        ftsStmt.run(c.doc_id, c.chunk_index, c.text);
      }
      this.db
        .prepare("UPDATE documents SET n_chunks = ?, n_chars = ?, is_scanned = ? WHERE id = ?")
        .run(chunks.length, nChars, isScanned ? 1 : 0, docId);
      this.db.exec("COMMIT");
    } catch (err) {
      this.db.exec("ROLLBACK");
      throw err;
    }
  }

  updateDocumentConversation(docId: string, conversationId: string): void {
    this.db.prepare("UPDATE documents SET conversation_id = ? WHERE id = ?").run(conversationId, docId);
    this.db.prepare("UPDATE attachments SET conversation_id = ?, expires_at = NULL WHERE doc_id = ?").run(conversationId, docId);
  }

  deleteDocument(id: string): string[] {
    const paths = (
      this.db.prepare("SELECT storage_path FROM attachments WHERE doc_id = ?").all(id) as Array<{ storage_path: string }>
    ).map((r) => r.storage_path);
    this.db.prepare("DELETE FROM attachments WHERE doc_id = ?").run(id);
    this.db.prepare("DELETE FROM document_chunks_fts WHERE doc_id = ?").run(id);
    this.db.prepare("DELETE FROM documents WHERE id = ?").run(id);
    return paths;
  }

  // ---- Attachments ----
  insertAttachment(att: StoredAttachmentRecord): void {
    this.db
      .prepare(
        `INSERT INTO attachments (id, kind, name, mime, size, width, height, sha256, storage_path, conversation_id, message_id, doc_id, source_type, exif_stripped, created_at, expires_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(
        att.id,
        att.kind,
        att.name,
        att.mime,
        att.size,
        att.width,
        att.height,
        att.sha256,
        att.storage_path,
        att.conversation_id,
        att.message_id,
        att.doc_id,
        att.source_type,
        att.exif_stripped,
        att.created_at,
        att.expires_at,
      );
  }

  getAttachment(id: string): StoredAttachmentRecord | null {
    const row = this.db
      .prepare(
        `SELECT id, kind, name, mime, size, width, height, sha256, storage_path, conversation_id, message_id, doc_id, source_type, exif_stripped, created_at, expires_at
         FROM attachments WHERE id = ?`,
      )
      .get(id) as StoredAttachmentRecord | undefined;
    return row ?? null;
  }

  listAttachmentsByIds(ids: string[]): StoredAttachmentRecord[] {
    const out: StoredAttachmentRecord[] = [];
    for (const id of ids) {
      const found = this.getAttachment(id);
      if (found) out.push(found);
    }
    return out;
  }

  listAttachmentsByConversation(conversationId: string): StoredAttachmentRecord[] {
    return this.db
      .prepare(
        `SELECT id, kind, name, mime, size, width, height, sha256, storage_path, conversation_id, message_id, doc_id, source_type, exif_stripped, created_at, expires_at
         FROM attachments WHERE conversation_id = ? ORDER BY created_at ASC`,
      )
      .all(conversationId) as unknown as StoredAttachmentRecord[];
  }

  bindAttachmentsToConversation(ids: string[], conversationId: string, messageId: string | null = null): void {
    if (ids.length === 0) return;
    const stmt = this.db.prepare(
      "UPDATE attachments SET conversation_id = ?, message_id = COALESCE(?, message_id), expires_at = NULL WHERE id = ?",
    );
    for (const id of ids) {
      stmt.run(conversationId, messageId, id);
    }
  }

  deleteAttachment(id: string): StoredAttachmentRecord | null {
    const existing = this.getAttachment(id);
    if (!existing) return null;
    this.db.prepare("DELETE FROM attachments WHERE id = ?").run(id);
    return existing;
  }

  deleteExpiredAttachments(now = Date.now() / 1000): StoredAttachmentRecord[] {
    const rows = this.db
      .prepare(
        `SELECT id, kind, name, mime, size, width, height, sha256, storage_path, conversation_id, message_id, doc_id, source_type, exif_stripped, created_at, expires_at
         FROM attachments WHERE expires_at IS NOT NULL AND expires_at <= ? AND conversation_id IS NULL`,
      )
      .all(now) as unknown as StoredAttachmentRecord[];
    if (rows.length > 0) {
      this.db
        .prepare("DELETE FROM attachments WHERE expires_at IS NOT NULL AND expires_at <= ? AND conversation_id IS NULL")
        .run(now);
    }
    return rows;
  }

  // ---- Audit & Usage ----
  recordAudit(action: string, detail: string): void {
    this.db
      .prepare("INSERT INTO audit_logs (ts, action, detail) VALUES (?, ?, ?)")
      .run(Date.now() / 1000, action.slice(0, 80), detail.slice(0, 500));
  }

  listAuditLogs(limit = 50): AuditEntry[] {
    return this.db
      .prepare("SELECT id, ts, action, detail FROM audit_logs ORDER BY id DESC LIMIT ?")
      .all(limit) as unknown as AuditEntry[];
  }

  recordUsage(metric: UsageMetricRow): void {
    this.db
      .prepare(
        `INSERT INTO usage_metrics (ts, model_id, provider, mode, prompt_tokens, completion_tokens, first_token_ms, total_ms, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(
        metric.ts,
        metric.model_id,
        metric.provider,
        metric.mode,
        metric.prompt_tokens,
        metric.completion_tokens,
        metric.first_token_ms,
        metric.total_ms,
        metric.status,
      );
  }

  getUsageSummary(windowHours = 24 * 30): ProviderUsageStat[] {
    const cutoff = Date.now() / 1000 - Math.max(1, windowHours) * 3600;
    const rows = this.db
      .prepare(
        `SELECT provider AS provider_id,
                model_id,
                COUNT(*) AS requests,
                SUM(CASE WHEN status = 'complete' THEN 1 ELSE 0 END) AS successes,
                SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) AS errors,
                ROUND(AVG(CASE WHEN first_token_ms > 0 THEN first_token_ms END), 1) AS avg_first_token_ms,
                ROUND(AVG(total_ms), 1) AS avg_total_ms,
                SUM(prompt_tokens) AS total_prompt_tokens,
                SUM(completion_tokens) AS total_completion_tokens
         FROM usage_metrics
         WHERE ts >= ?
         GROUP BY provider, model_id
         ORDER BY requests DESC`,
      )
      .all(cutoff) as Array<{
      provider_id: string;
      model_id: string;
      requests: number;
      successes: number;
      errors: number;
      avg_first_token_ms: number | null;
      avg_total_ms: number | null;
      total_prompt_tokens: number;
      total_completion_tokens: number;
    }>;

    return rows.map((r) => ({
      provider_id: r.provider_id,
      model_id: r.model_id,
      requests: Number(r.requests ?? 0),
      successes: Number(r.successes ?? 0),
      errors: Number(r.errors ?? 0),
      avg_first_token_ms: Number(r.avg_first_token_ms ?? 0),
      avg_total_ms: Number(r.avg_total_ms ?? 0),
      total_prompt_tokens: Number(r.total_prompt_tokens ?? 0),
      total_completion_tokens: Number(r.total_completion_tokens ?? 0),
    }));
  }

  // ---- Provider Configurations ----
  loadProviderConfigs(): Array<Omit<ProviderConfig, "configured" | "key_configured">> {
    const rows = this.db
      .prepare(
        `SELECT id, preset_id, name, protocol, base_url, enabled, is_local, default_model, models_json, health_status, health_message, last_checked_at, last_latency_ms, created_at, updated_at
         FROM provider_configs ORDER BY created_at ASC`,
      )
      .all() as Array<{
      id: string;
      preset_id: string;
      name: string;
      protocol: string;
      base_url: string;
      enabled: number;
      is_local: number;
      default_model: string;
      models_json: string;
      health_status: string;
      health_message: string;
      last_checked_at: number | null;
      last_latency_ms: number | null;
      created_at: number;
      updated_at: number;
    }>;
    return rows.map((r) => ({
      id: r.id,
      preset_id: r.preset_id,
      name: r.name,
      protocol: (r.protocol === "anthropic" || r.protocol === "gemini" ? r.protocol : "openai"),
      base_url: r.base_url,
      enabled: Boolean(r.enabled),
      is_local: Boolean(r.is_local),
      default_model: r.default_model,
      models: safeJsonParse(r.models_json, []),
      health_status: (r.health_status as ProviderConfig["health_status"]) || "unknown",
      health_message: r.health_message || "",
      last_checked_at: r.last_checked_at ?? null,
      last_latency_ms: r.last_latency_ms ?? null,
      created_at: r.created_at,
      updated_at: r.updated_at,
    }));
  }

  upsertProviderConfig(cfg: Omit<ProviderConfig, "configured" | "key_configured">): void {
    this.db
      .prepare(
        `INSERT INTO provider_configs (id, preset_id, name, protocol, base_url, enabled, is_local, default_model, models_json, health_status, health_message, last_checked_at, last_latency_ms, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(id) DO UPDATE SET
           preset_id = excluded.preset_id,
           name = excluded.name,
           protocol = excluded.protocol,
           base_url = excluded.base_url,
           enabled = excluded.enabled,
           is_local = excluded.is_local,
           default_model = excluded.default_model,
           models_json = excluded.models_json,
           health_status = excluded.health_status,
           health_message = excluded.health_message,
           last_checked_at = excluded.last_checked_at,
           last_latency_ms = excluded.last_latency_ms,
           updated_at = excluded.updated_at`,
      )
      .run(
        cfg.id,
        cfg.preset_id,
        cfg.name,
        cfg.protocol,
        cfg.base_url,
        cfg.enabled ? 1 : 0,
        cfg.is_local ? 1 : 0,
        cfg.default_model,
        JSON.stringify(cfg.models ?? []),
        cfg.health_status,
        cfg.health_message,
        cfg.last_checked_at ?? null,
        cfg.last_latency_ms ?? null,
        cfg.created_at,
        cfg.updated_at,
      );
  }

  deleteProviderConfig(id: string): void {
    this.db.prepare("DELETE FROM provider_configs WHERE id = ?").run(id);
  }

  close(): void {
    this.db.close();
  }
}
