import { GoogleGenAI, ThinkingLevel, Type, type Content, type FunctionDeclaration, type GroundingChunk } from "@google/genai";
import { evaluateArithmetic } from "./calculator";
import { newId, store } from "./store";
import type { Mode, MultimodalImageInput, ProviderChatMessage, Source, Step } from "./types";

export const GEMINI_FAST_MODEL_ID = "gemini-3.1-flash-lite";
export const GEMINI_MODEL_ID = "gemini-4-hydrogen";

export function selectGeminiThinkingLevel(modelId: string, mode: Mode): ThinkingLevel {
  if (modelId === GEMINI_FAST_MODEL_ID) {
    return mode === "fast" ? ThinkingLevel.MINIMAL : ThinkingLevel.MEDIUM;
  }
  return mode === "think" ? ThinkingLevel.HIGH : mode === "research" ? ThinkingLevel.MEDIUM : ThinkingLevel.LOW;
}

export function shouldAttachToolsInFastMode(prompt: string): { calculator: boolean; memory: boolean } {
  const q = prompt.toLowerCase();
  const calculator =
    /\d\s*[+\-*/^]\s*\d/.test(q) ||
    /\d\s*%/.test(q) ||
    /\b(calculate|compute|emi|interest|loan|percent|percentage|sum|multiply|divide|square root|sqrt)\b/.test(q);
  const memory = /\b(remember|save to memory|keep in mind|note that)\b/.test(q);
  return { calculator, memory };
}

function getGeminiClient(apiKeyOverride?: string): GoogleGenAI {
  const apiKey = (apiKeyOverride || store.getProviderApiKey("gemini") || process.env.GEMINI_API_KEY || "").trim();
  if (!apiKey) {
    throw new Error(
      "GEMINI_API_KEY is not configured. Add your Gemini API key in Settings → API providers or environment variables.",
    );
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

export function formatGeminiError(err: unknown): string {
  const msg = err instanceof Error ? err.message : String(err);
  const lower = msg.toLowerCase();
  if (lower.includes("api_key_invalid") || lower.includes("permission_denied") || lower.includes("403") || lower.includes("api key not valid")) {
    return "Gemini API rejected the key (API_KEY_INVALID / PERMISSION_DENIED). Please check your GEMINI_API_KEY in the Settings > Secrets panel.";
  }
  if (lower.includes("429") || lower.includes("resource_exhausted")) {
    return "Gemini API rate limit or quota exceeded (429 RESOURCE_EXHAUSTED). Please try again shortly or check your quota in Settings > Secrets.";
  }
  if (lower.includes("404") || lower.includes("not_found")) {
    return `Gemini model '${GEMINI_MODEL_ID}' was not found (404). Please verify model availability.`;
  }
  return msg;
}

export function extractGroundingSources(chunks?: GroundingChunk[]): Source[] {
  if (!chunks || chunks.length === 0) return [];
  const seen = new Set<string>();
  const sources: Source[] = [];
  for (const chunk of chunks) {
    const uri = chunk.web?.uri;
    const title = chunk.web?.title || uri || "Web source";
    if (!uri || seen.has(uri)) continue;
    seen.add(uri);
    let site = "";
    try {
      site = new URL(uri).hostname.replace(/^www\./, "");
    } catch {
      site = "web";
    }
    sources.push({
      n: sources.length + 1,
      kind: "web",
      title,
      url: uri,
      site,
      cited: true,
    });
  }
  return sources;
}

const calculatorDeclaration: FunctionDeclaration = {
  name: "calculator",
  description: "Evaluate an exact mathematical or arithmetic expression (e.g. '850000 * (0.095/12) / (1 - (1 + 0.095/12)**-84)').",
  parameters: {
    type: Type.OBJECT,
    properties: {
      expression: {
        type: Type.STRING,
        description: "Arithmetic expression using numbers, +, -, *, /, **, parentheses, and standard math functions.",
      },
    },
    required: ["expression"],
  },
};

const saveMemoryDeclaration: FunctionDeclaration = {
  name: "save_memory",
  description: "Store one short fact about the user for future conversations. Only call when the user explicitly asks to remember something.",
  parameters: {
    type: Type.OBJECT,
    properties: {
      fact: {
        type: Type.STRING,
        description: "The fact to remember, written concisely.",
      },
      category: {
        type: Type.STRING,
        description: "One of: preference, project, instruction, fact, learning, general.",
      },
    },
    required: ["fact"],
  },
};

export interface GeminiTurnCallbacks {
  onToken: (text: string) => void;
  onReasoning: (text: string) => void;
  onStep: (step: Step) => void;
  onSources: (sources: Source[]) => void;
  elapsedSec: () => number;
}

export async function runGeminiTurn(params: {
  modelId?: string;
  apiKey?: string;
  mode: Mode;
  systemInstruction: string;
  history: ProviderChatMessage[];
  userPrompt: string;
  userImages?: MultimodalImageInput[];
  memoryEnabled: boolean;
  projectId?: string | null;
  signal: AbortSignal;
  callbacks: GeminiTurnCallbacks;
}): Promise<{ content: string; reasoning: string; sources: Source[]; modelCalls: number; toolCalls: number }> {
  const { mode, systemInstruction, history, userPrompt, userImages = [], memoryEnabled, projectId = null, signal, callbacks } = params;
  const activeModel = params.modelId || GEMINI_MODEL_ID;
  const ai = getGeminiClient(params.apiKey);

  const contents: Content[] = [
    ...history.slice(-12).map((m) => ({
      role: m.role === "assistant" ? ("model" as const) : ("user" as const),
      parts: [
        ...(m.images ?? []).map((img) => ({ inlineData: { mimeType: img.mimeType, data: img.base64 } })),
        { text: m.content },
      ],
    })),
    {
      role: "user",
      parts: [
        ...userImages.map((img) => ({ inlineData: { mimeType: img.mimeType, data: img.base64 } })),
        { text: userPrompt },
      ],
    },
  ];

  const thinkingLevel = selectGeminiThinkingLevel(activeModel, mode);
  const isResearch = mode === "research";
  const fastTools = mode === "fast" ? shouldAttachToolsInFastMode(userPrompt) : { calculator: true, memory: true };

  const functionDeclarations: FunctionDeclaration[] = [];
  if (!isResearch) {
    if (fastTools.calculator) functionDeclarations.push(calculatorDeclaration);
    if (memoryEnabled && fastTools.memory) functionDeclarations.push(saveMemoryDeclaration);
  }

  const tools = isResearch
    ? [{ googleSearch: {} }]
    : functionDeclarations.length > 0
      ? [{ functionDeclarations }]
      : undefined;

  let fullContent = "";
  let fullReasoning = "";
  let sources: Source[] = [];
  let modelCalls = 0;
  let toolCalls = 0;

  const modelLabel = activeModel === GEMINI_FAST_MODEL_ID ? "Gemini 3.1 Flash Lite" : "Gemini 4 Hydrogen";
  const execStepId = newId().slice(0, 10);
  callbacks.onStep({
    id: execStepId,
    kind: isResearch ? "search" : mode === "think" ? "execute" : "model",
    title: isResearch ? "Searching & synthesizing with Gemini" : mode === "think" ? `Thinking with ${modelLabel}` : `Generating with ${modelLabel}`,
    detail: "",
    state: "running",
    t: callbacks.elapsedSec(),
  });

  try {
    for (let round = 0; round < 5; round++) {
      if (signal.aborted) {
        throw new DOMException("Aborted", "AbortError");
      }
      modelCalls += 1;

      const stream = await ai.models.generateContentStream({
        model: activeModel,
        contents,
        config: {
          systemInstruction,
          thinkingConfig: {
            thinkingLevel,
            ...(mode === "think" ? { includeThoughts: true } : {}),
          },
          ...(tools ? { tools } : {}),
          abortSignal: signal,
        },
      });

      const pendingFunctionCalls: Array<{ id?: string; name: string; args: Record<string, unknown> }> = [];
      const modelParts: Array<Record<string, unknown>> = [];

      for await (const chunk of stream) {
        if (signal.aborted) {
          throw new DOMException("Aborted", "AbortError");
        }
        const candidate = chunk.candidates?.[0];
        if (candidate?.groundingMetadata?.groundingChunks) {
          const extracted = extractGroundingSources(candidate.groundingMetadata.groundingChunks);
          if (extracted.length > 0) {
            sources = extracted;
            callbacks.onSources(sources);
          }
        }
        const parts = candidate?.content?.parts ?? [];
        for (const part of parts) {
          if (part.functionCall && part.functionCall.name) {
            pendingFunctionCalls.push({
              id: part.functionCall.id,
              name: part.functionCall.name,
              args: (part.functionCall.args as Record<string, unknown>) ?? {},
            });
            modelParts.push(part as unknown as Record<string, unknown>);
          } else if (part.thought && part.text) {
            fullReasoning += part.text;
            callbacks.onReasoning(part.text);
            modelParts.push(part as unknown as Record<string, unknown>);
          } else if (part.text) {
            fullContent += part.text;
            callbacks.onToken(part.text);
            modelParts.push(part as unknown as Record<string, unknown>);
          }
        }
      }

      if (pendingFunctionCalls.length === 0) {
        break;
      }

      // Append model turn and execute requested tools
      contents.push({ role: "model", parts: modelParts as Content["parts"] });
      const responseParts: Content["parts"] = [];

      for (const fc of pendingFunctionCalls) {
        toolCalls += 1;
        const toolStepId = newId().slice(0, 10);
        const label = fc.name === "calculator" ? "Calculator" : fc.name === "save_memory" ? "Saving to memory" : `Using ${fc.name}`;
        callbacks.onStep({
          id: toolStepId,
          kind: "tool",
          title: label,
          detail: JSON.stringify(fc.args),
          state: "running",
          t: callbacks.elapsedSec(),
        });

        let toolResult: Record<string, unknown>;
        let ok = true;
        if (fc.name === "calculator") {
          const expr = String(fc.args.expression ?? "");
          const calc = evaluateArithmetic(expr);
          ok = calc.ok;
          toolResult = calc.ok ? { result: calc.value, formatted: calc.formatted } : { error: calc.error };
        } else if (fc.name === "save_memory") {
          const fact = String(fc.args.fact ?? "").trim();
          const category = typeof fc.args.category === "string" ? fc.args.category : undefined;
          if (!memoryEnabled || !store.settings.memory_enabled) {
            ok = false;
            toolResult = { saved: false, error: "Memory saving is disabled in Settings." };
          } else if (!fact || fact.length > 400) {
            ok = false;
            toolResult = { saved: false, error: "Fact must be 1–400 characters." };
          } else {
            const savedMem = store.addMemory(fact, "assistant", {
              category,
              project_id: category === "project" ? projectId : null,
              skip_duplicate_error: true,
            });
            toolResult = {
              saved: true,
              fact: savedMem.content,
              category: savedMem.category,
              ...(savedMem.conflict ? { conflict_warning: savedMem.conflict.content } : {}),
            };
          }
        } else {
          ok = false;
          toolResult = { error: `Unknown tool: ${fc.name}` };
        }

        callbacks.onStep({
          id: toolStepId,
          kind: "tool",
          title: label,
          detail: JSON.stringify(toolResult),
          state: ok ? "done" : "error",
          t: callbacks.elapsedSec(),
          t_end: callbacks.elapsedSec(),
        });

        responseParts.push({
          functionResponse: {
            id: fc.id,
            name: fc.name,
            response: toolResult,
          },
        });
      }

      contents.push({ role: "user", parts: responseParts });
    }

    callbacks.onStep({
      id: execStepId,
      kind: isResearch ? "search" : mode === "think" ? "execute" : "model",
      title: isResearch ? "Searching & synthesizing with Gemini" : mode === "think" ? `Thinking with ${modelLabel}` : `Generating with ${modelLabel}`,
      detail: sources.length > 0 ? `${sources.length} web source(s)` : toolCalls > 0 ? `${toolCalls} tool call(s)` : "Completed",
      state: "done",
      t: callbacks.elapsedSec(),
      t_end: callbacks.elapsedSec(),
    });

    return { content: fullContent, reasoning: fullReasoning, sources, modelCalls, toolCalls };
  } catch (err) {
    if ((err instanceof DOMException || err instanceof Error) && err.name === "AbortError") {
      callbacks.onStep({
        id: execStepId,
        kind: isResearch ? "search" : mode === "think" ? "execute" : "model",
        title: "Stopped",
        detail: "Cancelled by user",
        state: "stopped",
        t: callbacks.elapsedSec(),
        t_end: callbacks.elapsedSec(),
      });
      throw err;
    }
    const friendly = formatGeminiError(err);
    callbacks.onStep({
      id: execStepId,
      kind: isResearch ? "search" : mode === "think" ? "execute" : "model",
      title: "Gemini request failed",
      detail: friendly,
      state: "error",
      t: callbacks.elapsedSec(),
      t_end: callbacks.elapsedSec(),
    });
    throw new Error(friendly);
  }
}

export async function generateGeminiTitle(userText: string, assistantText: string, apiKeyOverride?: string): Promise<string> {
  try {
    const ai = getGeminiClient(apiKeyOverride);
    const resp = await ai.models.generateContent({
      model: GEMINI_FAST_MODEL_ID,
      contents: `Write a concise 3 to 6 word title for this conversation (no quotes, no trailing punctuation):\n\nUser: ${userText.slice(0, 500)}\nAssistant: ${assistantText.slice(0, 500)}`,
      config: {
        thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL },
        abortSignal: AbortSignal.timeout(10000),
      },
    });
    const raw = resp.text?.trim().replace(/^["']|["']$/g, "").split("\n")[0]?.slice(0, 60) ?? "";
    return raw;
  } catch {
    return "";
  }
}
