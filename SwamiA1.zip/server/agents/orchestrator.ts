import { browserEngine } from "../browser/service";
import { skillRegistry } from "../skills/registry";
import { store, type SwamiStore } from "../store";
import type { Step } from "../types";

export interface SkillChainResult {
  skillsSelected: string[];
  results: Array<{ skillId: string; summary: string; output: Record<string, unknown> }>;
  combinedContext: string;
}

export async function runMatchingSkills(params: {
  prompt: string;
  mode: "fast" | "think" | "research";
  conversationId: string;
  projectId: string | null;
  documentIds: string[];
  activeStore?: SwamiStore;
  signal: AbortSignal;
  onStep?: (step: Step) => void;
}): Promise<SkillChainResult> {
  const activeStore = params.activeStore ?? store;
  const detected = skillRegistry.detectRelevantSkills(params.prompt, {
    hasDocuments: params.documentIds.length > 0,
    mode: params.mode,
  });

  // Explicit single/multi-skill pre-execution for deterministic tools (data, document, productivity, math)
  // while leaving general LLM generation to the main chat stream so streaming latency stays fast.
  const preRunIds = detected.filter((id) => ["document", "data", "productivity"].includes(id));
  const results: Array<{ skillId: string; summary: string; output: Record<string, unknown> }> = [];

  for (const skillId of preRunIds) {
    if (params.signal.aborted) throw new DOMException("Aborted", "AbortError");
    try {
      if (skillId === "document") {
        const res = await skillRegistry.executeSkill(
          "document",
          { question: params.prompt },
          {
            store: activeStore,
            conversationId: params.conversationId,
            documentIds: params.documentIds,
            signal: params.signal,
          },
        );
        results.push({ skillId, summary: res.summary, output: res.output });
      } else if (skillId === "data") {
        // Check if prompt itself contains CSV/JSON or an attached doc is CSV/JSON
        const csvOrJsonDoc = params.documentIds
          .map((id) => activeStore.documents.get(id))
          .find((d) => d && /\.(csv|tsv|json)$/i.test(d.name));
        const rawData = csvOrJsonDoc
          ? (activeStore.chunks.get(csvOrJsonDoc.id) ?? []).map((c) => c.text).join("\n")
          : params.prompt;
        if (csvOrJsonDoc || params.prompt.includes(",") || params.prompt.trim().startsWith("[")) {
          const res = await skillRegistry.executeSkill(
            "data",
            { data: rawData },
            { store: activeStore, conversationId: params.conversationId, signal: params.signal },
          );
          results.push({ skillId, summary: res.summary, output: res.output });
        }
      } else if (skillId === "productivity" && /\b(todo|checklist|action items|prioritize)\b/i.test(params.prompt)) {
        const res = await skillRegistry.executeSkill(
          "productivity",
          { notes: params.prompt },
          { store: activeStore, conversationId: params.conversationId, signal: params.signal },
        );
        results.push({ skillId, summary: res.summary, output: res.output });
      }
    } catch {
      // Non-fatal pre-skill failure: continue chat turn cleanly
    }
  }

  const combinedContext =
    results.length > 0
      ? results.map((r) => `<skill_result id="${r.skillId}" summary="${r.summary}">\n${JSON.stringify(r.output)}\n</skill_result>`).join("\n")
      : "";

  void browserEngine;
  return {
    skillsSelected: detected,
    results,
    combinedContext,
  };
}

export async function runAgentReasoningWithRouter(params: {
  prompt: string;
  systemPrompt?: string;
  activeStore?: SwamiStore;
  signal?: AbortSignal;
}) {
  const { modelRouter } = await import("../models/router");
  return modelRouter.generateText({
    activeStore: params.activeStore ?? store,
    mode: "think",
    taskType: "reasoning",
    systemPrompt:
      params.systemPrompt ??
      "You are SWAMI agent coordinator. Reason carefully and return structured, verifiable steps.",
    userPrompt: params.prompt,
    signal: params.signal,
  });
}

